# 计算点击率，包括触控和语音

import pandas as pd
from datetime import datetime, timedelta


def computer_click_rate(df):
    click_num = df['click'].notna().sum()
    voice_click_num = df['voice_click'].notna().sum()
    return (click_num + voice_click_num) / len(df), click_num, voice_click_num

count = 0
total_click_rate = 0
total_proportion_hand = 0
total_proportion_voice = 0

# start_data 为起始时间（周一）
start_date = datetime.strptime("2025-03-10", '%Y-%m-%d')
end_date = start_date + timedelta(days=6)
start_date_str = start_date.strftime('%Y%m%d')
end_date_str = end_date.strftime('%Y%m%d')
folder_name = f"{start_date_str}-{end_date_str}"

for i in range(0, 6, 1):
    date_time = start_date + timedelta(days=i)
    date_time_str = date_time.strftime('%Y-%m-%d')
    try:
        df = pd.read_csv(f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/media/{folder_name}/{date_time_str}.csv")
        count += 1
        click_rate, click_num, voice_click_num = computer_click_rate(df)
        # print(click_num)
        # print(voice_click_num)
        total_click_rate += click_rate
        
        proportion_hand = click_num / (click_num + voice_click_num)
        # print(proportion_hand)
        total_proportion_hand += proportion_hand

        proportion_voice = voice_click_num / (click_num + voice_click_num)
        # print(proportion_voice)
        # print('\n\n')
        total_proportion_voice += proportion_voice

    except Exception as e:
        print(f"An unexpected error occurred while processing result_202502{i}.csv: {e}")

avg_click_rate = round(total_click_rate / count, 4)
avg_proportion_hand = round(total_proportion_hand / count, 4)
avg_proportion_voice = round(total_proportion_voice / count, 4)
print("点击率:", avg_click_rate)
print("触控点击占比:", avg_proportion_hand)
print("语音点击占比", avg_proportion_voice)