import csv
import json
import random
from tqdm import tqdm
from utils.data_utils.data_trans import csv2jsonl
from utils.file_utils import read_jsonl_file
from utils.llm_utils.serverless_function import request_llm
from search.media_bot.log_analyse.prompt import SYSTEM_PROMPT, USER_PROMPT

random.seed(42)


class CalculateSearchMetrics:

    def __init__(self):
        self.input_csv_path = "/mnt/pfs-guan-ssai/nlu/zhaojiufeng/media_bot_log/new_data/media-bot.csv"
        self.input_jsonl_path = "data/cloud/search/media_bot/log_analyse/calculate_search_metrics/input.jsonl"
        self.output_path = "data/cloud/search/media_bot/log_analyse/calculate_search_metrics/output.tsv"
        self.sample_num = 100
        self.model_name = "gpt-4o"  # gpt-4o | claude-3_5-sonnet | deepseek-v3 | deepseek-r1 | deepseek-r1-distill-qwen-32b

    def process(self):
        # 转换输入文件，并读取输入数据
        csv2jsonl(self.input_csv_path, self.input_jsonl_path)
        input_list = read_jsonl_file(self.input_jsonl_path)
        # 随机采样数据
        sample_list = random.sample(input_list, self.sample_num)
        # 逐条处理数据
        output_list = []
        for sample_one in tqdm(sample_list, total=len(sample_list)):
            # 字段解析与校验
            query = sample_one.get("query", "")
            video_title = json.loads(sample_one.get("content", "{}")).get("videoTitle", "")
            result_list = json.loads(sample_one.get("result_list", "{}"))
            if query == "" or video_title == "" or len(result_list) == 0 or video_title not in query:
                continue
            # 获取title
            title_list = []
            for result_one in result_list:
                title = result_one.get("notice_title", "")
                if title != "":
                    title_list.append(title)
            if len(title_list) == 0:
                continue
            # 判断相关性(只通过query无法分析，结合video_title分析)
            label_str = "NONE"
            history = [
                SYSTEM_PROMPT,
                USER_PROMPT.format(search_data=json.dumps({
                    "query": query, "query_entity": video_title, "recall_result": title_list,
                }, ensure_ascii=False, indent=4))
            ]
            try:
                payload, response_data = request_llm(history, model=self.model_name, n=1, temperature=0)
                print(json.dumps({"payload": payload, "response": response_data}, ensure_ascii=False))
                label_str = response_data["choices"][0]["message"]["content"]
            except Exception as e:
                label_str = "Exception"
                print(e)
            output_list.append({
                "query": query,
                "entity": video_title,
                "title_list": "\n".join(title_list),
                "label": label_str
            })
        # 保存挖掘结果到tsv文件
        fieldnames = output_list[0].keys()
        with open(self.output_path, 'w', encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter="\t")
            writer.writeheader()
            writer.writerows(output_list)


if __name__ == "__main__":
    obj = CalculateSearchMetrics()
    obj.process()

# python -m search.media_bot.log_analyse.calculate_search_metrics
