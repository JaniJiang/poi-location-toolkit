#!/bin/bash

## 从 融合表 和 用户行为表 拿一周的数据
start_date="2025-03-10"
end_date=$(date -d "$start_date + 6 days" '+%Y%m%d')
folder_name="${start_date//-/}-$end_date"
mkdir "/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/media/$folder_name"

for i in {0..6}; do
  dt=$(date -d "$start_date + $i day" '+%Y-%m-%d')
  echo "Processing ${dt}"
    /mnt/pfs-guan-ssai/nlu/zhaojiufeng/adt --token d67cc581ad631e063f1e88cf42400a28 ark2csv --csv-file "/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/media/$folder_name/$dt.csv" --sql-string "
    SELECT merge.domain, merge.domain_li, merge.query, merge.raw_query, merge.slot_li, merge.request_time, merge.knowledge_search_result, merge.media_search_result,
    track.record_id, track.input, track.result_list, track.click, track.voice_click_index, track.voice_click, track.content
    FROM dwd_vechile_merge_prod_di merge
    JOIN (
    SELECT 
        base.record_id,
        a.input,
        JSON_EXTRACT(base.data_json,'$.voice_value.show_list') AS result_list,
        JSON_EXTRACT(b.data_json,'$.voice_value.show_text') AS click,
        JSON_EXTRACT(b.data_json,'$.voice_value.show_position') AS click_index,
        JSON_EXTRACT(c.data_json,'$.voice_value.show_position') AS voice_click_index,
        JSON_EXTRACT(c.data_json,'$.voice_value.show_text') AS voice_click,
        d.content
    FROM (
        SELECT record_id, session_id, data_json, ota_version 
        FROM dwd_vehicle_track_vehvoice_record_di 
        WHERE dt = '$dt' 
        AND event_key = 'vehvoice_002_0073'
        AND veh_series_no LIKE '%X%'
        AND vin IS NOT NULL
        AND busi_time IS NOT NULL
    ) base
    JOIN (
        SELECT record_id, input 
        FROM dwd_vehicle_track_vehvoice_record_di 
        WHERE dt = '$dt'
        AND event_key = 'vehvoice_002_0031'
        AND data_json LIKE '%media/search%'
        AND face_screen != '后排屏'
        AND veh_series_no LIKE '%X%'
        AND vin IS NOT NULL
        AND busi_time IS NOT NULL
    ) a ON base.record_id = a.record_id
    LEFT JOIN (
        SELECT record_id, data_json 
        FROM dwd_vehicle_track_vehvoice_record_di 
        WHERE dt = '$dt'
        AND event_key = 'vehvoice_002_0067'
        AND data_json LIKE '%触控%'
        AND veh_series_no LIKE '%X%'
        AND vin IS NOT NULL
        AND busi_time IS NOT NULL
    ) b ON base.record_id = b.record_id
    LEFT JOIN (
        SELECT session_id, data_json 
        FROM dwd_vehicle_track_vehvoice_record_di 
        WHERE dt = '$dt'
        AND event_key = 'vehvoice_002_0067'
        AND data_json LIKE '%语音%'
        AND veh_series_no LIKE '%X%'
        AND vin IS NOT NULL
        AND busi_time IS NOT NULL
    ) c ON base.session_id = c.session_id
    LEFT JOIN (
        SELECT record_id, content 
        FROM dwd_vehicle_track_vehvoice_record_di 
        WHERE dt = '$dt'
        AND event_key = 'vehvoice_002_0057'
        AND command IN ('media/search','video/search')
        AND veh_series_no LIKE '%X%'
    ) d ON base.record_id = d.record_id
    ) track ON merge.record_id = track.record_id
    WHERE merge.dt = '$dt'
    "
done


# # # 曝光日志
# /mnt/pfs-guan-ssai/nlu/zhaojiufeng/adt --token d67cc581ad631e063f1e88cf42400a28 ark2csv --csv-file "/mnt/pfs-guan-ssai/nlu/zhaojiufeng/media_bot_log/data/0073.csv" --sql-string "
# select *
# from
# (select  *
# from dwd_vehicle_track_vehvoice_record_di 
# where dt = '2025-03-11'
#     and event_key='vehvoice_002_0073'
#     and vin is not null
#     and busi_time is not null
# )base
# join
# (
#     select  *
#     from dwd_vehicle_track_vehvoice_record_di 
#     where dt = '2025-03-11'
#         and event_key='vehvoice_002_0031'
#         and data_json like '%media/search%'
#         and vin is not null
#         and busi_time is not null
# )a 
# on base.record_id=a.record_id
# # "


# ## 点击
# /mnt/pfs-guan-ssai/nlu/zhaojiufeng/adt --token d67cc581ad631e063f1e88cf42400a28 ark2csv --csv-file "/mnt/pfs-guan-ssai/nlu/zhaojiufeng/media_bot_log/data/点击.csv" --sql-string "
# select *
# from
# (select  *
# from dwd_vehicle_track_vehvoice_record_di 
# where dt = '2025-03-11'
#     and event_key='vehvoice_002_0073'
#     and vin is not null
#     and busi_time is not null
# )base
# join
# (
#     select  *
#     from dwd_vehicle_track_vehvoice_record_di 
#     where dt = '2025-03-11'
#         and event_key='vehvoice_002_0031'
#         and data_json like '%media/search%'
#         and vin is not null
#         and busi_time is not null
# )a 
# on base.record_id=a.record_id
# left join
# (
#     select  *
#     from dwd_vehicle_track_vehvoice_record_di 
#     where dt = '2025-03-11'
#         and event_key='vehvoice_002_0067' and  data_json like '%触控%'
#         and vin is not null
#         and busi_time is not null
#         and veh_series_no like '%X%'
# )b
# on base.record_id=b.record_id
# left join
# (
#     select  *
#     from dwd_vehicle_track_vehvoice_record_di 
#     where dt = '2025-03-11'
#         and event_key='vehvoice_002_0067' and  data_json like '%语音%'
#         and vin is not null
#         and busi_time is not null
#         and veh_series_no like '%X%'
# )c
# on base.session_id=c.session_id
# "



   

