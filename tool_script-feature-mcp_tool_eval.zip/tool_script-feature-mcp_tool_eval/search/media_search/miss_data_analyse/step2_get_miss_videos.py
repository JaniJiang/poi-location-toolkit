import os
import pandas as pd
from tqdm import tqdm
from datetime import datetime, timedelta
from typing import List, Optional, Dict
from utils.search_utils.es_client import ElasticSearchClient


class MissVideoData:
    def __init__(self, env: str, index_name: str, refresh_index: bool = False):
        self.index_name = index_name
        self.refresh_index = refresh_index
        cluster_name = "meta_prod" if env == "prod" else "meta_testtwo"
        self.input_path = "/mnt/volumes/ss-spaceai-lx-my/zhaojiufeng/data/data_cloud/search/media_search/video/meta/20251013.csv"
        self.output_path = "/mnt/volumes/ss-spaceai-lx-my/zhaojiufeng/data/data_cloud/search/media_search/video/miss_videos/20251013.csv"
        self.es_client = ElasticSearchClient(cluster_name)
    
    def process(self) -> Optional[List[Dict]]:
        try:
            df = pd.read_csv(self.input_path)
        except Exception as e:
            print(f"[ERROR] Error reading data file: {e}")
            return None
        
        missed_videos = []
        print(f"[INFO] Processing {len(df)} videos...")
        for idx, row in tqdm(df.iterrows(), total=len(df), desc="Searching videos"):
            title = row['title']
            li_video_id = row['li_video_id']
            video_id = row['app_video_id']
            category = row['category_name']
            search_query = {
                "query": {
                    "bool": {
                        "should": [
                            {
                                "nested": {
                                    "path": "where_look",
                                    "query": {
                                        "term": {
                                            "where_look.li_video_id": li_video_id
                                        }
                                    }
                                }
                            },
                            {
                                "nested": {
                                    "path": "where_look",
                                    "query": {
                                        "term": {
                                            "where_look.video_id": video_id
                                        }
                                    }
                                }
                            }
                        ],
                        "minimum_should_match": 1
                    }
                }
            }
            
            try:
                res = self.es_client.search(
                    search_query, self.index_name, need_parse=True
                )
                
                # 检查结果是否为空
                if res is None or len(res) == 0:
                    missed_videos.append({
                        'li_video_id': li_video_id,
                        'video_id': video_id,
                        'title': title,
                        'category': category
                    })
                
            except Exception as e:
                print(f"\n[ERROR] ES search failed for title '{title}': {e}")
        
        print(f"\n[SUMMARY] Total missed videos: {len(missed_videos)}")
        return missed_videos


if __name__ == '__main__':
    env = "prod"
    index_name = "ssai_tv_meta_20251013"
    
    # 创建实例并处理
    processor = MissVideoData(env, index_name)
    result = processor.process()
    
    if result is not None and len(result) > 0:
        df_out = pd.DataFrame(result)
        # 保存到CSV文件
        df_out.to_csv(
            processor.output_path,
            index=False,
            encoding="utf-8-sig",
            sep="\t"
        )
        print(f"[INFO] Missed data saved to {processor.output_path}")
    else:
        print("[INFO] No missed videos found or process failed")
    
    # python -m search.media_search.miss_data_analyse.step2_get_miss_videos