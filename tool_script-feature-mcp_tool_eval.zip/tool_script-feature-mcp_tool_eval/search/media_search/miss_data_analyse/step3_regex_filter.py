import re
import pandas as pd
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor, as_completed
from utils.llm_utils.serverless_function import request_llm

class AnalyseMissVideo:
    def __init__(self, input_path=None):
        self.input_path = "/mnt/volumes/ss-spaceai-lx-my/zhaojiufeng/data/data_cloud/search/media_search/video/miss_videos/migu/20251013_migu_miss_videos.csv"
        self.regex_filter_path = "/mnt/volumes/ss-spaceai-lx-my/zhaojiufeng/data/data_cloud/search/media_search/video/miss_videos/migu/regex_filter_results.csv"
        self.default_keywords = [
            '解说', '说电影', '讲解', '详解', '解读', '解析', '带你看',
            '几分钟看', '分钟看完', '一口气看完', '看完', '看懂',
            '片段', '混剪', '剪辑', '精剪', '重剪', '剪切',
            '合集', '合辑', '集锦', '精选', '盘点', '排行',
            'TOP', '十大', '五大', '百大',
            '专访', '访谈', '访问', 'Interview', '谈话', '对谈',
            '预告', '花絮', '幕后', '删减', '未删减',
            '影评', '点评', '吐槽', '赏析',
            # 补充
            '课程优秀作品', '优秀作品', '精彩看点', 'DIY'
        ]

    def regex_filter(self, title):
        pattern_str = '|'.join(self.default_keywords)
        filter_pattern = re.compile(pattern_str, re.IGNORECASE)
        return bool(filter_pattern.search(str(title)))

    # 新增方法，判断是否是带《》且外面有文字的标题
    def is_modified_movie_title(self, title):
        title = str(title).strip()  
        matches = re.findall(r'《[^》]+》', title)
        if not matches:
            return False  
        left = title
        for m in matches:
            left = left.replace(m, '')
        left = left.strip()
        if left == '':
            return False  # 纯片名
        if re.match(r'^[\s,.，。!！?？;；、…]*$', left):
            return False
        return True

    def write_row(self, filepath, row_dict, columns, header=False):
        df_row = pd.DataFrame([row_dict], columns=columns)
        df_row.to_csv(
            filepath,
            mode='a',
            header=header,
            index=False,
            encoding="utf-8-sig",
            sep='\t'
        )

    def process(self):
        df = pd.read_csv(self.input_path, sep='\t')
        miss_columns = ['li_video_id', 'video_id', 'title', 'category']

        with open(self.regex_filter_path, 'w', encoding="utf-8-sig") as f:
            f.write('\t'.join(miss_columns) + '\n')

        regex_filter_result = []
        for idx, row in tqdm(df.iterrows(), total=len(df), desc="Analyse videos"): 
            li_video_id = row.get('li_video_id', '')
            video_id = row.get('video_id', '')
            title = row.get('title', '')
            category = row.get('category', '')
            if row['category'] not in ['电影', '电视剧', '综艺', '动漫', '儿童', '纪录片']:
                continue
            if self.regex_filter(title):
                continue
            if self.is_modified_movie_title(title):
                continue
            row_dict = {
                'li_video_id': li_video_id,
                'video_id': video_id,
                'title': title,
                'category': category
            }
            regex_filter_result.append(row_dict)
            self.write_row(self.regex_filter_path, row_dict, miss_columns, header=False)
        return regex_filter_result

if __name__ == '__main__':
    analyser = AnalyseMissVideo()
    miss_videos = analyser.process()
    # python -m search.media_search.miss_data_analyse.step3_regex_filter