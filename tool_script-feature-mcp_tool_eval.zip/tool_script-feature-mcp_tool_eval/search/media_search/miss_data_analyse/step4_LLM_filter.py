import re
import pandas as pd
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor, as_completed
from utils.llm_utils.serverless_function import request_llm

class AnalyseMissVideo:
    def __init__(self, input_path=None):
        if input_path is not None:
            self.input_path = input_path
        else:
            self.input_path = "/mnt/volumes/ss-spaceai-lx-my/zhaojiufeng/data/data_cloud/search/media_search/video/miss_videos/migu/regex_filter_results.csv"
        # self.llm_filter_path = "/mnt/volumes/ss-spaceai-lx-my/zhaojiufeng/data/data_cloud/search/media_search/video/miss_videos/llm_filter_results.csv"
        self.llm_filter_path = "/mnt/volumes/ss-spaceai-lx-my/zhaojiufeng/data/data_cloud/search/media_search/video/miss_videos/migu/llm_filter_results.csv"
        self.prompt_template = (
            "请判断下面的标题是否为影视作品（包括电影、电视剧、纪录片或动画片）。\n\n"
            "注意过滤以下类型：\n"
            "- 花絮、幕后、混剪、影评、解说、访谈、宣传片、自媒体或其他衍生内容\n"
            "- 当标题为“xxx精华篇”或“xxx全集”时，也视为影视作品\n\n"
            "标题：{title}\n"
        )
        self.user_pro = (
            "请严格按照以下要求输出：只回复true或false（小写），true表示需要保留的正式影视作品，false表示非正式内容。\n"
            "禁止输出任何说明文字、标点或解释。\n"
        )
    
    def LLM_filter(self, title, model="claude-3_5-sonnet"):
        instruction = self.prompt_template.format(title=title)
        try:
            _, response_data = request_llm([instruction, self.user_pro], model=model)
            res = response_data['choices'][0]['message']['content']
            if res == "true":
                return True
            elif res == "false":
                return False
            else:
                return False
        except Exception as e:
            print(f'Error:{e}')
            return False

    def write_row(self, filepath, row_dict, columns, header=False):
        df_row = pd.DataFrame([row_dict], columns=columns)
        df_row.to_csv(
            filepath,
            mode='a',
            header=header,
            index=False,
            encoding="utf-8-sig",
            sep='\t'
        )

    def process(self):
        df = pd.read_csv(self.input_path, sep='\t')
        miss_columns = ['li_video_id', 'video_id', 'title', 'category']

        with open(self.llm_filter_path, 'w', encoding="utf-8-sig") as f:
            f.write('\t'.join(miss_columns) + '\n')

        llm_filter_result = []
        for idx, row in tqdm(df.iterrows(), total=len(df), desc="Analyse videos"): 
            li_video_id = row.get('li_video_id', '')
            video_id = row.get('video_id', '')
            title = row.get('title', '')
            category = row.get('category', '')
            if self.LLM_filter(title):
                row_dict = {
                    'li_video_id': li_video_id,
                    'video_id': video_id,
                    'title': title,
                    'category': category
                }
                self.write_row(self.llm_filter_path, row_dict, miss_columns, header=False) 
                llm_filter_result.append(row_dict)  
                
        return llm_filter_result

if __name__ == '__main__':
    analyser = AnalyseMissVideo()
    miss_videos = analyser.process()
    # python -m search.media_search.miss_data_analyse.step4_LLM_filter