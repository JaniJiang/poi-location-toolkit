import pandas as pd
from tqdm import tqdm
from datetime import datetime, timedelta
from typing import List, Optional, Dict
from utils.search_utils.es_client import ElasticSearchClient

class MissVideoData:
    def __init__(self, env: str, index_name: str, refresh_index: bool = False):
        self.index_name = index_name
        self.refresh_index = refresh_index
        cluster_name = "meta_prod" if env == "prod" else "meta_testtwo"
        self.output_path = "/mnt/volumes/ss-spaceai-lx-my/zhaojiufeng/data/data_cloud/search/media_search/video/media-bot_test/teachday_upata.tsv"
        self.li_id_txt_path = "/mnt/volumes/ss-spaceai-lx-my/zhaojiufeng/data/data_cloud/search/media_search/video/media-bot_test/teachday_upata_li_ids.txt"
        self.es_client = ElasticSearchClient(cluster_name)
    
    def process(self) -> Optional[List[Dict]]:
        end_date = datetime.now() + timedelta(days=60)
        start_date = datetime.now() - timedelta(days=60)
        start_date_str = start_date.strftime("%Y-%m-%d")
        end_date_str = end_date.strftime("%Y-%m-%d")

        # 主文档publish_time范围查询
        search_query = {
            "query": {
                "bool": {
                    "must": [
                        {
                            "range": {
                                "publish_time": {
                                    "gte": start_date_str,
                                    "lte": end_date_str,
                                    "format": "yyyy-MM-dd"
                                }
                            }
                        }
                    ]
                }
            },
            "size": 3000
        }

        try:
            res = self.es_client.search(
                search_query, self.index_name, need_parse=True
            )
            li_ids = []
            updata_data = []
            for video in res:
                if video['type'] not in ['电影', '电视剧', '综艺']:
                    continue
                if video['title'] in ['养生堂', '第三调解室', '传奇故事', '金牌调解']:
                    continue
                where_look = video.get('where_look', [])  #
                for item in where_look:
                    li_id = item.get('li_video_id') 
                    if li_id:
                        li_ids.append(li_id)
                        updata_data.append({
                            "li_id": li_id,
                            "video_id": item.get('video_id'),
                            "title": video.get('title'),
                            'publish_time': video.get('publish_time')
                        })
            # 写li_ids为txt，每行一个
            with open(self.li_id_txt_path, "w", encoding="utf-8") as f_ids:
                for id in li_ids:
                    f_ids.write(str(id) + "\n")
            if updata_data:
                df = pd.DataFrame(updata_data)
                df.to_csv(self.output_path, index=False, encoding="utf-8-sig", sep='\t')
            return res  # 返回原始结果
        except Exception as e:
            print(f"Error: {e}")
            return None

if __name__ == '__main__':
    env = "prod"
    index_name = "ssai_tv_meta_20251015"
    processor = MissVideoData(env, index_name)
    result = processor.process()
    if result is not None:
        # print(result)
        print(len(result))
    else:
        print("No result or error occurred")

    # python -m search.media_search.miss_data_analyse.media-bot_test
    