import json
import os
from datetime import datetime
from utils.search_utils.es_client import ElasticSearchClient


def data_filter(meta_save_path, test_save_path):
    meta_data = []
    with open(meta_save_path, 'r', encoding='utf-8') as rf:
        for line in rf:
            if line.strip():
                try:
                    meta_data.append(json.loads(line.strip()))
                except json.JSONDecodeError as e:
                    print(f"JSON解码出错: {e}，行内容: {line}")

    # 截止日期为2025年8月31日
    deadline = datetime(2025, 7, 25)
    filtered_data = []
    for item in meta_data:
        try:
            dt = datetime.strptime(item['publish_time'], "%Y-%m-%d")
            if dt <= deadline:
                filtered_data.append(item)
        except Exception as e:
            print(f"跳过无效publish_time: {item.get('publish_time')}, 错误: {e}")

    # 按publish_time排序
    meta_data_sorted = sorted(
        filtered_data,
        key=lambda x: datetime.strptime(x['publish_time'], "%Y-%m-%d"),
        reverse=True
    )
    result = []
    titles = [
        "生活如沸",
        "异修罗",
        "我独自升级",
        "金属口红",
        "我们的国家公园",
        "非正式会谈",
        "乘风破浪的姐姐",
        "大侦探 第七季",
        "声生不息",
        "快乐再出发",
        "再见爱人",
        "快乐大本营",
        "密室大逃脱",
        "爸爸当家",
        "甄嬛传",
        "嘘，国王在冬眠",
        "长安十二时辰",
        "潜伏",
        "人民的名义",
        "平凡的荣耀",
        "这就是街舞",
        "盒子里的猫",
        "这是我的西游记",
        "七根心简",
        "藏海传",
        "掌心"]
    cnt = 1
    title_res = []
    other_res = []
    iqiyi_count = 1000
    tencent_count = 1000
    migu_count = 500
    mango_count = 800
    youku_count = 800
    bilibili_count = 800
    for meta in meta_data_sorted:
        title = meta["title"]
        if title in titles:
            for source in meta["where_look"]:
                title_res.append({
                    "li_id": source["li_video_id"],
                    "video_id": source["video_id"],
                    "title": title,
                    "source": source["source"].split('.')[-1],
                    "rb": title + source["source"].split('.')[-1]
                })
        else:
            sources = meta["where_look"]
            for source in sources:
                if source["source"] == "com.lixiang.crs.plays.youku" and youku_count > 0:
                    other_res.append({
                        "li_id": source["li_video_id"],
                        "video_id": source["video_id"],
                        "title": title,
                        "source": source["source"].split('.')[-1],
                        "rb": title + source["source"].split('.')[-1]
                    })
                    youku_count -= 1
                elif source["source"] == "com.lixiang.crs.plays.mango" and mango_count > 0:
                    other_res.append({
                        "li_id": source["li_video_id"],
                        "video_id": source["video_id"],
                        "title": title,
                        "source": source["source"].split('.')[-1],
                        "rb": title + source["source"].split('.')[-1]
                    })
                    mango_count -= 1
                elif source["source"] == "com.lixiang.crs.plays.bilibili" and bilibili_count > 0:
                    other_res.append({
                        "li_id": source["li_video_id"],
                        "video_id": source["video_id"],
                        "title": title,
                        "source": source["source"].split('.')[-1],
                        "rb": title + source["source"].split('.')[-1]
                    })
                    bilibili_count -= 1
                elif source["source"] == "com.lixiang.crs.plays.tencentvideo" and tencent_count > 0:
                    other_res.append({
                        "li_id": source["li_video_id"],
                        "video_id": source["video_id"],
                        "title": title,
                        "source": source["source"].split('.')[-1],
                        "rb": title + source["source"].split('.')[-1]
                    })
                    tencent_count -= 1
                elif source["source"] == "com.lixiang.crs.plays.iqiyi" and iqiyi_count > 0:
                    other_res.append({
                        "li_id": source["li_video_id"],
                        "video_id": source["video_id"],
                        "title": title,
                        "source": source["source"].split('.')[-1],
                        "rb": title + source["source"].split('.')[-1]
                    })
                    iqiyi_count -= 1
                elif source["source"] == "com.lixiang.crs.plays.miguvideo" and migu_count > 0:
                    other_res.append({
                        "li_id": source["li_video_id"],
                        "video_id": source["video_id"],
                        "title": title,
                        "source": source["source"].split('.')[-1],
                        "rb": title + source["source"].split('.')[-1]
                    })
                    migu_count -= 1

    result = title_res + other_res
    with open(output_path, 'w', encoding='utf-8') as wf:
        for obj in result:
            wf.write(json.dumps(obj, ensure_ascii=False) + '\n')

    print(f"共写入 {len(result)} 条数据到 {output_path}")
    return result


def deduplicate_jsonl(input_path, output_path_prefix,
                      unique_key='rb', batch_size=1000):
    seen = set()
    li_ids = []
    video_ids = []
    with open(input_path, 'r', encoding='utf-8') as rf:
        for line in rf:
            if not line.strip():
                continue
            try:
                data = json.loads(line.strip())
                key = data.get(unique_key)
                li_id = data.get("li_id")
                video_id = data.get("video_id")
                if key is None:
                    continue
                if key not in seen:
                    seen.add(key)
                    if li_id != 0:
                        li_ids.append(str(li_id))
                    if video_id:
                        video_ids.append(f"'{video_id}'")
            except Exception as e:
                print(f"Error: {e}, line: {line}")

    # 分批写入不同文件，每1000个一个文件
    total = len(video_ids)
    batch_num = 0
    for i in range(0, total, batch_size):
        batch = video_ids[i:i + batch_size]
        batch_num += 1
        output_file = f"{output_path_prefix}_{batch_num}.txt"
        with open(output_file, 'w', encoding='utf-8') as wf:
            wf.write(','.join(batch))
        print(f"批次{batch_num}: 写入{len(batch)}个video_id到 {output_file}")

    print(f'总共写入 {total} 个唯一{unique_key} 到 {batch_num} 个文件。')


if __name__ == '__main__':
    env = "meta_testtwo"
    alias_name = "test_env_ssai_tv_meta_20250721"
    meta_save_path = f"data/data_cloud/search/media_search/ssai_tv_meta/{alias_name}.jsonl"
    output_path = f"data/data_cloud/search/media_search/ssai_tv_meta/test_data.jsonl"
    output_path_prefix = 'data/data_cloud/search/media_search/ssai_tv_meta/test_data'
    client = ElasticSearchClient(env)
    # 拉取数据
    client.dump_data(alias_name, meta_save_path)
    data_filter(meta_save_path, output_path)
    deduplicate_jsonl(output_path, output_path_prefix, unique_key='rb')

    # python -m search.media_search.get_test_data
