import requests
import json
import random
import pandas as pd
from tqdm import tqdm
from datetime import datetime
from utils.search_utils.es_client import ElasticSearchClient

addr_mapping = {
    "testtwo": "http://ssai-media-bot-lids-testtwo.ssai-apis-staging.chj.cloud/media/video/search",
    "bj_prod": "http://ssai-media-bot-lids.ssai-apis.chj.cloud/media/video/search"
}


def send_post(env, ip_dict):
    input_template_list = ["我想看*", "播放*的视频"]
    cnt = 0
    results = []
    for title, ip_list in tqdm(ip_dict.items(), desc="POST请求中"):
        input_text = random.choice(input_template_list)
        ip = random.choice(ip_list)
        input_text = input_text.replace('*', ip)
        # 每隔5个发送一次
        if cnt % 5 == 0:
            timestamp = int(datetime.now().timestamp())
            body = {
                "msgId": f"测试{random.randint(1000,9999)}_{cnt}",
                "aiUserId": "测试随便写",
                "extMap": {"videoSearchDebug": "{\"needCMS\":false}"},
                "voicePrintInfo": {"voicePrintAge": "VPA_ADULT"},
                "nlu": [
                    {
                        "dass": [
                            {
                                "input": input_text,
                                "domain": "media",
                                "action": "search",
                                "slots": {
                                    "ip": ip,
                                    "mediaType": "视频"
                                    # "videoTitle": "密室大逃脱"
                                },
                                "source": "RULE",
                                "confidence": 1.5977
                            }
                        ]
                    }
                ],
                "sessionId": "测试随便写",
                "input": {},
                "timestamp": timestamp,
                "dialogStatus": "start",
                "voiceVersion": "7.2.0.0"
            }
            try:
                response = requests.post(
                    addr_mapping[env], json=body, timeout=10)
                response.raise_for_status()
                resp_json = response.json()
                data = resp_json.get("data", {})
                widgets = data.get("widgets", [])
                search_result = []
                search_titles = []
                for widget in widgets:
                    search_title = widget.get("title", "")
                    search_titles.append(search_title)
                    search_desc = widget.get("desc", "")
                    search_result.append({
                        "search_title": search_title,
                        "search_desc": search_desc
                    })
                results.append((title, ip, search_titles))
            except Exception as e:
                print(f"请求出错: {e}")
                results.append((title, ip, []))
        cnt += 1
        if len(results) > 1000:
            break
    return results


def eval(env, ip_dict_path):
    ip_dict = {}
    with open(ip_dict_path, 'r', encoding='utf-8') as rf:
        for line in rf:
            parts = line.strip().split(',')
            # 跳过表头或格式不对
            if len(parts) < 2 or parts[0] == "title":
                continue
            title, ip = parts[0], parts[1]
            ip_dict[title] = ip.split('-')
    data = send_post(env, ip_dict)
    right_num = 0
    all_num = 0
    for item in data:
        title, ip, search_titles = item
        # 判断title是否出现在返回的搜索结果里
        if len(search_titles) > 0:
            all_num += 1
            if title in search_titles:
                right_num += 1
    acc = right_num / all_num if all_num != 0 else 0
    print("准确率：", acc)
    return data


if __name__ == '__main__':
    env = 'testtwo'
    ip_dict_path = "/mnt/volumes/ss-spaceai-lx-my/zhaojiufeng/data/data_cloud/search/media_search/mining/join_ip_slots/title_ip_mapping_v6.csv"
    eval(env, ip_dict_path)
    # python -m search.media_search.mining.eval
