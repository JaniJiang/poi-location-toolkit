from pyspark.sql import SparkSession
from utils.file_utils import check_output_path
from pyspark.sql.functions import explode, col, udf
from pyspark.sql.types import StringType, IntegerType, StructType, StructField, ArrayType
from pyspark.sql.functions import (
    col, explode_outer, size, when, lit, array, array_remove, coalesce
)
from pyspark.sql.functions import col, explode_outer, size, when, lit, coalesce, expr


class JoinIpSlots:
    def __init__(self):
        self.meta_data_path = "/mnt/volumes/ss-spaceai-lx-my/zhaojiufeng/data/data_cloud/search/media_search/ssai_tv_meta/test_env_ssai_tv_meta_20250721.jsonl"
        self.query_slots_path = "/mnt/volumes/ss-spaceai-lx-my/huyangzhao/tool_script/data/cloud_share/search/media_search/mining/join_ip_slots/query_slots_filtered_final_v5.tsv"
        self.output_path = "/mnt/volumes/ss-spaceai-lx-my/zhaojiufeng/data/data_cloud/search/media_search/mining/join_ip_slots/join_ip_slots_v6.tsv"
        check_output_path(self.output_path)

    def process(self):
        spark = SparkSession.builder.appName("FuzzyIPMatch").getOrCreate()

        meta_df = spark.read.json(
            self.meta_data_path).select(
            "id", "ip", "title", "alias", "desc", "type")
        meta_df_filtered = meta_df.filter(
            meta_df["type"].isin("电影", "动漫", "电视剧"))

        ip_df = spark.read.option(
            "header",
            True).option(
            "sep",
            "\t").csv(
            self.query_slots_path)
        ip_df = ip_df.withColumn("pv", col("pv").cast("int"))
        ip_list = [(row['ip'], row['pv'])
                   for row in ip_df.select("ip", "pv").collect()]
        ip_broadcast = spark.sparkContext.broadcast(ip_list)

        def match_ips(title, alias, desc, ip_field):
            results = []
            works = []
            title = str(title) if title is not None else ""
            alias = str(alias) if alias is not None else ""
            desc = str(desc) if desc is not None else ""
            ip_field = str(ip_field) if ip_field is not None else ""
            for ip_val, pv in ip_broadcast.value:
                if ip_val in title:
                    results.append(ip_val)
                    works.append("title")
                elif ip_val in alias:
                    results.append(ip_val)
                    works.append("alias")
                elif ip_val in desc:
                    results.append(ip_val)
                    works.append("desc")
                elif ip_val in ip_field:
                    results.append(ip_val)
                    works.append("ip")
            return results, works

        @udf("array<string>")
        def match_ips_udf(title, alias, desc, ip_field):
            return match_ips(title, alias, desc, ip_field)[0]

        @udf("array<string>")
        def match_works_udf(title, alias, desc, ip_field):
            return match_ips(title, alias, desc, ip_field)[1]

        meta_df_matched = meta_df_filtered \
            .withColumn("match_ip", match_ips_udf(col("title"), col("alias"), col("desc"), col("ip"))) \
            .withColumn("match_work", match_works_udf(col("title"), col("alias"), col("desc"), col("ip")))

        # 只保留有命中记录的那些行
        meta_df_result = meta_df_matched.filter(
            (col("match_ip").isNotNull()) & (size(col("match_ip")) > 0))
        meta_df_result.show(10, truncate=False)
        # 去重 & 保存结果
        meta_df_result = meta_df_result.distinct()
        meta_df_result.toPandas().to_csv(self.output_path, sep="\t", index=False)
        print(f"文件已成功保存至: {self.output_path}")

        return meta_df_result


if __name__ == "__main__":
    jip = JoinIpSlots()
    jip.process()
