import os
import pandas as pd
from tqdm import tqdm
from search.media_search.meta import *
from utils.llm_utils.chat_with_lapi_LLM import *
from utils.llm_utils.serverless_function import request_llm
from utils.file_utils import check_output_path, read_text_file
from concurrent.futures import ThreadPoolExecutor, as_completed


class FilterIpSlots:

    def __init__(self):
        self.input_path = "data/cloud_share/search/media_search/mining/join_ip_slots/query_slots.tsv"
        self.input_black_path = "data/cloud_share/search/media_search/mining/join_ip_slots/query_slots_black.tsv"
        self.output_path_raw = "data/cloud_share/search/media_search/mining/join_ip_slots/query_slots_filtered_raw_v4.tsv"
        self.output_path_openai = "data/cloud_share/search/media_search/mining/join_ip_slots/query_slots_filtered_openai_v4.tsv"
        # check_output_path(self.output_path_row)
        self.black_ip_list = read_text_file(self.input_black_path)
        self.black_ip_dict = {black_ip: True for black_ip in self.black_ip_list}
        self.model = "qwen__qwen3-32b"

    def filter_by_llm(self, ip):
        try:
            res = chat_with_lpai_LLM_signal(ip_system_template.format(
                ip=ip), model=self.model, url=llm_config[self.model], temperature=0.1)
            if "qwen3" in self.model:
                res, _ = parse_json_from_think_res(res)
            else:
                res = json.loads(res)
            answer = res["answer"]
            work = res["work"]
            return answer, work
        except Exception as e:
            print(e)
            return 0, []

    def process_row_lpai(self, row):
        ip = row["ip"]
        pv = row["pv"]
        if len(ip) <= 1 or pv <= 1 or ip in self.black_ip_dict:
            return None
        flag, work = self.filter_by_llm(ip)
        return ip, pv, flag, work

    def process_row_openai(self, idx, data, model="gpt-4o"):
        ip = data["ip"]
        pv = data["pv"]
        flag = data["flag"]

        if flag == 1 or (flag == 0 and pv <= 50):
            return None
        try:
            _, response_data = request_llm([ip_system_template.format(ip=ip), "请严格按上面的JSON格式回复"], model=model)
            res = response_data['choices'][0]['message']['content']
            res = eval(res)
            if res["answer"] == 0:
                return None
            else:
                return idx, 1, res["work"]
        except Exception as e:
            return None

    def process(self):
        if not os.path.exists(self.output_path_raw):
            # qwen优先标注
            query_slots_df = pd.read_csv(self.input_path, sep="\t").fillna("")
            results = []

            with ThreadPoolExecutor(max_workers=128) as executor:
                futures = [executor.submit(self.process_row_lpai, row) for _, row in query_slots_df.iterrows()]
                for future in tqdm(as_completed(futures), total=len(futures)):
                    result = future.result()
                    if result:
                        results.append(result)

            with open(self.output_path_raw, "w") as f:
                f.write("ip\tpv\tflag\twork\n")
                for ip, pv, flag, work in results:
                    f.write(f"{ip}\t{pv}\t{flag}\t{work}\n")
            print(f"文件已成功保存： {self.output_path_raw}")

        # gpt大模型处理剩下标注
        df = pd.read_csv(self.output_path_raw, sep="\t")
        df_len = len(df)
        tasks = []
        with ThreadPoolExecutor(max_workers=5) as executor:
            for idx in range(df_len):
                data = df.iloc[idx]
                tasks.append(executor.submit(self.process_row_openai, idx, data))

            for future in tqdm(as_completed(tasks), total=len(tasks), desc="多线程处理中..."):
                result = future.result()
                if result:
                    idx, new_flag, new_work = result
                    df.at[idx, "flag"] = new_flag
                    df.at[idx, "work"] = new_work

        df.to_csv(self.output_path_openai, sep="\t", index=False)


if __name__ == "__main__":
    obj = FilterIpSlots()
    obj.process()

# python -m search.media_search.mining.step1_filter_ip_slots
