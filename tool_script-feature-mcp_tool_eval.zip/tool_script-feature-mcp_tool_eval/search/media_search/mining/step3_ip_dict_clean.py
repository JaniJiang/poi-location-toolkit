import json
import ast
import pandas as pd
from tqdm import tqdm
from utils.llm_utils.serverless_function import request_llm


def get_llm_response(title, desc, model="gpt-4o"):
    prompt_template = """
    你是一名影视数据分析专家。你现在将接收到一部影视作品的名称以及该影片的详细描述。请你根据你对于影视行业的了解和相关资源，分析并精准地识别出该影片中具有代表性或知名度较高的人物角色，返回该影片的热门角色列表。

    请根据下方示例格式作答：

    影视名称：熊出没
    详细信息：本系列动画片轻松搞笑，讲述了两头熊——熊大、熊二和光头强之间发生的保护森林和盗砍盗伐的搞笑环保大战。
    热门角色：['熊大', '熊二', '光头强']

    下面是待分析的影片信息：

    影视名称：{title}
    详细信息：{desc}
    """

    user_pro = """
    请严格按照以下 JSON 格式回复，禁止使用 Markdown 或其他格式和说明性文字：

    {
        "title": "影视名称",        // 与输入的影视名称完全一致
        "ip": ["角色1", "角色2"]   // 热门角色，请确保为角色中文正式名称，按知名度或重要性排序，使用列表形式返回
    }
    """
    instruction = prompt_template.format(title=title, desc=desc)
    try:
        _, response_data = request_llm([instruction, user_pro], model=model)
        res = response_data['choices'][0]['message']['content']
        res = json.loads(res)
        return res
    except Exception as e:
        print("Error:", e)
        return "error"


def ip_dict_clean(step3_output_file):
    df = pd.read_csv(step3_output_file, sep='\t')
    output_file = "/mnt/volumes/ss-spaceai-lx-my/zhaojiufeng/data/data_cloud/search/media_search/mining/join_ip_slots/step3_output_file_v6.tsv"
    columns = [
        "title",
        "alias",
        "desc",
        "ip",
        "type",
        "match_work",
        "match_ip",
        "desc_ip",
        "res"]
    with open(output_file, 'w', encoding='utf-8') as fout:
        fout.write('\t'.join(columns) + '\n')

    for idx, row in tqdm(
            df.iterrows(), total=df.shape[0], desc="Processing rows"):
        desc_ips = get_llm_response(row['title'], row['desc'])
        if desc_ips != 'error' and isinstance(
                desc_ips, dict) and 'ip' in desc_ips.keys():
            try:
                match_ip_set = set(ast.literal_eval(row['match_ip']))
                desc_ips_set = set(desc_ips['ip'])
                intersection = match_ip_set & desc_ips_set
                if intersection:
                    with open(output_file, 'a', encoding='utf-8') as fout:
                        fout.write(
                            '{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\n'.format(
                                row['title'],
                                row['alias'],
                                row['desc'],
                                row['ip'],
                                row['type'],
                                row['match_work'],
                                row['match_ip'],
                                json.dumps(desc_ips['ip'], ensure_ascii=False),
                                json.dumps(
                                    list(intersection), ensure_ascii=False)
                            )
                        )
            except Exception as inner_e:
                print(
                    f"Processing error at idx={idx} title={row['title']}",
                    inner_e)


if __name__ == '__main__':
    step3_output_file = "/mnt/volumes/ss-spaceai-lx-my/zhaojiufeng/data/data_cloud/search/media_search/mining/join_ip_slots/join_ip_slots_v6.tsv"
    ip_dict_clean(step3_output_file)
    # nohup python -m search.media_search.mining.step3_ip_dict_clean >
    # search/media_search/mining/step3_ip_dict_clean.log 2>&1 &
