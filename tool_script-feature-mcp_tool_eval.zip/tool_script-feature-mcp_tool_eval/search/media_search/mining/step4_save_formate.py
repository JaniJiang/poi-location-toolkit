import json
import ast
import pandas as pd
from tqdm import tqdm


def random_sample(step3_output_file, output_file):
    df = pd.read_csv(step3_output_file, sep='\t')
    sample_df = df.sample(n=200, random_state=42)
    print(f"总行数: {len(df)}")
    print(f"样本行数: {len(sample_df)}")
    print(sample_df.head())
    sample_df.to_csv(output_file, sep='\t', index=False)


def get_title_ip_dict(step3_save_path, output_path):
    mapping = {}
    df = pd.read_csv(step3_save_path, sep='\t')
    for idx, row in tqdm(
            df.iterrows(), total=df.shape[0], desc="Building mapping"):
        title = row['title']
        match_ip = row['res']
        # 判断title和match_ip的有效性
        if pd.notna(title) and title not in mapping and pd.notna(match_ip):
            try:
                val = ast.literal_eval(match_ip)
                if isinstance(val, list):  # 只接受list类型
                    mapping[title] = val
                else:
                    mapping[title] = [val]
            except Exception as e:
                print(
                    f"decode error at idx={idx}, title={title}, value={match_ip}, error={e}")
    # 输出到文件，分隔符为','
    if output_path:
        items = [
            {'title': k, 'match_ip': '-'.join([str(x) for x in v])}
            for k, v in mapping.items() if isinstance(v, list) and v
        ]
        pd.DataFrame(items, columns=['title', 'match_ip']) \
            .to_csv(output_path, sep=',', index=False, encoding='utf-8')
    print(mapping.get("哈小浪一家 第1季"))
    return mapping


if __name__ == '__main__':
    step3_save_path = "/mnt/volumes/ss-spaceai-lx-my/zhaojiufeng/data/data_cloud/search/media_search/mining/join_ip_slots/step3_output_file_v6.tsv"
    output_path = "/mnt/volumes/ss-spaceai-lx-my/zhaojiufeng/data/data_cloud/search/media_search/mining/join_ip_slots/title_ip_mapping_v6.csv"
    get_title_ip_dict(step3_save_path, output_path)
    sample_output_file = "/mnt/volumes/ss-spaceai-lx-my/zhaojiufeng/data/data_cloud/search/media_search/mining/join_ip_slots/step3_output_file_v6_sample.tsv"
    random_sample(step3_save_path, sample_output_file)
