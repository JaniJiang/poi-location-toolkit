import os
import csv
import threading
import pandas as pd
from tqdm import tqdm
from joblib import Parallel, delayed
from utils.file_utils import read_jsonl_file, check_output_path


class JoinIpSlots:

    def __init__(self):
        self.meta_data_path = "data/cloud_share/search/media_search/ssai_tv_meta/ssai_tv_meta_20250706.jsonl"
        self.query_slots_path = "data/cloud_share/search/media_search/mining/join_ip_slots/query_slots_filtered.tsv"
        self.output_path = "data/cloud_share/search/media_search/mining/join_ip_slots/join_ip_slots.tsv"
        check_output_path(self.output_path)
        self.field_name_list = ["ip", "title", "alias", "desc"]
        # 设置并发控制参数
        self.n_jobs = 30  # 并发度
        self.file_lock = threading.Lock()  # 文件锁

    def process(self):
        # 读取槽位数据
        self.query_slots_df = pd.read_csv(self.query_slots_path, sep="\t").fillna("")
        # 读取媒资数据
        meta_data_list = read_jsonl_file(self.meta_data_path)
        # 并发处理
        Parallel(n_jobs=self.n_jobs, prefer="threads")(
            delayed(self.process_item)(meta_data_item)
            for meta_data_item in tqdm(meta_data_list, total=len(meta_data_list), desc="process_item")
        )

    def process_item(self, meta_data_item):
        output_item = {"id": meta_data_item.get("id", "")}
        for field_name in self.field_name_list:
            output_item[field_name] = meta_data_item.get(field_name, "")
        # 计算字段匹配度
        for field_name in self.field_name_list:
            field_value_list = meta_data_item.get(field_name, None)
            if field_value_list is None or len(field_value_list) == 0:
                continue
            if type(field_value_list) is str:
                field_value_list = [field_value_list]
            field_value_list = list(set([val.strip().replace(" ", "")
                                    for val in field_value_list if val.strip() != ""]))
            if len(field_value_list) == 0:
                continue
            match_flag, match_field_value, match_ip, match_pv = self.calculate_field_match(field_name, field_value_list)
            if match_flag is True:
                output_item["field_name"] = field_name
                output_item["field_value"] = match_field_value
                output_item["match_ip"] = match_ip
                output_item["match_pv"] = match_pv
                self.save_result(self.output_path, [output_item])
                return

    def calculate_field_match(self, field_name, field_value_list):
        for _, row in self.query_slots_df.iterrows():
            if field_name == "ip":
                if row["ip"] in field_value_list:
                    return True, row["ip"], row["ip"], row["pv"]
            else:
                for field_value in field_value_list:
                    if row["ip"] in field_value:
                        return True, field_value, row["ip"], row["pv"]
        return False, "", "", 0

    def save_result(self, output_path, result_list):
        with self.file_lock:
            fieldnames = result_list[0].keys()
            file_exists = os.path.isfile(output_path) and os.path.getsize(output_path) > 0
            with open(output_path, "a", encoding="utf-8", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter="\t")
                if not file_exists:
                    writer.writeheader()
                writer.writerows(result_list)


if __name__ == "__main__":
    obj = JoinIpSlots()
    obj.process()

# python -m search.media_search.mining.step2_join_ip_slots
# nohup python -m search.media_search.mining.step2_join_ip_slots > log/search/media_search/mining/step2_join_ip_slots.log 2>&1 &
