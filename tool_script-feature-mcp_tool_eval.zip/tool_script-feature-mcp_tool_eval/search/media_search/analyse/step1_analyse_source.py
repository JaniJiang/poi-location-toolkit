import json
import pandas as pd


class AnalyseSource:

    def __init__(self):
        self.input_path_list = [
            # {
            #     "type": "MEDIASearch_video",
            #     "field": "media_search_result",
            #     "path": "data/cloud_share/search/media_search/analyse/analyse_source/MEDIASearch_video.tsv",
            # },
            # {
            #     "type": "MEDIASearch_music",
            #     "field": "media_search_result",
            #     "path": "data/cloud_share/search/media_search/analyse/analyse_source/MEDIASearch_music.tsv",
            # },
            {
                "type": "QASearch_video",
                "field": "knowledge_search_result",
                "path": "data/cloud_share/search/media_search/analyse/analyse_source/QASearch_video.tsv",
            },
            # {
            #     "type": "QASearch_music",
            #     "field": "knowledge_search_result",
            #     "path": "data/cloud_share/search/media_search/analyse/analyse_source/QASearch_music.tsv",
            # },
        ]

    def process(self):
        for input_item in self.input_path_list:
            input_df = pd.read_csv(input_item["path"], sep="\t").fillna("")
            for _, row in input_df.iterrows():
                try:
                    source_list = []
                    search_result_str = row[input_item["field"]]
                    search_result_list = json.loads(search_result_str)
                    if input_item["field"] == "media_search_result":
                        data_list = search_result_list[0]["data"]
                        for data_one in data_list:
                            source = data_one["extend_data"]["from"]
                            source_list.append(source)
                    else:
                        data_list = search_result_list[0]["data"][0]["bot_data"]
                        for data_one in data_list:
                            source = data_one["source_name"]
                            source_list.append(source)
                    print(source_list)
                except:
                    continue


if __name__ == "__main__":
    obj = AnalyseSource()
    obj.process()

# python -m search.media_search.analyse.step1_analyse_source
