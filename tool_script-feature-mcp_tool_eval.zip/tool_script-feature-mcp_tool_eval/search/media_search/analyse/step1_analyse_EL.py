import os
import re
import traceback
import json
import requests
import pandas as pd
from tqdm import tqdm
from datetime import datetime, timedelta
from search.media_search.meta import *
from concurrent.futures import ThreadPoolExecutor, as_completed


def my_re(text):
    # 先匹配所有《xxx》
    pattern = r'《([^》]+)》'
    all_matches = re.finditer(pattern, text)

    # 过滤掉前后带特定词的
    exclude_prefixes = ['专辑', '收录于', '出自']
    exclude_suffixes = ['专辑']

    results = []
    for match in all_matches:
        start, end = match.span()
        content = match.group(1)

        prefix = text[max(0, start-3):start]
        suffix = text[end:end+2]

        if any(p in prefix for p in exclude_prefixes):
            continue
        if any(s in suffix for s in exclude_suffixes):
            continue

        results.append(content)

    return results


def get_eslink_response(query: str, link_type: str, need_book: bool):
    if need_book:
        query = "《" + query + "》"
    URL = "http://ks-engine-server-inference.ssai-apis-staging.chj.cloud:80/cloud/inner/nlp/kg/knowledge-search-engine/entity-link"
    payload = {"metadata": {}, "query": query, "linkType": link_type}
    resp = requests.post(URL, json=payload, headers={"Content-Type": "application/json"})
    resp.raise_for_status()
    return resp.json()


def process_eslink(source_name_list: list, link_type: str):
    cover_list, cover_list_book = [], []
    for source_title in source_name_list:
        # 无书名号的情况
        res = get_eslink_response(source_title, link_type, need_book=False)
        cover_list.append(1 if "data" in res else 0)
        # 有书名号的情况
        res_book = get_eslink_response(source_title, link_type, need_book=True)
        cover_list_book.append(1 if "data" in res_book else 0)

    return cover_list, cover_list_book, sum(cover_list), sum(cover_list_book)


def process_row(idx, row, link_type, key_value):
    try:
        row_source = json.loads(row[key_value])
        if not row_source:
            return idx, [], 0, [], 0, None, 0, None, 0, None, 0, None, 0
        # full_ouput_name_list = re.findall(r'(?<!专辑[:：]?|收录于|出自)\s*《([^》]+)》(?!专辑)', row["output"])
        full_ouput_name_list = my_re(row["output"])
        full_ouput_name_list = list(dict.fromkeys(full_ouput_name_list))  # 去重
        media_resources_list = row_source[0].get(
            "data", []) if key_value == "media_search_result" else row_source[0].get("data", [])[0].get("bot_data", [])

        media_name_list = [
            source["media_resources"][0]["title"]
            for source in media_resources_list
            if "media_resources" in source
        ]
        drop_ouput_name_list = [x for x in full_ouput_name_list if x not in media_name_list]
        process_eslink_cache = {}

        def get_eslink_cached(name_list):
            key = tuple(name_list)
            if key not in process_eslink_cache:
                process_eslink_cache[key] = process_eslink(name_list, link_type)
            return process_eslink_cache[key]

        full_cover_list, full_cover_list_book, full_num1, full_num2 = get_eslink_cached(full_ouput_name_list)
        frop_cover_list, drop_cover_list_book, drop_num1, dtop_num2 = get_eslink_cached(drop_ouput_name_list)

        return idx,  json.dumps(full_ouput_name_list, ensure_ascii=False, indent=2), len(full_ouput_name_list),  \
            json.dumps(drop_ouput_name_list, ensure_ascii=False, indent=2), len(drop_ouput_name_list), \
            json.dumps(full_cover_list, ensure_ascii=False, indent=2), full_num1, \
            json.dumps(full_cover_list_book, ensure_ascii=False, indent=2),  full_num2, \
            json.dumps(frop_cover_list, ensure_ascii=False, indent=2), drop_num1, \
            json.dumps(drop_cover_list_book, ensure_ascii=False, indent=2), dtop_num2
    except Exception as e:
        # print(f"第 {idx} 行处理出错，跳过。原因：{e}")
        raw_line = locals().get('line', '<无法获取原始行>')
        print('='*60)
        print(f'[ERROR] 第 {idx} 行处理失败，已跳过')
        print(f'原始内容: {raw_line!r}')
        print(f'异常类型: {type(e).__name__}')
        print(f'异常信息: {e}')
        print('--- traceback ---')
        traceback.print_exc()
        print('='*60)
        return idx, [], 0, [], 0, None, 0, None, 0, None, 0, None, 0


def process_data(data_path: str, save_path: str, max_workers=12):
    if data_path.endswith("music.tsv"):
        link_type = "LT_MUSIC"
    elif data_path.endswith("vedio.tsv"):
        link_type = "LT_Movie"
    else:
        raise ValueError("不支持该任务！")
    if "mediasearch" in data_path:
        key = 'media_search_result'
    elif "qasearch" in data_path:
        key = 'knowledge_search_result'
    else:
        raise ValueError("不支持该任务！")

    df = pd.read_csv(data_path, sep="\t", usecols=[0, 1, 2, 3, 4])
    len_df = len(df)
    # 初始化字段
    df["full_name_list"] = [[] for _ in range(len_df)]
    df["full_name_list_num"] = 0
    df["full_EntityLink覆盖详情"] = None
    df["full_EntityLink覆盖数量"] = 0
    df["full_EntityLink覆盖详情-带书名号"] = None
    df["full_EntityLink覆盖数量-带书名号"] = 0

    df["drop_name_list"] = [[] for _ in range(len_df)]
    df["drop_name_list_num"] = 0
    df["drop_EntityLink覆盖详情"] = None
    df["drop_EntityLink覆盖数量"] = 0
    df["drop_EntityLink覆盖详情-带书名号"] = None
    df["drop_EntityLink覆盖数量-带书名号"] = 0

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(process_row, idx, df.iloc[idx], link_type, key) for idx in range(len_df)]

        for future in tqdm(as_completed(futures), total=len_df, desc="Processing"):
            idx, full_ouput_name_list, len_full, drop_ouput_name_list, len_drop, \
                full_cover_list, full_num1, full_cover_list_book,  full_num2, \
                frop_cover_list,  drop_num1, drop_cover_list_book, dtop_num2 = future.result()

            df.at[idx, "full_name_list"] = full_ouput_name_list
            df.at[idx, "full_name_list_num"] = len_full
            df.at[idx, "full_EntityLink覆盖详情"] = full_cover_list
            df.at[idx, "full_EntityLink覆盖数量"] = full_num1
            df.at[idx, "full_EntityLink覆盖详情-带书名号"] = full_cover_list_book
            df.at[idx, "full_EntityLink覆盖数量-带书名号"] = full_num2

            df.at[idx, "drop_name_list"] = drop_ouput_name_list
            df.at[idx, "drop_name_list_num"] = len_drop
            df.at[idx, "drop_EntityLink覆盖详情"] = frop_cover_list
            df.at[idx, "drop_EntityLink覆盖数量"] = drop_num1
            df.at[idx, "drop_EntityLink覆盖详情-带书名号"] = drop_cover_list_book
            df.at[idx, "drop_EntityLink覆盖数量-带书名号"] = dtop_num2

    df.to_csv(save_path, sep="\t", index=False)
    print(f"文件 {save_path} 已成功写入")


if __name__ == "__main__":
    data_path = f"{DATA_ROOT}/analyse/qasearch_vedio.tsv"
    save_path = f"{DATA_ROOT}/analyse/qasearch_vedio_el.tsv"
    process_data(data_path, save_path)
    # _ = ["LT_MUSIC", "LT_Movie"]
    # print("有书名号：", get_eslink_response("你不是真正的快乐是谁的原创", 'LT_MUSIC', True))
    # print("----"*10)
    # print("无书名号：", get_eslink_response("《贝加尔湖畔》sahdsahdjashd", 'LT_MUSIC', False))
    # print("----"*10)
    # print("无书名号：", get_eslink_response("钢铁侠sahdsahdjashd", 'LT_Movie', False))
    # print("----"*10)
    # print("无书名号：", get_eslink_response("《钢铁侠》sahdsahdjashd《驯龙高手3》dadassad《dsadadsadsasa》", 'LT_Movie', False))

    # print("去除异类:", get_eslink_response("《共和国之旗》", 'LT_Movie', False))
    # python -m search.media_search.analyse.step1_analyse_EL
