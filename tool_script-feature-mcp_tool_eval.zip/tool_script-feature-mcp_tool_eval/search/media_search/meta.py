DATA_ROOT = "data/cloud_share/search/media_search"
CODE_ROOT = "search/media_search"
llm_config = {
    "qwen__qwen2_5-72b-instruct": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/qwen--qwen2-5-72b-instruct-7a01-fmdvpd/v1/chat/completions",
    "qwen__qwen3-32b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/qwen--qwen3-32b-461f-erfive/v1/chat/completions",
    "qwen__qwen3-235b-a22b-thinking-2507": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/qwen--qwen3-235b-a22b-thinking-1cfa-tkynjv/v1/chat/completions"
}

# ip_system_template_v1 = """形象IP（形象知识产权）：这种类型的IP通常与一个特定的品牌形象、角色或故事内容相关，广泛用于电影、电视、漫画、游戏、产品等各种娱乐和商业领域。形象IP是品牌和创作者的有价值资产，通常包括以下几个方面：专利、商标、版权、商业秘密.
# # 任务描述
# 请判断:{ip}, 是不是一个IP？
# # 回复要求
# 请你只需要回复以下json格式即可，非markdown格式：
# {{
#     "answer": 1 or 0 # 1代码是IP，0代表不是IP
#     ”work“: "..." # 该IP所属的作品, ""代表不是IP
# }}"""

# ip_system_template_v2 = """形象IP（形象知识产权）：通常与一个特定的品牌形象、角色或故事内容相关，广泛用于电影、电视、漫画、游戏、产品等各种娱乐和商业领域。形象IP是品牌和创作者的有价值资产，通常包括以下几个方面：专利、商标、版权、商业秘密，当然IP也可以是一个知名的人。
# # 任务描述
# 请判断:{ip}是不是一个IP？
# # IP要求
# 1. 请记住判断名字一定要严格和真实IP的名字对应，不能有一点差异。
# 2. 判断的IP不能是一种模糊的东西，一定要有IP对应的名字。
# # 回复要求
# 请你仅仅只需要回复以下json格式即可，非markdown格式：
# {{
#     "answer": 1 or 0 # 1代码是IP，0代表不是IP
#     "work": [...] # 该IP所关联的作品或者人物，[]代表不是IP
# }}
# """

ip_system_template = """形象IP（形象知识产权）：通常与一个特定的品牌形象、角色或故事内容相关，广泛用于电影、电视、漫画、游戏、产品等各种娱乐和商业领域。形象IP是品牌和创作者的有价值资产，通常包括以下几个方面：专利、商标、版权、商业秘密，当然IP也可以是一个知名的人。
# 任务描述
请判断:{ip}是不是一个IP？
# IP要求
1. 请记住判断名字一定要严格和真实IP的名字对应，由于是语音生成的所以会很模糊会出现错别字，所以需要你自行判断，错别字错误的也可算正确。
2. 判断的IP不能是一种模糊的东西，一定要有IP对应的名字。
3. 违反法律或者政治内容，可以视为非IP。
# 回复要求
请你仅仅只需要回复以下json格式即可，非markdown格式：
{{
    "answer": 1 or 0 # 1代码是IP，0代表不是IP
    "work": [...] # 该IP所关联的作品或者人物，[]代表不是IP
}}"""
