#!/bin/bash
# bash search/qa_bot/service_bot_intent/run_pipeline.sh

python -m search.qa_bot.service_bot_intent.step1_train
echo "step1_train done"

python -m search.qa_bot.service_bot_intent.step2_export_onnx
echo "step2_export_onnx done"

python -m search.qa_bot.service_bot_intent.step3_onnx_infer
echo "step3_onnx_infer done"

python -m search.qa_bot.service_bot_intent.step4_predict_sample
echo "step4_predict_sample done"
