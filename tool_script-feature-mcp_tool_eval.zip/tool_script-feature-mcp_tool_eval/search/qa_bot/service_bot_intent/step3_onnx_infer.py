import onnxruntime
import numpy as np
from tqdm import tqdm
from transformers import AutoTokenizer
from search.qa_bot.service_bot_intent.meta_info import MODEL_VERSION


def softmax(logits):
    exp_logits = np.exp(logits - np.max(logits))
    return exp_logits / exp_logits.sum(axis=-1, keepdims=True)


def onnx_inference(base_model_dir, save_onnx_model_path, text_list, max_len=128):
    tokenizer = AutoTokenizer.from_pretrained(base_model_dir)
    session = onnxruntime.InferenceSession(save_onnx_model_path)
    input_name1 = session.get_inputs()[0].name   # "input_ids"
    input_name2 = session.get_inputs()[1].name   # "attention_mask"
    output_name = session.get_outputs()[0].name  # "output"
    all_preds = []
    for text in tqdm(text_list, desc="Inference"):
        try:
            encoding = tokenizer.encode_plus(
                text,
                add_special_tokens=True,
                max_length=max_len,
                truncation=True,
                padding="max_length",
                return_attention_mask=True,
                return_tensors="np",
            )
            input_ids = encoding["input_ids"]
            attention_mask = encoding["attention_mask"]
            # 运行推理
            outputs = session.run([output_name], {
                input_name1: input_ids,
                input_name2: attention_mask
            })
            logits = outputs[0]
            probs = softmax(logits)
            pred_label = np.argmax(probs, axis=1).item()
            pred_prob = probs[0][pred_label].item()
            all_preds.append((text, pred_label, pred_prob, probs))
        except:
            all_preds.append((text, "NONE", "NONE", "NONE"))
    return all_preds


if __name__ == "__main__":
    save_onnx_model_path = f"{MODEL_OUTPUT}/{MODEL_VERSION}/bert_model.onnx"

    input_list = [
        ["su七ultra零到三百公里需要多久", 0],
        ["更改锁车音在哪里操作", 1],
        ["副驾的按摩有没有打开", 1],
    ]
    text_list = [item[0] for item in input_list]

    predictions = onnx_inference(BASE_MODEL_DIR, save_onnx_model_path, text_list)
    for idx, (text, pred_label, pred_prob, probs) in enumerate(predictions):
        print(f"idx：{idx}")
        print(f"文本：{text}")
        print(f"真实标签：{input_list[idx][1]}")
        print(f"预测标签：{pred_label}")
        print(f"预测概率：{pred_prob}")
        print(f"概率分布：{probs}")
        print("-" * 30)

# python -m search.qa_bot.service_bot_intent.step3_onnx_infer
