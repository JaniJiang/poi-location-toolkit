import os
import torch
import pandas as pd
from tqdm import tqdm
from typing import Dict
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_score, recall_score, f1_score, classification_report
from transformers import BertTokenizer, BertForSequenceClassification
import torch
from search.qa_bot.service_bot_intent.meta_info import *

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")


class TextDataset(Dataset):
    """自定义数据集类"""

    def __init__(self, texts: pd.Series, labels: pd.Series, tokenizer: BertTokenizer, max_len: int):
        self.texts = texts.reset_index(drop=True)
        self.labels = labels.reset_index(drop=True)
        self.tokenizer = tokenizer
        self.max_len = max_len

    def __len__(self) -> int:
        return len(self.texts)

    def __getitem__(self, idx: int) -> Dict[str, torch.Tensor]:
        text = str(self.texts[idx])
        label = int(self.labels[idx])
        encoding = self.tokenizer.encode_plus(
            text,
            add_special_tokens=True,      # 添加特殊token [CLS] 和 [SEP]
            max_length=self.max_len,      # 截断或填充的最大长度
            truncation=True,              # 截断长于max_len的文本
            padding="max_length",         # 填充短于max_len的文本
            return_token_type_ids=False,
            return_attention_mask=True,
            return_tensors="pt",          # 返回PyTorch tensors
        )
        return {
            "input_ids": encoding["input_ids"].flatten(),
            "attention_mask": encoding["attention_mask"].flatten(),
            "labels": torch.tensor(label, dtype=torch.long)
        }


def create_data_loader(df: pd.DataFrame, tokenizer: BertTokenizer, max_len: int, batch_size: int) -> DataLoader:
    """创建数据加载器"""
    dataset = TextDataset(texts=df["text"], labels=df["new_label"], tokenizer=tokenizer, max_len=max_len)
    return DataLoader(dataset, batch_size=batch_size, shuffle=True, num_workers=2)


def train_epoch(model: BertForSequenceClassification, data_loader: DataLoader, optimizer, device: torch.device):
    """训练函数"""
    model.train()
    total_correct = 0
    total_loss = 0
    true_labels = []
    pred_labels = []
    for batch in tqdm(data_loader, desc="Training"):
        optimizer.zero_grad()
        input_ids = batch["input_ids"].to(device)
        attention_mask = batch["attention_mask"].to(device)
        labels = batch["labels"].to(device)
        outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
        loss = outputs.loss
        logits = outputs.logits
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
        preds = torch.argmax(logits, dim=1)
        total_correct += torch.sum(preds == labels).item()
        true_labels.extend(labels.cpu().numpy())
        pred_labels.extend(preds.cpu().numpy())
    avg_loss = total_loss / len(data_loader)
    avg_acc = total_correct / len(data_loader.dataset)
    metrics_report = calculate_metrics(true_labels, pred_labels,)
    return avg_loss, avg_acc, metrics_report


def eval_model(model: BertForSequenceClassification, data_loader: DataLoader, device: torch.device):
    """验证函数"""
    model.eval()
    total_correct = 0
    total_loss = 0
    true_labels = []
    pred_labels = []
    with torch.no_grad():
        for batch in tqdm(data_loader, desc="Evaluating"):
            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)
            labels = batch["labels"].to(device)
            outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
            loss = outputs.loss
            logits = outputs.logits
            total_loss += loss.item()
            preds = torch.argmax(logits, dim=1)
            total_correct += torch.sum(preds == labels).item()
            true_labels.extend(labels.cpu().numpy())
            pred_labels.extend(preds.cpu().numpy())
    avg_loss = total_loss / len(data_loader)
    avg_acc = total_correct / len(data_loader.dataset)
    metrics_report = calculate_metrics(true_labels, pred_labels)
    return avg_loss, avg_acc, metrics_report


def calculate_metrics(true_labels, pred_labels, average_list=["macro", "weighted", "micro"]):
    metrics_report = []
    # 整体指标
    for average in average_list:
        avg_precision = precision_score(true_labels, pred_labels, average=average, zero_division=0)
        avg_recall = recall_score(true_labels, pred_labels, average=average, zero_division=0)
        avg_f1 = f1_score(true_labels, pred_labels, average=average, zero_division=0)
        metrics_report.append(f"{average}: Precision {avg_precision:.4f}, Recall {avg_recall:.4f}, F1 {avg_f1:.4f}")
    # 每个标签的指标
    classification_metrics = classification_report(true_labels, pred_labels, output_dict=True, zero_division=0)
    for label, values in classification_metrics.items():
        if label.isdigit():  # 只处理类别标签
            precision = values["precision"]
            recall = values["recall"]
            f1 = values["f1-score"]
            support = values["support"]
            metrics_report.append(
                f"Class {label}: Precision {precision:.4f}, Recall {recall:.4f}, F1 {f1:.4f}, Support {support}")
    return "\n".join(metrics_report)


def main(base_model_dir, sample_path, save_model_path):
    """主函数"""
    # 加载数据，划分训练集和验证集
    df = pd.read_csv(sample_path, encoding="utf-8")
    if "sample_type" in df.columns:
        train_df = df[df["sample_type"] == "train"].copy()
        val_df = df[df["sample_type"] == "val"].copy()
        print("按照sample_type列划分数据集")
    else:
        train_df, val_df = train_test_split(df, test_size=0.02, random_state=42)
        print("使用train_test_split划分数据集")
    # 创建数据加载器
    MAX_LEN = 128
    BATCH_SIZE = 16
    tokenizer = BertTokenizer.from_pretrained(base_model_dir)
    train_loader = create_data_loader(train_df, tokenizer, MAX_LEN, BATCH_SIZE)
    val_loader = create_data_loader(val_df, tokenizer, MAX_LEN, BATCH_SIZE)
    # 加载预训练的BERT模型
    model = BertForSequenceClassification.from_pretrained(base_model_dir, num_labels=2)
    model = model.to(device)
    # 定义优化器
    optimizer = torch.optim.AdamW(model.parameters(), lr=2e-5)
    # 训练模型
    EPOCHS = 8
    best_accuracy = 0
    for epoch in range(EPOCHS):
        print(f"\nEpoch {epoch + 1}/{EPOCHS}\n" + "-" * 10)
        # 训练一个epoch
        train_loss, train_acc, train_metrics_report = train_epoch(
            model, train_loader, optimizer, device)
        print(f"Train loss: {train_loss:.4f}, Acc: {train_acc:.4f}\n" + "-" * 10)
        print("Train classification report:")
        print(train_metrics_report)
        # 验证模型效果
        val_loss, val_acc, val_metrics_report = eval_model(model, val_loader, device)
        print(f"Valid loss: {val_loss:.4f}, Acc: {val_acc:.4f}")
        print("Valid classification report:")
        print(val_metrics_report)
        # 保存表现最好的模型
        if val_acc > best_accuracy:
            torch.save(model.state_dict(), save_model_path)
            best_accuracy = val_acc
            print("Best model saved.")


if __name__ == "__main__":
    sample_path = f"{SAMPLE_DIR}/{SAMPLE_VERSION}.csv"
    save_model_path = f"{MODEL_OUTPUT}/{MODEL_VERSION}/best_model_state_copy.bin"
    os.makedirs(os.path.dirname(save_model_path), exist_ok=True)
    main(BASE_MODEL_DIR, sample_path, save_model_path)

# python -m search.qa_bot.service_bot_intent.step1_train
