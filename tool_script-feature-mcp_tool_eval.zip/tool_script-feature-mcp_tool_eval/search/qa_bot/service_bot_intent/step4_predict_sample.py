import os
import pandas as pd
from sklearn.model_selection import train_test_split
from search.qa_bot.service_bot_intent.step3_onnx_infer import onnx_inference
from search.qa_bot.service_bot_intent.meta_info import MODEL_VERSION

if __name__ == "__main__":
    save_onnx_model_path = f"{MODEL_OUTPUT}/{MODEL_VERSION}/bert_model.onnx"
    sample_path = f"{EVAL_DIR}/source/{EVAL_VERSION}.csv"
    predict_path = f"{EVAL_DIR}/result/{EVAL_VERSION}.csv"
    os.makedirs(os.path.dirname(predict_path), exist_ok=True)

    # 读取样本数据
    df = pd.read_csv(sample_path, encoding="utf-8")
    data_list = []
    if "sample_type" in df.columns:
        data_list = df.to_dict("records")
        print("按照sample_type列划分数据集")
    else:
        train_df, val_df = train_test_split(df, test_size=0.02, random_state=42)
        train_df["sample_type"] = "train"
        val_df["sample_type"] = "val"
        combined_df = pd.concat([train_df, val_df])
        data_list = combined_df.to_dict("records")
        print("使用train_test_split划分数据集")

    # 预测样本
    text_list = [item["text"] for item in data_list]
    predictions = onnx_inference(BASE_MODEL_DIR, save_onnx_model_path, text_list)
    with open(predict_path, "w") as f:
        for idx, (text, pred_label, pred_prob, probs) in enumerate(predictions):
            item = data_list[idx]
            true_label = item["new_label"]
            sample_type = item["sample_type"]
            is_accuracy = int(true_label == pred_label)
            f.write(f"{text},{true_label},{pred_label},{is_accuracy},{pred_prob},{probs},{sample_type}\n")

# python -m search.qa_bot.service_bot_intent.step4_predict_sample
