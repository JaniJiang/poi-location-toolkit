import random
from tqdm import tqdm
from utils.file_utils import read_jsonl_file, check_output_path
from search.qa_bot.service_bot_intent.meta_info import MODEL_VERSION


class trans_llm_sample:

    def __init__(self):
        self.date_list = ["20250328", "20250329", "20250330", "20250331", "20250402"]
        self.input_dir = "data/cloud/search/qa_bot/qa_data_analyse_wzy"
        self.output_path = f"data/cloud/search/qa_bot/service_bot_intent/data/{MODEL_VERSION}.tsv"
        check_output_path(self.output_path)
        # 随机参数
        self.my_random = random.Random()
        self.my_random.seed(42)

    def process(self):
        # 读取数据并转换label
        output_list = []
        for date in tqdm(self.date_list):
            input_path = f"{self.input_dir}/{date}/step2_question_intent.jsonl"
            input_list = read_jsonl_file(input_path)
            for item in input_list:
                try:
                    query = item["query"]
                    label_str = item["if_serviceBot"]["一级分类"]
                    if query == "" or label_str == "":
                        continue
                    label_id = "1" if label_str == "服务专家" else "0"
                    output_list.append("\t".join([query, label_id]))
                except:
                    pass
        # 数据量分析
        print("origin sample num:", len(output_list))
        output_list = list(set(output_list))
        print("unique sample num:", len(output_list))
        # 随机数据
        self.my_random.shuffle(output_list)
        # 保存处理结果
        with open(self.output_path, "w") as f:
            f.write("\n".join(output_list)+"\n")


if __name__ == "__main__":
    obj = trans_llm_sample()
    obj.process()

# python -m search.qa_bot.service_bot_intent.sample.trans_llm_sample
