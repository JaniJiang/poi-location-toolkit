# 基座模型
BASE_MODEL_DIR = "data/cloud_share/qabot_miner/bert_model/model/base_model/bert-base-chinese"

# 数据集
SAMPLE_DIR = "data/cloud_share/qabot_miner/intent_data/train"
SAMPLE_VERSION = "v3_20250424"

# 模型输出
MODEL_OUTPUT = "data/cloud_share/qabot_miner/bert_model/model"
MODEL_VERSION = "v3_20250424"  # v1_20250411,v3_20250424

# eval
EVAL_DIR = "data/cloud_share/qabot_miner/intent_data/eval"
EVAL_VERSION = "v3_20250424"
