# 服务专家工具代码集成

本文件夹下包含了
- 服务专家数据挖掘工具
- 相关性模型训练、测试的相关代码

具体文件夹功能见下方目录结构

## 目录结构

- **`service_bot_analyse`**：指标分析工具，用于定期产出线上指标
- **`service_bot_miner`**：数据挖掘工具，用于生产数据；工具会继承service_bot_analyse中的类，对更大范围的全量日志进行数据挖掘
- **`service_bot_relevance`**：相关性模型
- **`service_bot_intent`**：意图识别模型