from search.qa_bot.service_bot_analyse.steps.step4_knowledge_extract import KnowledgeExtract
from search.qa_bot.service_bot_analyse.steps.step5_knowledge_index import KnowledgeIndex
from search.qa_bot.service_bot_miner.meta import *


class KnowledgeExtractAndIndex:
    def __init__(self):
        self.knowledge_extract = KnowledgeExtract()
        self.knowledge_index = KnowledgeIndex()

    def process(self):
        self.knowledge_extract.input_path_list = [
            {
                # 服务专家数据data.json先从QA配置管理平台下载: https://voice-platform.ssai.lixiangoa.com/qa/library,并存储至DATA_DIR下
                "path": DATA_MINER_FILE_PATHS["STEP7"]["input"],
                "type": "file",
                "from": "qa",
                "enable": True
            }
        ]
        self.knowledge_extract.output_path = MINE_BASE_DATA_DIR / "step4_knowledge_extract"

        self.knowledge_index.input_path_list = [
            {
                "path": MINE_BASE_DATA_DIR / "step4_knowledge_extract.qa.jsonl",
                "from": "qa",
                "enable": True,
                "need_dedup": False,
            }
        ]
        self.knowledge_index.output_path = DATA_MINER_FILE_PATHS["STEP7"]["output"]
        # 提取知识
        self.knowledge_extract.process()
        # 构建知识索引
        self.knowledge_index.process()


if __name__ == "__main__":
    knowledge_extract_and_index = KnowledgeExtractAndIndex()
    knowledge_extract_and_index.process()
