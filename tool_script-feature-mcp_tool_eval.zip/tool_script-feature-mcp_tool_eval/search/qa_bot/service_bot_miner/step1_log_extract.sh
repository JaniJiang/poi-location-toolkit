#!/bin/bash
# 查询圈选脚本：从指定日期范围内提取服务专家和汽车RAG的Query数据用于分析

# --- 配置参数 ---
# 目标结束日期（格式：YYYY-MM-DD）
export DATA_DATE="2025-06-11" 
# 需要获取的连续天数（含结束日期当天）
export DAYS_TO_FETCH=30       
# 输出文件存储的基础路径
export BASE_OUTPUT_PATH="data/cloud_share/qabot_miner/wuzhenyan/mine_data_05_12_06_11"

# --- 计算起始日期 ---
# 通过结束日期倒推开始日期（结束日期 - (天数-1)天）
export START_DATE=$(date -d "$DATA_DATE - $(($DAYS_TO_FETCH - 1)) days" +"%Y-%m-%d")
if [ $? -ne 0 ]; then
  echo "日期计算失败。请确认系统支持GNU date命令的-d选项"
  exit 1
fi
echo "将获取从 $START_DATE 到 $DATA_DATE 的 $DAYS_TO_FETCH 天数据"

# --- 定义SQL查询语句 ---
# 查询内容包含query、slot_li、output、knowledge_search_result字段
# 条件1：日期范围在开始日期和结束日期之间
# 条件2：domain为gpt_autoqa
SQL_STRING_AS="SELECT DISTINCT query, slot_li, output, knowledge_search_result \
FROM dwd_vechile_merge_prod_di \
WHERE (dt BETWEEN '$START_DATE' AND '$DATA_DATE') \
  AND domain = 'gpt_autoqa' \
AND vehicle_category = '1' \
AND ota_version > '5' \
AND query is not null and query != ''"

# --- 定义输出文件 ---
# CSV文件命名规则：autosearch_data_起始日期_to_结束日期.csv
CSV_FILE_AS="${BASE_OUTPUT_PATH}/autosearch_data_${START_DATE}_to_${DATA_DATE}.csv"
# 创建目标目录（如果不存在）
mkdir -p "$(dirname "$CSV_FILE_AS")"

# --- 执行查询并导出数据 ---
echo "开始执行SQL查询并导出CSV文件..."
echo "SQL语句: $SQL_STRING_AS"
echo "输出路径: $CSV_FILE_AS"

# 使用adt工具执行查询（需配置有效token）
data/cloud_share/tool/adt --token 731a63a43618b0b444a2b86f36cf3e14 ark2csv --sql-string "$SQL_STRING_AS" --csv-file "$CSV_FILE_AS"

if [ $? -eq 0 ]; then
  echo "数据已成功导出至 $CSV_FILE_AS"
else
  echo "数据导出过程中发生错误。"
  exit 1
fi

echo "脚本执行完成。"