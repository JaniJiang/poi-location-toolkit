from asyncio import Semaphore
from search.qa_bot.service_bot_analyse.utils.prompt import *
from search.qa_bot.service_bot_miner.meta import *
from utils.llm_utils.serverless_function import request_llm_async, RateLimiter
from utils.file_utils import read_jsonl_file
import json
from tqdm import tqdm
import pandas as pd
import asyncio
import aiohttp


class RealAndRelevance:
    """真实相关判断工具：
       通过LLM+策略规则判断服务专家回复是否与理想汽车知识库真实相关
       核心流程：规则过滤 + LLM判断 + 结果统计分析
    """

    def __init__(self):
        # --- 配置参数 ---
        # 输入输出路径
        self.input_path = DATA_MINER_FILE_PATHS["step4"]["input"]  # 待处理数据源
        self.output_path = DATA_MINER_FILE_PATHS["step4"]["output"]    # 处理结果输出
        # 模型配置
        self.model_name = "deepseek-r1"  # 可选模型: gpt-4o | claude-3_5-sonnet | deepseek-v3 | deepseek-r1 | deepseek-r1-distill-qwen-32b
        # 并发控制
        self.max_concurrent = 10  # 最大并发数（控制资源消耗）
        self.qps = 3              # 请求频率限制（建议≤4）

    def analyse_result(self):
        """结果分析模块：统计判断准确率"""
        with open(self.output_path, 'r', encoding='utf-8') as file:
            acc = 0
            acc_inner = 0
            all = 0
            for line in file:
                all += 1
                try:
                    data = json.loads(line)
                    # 严格标准：仅当if_inner=1时采用LLM判断结果
                    if data["if_inner"] == 0:
                        label = 0  # 严格标准标记为不相关
                    else:
                        label = 1 if data['gpt_label'] == "完全可解" else 0
                    if label == data["label"]:
                        acc_inner += 1

                    # 宽松标准：所有样本均采用LLM判断结果
                    label = 1 if data['gpt_label'] == "完全可解" else 0
                    if label == data['label']:
                        acc += 1
                except json.JSONDecodeError as e:
                    print(f"解析错误: {e}")
                    print(f"问题行: {line}")
            print(f"严格结果acc: {acc_inner / all:.4f}")
            print(f"宽松结果acc: {acc / all:.4f}")

    def process(self, test=False):
        """主处理流程：加载数据→规则过滤→LLM判断→保存结果"""
        # 1. 加载输入数据
        input_list = read_jsonl_file(self.input_path)
        # 2. 加载外部公司词典（用于识别非理想知识）
        dict_list = pd.read_csv("search/qa_bot/service_bot_analyse/vocab/car-company-other.txt",
                                sep='\t').iloc[:, 1].to_list()

        # 测试模式配置
        if test:
            test_path = "data/cloud/search/qa_bot/qa_data_analyse/testset/真实相关工具测试集.xlsx"
            self.output_path = "data/cloud/search/qa_bot/qa_data_analyse/testset/真实相关工具测试集_res.jsonl"
            input_list = pd.read_excel(test_path)
            input_list = input_list.dropna(subset=["label"]).head(200).iloc

        # 3. 异步处理任务
        loop = asyncio.get_event_loop()
        loop.run_until_complete(self.process_async(input_list, max_retries=3, dict_list=dict_list))

        if test:
            self.analyse_result()

    async def process_async(self, input_list, max_retries, dict_list):
        """异步处理入口：控制并发和速率限制"""
        # 初始化限速器和并发控制器
        rate_limiter = RateLimiter(self.qps)
        semaphore = Semaphore(self.max_concurrent)

        async with aiohttp.ClientSession() as session:
            # 创建所有异步任务
            tasks = [self.process_item_async(rate_limiter, semaphore, session, item,
                                             max_retries, dict_list) for item in input_list]

            # 并行执行任务并写入结果
            with open(self.output_path, 'w', encoding='utf-8') as f:
                for item, future in tqdm(zip(input_list, asyncio.as_completed(tasks)), total=len(tasks)):
                    response = await future
                    if not response['gpt_label']:
                        continue
                    f.write(json.dumps(response.to_dict() if type(response)
                            != dict else response, ensure_ascii=False) + "\n")
                    f.flush()  # 实时刷新缓冲区

    async def process_item_async(self, rate_limiter, semaphore, session, item, max_retries, dict_list):
        """单条数据处理流程：规则过滤→LLM判断→结果回写"""
        if type(item) is not dict:
            item = item.to_dict()
        try:
            # 1. 提取知识搜索结果
            search_res_list = []
            for search_res in json.loads(item['knowledge_search_result']):
                search_res_list += search_res['data'][0]['bot_data']
        except Exception as e:
            print(e)
            item["gpt_label"] = []
            item["label_analyse"] = []
            return item

        # 2. 基于规则判断是否包含理想汽车知识
        if_skip = True
        search_obs = ""  # 理想相关知识内容
        outer_list = []  # 外部公司关键词列表

        for res in search_res_list:
            if not "source_domain" in res.keys():
                continue
            # 直接匹配"lixiang"或"理想"标识
            if "lixiang" in res["source_domain"] or "理想" in res["content"].replace("该知识来自理想汽车", ""):
                if_skip = False
                search_obs += res["content"]
            else:
                # 匹配外部公司关键词
                flag = 0
                for outer_company in dict_list:
                    for o in outer_company.split('，'):
                        if o in res["content"]:
                            outer_list.append(o)
                            flag = 1
                            continue
                if flag == 0:
                    # 未匹配到外部公司则加入知识内容
                    search_obs += res["content"]

        # 3. 构建LLM输入提示词
        if if_skip:
            # 情况1：无理想相关知识
            history = [
                SYSTEM_PROMPT_STAGE_3_TMP,
                USER_PROMPT_STAGE_3_TMP.format(
                    question=item["query"],
                    answer=item["output"],
                    obs=search_obs,
                    outer=outer_list
                )
            ]
            item["if_inner"] = 0  # 标记为内部知识缺失
        else:
            # 情况2：存在理想相关知识
            history = [
                SYSTEM_PROMPT_STAGE_3_TMP,
                USER_PROMPT_STAGE_3_TMP.format(
                    question=item["query"],
                    answer=item["output"],
                    obs=search_obs,
                    outer=outer_list
                )
            ]
            item["if_inner"] = 1  # 标记为内部知识存在

        # 4. 调用LLM进行判断
        try:
            payload, response_data = await request_llm_async(
                rate_limiter,
                semaphore,
                session,
                max_retries,
                history,
                model=self.model_name,
                n=1,
                temperature=0
            )
            question_new_str = response_data["choices"][0]["message"]["content"]
            question_new_list = json.loads(question_new_str)
        except Exception as e:
            question_new_list = []
            print(e)
            try:
                # 尝试修复格式错误
                question_new_list = json.loads(question_new_str.strip().strip(
                    '`').replace("json", '').replace("\n", ""))
            except Exception as e:
                print("llm-api调用失败")
                print(e)
                item["gpt_label"] = "不可解"
                item["label_analyse"] = "llm-api调用失败"
                return item

        # 5. 回写判断结果
        item["gpt_label"] = question_new_list["result"]
        item["label_analyse"] = question_new_list["analyse"]
        return item


if __name__ == "__main__":
    print("############## Step3 Processing ##############")
    obj = RealAndRelevance()
    obj.process(test=False)
