from typing import List
from tqdm import tqdm
import pandas as pd
import aiohttp
import asyncio
import json
import csv
from utils.file_utils import read_jsonl_file
from utils.search_utils.memory_qdrant import MemoryQdrant
from utils.nlp_utils.embedding import get_batch_embedding
from search.qa_bot.service_bot_analyse.utils.prompt import *
from utils.llm_utils.serverless_function import request_llm_async, RateLimiter
from asyncio import Semaphore
from search.qa_bot.service_bot_analyse.utils.meta import DIM, BATCH_SIZE
from search.qa_bot.service_bot_miner.meta import *
from tqdm.asyncio import tqdm_asyncio
import random


class Coverage_Tool:
    """聚类Query统计工具：对聚类结果进行频次统计"""

    def __init__(self):
        self.query_path = DATA_MINER_FILE_PATHS["step8"]["input"]
        self.output_path = DATA_MINER_FILE_PATHS["step8"]["output"]
        self.qa_index_path = DATA_MINER_FILE_PATHS["step8"]["knowledge_info"]
        self.recall_num = 5
        # gpt-4o | claude-3_5-sonnet | deepseek-v3 | deepseek-r1 | deepseek-r1-distill-qwen-32b
        self.model_name = "gpt-4o"
        self.max_concurrent = 2000
        self.qps = 2   # 推荐不大于4

    def process(self):
        # 读取query数据
        query_data_list = read_jsonl_file(self.query_path)
        query_data_list = [item for item in query_data_list if item.get(
            'representative_query') != '']
        query_text_list = pd.DataFrame(query_data_list)
        # 读取index数据
        qa_text_index = self.build_index(self.qa_index_path)
        # 多线程调用
        loop = asyncio.get_event_loop()
        loop.run_until_complete(self.process_async(
            query_text_list, qa_text_index, max_retries=3))

    async def process_async(self, input_list, qa_text_index, max_retries):
        # 随机选取代表性的用户query
        represent_user_quer_list = []
        for qList in input_list["orig_query_list"]:
            avg_len = sum(len(s) for s in qList) / len(qList)
            # 筛选出长度大于平均长度的字符串
            filtered_strings = [s for s in qList if len(s) > avg_len]

            # 为空
            if len(filtered_strings) < 1:
                represent_user_quer_list.append(qList[0])
                continue
            # 随机选择一个字符串
            selected_string = random.choice(filtered_strings)
            represent_user_quer_list.append(selected_string)
        input_list["repres_userq"] = represent_user_quer_list

        # 获取emed
        print("############## Compute Embedding ##############")
        query_embedding_list_ori = get_batch_embedding(
            list(input_list["representative_query"]), DIM, BATCH_SIZE)
        query_embedding_list_new = get_batch_embedding(
            list(input_list["repres_userq"]), DIM, BATCH_SIZE)
        # 先检索
        print("############## Knowledge Retrieval ##############")
        recall_list_qa_ori = qa_text_index.search_batch(
            query_embedding_list_ori, top_k=self.recall_num, deduplicate=True)
        recall_list_qa_new = qa_text_index.search_batch(
            query_embedding_list_new, top_k=self.recall_num, deduplicate=True)
        # 检索结果去重
        recall_list_qa = []
        for i in range(len(query_embedding_list_new)):
            seen = set()
            result = []
            for d in recall_list_qa_new[i]+recall_list_qa_ori[i]:
                if d["id"] not in seen:
                    seen.add(d["id"])
                    result.append(d)
            recall_list_qa.append(result)
        # 并行推理
        print("############## Coverage Inference ##############")
        rate_limiter = RateLimiter(self.qps)
        semaphore = Semaphore(self.max_concurrent)  # 限制最大并发数为 max_concurrent
        async with aiohttp.ClientSession() as session:
            tasks = [self.process_item_async(rate_limiter, recall_list_qa[index],
                                             semaphore, session,
                                             index, input_list, max_retries)
                     for index in range(len(input_list))]
            results = [None] * len(tasks)
            task_objects = [asyncio.create_task(task) for task in tasks]
            # tqdm_asyncio按index返回并发结果
            for _, task in tqdm_asyncio(zip(range(len(tasks)), task_objects), total=len(tasks)):
                response, index = await task
                # 根据任务的索引存储结果
                results[index] = response

            with open(self.output_path, 'w', newline='', encoding='utf-8') as f:
                # 定义CSV列名
                fieldnames = [
                    'representative_query',
                    "api_query",
                    'knowledge_coverage',
                    'frequency',
                    'cluster_id',
                    'pv_list',
                    'recall_list',
                    'original_queries',
                    'explain',
                    'knowledge_id',
                    "user_queries",
                ]

                # 创建CSV写入器
                writer = csv.DictWriter(f, fieldnames=fieldnames)

                # 写入表头
                writer.writeheader()

                for response in results:
                    # 将original_queries列表转换为逗号分隔的字符串
                    original_queries_str = '| '.join(
                        response['original_queries'])

                    # 构造数据行
                    row = {
                        'representative_query': response['representative_query'],
                        'api_query': response['api_query'],
                        'knowledge_coverage': response['knowledge_coverage'],
                        'frequency': response['frequency'],
                        'cluster_id': response['cluster_id'],
                        'pv_list': response['pv_list'],
                        'recall_list': response['recall_list'],
                        'original_queries': original_queries_str,
                        'explain': response['explain'],
                        'knowledge_id': response['knowledge_id'],
                        "user_queries": response['user_queries'],
                    }

                    # 写入CSV行
                    writer.writerow(row)
                print(f'结果写入:{self.output_path}')

    async def process_item_async(self, rate_limiter, qa_item_list, semaphore, session, index, input_list, max_retries):
        api_query = input_list['representative_query'][index]
        item = input_list['repres_userq'][index]
        cluster_id = input_list['cluster_id'][index]
        pv_list = input_list['pv_list'][index]
        frequency = input_list['frequency'][index]
        recall_list = [str(o['id'])+":"+o['payload']['question'][0] for o in qa_item_list],
        query_list = input_list['original_queries'][index]
        user_queries = input_list["orig_query_list"][index]
        # inference
        has_item, explain, matched_item, knowledge_id = await self.do_rank_async(item, qa_item_list, rate_limiter, semaphore, session, max_retries)
        format_info = {
            "representative_query": item,
            "api_query": api_query,
            "cluster_id": int(cluster_id),
            "frequency": int(frequency),
            "knowledge_coverage": has_item,
            'pv_list': pv_list,
            'recall_list': recall_list,
            "original_queries": query_list,
            "explain": explain,
            "knowledge_id": knowledge_id,
            "user_queries": user_queries
        }
        return format_info, index

    def build_index(self, index_path):
        print(f"build_index: {index_path}")
        text_index = MemoryQdrant()
        index_list = read_jsonl_file(index_path)
        if len(index_list) < 1:
            print("######### Warning: index为空 #########")
        for point in tqdm(index_list):
            text_index.add_points([point])
        return text_index

    async def do_rank_async(self, query, item_list, rate_limiter, semaphore, session, max_retries):
        return await self.do_llm_ran_async(query, item_list, rate_limiter, semaphore, session, max_retries)

    async def do_llm_ran_async(self, query, item_list, rate_limiter, semaphore, session, max_retries):
        if not item_list:
            return "0", "", {}
        # 输入topn
        qid_list = []
        answer_list = []
        question_list = []
        for item in item_list:
            question = ", ".join(item["payload"]["question"][:10])
            answer = item["payload"]["answer"]
            if question in question_list:   # 去重
                continue
            answer_list.append(answer)
            question_list.append(question)
            qid_list.append(item["payload"]["question_id"])
        history = [
            SYSTEM_PROMPT_STAGE_6_TEST,
            USER_PROMPT_STAGE_6_NEW.format(
                question=query, knowledge="\n".join([str({"id": qid_list[index], "question": question_list[index], "answer": answer_list[index]}) for index in range(len(answer_list))]))
        ]
        # 推理
        try:
            payload, response_data = await request_llm_async(rate_limiter, semaphore, session, max_retries, history, model=self.model_name, n=1, temperature=0)
            # print(json.dumps({"payload": payload, "response": response_data}, ensure_ascii=False))
            question_new_str = response_data["choices"][0]["message"]["content"]
            question_new_list = json.loads(question_new_str)
        except Exception as e:
            print(f'解析出错，错误信息为：{e}')
            try:
                question_new_list = json.loads(question_new_str.strip().strip(
                    '`').replace("json", '').replace("\n", ""))
            except Exception as e:
                print(f'推理出错，错误信息为：{e}')
                # 推理失败返回空
                return "0", "", {}, -1
        # qid校验
        try:
            id = question_new_list["id"]
            if id == 0 | (id not in qid_list):
                return "0", question_new_list["analyse"], item, -1
            else:
                # find corresonding item
                for item in item_list:
                    if item["payload"]["question_id"] == id:
                        break
                return str(question_new_list["result"]), question_new_list["analyse"], item, id
        except Exception as e:
            print(f'Qid校验出错，错误信息为：{e}')
            return "0", question_new_list["analyse"], item, -1


if __name__ == "__main__":
    obj = Coverage_Tool()
    obj.process()
