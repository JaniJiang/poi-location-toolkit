from search.qa_bot.service_bot_miner.meta import *
from search.qa_bot.service_bot_analyse.utils.meta import DIM, BATCH_SIZE
from utils.llm_utils.serverless_function import request_llm_async, RateLimiter
from search.qa_bot.service_bot_miner.prompt import *
from collections import defaultdict
from tqdm.asyncio import tqdm_asyncio
from asyncio import Semaphore
import pandas as pd
import asyncio
import aiohttp
import json
from tqdm import tqdm
from utils.nlp_utils.embedding import get_batch_embedding
from utils.file_utils import read_jsonl_file
from sklearn.mixture import GaussianMixture as GMM
import numpy as np
import os


class Cluster_Tool:
    """对Query聚类：GMM+LMM两阶段"""

    def __init__(self):
        self.cluster_num = 200
        self.model_name = "gpt-4o"
        self.max_concurrent = 2000
        self.qps = 2   # 推荐不大于4
        self.cluster_gmm_input = DATA_MINER_FILE_PATHS["step6_GMM"]["input"]
        self.cluster_gmm_output = DATA_MINER_FILE_PATHS["step6_GMM"]["output"]
        self.pv_path = DATA_MINER_FILE_PATHS["step6_LLM"]["pv_info"]
        self.cluster_lmm_input = DATA_MINER_FILE_PATHS["step6_LLM"]["input"]
        self.cluster_lmm_output = DATA_MINER_FILE_PATHS["step6_LLM"]["output"]

    def cluster_by_GMM(self):
        """加载数据并提取向量与原始条目"""
        querys = []
        with open(self.cluster_gmm_input, "r", encoding="utf-8") as f:
            for line in f:
                entry = json.loads(line.strip())
                if entry['label'] != 1:
                    querys.append(entry['query'])
        if querys == []:
            print(f"{self.cluster_gmm_input}中没有未覆盖的query")
            return
        print(f"RAG未覆盖的Query数量为:{len(querys)}")
        # self.cluster_num = int(input("输入聚类簇数量："))
        self.cluster_num = int(len(querys)/3)
        if self.cluster_num > len(querys):
            print(f"聚类数:{self.cluster_num}大于query数:{len(querys)}，请重新设置聚类数")
            return
        vectors = get_batch_embedding(querys, DIM, BATCH_SIZE)
        labels = self.cluster(np.array(vectors), n_clusters=self.cluster_num)
        self.write_clustered_queries(querys, labels, self.cluster_num)

    def cluster_by_LMM(self):
        # 读取query数据
        query_data_list = read_jsonl_file(self.cluster_lmm_input)
        query_dict = defaultdict(list)

        for item in query_data_list:
            cluster_id = item["cluster_id"]
            query = item["query"]
            query_dict[cluster_id].append(query)
        df_pv = pd.read_csv(self.pv_path, header=0, encoding='utf-8',  usecols=['text', 'pv', 'pred_label'])
        if not IF_RUN_LOW_PV:
            df_pv = df_pv[(df_pv['pv'] >= 10) & (df_pv['pred_label'] == 1)]
        else:
            df_pv = df_pv[(df_pv['pv'] >= 3) & (df_pv['pv'] < 10) & (df_pv['pred_label'] == 1)]
        del df_pv['pred_label']
        query_pv_lookup = pd.Series(df_pv['pv'].values, index=df_pv['text']).to_dict()

        # 多线程调用
        loop = asyncio.get_event_loop()
        loop.run_until_complete(self.process_async(query_dict, query_pv_lookup, max_retries=3))

    def cluster(self, querys, cluster_name='GMM', n_clusters=None):
        cluster_choice = ['GMM']
        if cluster_name not in cluster_choice:
            raise ValueError(
                f"Invalid cluster name. Choose from {cluster_choice}.")
        if cluster_name == 'GMM':
            gmm = GMM(n_components=n_clusters, random_state=42)
            labels = gmm.fit_predict(querys)
        return labels

    def write_clustered_queries(self, queries, labels, n_components, cluster_name='GMM'):
        """将查询按簇大小排序后写入JSONL文件（簇越大越先写）"""
        save_path = self.cluster_gmm_output

        # 按簇分组并统计大小
        clusters = defaultdict(list)
        for query, label in zip(queries, labels):
            clusters[label].append(query)

        # 按簇大小降序排序簇ID（簇ID相同则按数字升序排列）
        sorted_clusters = sorted(
            clusters.keys(),
            key=lambda x: (-len(clusters[x]), x)  # 先按大小降序，再按簇ID升序
        )

        with open(save_path, 'w') as f:
            for cluster_id in sorted_clusters:
                for query in clusters[cluster_id]:
                    json_line = {
                        "query": query,
                        "cluster_id": int(cluster_id)
                    }
                    f.write(json.dumps(json_line, ensure_ascii=False) + '\n')

        print(f"已保存聚类结果到: {os.path.abspath(save_path)}")

    async def process_async(self, query_dict, query_pv_lookup, max_retries):
        rate_limiter = RateLimiter(self.qps)
        semaphore = Semaphore(self.max_concurrent)  # 限制最大并发数为 max_concurrent
        async with aiohttp.ClientSession() as session:
            # 将query和query embedding分别传入异步函数
            tasks = [self.process_item_async(rate_limiter, semaphore, session,
                                             index, cluster_id, query_list, query_pv_lookup, max_retries)
                     for index, (cluster_id, query_list) in enumerate(query_dict.items())]
            results = [None] * len(tasks)
            task_objects = [asyncio.create_task(task) for task in tasks]
            # tqdm_asyncio按index返回并发结果
            for _, task in tqdm_asyncio(zip(range(len(tasks)), task_objects), total=len(tasks)):
                response, index = await task
                # 根据任务的索引存储结果
                results[index] = response

            with open(self.cluster_lmm_output, 'w', encoding='utf-8') as f:
                # results = await asyncio.gather(*tasks)  # 使用 asyncio.gather 获取结果
                for response in results:
                    for item in response:
                        # 处理单个字典
                        representative_query = item['representative_query']
                        cluster_id = item['cluster_id']
                        original_queries = item['original_queries']
                        pv_list = item['pv_list']
                        # 统计query频次
                        frequency = item['count']
                        # 将结果写入文件
                        f.write(json.dumps({"representative_query": representative_query, "cluster_id": cluster_id,
                                "frequency": frequency, 'pv_list': pv_list, "original_queries": original_queries}, ensure_ascii=False) + '\n')

    async def process_item_async(self, rate_limiter, semaphore, session, index, cluster_id, query_list, query_pv_lookup, max_retries):
        # inference
        response = await self.do_rank_async(query_list, rate_limiter, semaphore, session, max_retries)
        for item in response:
            item["cluster_id"] = cluster_id
            item['pv_list'] = []
            for query in item['original_queries']:
                pv_value = query_pv_lookup.get(query, None)
                if pv_value is None:
                    print(f"警告: 在 CSV 文件中未找到查询 '{query}' 的 PV 数据。对应 PV 值设为 None。")
                    item['pv_list'] = []
                    break
                item['pv_list'].append(pv_value)
            item['count'] = sum(item['pv_list'])
        response = [item for item in response if item['count'] != 0]  # 过滤pv=0的item
        return response, index

    async def do_rank_async(self, query_list, rate_limiter, semaphore, session, max_retries):
        if len(query_list) == 0:
            return [{'representative_query': '', 'original_queries': []}]
        return await self.do_llm_ran_async(query_list, rate_limiter, semaphore, session, max_retries)

    async def do_llm_ran_async(self, query_list, rate_limiter, semaphore, session, max_retries):
        history = [
            SYSTEM_PROMPT_QUERY_GATHER,
            USER_PROMPT_QUERY_GATHER.format(
                querys=query_list)
        ]
        # 推理
        try:
            payload, response_data = await request_llm_async(rate_limiter, semaphore, session, max_retries, history, model=self.model_name, n=1, temperature=0)
            question_new_str = response_data["choices"][0]["message"]["content"]
            question_new_list = json.loads(question_new_str)
        except Exception as e:
            print(f'解析失败: {e}')
            try:
                question_new_list = json.loads(question_new_str.strip().strip(
                    '`').replace("json", '').replace("\n", ""))
            except Exception as e:
                print(f'推理失败: {e}')
                # 推理失败返回空
                return [{'representative_query': '', 'original_queries': []}]
        return question_new_list


if __name__ == "__main__":
    obj = Cluster_Tool()
    obj.cluster_by_GMM()
    # obj.cluster_by_LMM()
