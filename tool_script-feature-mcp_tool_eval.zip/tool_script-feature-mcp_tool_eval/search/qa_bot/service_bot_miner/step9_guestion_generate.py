import pandas as pd
import aiohttp
from tqdm.asyncio import tqdm_asyncio
from utils.llm_utils.serverless_function import request_llm_async, RateLimiter
from search.qa_bot.service_bot_miner.meta import *
from search.qa_bot.service_bot_analyse.utils.prompt import *
from asyncio import Semaphore
from tqdm import tqdm
from utils.file_utils import read_jsonl_file
from utils.search_utils.semantic_deduplicate import semantic_deduplicate
import json
import asyncio
import requests
import time
import random

# 模拟请求rescore模型
URL = "http://nlu-tritonserver-inference-http.ssai-apis-staging.chj.cloud/v2/models/qabot-rescore-ensemble/infer"
REQUEST = {
    "id": "wzy",
    "inputs": [
        {
            "name": "user_query",
            "shape": [
                1
            ],
            "datatype": "BYTES",
            "data": [
                [
                    "query"
                ]
            ]
        },
        {
            "name": "topk",
            "shape": [
                1
            ],
            "datatype": "UINT8",
            "data": [
                1
            ]
        },
        {
            "name": "candidate_query_list",
            "shape": [
                1,
                3
            ],
            "datatype": "BYTES",
            "data": [
                "1",
                "",
                "1"
            ]
        }
    ]
}


class QuestionGenerate:
    """Query泛化工具"""

    def __init__(self):
        # 输入输出路径
        self.input_path = DATA_MINER_FILE_PATHS["step9_Generate"]["input"]  # 待处理数据源
        self.output_path = DATA_MINER_FILE_PATHS["step9_Generate"]["output"]    # 处理结果输出
        self.model_name = "claude-3_5-sonnet"  # gpt-4o | claude-3_5-sonnet | deepseek-v3 | deepseek-r1 | deepseek-r1-distill-qwen-32b
        self.max_concurrent = 2000
        self.qps = 3    # 推荐不大于4

    def process(self):
        # Load all the data
        input_list = pd.DataFrame(read_jsonl_file(self.input_path))
        # input_list = pd.read_csv(self.input_path)
        input_list = input_list[input_list["knowledge_coverage"] == 1]

        def agg_user_query_list(user_query_list):
            output = []
            for query_list in user_query_list:
                output += json.loads(query_list.replace("'", '"'))
            return output
        # 聚合相同标准问的cluster
        input_list = input_list.groupby('knowledge_id').agg({
            "frequency": lambda x: sum(x),
            "user_queries": agg_user_query_list,
            "api_query": lambda x: list(x),
        }).reset_index()
        # 按照frequency倒排
        input_list.sort_values(by='frequency', ascending=False, inplace=True)
        # 获取原始的query进行泛化
        with open("data/cloud/search/qa_bot/qa_data_analyse/testset/data_0604.json", "r") as file:
            data = json.load(file)
        qadict = dict()
        for d in data:
            if "answerGroup" in d.keys():
                question_id = d["answerGroup"][0]['questionId']
            else:
                continue
            qadict[f"{question_id}"] = {"question_list": d['question'],
                                        "answer": d["answerGroup"][0]['answers'][0]['ttsContent']}

        # 遍历knowledge_id查询原始泛化问
        question_list = []
        answer_list = []
        for kid in input_list['knowledge_id'].to_list():
            try:
                kid = int(kid)
                question_list.append(qadict[f"{kid}"]['question_list'])
                answer_list.append(qadict[f"{kid}"]['answer'])
            except Exception as e:
                print("匹配标准问失败!!: ", str(kid))
                question_list.append('')
                answer_list.append('')
        input_list["question_list"] = question_list
        input_list["answer"] = answer_list

        # 多线程调用
        loop = asyncio.get_event_loop()
        loop.run_until_complete(self.process_async(input_list, max_retries=5))

    async def process_async(self, input_list, max_retries):
        rate_limiter = RateLimiter(self.qps)
        semaphore = Semaphore(self.max_concurrent)  # 限制最大并发数为 max_concurrent
        async with aiohttp.ClientSession() as session:
            tasks = [self.process_item_async(rate_limiter, semaphore, session,
                                             item, max_retries)
                     for item in input_list.iloc]
            results = [None] * len(tasks)
            task_objects = [asyncio.create_task(task) for task in tasks]
            # tqdm_asyncio按index返回并发结果
            for index, task in tqdm_asyncio(zip(range(len(tasks)), task_objects), total=len(tasks)):
                response = await task
                # 根据任务的索引存储结果
                results[index] = response

            with open(self.output_path, 'w', encoding='utf-8') as f:
                for item, response in zip(input_list.iloc, results):
                    f.write(json.dumps(response.to_dict(), ensure_ascii=False) + "\n")
                    f.flush()  # ensure the data is written to disk after each iteration

    async def process_item_async(self, rate_limiter, semaphore, session, item, max_retries):
        # 原有泛化问列表
        old_question_list = random.sample(item["question_list"], k=min(10, len(item["question_list"])))
        if len(old_question_list) < 1:
            # 没有原始泛化问（匹配标准问失败），不进行泛化
            item.loc["original_question_new"] = ''
            item.loc["question_new"] = ''
            return item
        # 调用LLM泛化question
        history = [
            SYSTEM_PROMPT,
            USER_PROMPT.format(query=item["user_queries"],
                               question=old_question_list,
                               answer=item["answer"])
        ]
        try:
            payload, response_data = await request_llm_async(rate_limiter, semaphore, session, max_retries, history, model=self.model_name, n=1, temperature=0)
            # print(json.dumps({"payload": payload, "response": response_data}, ensure_ascii=False))
            question_new_str = response_data["choices"][0]["message"]["content"]
            question_new_list = json.loads(question_new_str.replace('，', ','))
        except Exception as e:
            question_new_list = []
            print(e)
        question_new_list = [query for query in question_new_list if query not in item["question_list"]]    # 绝对去重
        item.loc["original_question_new"] = '\n'.join(map(str, question_new_list))
        # 添加原始query并进行语义去重
        if type(item["user_queries"]) != list:
            try:
                user_queries_list = json.loads(item["user_queries"].replace('\'', '\"'))
            except Exception as e:
                print("!!!Warning:", e)
                item.loc["question_new"] = ""
        else:
            user_queries_list = item["user_queries"]
        if len(user_queries_list) <= 5:
            out_list = semantic_deduplicate(question_new_list+user_queries_list, old_question_list)
        else:
            out_list = semantic_deduplicate(
                question_new_list+random.sample(item["api_query"], min(5, len(item["api_query"]))), old_question_list)
        # 回写处理结果
        item.loc["question_new"] = '\n'.join(map(str, out_list))
        return item


if __name__ == "__main__":
    print("############## Step9 Processing ##############")
    obj = QuestionGenerate()
    obj.process()

# python -m search.qa_bot.qa_data_analyse.step7_question_generate
