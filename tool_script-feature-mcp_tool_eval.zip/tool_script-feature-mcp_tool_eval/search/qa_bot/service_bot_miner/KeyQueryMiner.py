from search.qa_bot.service_bot_miner.meta import *
from search.qa_bot.service_bot_miner.step2_query_count import QueryCounter
from search.qa_bot.service_bot_miner.step3_coarse_filter import Coarse_Filter
from search.qa_bot.service_bot_miner.step4_real_and_relevance import RealAndRelevance
from search.qa_bot.service_bot_miner.step5_rag_and_extra_coverage import Rag_Extra_Coverage
from search.qa_bot.service_bot_miner.step6_cluster import Cluster_Tool
from search.qa_bot.service_bot_miner.step7_get_new_konw import KnowledgeExtractAndIndex
from search.qa_bot.service_bot_miner.step7_get_orig_query import GetOrigQuery
from search.qa_bot.service_bot_miner.step7_semantic_filter import SemanticFilter
from search.qa_bot.service_bot_miner.step8_post_process import PostProcess
from search.qa_bot.service_bot_miner.step8_coverage_tool import Coverage_Tool
from search.qa_bot.service_bot_miner.step9_guestion_generate import QuestionGenerate
from search.qa_bot.service_bot_miner.tool.data_analyse_tool import DataAnalyse
import pandas as pd
import json


class KeyQueryMiner:
    """核心查询挖掘流水线主类，包含完整的数据处理流程"""

    def __init__(self):
        """初始化各阶段处理工具实例"""
        self.query_count_tool = QueryCounter()
        self.coarse_filt_tool = Coarse_Filter()
        self.data_analyse_tool = DataAnalyse()
        self.relevance_tool = RealAndRelevance()
        self.rag_extra_coverage_tool = Rag_Extra_Coverage()
        self.cluster_tool = Cluster_Tool()
        self.semantic_filter_tool = SemanticFilter()
        self.get_orig_query_tool = GetOrigQuery()
        self.get_new_know_tool = KnowledgeExtractAndIndex()
        self.coverage_tool = Coverage_Tool()
        self.postprocess_tool = PostProcess()
        self.question_generate_tool = QuestionGenerate()

    def csv2jsonl(self, csv_file_path, jsonl_file_path):
        """
        将CSV文件转换为JSONL格式

        参数:
            csv_file_path (str): 输入CSV文件路径
            jsonl_file_path (str): 输出JSONL文件路径
        """
        # 读取CSV文件（注意：如果CSV中存在特殊字符或转义问题，可能需要调整encoding参数）
        df = pd.read_csv(csv_file_path)

        # 创建JSONL文件
        with open(jsonl_file_path, 'w', encoding='utf-8') as jsonl_file:
            for _, row in df.iterrows():
                # 构建最终的JSON对象
                json_obj = {
                    "query": row['query'],
                    "output": row['output'],
                    "knowledge_search_result": row['knowledge_search_result']
                }

                # 写入JSONL文件（每行一个完整的JSON对象）
                jsonl_file.write(json.dumps(json_obj, ensure_ascii=False) + '\n')
        print(f"CSV文件已成功转换为JSONL文件：{jsonl_file_path}")

    def query_count(self, input_path, output_path):
        """
        执行查询频次统计处理

        参数:
            input_path (str): 原始查询数据CSV路径
            output_path (str): 统计结果输出CSV路径
        """
        self.query_count_tool.input_csv_path = input_path
        self.query_count_tool.output_csv_path = output_path
        self.query_count_tool.process_file()

    def coarse_filt(self, input_path, output_path, cluster_output=None):
        """
        使用BERT模型进行初步过滤（可选后续聚类）

        参数:
            input_path (str): 输入数据路径
            output_path (str): 过滤结果输出路径
            cluster_output (str): 可选的聚类结果输出路径
        """
        self.coarse_filt_tool.query_data = input_path
        self.coarse_filt_tool.bert_output = output_path
        self.coarse_filt_tool.bert_filter()
        if cluster_output is not None:
            self.coarse_filt_tool.cluster_service_bot(output_path, cluster_output)

    def relevence(self, input_path, output_path):
        """
        执行真实相关性判断处理

        参数:
            input_path (str): 输入数据路径（JSONL格式）
            output_path (str): 处理结果输出路径（JSONL格式）
        """
        self.relevance_tool.input_path = input_path
        self.relevance_tool.output_path = output_path
        self.relevance_tool.process()

    def rag_coverage(self, input_path, output_path):
        """
        执行RAG知识覆盖分析

        参数:
            input_path (str): 输入数据路径（JSONL格式）
            output_path (str): 处理结果输出路径（JSONL格式）
        """
        self.rag_extra_coverage_tool.input_path = input_path
        self.rag_extra_coverage_tool.output_path = output_path
        self.rag_extra_coverage_tool.process()

    def cluster_GMM_stage(self, input_path, output_path, date='27-09', cluster_name='GMM'):
        """
        执行GMM聚类分析

        参数:
            input_path (str): 输入数据路径（JSONL格式）
            output_path (str): 聚类结果输出路径（JSONL格式）
            date (str): 聚类日期标识
            cluster_name (str): 聚类方法名称
        """
        self.cluster_tool.cluster_date = date
        self.cluster_tool.cluster_gmm_input = input_path
        self.cluster_tool.cluster_gmm_output = output_path  # 未覆盖中筛选出的query
        self.cluster_tool.cluster_by_GMM()

    def cluser_LLM_stage(self, query_path, pv_path, output_path):
        """
        执行LLM辅助聚类分析

        参数:
            query_path (str): 查询数据路径（JSONL格式）
            pv_path (str): PV统计数据路径（CSV格式）
            output_path (str): 聚类结果输出路径（JSONL格式）
        """
        self.cluster_tool.cluster_lmm_input = query_path
        self.cluster_tool.pv_path = pv_path
        self.cluster_tool.cluster_lmm_output = output_path
        self.cluster_tool.cluster_by_LMM()

    def semantic_filter(self, input_path, output_path):
        """
        语义过滤

        参数:
            input_path (str): 输入数据路径（JSONL格式）
            output_path (str): 最终结果输出路径（CSV格式）
        """
        self.semantic_filter_tool.input_path = input_path
        self.semantic_filter_tool.output_path = output_path
        self.semantic_filter_tool.process()

    def get_orig_query(self, input_path, output_path):
        """
        获取原始query

        参数:
            input_path (str): 输入数据路径（JSONL格式）
            output_path (str): 最终结果输出路径（CSV格式）
        """
        self.get_orig_query_tool.input_path = input_path
        self.get_orig_query_tool.output_path = output_path
        self.get_orig_query_tool.process()

    def coverage(self, input_path, output_path, qa_index_path):
        """
        执行最终知识覆盖分析

        参数:
            input_path (str): 输入数据路径（JSONL格式）
            output_path (str): 最终结果输出路径（CSV格式）
            qa_index_path (str): QA知识库索引路径（JSONL格式）
        """
        self.coverage_tool.query_path = input_path
        self.coverage_tool.output_path = output_path
        self.coverage_tool.qa_index_path = qa_index_path
        self.coverage_tool.process()

    def postprocess(self, input_path, output_path):
        """
        后处理

        参数:
            input_path (str): 输入数据路径（JSONL格式）
            output_path (str): 最终结果输出路径（CSV格式）
        """
        self.postprocess_tool.input_path = input_path
        self.postprocess_tool.output_path = output_path
        self.postprocess_tool.process()

    def question_generate(self, input_path, output_path):
        """
        后处理

        参数:
            input_path (str): 输入数据路径（JSONL格式）
            output_path (str): 最终结果输出路径（CSV格式）
        """
        self.question_generate_tool.input_path = input_path
        self.question_generate_tool.output_path = output_path
        self.question_generate_tool.process()


if __name__ == "__main__":
    miner = KeyQueryMiner()
    # # step2 Query的PV统计
    # miner.query_count(DATA_MINER_FILE_PATHS["step2"]["input"], DATA_MINER_FILE_PATHS["step2"]["output"])
    # # step3 bert粗筛(粗筛后是否对数据聚类可选)
    # miner.coarse_filt(DATA_MINER_FILE_PATHS["step3"]["input"], DATA_MINER_FILE_PATHS["step3"]["output"])
    # # step3.5 为step4准备数据
    # miner.data_analyse_tool.get_origin_info(
    #     DATA_MINER_FILE_PATHS["step3.5"]["input"],
    #     DATA_MINER_FILE_PATHS["step3.5"]["autosearch_info"],
    #     DATA_MINER_FILE_PATHS["step3.5"]["output_csv"]
    # )
    # miner.csv2jsonl(DATA_MINER_FILE_PATHS["step3.5"]["output_csv"], DATA_MINER_FILE_PATHS["step3.5"]["output_jsonl"])
    # # step4 真实相关工具
    # miner.relevence(DATA_MINER_FILE_PATHS["step4"]["input"],
    #                 DATA_MINER_FILE_PATHS["step4"]["output"])
    # step5 Rag知识覆盖工具
    miner.rag_coverage(DATA_MINER_FILE_PATHS["step5"]["input"],
                       DATA_MINER_FILE_PATHS["step5"]["output"])

    # step6 聚类-GMM
    miner.cluster_GMM_stage(DATA_MINER_FILE_PATHS["step6_GMM"]["input"],
                            DATA_MINER_FILE_PATHS["step6_GMM"]["output"])
    # step6 聚类-LLM
    miner.cluser_LLM_stage(DATA_MINER_FILE_PATHS["step6_LLM"]["input"],
                           DATA_MINER_FILE_PATHS["step6_LLM"]["pv_info"],
                           DATA_MINER_FILE_PATHS["step6_LLM"]["output"])
    # step7 语义过滤
    miner.semantic_filter(DATA_MINER_FILE_PATHS["step7_SEMFIL"]["input"],
                          DATA_MINER_FILE_PATHS["step7_SEMFIL"]["output"])
    # step7 获取原始query
    miner.get_orig_query(DATA_MINER_FILE_PATHS["step7_GETINFO"]["input"],
                         DATA_MINER_FILE_PATHS["step7_GETINFO"]["output"])
    # step8 知识覆盖工具
    miner.coverage(DATA_MINER_FILE_PATHS["step8"]["input"],
                   DATA_MINER_FILE_PATHS["step8"]["output"], DATA_MINER_FILE_PATHS["step8"]["knowledge_info"])
    # step8 后处理
    miner.postprocess(DATA_MINER_FILE_PATHS["step8_Process"]["input"],
                      DATA_MINER_FILE_PATHS["step8_Process"]["output"])
    # step9 泛化
    miner.question_generate(DATA_MINER_FILE_PATHS["step9_Generate"]["input"],
                            DATA_MINER_FILE_PATHS["step9_Generate"]["output"])
