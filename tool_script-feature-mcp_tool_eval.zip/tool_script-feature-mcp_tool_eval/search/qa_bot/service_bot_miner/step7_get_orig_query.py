import pandas as pd
import json
from tqdm import tqdm
from utils.file_utils import read_jsonl_file
from search.qa_bot.service_bot_miner.meta import *
from search.qa_bot.service_bot_analyse.utils.prompt import *


class GetOrigQuery:
    """Query泛化工具"""

    def __init__(self):
        # 输入输出路径
        self.orig_path = DATA_MINER_FILE_PATHS["step7_GETINFO"]["metadata_path"]
        self.input_path = DATA_MINER_FILE_PATHS["step7_GETINFO"]["input"]  # 待处理数据源
        self.output_path = DATA_MINER_FILE_PATHS["step7_GETINFO"]["output"]    # 处理结果输出

    def find_orig_query(self, df):
        """
        简介版，需在step2计算pv时保存原始query数据
        """
        df_with_orig_queries = pd.read_csv(self.orig_path)
        # 遍历queries_list查询原始query
        queries_list = df["original_queries"].to_list()
        orig_query_list = []
        for query_list in tqdm(queries_list):
            cluster_query_list = query_list.copy()
            for query in query_list:
                tmp_orig_query_list = json.loads(df_with_orig_queries[df_with_orig_queries['query'] == query]
                                                 ['orig_query'].values[0].replace("'", '"'))
                cluster_query_list += tmp_orig_query_list
                # try:
                #     cluster_query_list += list(set(result['query'][[(query in slot)
                #                                for slot in result['slot_li'].to_list()]].to_list()))
                # except Exception as e:
                #     print(e)
            orig_query_list.append(list(set(cluster_query_list)))
        df['orig_query_list'] = orig_query_list
        return df

        """
        原方法：重新便利原始日志，容易出现数据丢失，废弃
        """
        # self.orig_path = "/mnt/volumes/ss-sai-lx-my/xuzhou1/data_share/qabot_miner/caiqiye/mine_data_4.12_5.11/autosearch_data_2025-04-12_to_2025-05-11.csv"
        # queries_list = df["original_queries"].to_list()
        # queries_list = ["\"" + query + "\"" for query_list in queries_list for query in query_list]
        # target_values = set(queries_list)
        # pattern = '|'.join(target_values)

        # column_name = 'slot_li'  # 替换为你要筛选的列名

        # # 初始化一个空的列表，用于存储筛选后的数据
        # filtered_data = []

        # # 分块读取 CSV 文件
        # chunk_size = 100000  # 每块的行数，可以根据你的内存大小调整
        # for chunk in tqdm(pd.read_csv(self.orig_path, chunksize=chunk_size), desc="Processing chunks"):
        #     # 筛选出符合条件的行
        #     filtered_chunk = chunk[chunk[column_name].str.contains(pattern, na=False)]
        #     filtered_data.append(filtered_chunk)
        #     break

        # # 将所有筛选后的数据合并为一个 DataFrame
        # result = pd.concat(filtered_data)

        # # 遍历queries_list查询原始query
        # queries_list = df["original_queries"].to_list()
        # orig_query_list = []
        # for query_list in queries_list:
        #     cluster_query_list = query_list.copy()
        #     for query in query_list:
        #         try:
        #             cluster_query_list += list(set(result['query'][[(query in slot)
        #                                        for slot in result['slot_li'].to_list()]].to_list()))
        #         except Exception as e:
        #             print(e)
        #     orig_query_list.append(cluster_query_list)
        # df['orig_query_list'] = orig_query_list

        # return df

    def process(self):
        # Load all the data
        df = read_jsonl_file(self.input_path)
        df = pd.DataFrame(df)

        df = self.find_orig_query(df)
        df.to_json(self.output_path, orient="records", lines=True, force_ascii=False)


if __name__ == "__main__":
    print("############## Step7 Processing ##############")
    obj = GetOrigQuery()
    obj.process()
