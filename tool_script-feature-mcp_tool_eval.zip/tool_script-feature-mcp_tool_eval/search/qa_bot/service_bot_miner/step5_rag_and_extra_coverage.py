from asyncio import Semaphore
from search.qa_bot.service_bot_miner.prompt import *
from search.qa_bot.service_bot_miner.meta import *
from utils.llm_utils.serverless_function import request_llm_async, RateLimiter
from utils.file_utils import read_jsonl_file
from tqdm.asyncio import tqdm_asyncio
import json
from tqdm import tqdm
import asyncio
import aiohttp


class Rag_Extra_Coverage:
    """RAG/外部知识覆盖判断工具：
       通过LLM判断服务专家回复中RAG知识和外部知识是否覆盖了问题需求
       处理流程：知识解析→分类→LLM判断→结果整合
    """

    def __init__(self):
        # --- 配置参数 ---
        # 输入输出路径
        self.input_path = DATA_MINER_FILE_PATHS["step5"]["input"]  # 待处理数据源（需排除完全可解样本）
        self.output_path = DATA_MINER_FILE_PATHS["step5"]["output"]  # 覆盖判断结果输出
        # 模型配置
        self.model_name = "deepseek-r1"  # 可选模型: gpt-4o | claude-3_5-sonnet | deepseek-v3 | deepseek-r1 | deepseek-r1-distill-qwen-32b
        # 并发控制
        self.max_concurrent = 10  # 最大并发数（控制资源消耗）
        self.qps = 3              # 请求频率限制（建议≤4）

    def process(self):
        """主处理流程：加载数据→过滤样本→异步处理→保存结果"""
        # 1. 加载输入数据并过滤样本
        input_list = read_jsonl_file(self.input_path)
        # 仅处理非"完全可解"的样本（已确认非理想知识可解的样本）
        input_list = [item for item in input_list if item['gpt_label'] != '完全可解']

        # 2. 启动异步处理
        loop = asyncio.get_event_loop()
        loop.run_until_complete(self.process_async(input_list, max_retries=3))

    async def process_async(self, input_list, max_retries):
        """异步处理入口：管理并发和速率限制"""
        # 初始化限速器和并发控制器
        rate_limiter = RateLimiter(self.qps)
        semaphore = Semaphore(self.max_concurrent)

        async with aiohttp.ClientSession() as session:
            # 创建所有异步任务
            tasks = [
                self.process_item_async(rate_limiter, semaphore, session, input_list[index], max_retries, index)
                for index in range(len(input_list))
            ]

            # 初始化结果存储数组
            results = [None] * len(tasks)
            task_objects = [asyncio.create_task(task) for task in tasks]

            # 并行执行任务并按索引存储结果
            for _, task in tqdm_asyncio(zip(range(len(tasks)), task_objects), total=len(tasks)):
                response, index = await task
                results[index] = response

            # 写入最终结果
            with open(self.output_path, 'w', encoding='utf-8') as f:
                for response in tqdm(results, total=len(results)):
                    f.write(json.dumps(response, ensure_ascii=False) + "\n")
            print("############## Finish Inference ##############")

    async def process_item_async(self, rate_limiter, semaphore, session, item, max_retries, task_index):
        """单条数据处理流程：知识解析→分类→LLM判断→结果整合"""
        # 1. 解析知识搜索结果
        rag_knowledge_list = []       # 存储理想汽车相关知识
        extra_knowledge_list = []     # 存储外部公司相关知识

        try:
            data = json.loads(item['knowledge_search_result'])
            for index in range(len(data)):
                first_element = data[index]
                inner_data = first_element['data']
                inner_dict = inner_data[0]
                bot_data_list = inner_dict['bot_data']

                # 提取知识内容并分类
                for knowledge_item in bot_data_list:
                    content = knowledge_item.get('content', '')
                    knowledge = {'content': content}

                    if 'lixiang' in knowledge_item['source_domain']:
                        rag_knowledge_list.append(knowledge)
                    else:
                        extra_knowledge_list.append(knowledge)
        except Exception as e:
            print(f"知识解析失败: {e}")
            return {
                "query": item['query'],
                "output": item['output'],
                "rag_label": 0,
                "rag_reason": "解析失败",
                "extra_label": 0,
                "extra_reason": "解析失败",
                'label': 0,
                "rag": [],
                "extra": []
            }, task_index

        # 2. 处理空知识情况
        if len(rag_knowledge_list) < 1 and len(extra_knowledge_list) < 1:
            formated_item = {
                "query": item['query'],
                "output": item['output'],
                "rag_label": 0,
                "rag_reason": "列表为空",
                "extra_label": 0,
                "extra_reason": "列表为空",
                "label": 0,
                "rag": [],
                "extra": []
            }
            return formated_item, task_index

        # 3. 构建LLM输入提示词
        history = [
            SYSTEM_PROMPT_COVERAGE_test,
            USER_PROMPT_COVERAGE.format(
                question=item['query'],
                rag_knowledge=rag_knowledge_list,
                extra_knowledge=extra_knowledge_list
            )
        ]

        # 4. 调用LLM进行判断
        question_new_list = []
        try:
            payload, response_data = await request_llm_async(
                rate_limiter,
                semaphore,
                session,
                max_retries,
                history,
                model=self.model_name,
                n=1,
                temperature=0
            )
            question_new_str = response_data["choices"][0]["message"]["content"]
            question_new_list = json.loads(question_new_str)
        except Exception as e:
            print(f'解析出错：{e}')
            try:
                # 尝试修复格式错误
                question_new_list = json.loads(
                    question_new_str.strip().strip(
                        '`').replace("json", '').replace("\n", "")
                )
            except Exception as e:
                print(f'推理失败{e}')

        # 5. 整合判断结果
        if len(question_new_list) < 1:
            formated_item = {
                "query": item['query'],
                "output": item['output'],
                "rag_label": 0,
                "rag_reason": "推理失败",
                "extra_label": 0,
                "extra_reason": "推理失败",
                "label": 0,
                "rag": rag_knowledge_list,
                "extra": extra_knowledge_list
            }
        else:
            formated_item = {
                "query": item['query'],
                "output": item['output'],
                "rag_label": question_new_list["rag_evaluation"]["relevant"],
                "rag_reason": question_new_list["rag_evaluation"]["reason"],
                "extra_label": question_new_list["external_evaluation"]["relevant"],
                "extra_reason": question_new_list["external_evaluation"]["reason"],
                "label": 1 if question_new_list["rag_evaluation"]["relevant"] == 1 or
                question_new_list["external_evaluation"]["relevant"] == 1 else 0,
                "rag": rag_knowledge_list,
                "extra": extra_knowledge_list
            }

        return formated_item, task_index


if __name__ == "__main__":
    print("##############Processing ##############")
    obj = Rag_Extra_Coverage()
    obj.process()
