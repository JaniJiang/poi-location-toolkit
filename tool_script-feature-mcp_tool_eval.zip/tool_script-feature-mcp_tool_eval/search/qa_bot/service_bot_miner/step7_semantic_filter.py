import aiohttp
import asyncio
import json
from tqdm.asyncio import tqdm_asyncio
from utils.file_utils import read_jsonl_file
from utils.llm_utils.serverless_function import request_llm_async, RateLimiter
from search.qa_bot.service_bot_miner.meta import *
from search.qa_bot.service_bot_analyse.utils.prompt import *
from asyncio import Semaphore


class SemanticFilter:
    """
    过滤语义不明的query
    """

    def __init__(self):
        # --- 配置参数 ---
        # 输入输出路径
        self.input_path = DATA_MINER_FILE_PATHS["step7_SEMFIL"]["input"]  # 待处理数据源
        self.output_path = DATA_MINER_FILE_PATHS["step7_SEMFIL"]["output"]    # 处理结果输出
        # 模型配置
        self.model_name = "gpt-4o"  # 可选模型: gpt-4o | claude-3_5-sonnet | deepseek-v3 | deepseek-r1 | deepseek-r1-distill-qwen-32b
        # 并发控制
        self.max_concurrent = 10  # 最大并发数（控制资源消耗）
        self.qps = 3              # 请求频率限制（建议≤4）

    def process(self, test=False):
        """主处理流程：加载数据→规则过滤→LLM判断→保存结果"""
        # 1. 加载输入数据
        input_list = read_jsonl_file(self.input_path)

        # 3. 异步处理任务
        loop = asyncio.get_event_loop()
        loop.run_until_complete(self.process_async(input_list, max_retries=3))

    async def process_async(self, input_list, max_retries):
        """异步处理入口：控制并发和速率限制"""
        # 初始化限速器和并发控制器
        rate_limiter = RateLimiter(self.qps)
        semaphore = Semaphore(self.max_concurrent)

        async with aiohttp.ClientSession() as session:
            # 创建所有异步任务
            tasks = [self.process_item_async(rate_limiter, semaphore, session, item,
                                             max_retries) for item in input_list]

            # tqdm_asyncio按index返回并发结果
            results = [None] * len(tasks)
            task_objects = [asyncio.create_task(task) for task in tasks]
            for index, task in tqdm_asyncio(zip(range(len(tasks)), task_objects), total=len(tasks)):
                response = await task
                # 根据任务的索引存储结果
                results[index] = response

            # 并行执行任务并写入结果
            with open(self.output_path, 'w', encoding='utf-8') as f:
                for _, task in tqdm_asyncio(zip(range(len(tasks)), task_objects), total=len(tasks)):
                    response = await task
                    f.write(json.dumps(response.to_dict() if type(response)
                            != dict else response, ensure_ascii=False) + "\n")
                    f.flush()  # 实时刷新缓冲区

    async def process_item_async(self, rate_limiter, semaphore, session, item, max_retries):
        """单条数据处理流程：规则过滤→LLM判断→结果回写"""

        history = [
            SYSTEM_PROMPT_STAGE_7_SEMANTIC_FILTER,
            USER_PROMPT_STAGE_7_SEMANTIC_FILTER.format(
                query=[item["representative_query"]]+item['original_queries'],
            )
        ]

        # 调用LLM进行判断
        try:
            payload, response_data = await request_llm_async(
                rate_limiter,
                semaphore,
                session,
                max_retries,
                history,
                model=self.model_name,
                n=1,
                temperature=0
            )
            question_new_str = response_data["choices"][0]["message"]["content"]
            question_new_list = json.loads(question_new_str)
        except Exception as e:
            question_new_list = []
            print(e)
            try:
                # 尝试修复格式错误
                question_new_list = json.loads(question_new_str.strip().strip(
                    '`').replace("json", '').replace("\n", ""))
            except Exception as e:
                print("llm-api调用失败")
                print(e)
                item["gpt_label"] = "不可解"
                item["label_analyse"] = "llm-api调用失败"
                return item

        # 5. 回写判断结果
        item["gpt_label"] = question_new_list["result"]
        item["label_analyse"] = question_new_list["analyse"]
        item["representative_query"] = question_new_list["representative_query"]
        return item


if __name__ == "__main__":
    print("############## Step7 Processing ##############")
    obj = SemanticFilter()
    obj.process(test=False)
