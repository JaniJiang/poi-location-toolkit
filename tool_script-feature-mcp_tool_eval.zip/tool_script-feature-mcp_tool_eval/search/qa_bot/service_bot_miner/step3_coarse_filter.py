import pandas as pd
from sklearn.cluster import MiniBatchKMeans
from FlagEmbedding import FlagModel
from search.qa_bot.service_bot_intent.step3_onnx_infer import onnx_inference
from search.qa_bot.service_bot_intent.meta_info import MODEL_VERSION
from search.qa_bot.service_bot_miner.meta import *
from tqdm import tqdm
# 防止聚类时OpenBLAS使用的线程数超过了它在编译时设定的最大限制
import os
os.environ['OPENBLAS_NUM_THREADS'] = '64'


class Coarse_Filter:
    """粗筛模块：基于BERT模型过滤样本并进行聚类分析"""

    def __init__(self):
        # --- 配置参数 ---
        # 输入输出相关配置
        self.column_name = 'query'  # 需要处理的查询字段名称
        self.file_encoding = 'utf-8'  # 文件编码格式
        self.base_model_dir = "data/cloud_share/qabot_miner/bert_model/model/base_model/bert-base-chinese"  # 基础BERT模型路径
        # 导出的ONNX模型路径
        self.save_onnx_model_path = f"data/cloud_share/qabot_miner/bert_model/onnx_model/{MODEL_VERSION}/bert_model.onnx"

        # 初始化BGE模型配置
        self.bge_model_path = "data/cloud_share/qabot_miner/bge_model"

        # 数据文件路径
        self.query_data = DATA_MINER_FILE_PATHS["step3"]["input"]  # 输入数据源
        self.bert_output = DATA_MINER_FILE_PATHS["step3"]["output"]  # BERT处理结果输出

    def bert_filter(self):
        """BERT过滤流程：过滤低频样本并保存模型推理结果"""
        # 1. 读取原始数据（包含query和pv字段）
        df = pd.read_csv(self.query_data, header=0, encoding="utf-8")
        if not IF_RUN_LOW_PV:
            # 2. 过滤高频样本（仅保留pv<10的query）
            df = df[df['pv'] >= 10]
        else:
            # 2. 过滤低频样本（仅保留pv in [3,10)的query）
            df = df[(df['pv'] >= 3) & (df['pv'] < 10)]
        # 3. 过滤理想one
        df = df.dropna(subset=['query'])
        df = df[['理想one' not in query.lower() for query in df['query']]]
        data_list = df.to_dict("records")  # 转换为字典列表
        text_list = [item["query"] for item in data_list]  # 提取query文本列表

        # 3. 调用ONNX模型进行推理
        predictions = onnx_inference(
            self.base_model_dir,
            self.save_onnx_model_path,
            text_list
        )

        # 4. 保存推理结果到ccSV文件
        with open(self.bert_output, "w") as f:
            # 写入表头
            f.write("text,pv,pred_label,pred_prob,probs\n")
            # 按格式写入每条记录
            for idx, (text, pred_label, pred_prob, probs) in enumerate(predictions):
                item = data_list[idx]
                pv = item["pv"]
                f.write(f"{text.replace(',','')},{pv},{pred_label},{pred_prob},{probs}\n")
        print(f'bert粗筛结果已存储至：{self.bert_output}')

    def cluster_service_bot(self, input_file, output_file):
        """聚类分析模块：对BERT过滤后的样本进行K-Means聚类"""
        # 1. 读取数据
        df = pd.read_csv(input_file, encoding='utf-8', header=0)
        # 2. 筛选pv<10的样本（目标类别）
        df = df[df['pv'] < 10]
        if "kmeans_cluster" in df.columns:
            cluster_target = int(input("输入你想要聚类的目标簇id:"))
            df = df[df["kmeans_cluster"] == cluster_target]
        texts_to_cluster = df['query'].tolist()  # 提取待聚类文本

        # 3. 生成文本嵌入向量
        bge_model = FlagModel(
            self.bge_model_path,  # 使用的嵌入模型
            query_instruction_for_retrieval="为这个句子生成一个向量用于后续聚类",  # 模型指令
            use_fp16=True  # 使用半精度浮点加速
        )
        # 检查模型是否加在在GPU上
        print(f"BGE模型所在设备为:{bge_model.device}\n")
        embeddings = bge_model.encode(
            texts_to_cluster,
            batch_size=256,  # 批处理大小
            convert_to_numpy=True  # 转换为numpy数组
        )

        # 4. 肘部法则确定最佳K值
        # k_range = [5]  # 可选范围：[200, 250, 500, 1000, 2000, 3000, 3500, 4000, 4500, 5000]
        # sse = []  # 存储不同K值的SSE误差
        # print('-----------开始测试不同 K 值的指标----------')
        # for k in tqdm(k_range, desc="计算k值指标"):
        #     # 执行K-Means聚类
        #     kmeans_temp = MiniBatchKMeans(
        #     n_clusters=k,
        #     random_state=42,
        #     n_init=10,
        #     batch_size = 1024
        # )
        #     kmeans_temp.fit(embeddings)
        #     sse.append(kmeans_temp.inertia_)  # 记录SSE值

        # 5. 绘制肘部法则图
        # plt.figure(figsize=(10, 5))
        # plt.subplot(1, 2, 1)
        # plt.plot(k_range, sse, marker='o')
        # plt.xlabel('k')  # K值
        # plt.ylabel('SSE')  # 平方误差和
        # plt.grid(True)
        # plt.tight_layout()
        # plot_filename = 'data/cloud_share/search/qa_bot/qa_data_analyse/mine_data/step3_kmeans_k_selection_plots.png'
        # plt.savefig(plot_filename)
        # plt.close()  # 关闭图形对象
        # print(f"\nK 值选择图表已保存到: {plot_filename}")

        # 6. 用户指定最优K值
        # optimal_k = int(input("根据图表，请输入您选择的最佳 K 值: ") or 500)
        # print(f"\n使用 K = {optimal_k} 进行最终 K-Means 聚类...")

        # 7. 执行最终聚类
        print(f"Query数量为:{len(texts_to_cluster)}\n")
        n_clusters = int(input("根据上面的Query数量指定聚类数量:"))
        kmeans_final = MiniBatchKMeans(
            n_clusters=n_clusters,
            random_state=42,
            n_init=10,
            batch_size=1024
        )
        cluster_labels = kmeans_final.fit_predict(embeddings)  # 获取聚类标签

        cluster_counter = {}
        for cluster_label in tqdm(cluster_labels, desc="簇内数量统计"):
            cluster_counter[cluster_label] = cluster_counter.get(cluster_label, 0) + 1
        print("------聚类后簇数量情况--------")
        print(cluster_counter)
        print("-----------------------------")

        # 8. 保存聚类结果
        df['kmeans_cluster'] = cluster_labels  # 添加聚类标签列
        df_to_save = df[['query', 'pv', 'kmeans_cluster']]  # 保留必要字段
        df_to_save.to_csv(output_file, index=False, encoding='utf-8')
        print(f"\n聚类结果已保存到: {output_file}")


if __name__ == "__main__":
    filter = Coarse_Filter()
    # filter.bert_output = 'data/cloud/search/qa_bot/qa_data_analyse/bert_analyse/v3_test.csv'
    filter.bert_filter()
    # filter.tsv2csv(
    #     'data/cloud/search/qa_bot/qa_data_analyse/mine_data/step_3_bert_filtered.tsv')
    # filter.cluster_service_bot(
    #     'data/cloud/search/qa_bot/qa_data_analyse/mine_data/step_3_bert_filtered.csv',
    #     'data/cloud/search/qa_bot/qa_data_analyse/mine_data/mine_after_3_cluster.csv',
    #     )
