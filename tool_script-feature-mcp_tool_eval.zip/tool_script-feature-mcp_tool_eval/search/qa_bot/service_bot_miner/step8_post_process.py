import pandas as pd
from tqdm import tqdm
from search.qa_bot.service_bot_miner.meta import *
from search.qa_bot.service_bot_analyse.utils.prompt import *
import json
import requests
import json
import time
from utils.search_utils.semantic_deduplicate import compute_similarity


URL = "http://cockpit-qabot-lids-testtwo.ssai-apis-staging.chj.cloud:80/expert/query"
PAYLOAD = {
    "msgId": "wzy_test",
    "aiUserId": "wzy",
    "timestamp": 1730168715678,
    "voiceVersion": "6.0.0.0",
    "topK": 10,
    "extendData": {
        "vehicleConfigCode": "1,64,1,0,48,251,255,0,255,255,31,255,0,31,227,255,143",
        "vehicleModel": "X01",
        "userManualVersion": "10",
        "appVersion": {
            "help": "5000001"
        },
        "huOtaVersion": "1.0",
        "nightMode": 0,
        "spu": "ss2pro"
    },
    "input": {
        "text": "L7 Max怎么重启安全驾驶交互屏",
        "voiceImage": {
            "position": 0
        }
    }
}
HEADERS = {
    'User-Agent': 'Apifox/1.0.0 (https://www.apifox.cn)',
    'Content-Type': 'application/json'
}


class PostProcess:
    """工具后处理"""

    def __init__(self):
        # 输入输出路径
        self.input_path = DATA_MINER_FILE_PATHS["step8_Process"]["input"]  # 待处理数据源
        self.output_path = DATA_MINER_FILE_PATHS["step8_Process"]["output"]    # 处理结果输出

    def process(self):
        # load data
        data = pd.read_csv(self.input_path)
        duplicated_data = pd.read_csv("data/cloud_share/qabot_miner/labeling_new_knowledge.tsv")
        # 对已覆盖的问题，调用本地服务，看是不是链路的原因
        unsolved_list = []
        for index in tqdm(range(len(data))):
            item = data.iloc[index]
            PAYLOAD["input"]["text"] = item['representative_query']
            response = requests.request("POST", URL, headers=HEADERS, data=json.dumps(PAYLOAD))
            try:
                if item['knowledge_coverage'] == 1:
                    if (str(int(item['knowledge_id']))+":"+response.json()["data"][0]['question'] in item['recall_list']) and float(response.json()["data"][0]['score']) > 0.7:
                        print(item['representative_query'] + "already solved, matched question" +
                              response.json()["data"][0]['question'])
                        continue
                else:
                    # TODO:对未上线的，即生产中、审核中的「知识缺失」数据进行去重
                    res_score = compute_similarity(item['representative_query'], duplicated_data.iloc[:, 0].to_list())
                    max_score = max(res_score[:, :, 1][0])
                    if max_score > 0.8:
                        # 有重复的问题，标为2
                        max_question = duplicated_data.iloc[:, 0].to_list(
                        )[list(res_score[:, :, 1][0]).index(max_score)]
                        print("found duplicate question: ", max_question, "for query: ", item['representative_query'])
                        item["knowledge_coverage"] = 2
            except Exception as e:
                print(response.text)
            unsolved_list.append(item)
            time.sleep(1)
        pd.DataFrame(unsolved_list).to_json(self.output_path, orient="records", lines=True, force_ascii=False)


if __name__ == "__main__":
    print("############## Step9 Processing ##############")
    obj = PostProcess()
    obj.process()
