from search.qa_bot.service_bot_miner.meta import *
import pandas as pd
from tqdm import tqdm
import json
import csv
import sys
# --- 配置 ---


class DataAnalyse:
    def __init__(self):
        self.column_name = 'query'
        self.file_encoding = 'utf-8'

    def get_origin_info(self, service_bot_input, auto_input, output_file):
        df_service = pd.read_csv(
            service_bot_input, encoding='utf-8', header=0)

        if not IF_RUN_LOW_PV:
            candidates = df_service[(df_service['pv'] >= 10) &
                                    (df_service['pred_label'] == 1)]['text'].unique().tolist()
        else:
            candidates = df_service[(df_service['pv'] >= 3) & (df_service['pv'] < 10) &
                                    (df_service['pred_label'] == 1)]['text'].unique().tolist()
        query_map = {}
        chunksize = 10000  # 每次处理的行数，可以根据内存情况调整
        # 分块读取文件，指定 slot_li 列的数据类型为 str
        for chunk in pd.read_csv(auto_input, encoding='utf-8', header=0, chunksize=chunksize, dtype={'slot_li': str}):
            chunk = chunk.dropna()
            for _, row in chunk.iterrows():
                try:
                    content_list = json.loads(row['slot_li'])
                    if len(content_list) > 1:
                        continue
                    query = content_list[0].get('QUERY')
                except json.JSONDecodeError as e:
                    query = None
                    print(f"解析错误, 无法获取 query, 原始内容: {row['slot_li']}, 行号：{row.name}")
                    continue
                if query and query not in query_map:
                    # 仅保留第一次出现的匹配项
                    query_map[query] = {
                        'output': row['output'],
                        'knowledge_search_result': row['knowledge_search_result']
                    }

        print("Filtering for matches...")
        results = []
        for text in candidates:
            if text in query_map:
                data = query_map[text]
                results.append({
                    'query': text,
                    'output': data['output'],
                    'knowledge_search_result': data['knowledge_search_result']
                })
        df_result = pd.DataFrame(results)
        df_result.to_csv(output_file, index=False, encoding='utf-8')

        print(f"Saving results to '{output_file}'...")

    def jsonl2csv(self, jsonl_input, csv_output):
        # 读取 JSONL 并提取字段
        data_rows = []
        with open(jsonl_input, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    item = json.loads(line.strip())
                    query = item.get("query", "")          # 提取 query
                    gpt_label = item.get("gpt_label", "")  # 提取 gpt_label
                    analyse = item.get("label_analyse", "")      # 提取 analyse
                    knowledge_search_result = item.get("knowledge_search_result", "")  # 提取 knowledge_search_result
                    output = item.get("output", "")  # 提取 output
                    data_rows.append({
                        "query": query,
                        "analyse": analyse,
                        "gpt_label": gpt_label,
                        "output": output,
                        "knowledge_search_result": knowledge_search_result
                    })
                except json.JSONDecodeError as e:
                    print(f"解析错误：{line[:50]}... 错误信息：{str(e)}")

        # 写入 CSV 文件
        with open(csv_output, 'w', newline='', encoding='utf-8') as f:
            fieldnames = ["query", 'analyse', "gpt_label", 'output', 'knowledge_search_result']
            writer = csv.DictWriter(f, fieldnames=fieldnames)

            # 写入表头
            writer.writeheader()

            # 写入数据行
            for row in data_rows:
                writer.writerow(row)


if __name__ == "__main__":
    data_review = DataAnalyse()
    # data_review.get_origin_info(DATA_MINER_FILE_PATHS["step3.5"]["input"],
    #                             DATA_MINER_FILE_PATHS["step3.5"]["autosearch_info"], DATA_MINER_FILE_PATHS["step3.5"]["output_csv"])
