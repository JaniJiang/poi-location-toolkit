import hashlib
from asyncio import Semaphore
from utils.llm_utils.serverless_function import request_llm_async, RateLimiter
from search.qa_bot.service_bot_analyse.prompt import *
from search.qa_bot.service_bot_analyse.meta import *
from utils.nlp_utils.embedding import get_batch_embedding
from utils.search_utils.memory_qdrant import MemoryQdrant
from utils.file_utils import read_jsonl_file
import os
import sys
import json
import asyncio
import aiohttp
from tqdm import tqdm


class EvalCluster:
    """评估聚类选取出的未覆盖query的重要性"""

    def __init__(self):
        self.uncover_all = f"{DATA_DIR}/{20250306}/step9_uncover_query.jsonl"
        # 通过聚类方式抽取的要添加的数据
        self.vital_query = f"{DATA_DIR}/{DATE}/step9_vital_query.jsonl"
        # 随机抽取的要添加的数据
        self.random_query = f"{DATA_DIR}/{DATE}/step9_random_query.jsonl"
        # 添加新知识后的新数据库
        self.new_knowledge = f"{DATA_DIR}/{DATE}/eval_knowledge_index.jsonl"
        # 随机抽取Query构建的数据库
        self.new_knowledge1 = f"{DATA_DIR}/{DATE}/eval_knowledge_index1.jsonl"
        # 原有知识库
        self.origin_knowledge = f"{DATA_DIR}/{DATE}/step5_knowledge_index.jsonl"
        self.vital_cover_results = f"{DATA_DIR}/{DATE}/eval_vital_cover_results.jsonl"
        self.random_cover_results = f"{DATA_DIR}/{DATE}/eval_random_cover_results.jsonl"
        self.origin_cover_results = f"{DATA_DIR}/{DATE}/eval_origin_cover_results.jsonl"
        self.recall_num = 5
        # gpt-4o | claude-3_5-sonnet | deepseek-v3 | deepseek-r1 | deepseek-r1-distill-qwen-32b
        self.model_name = "gpt-4o"
        self.rank_type = "llm"  # relevance | llm
        self.max_concurrent = 10
        self.qps = 3    # 推荐不大于4

    # 查看知识覆盖工具的异常样本（同样Query不同结果）
    def analyse_tool(self):
        # 1. 将A中的query映射到has_item状态（字典）
        vital_result = read_jsonl_file(self.vital_cover_results)
        vital_dict = {item['query']: item['has_item'] for item in vital_result}

        origin_result = read_jsonl_file(self.origin_cover_results)
        # 2. 遍历B中的每个元素，筛选符合条件的query
        result = []
        for item in origin_result:
            if item['has_item'] == '1':  # B中的has_item必须为1
                query = item['query']
                if vital_dict.get(query, 1) == '0':  # A中存在该query且has_item为0
                    result.append(query)
        print(result)

    # 查看不同依赖不同方式补充知识后的知识覆盖率
    def count_cover_rate(self):
        vital_result = read_jsonl_file(self.vital_cover_results)
        random_result = read_jsonl_file(self.random_cover_results)
        origin_result = read_jsonl_file(self.origin_cover_results)
        vital_count = 0
        ramdom_count = 0
        origin_count = 0
        for result in vital_result:
            vital_count += 1 if result['has_item'] == '1' else 0
        for result in random_result:
            ramdom_count += 1 if result['has_item'] == '1' else 0
        for result in origin_result:
            origin_count += 1 if result['has_item'] == '1' else 0
        print(
            f'cluster方法的覆盖数量为：{vital_count}，覆盖率为:{vital_count/len(vital_result)}')
        print(
            f'random方法的覆盖数量为：{ramdom_count}，覆盖率为:{ramdom_count/len(random_result)}')
        print(
            f'origin的覆盖数量为：{origin_count}，覆盖率为:{origin_count/len(origin_result)}')

    # 从新数据库检索至输出知识覆盖率的过程
    def process(self):
        # 读取query数据
        test_query = read_jsonl_file(self.uncover_all)
        test_query_list = []
        test_query_embed = []
        for query in test_query:
            test_query_list.append(query["query"])
            test_query_embed.append(query["vector"])
        # 读取index数据
        # origin_index = self.build_index(self.origin_knowledge)
        vital_index = self.build_index(self.new_knowledge)  # 采用聚类添加获得的知识库
        random_index = self.build_index(self.new_knowledge1)  # 采用随机抽取添加获得的知识库
        # 多线程调用
        loop = asyncio.get_event_loop()
        loop.run_until_complete(self.process_async(
            test_query_list, test_query_embed, vital_index, random_index, max_retries=3))
        # loop.run_until_complete(self.process_async(
        #     test_query_list, test_query_embed, origin_index, None, max_retries=3))

    async def process_async(self, input_list, input_embed, vital_index, random_index, max_retries):
        query_embedding_list = input_embed
        rate_limiter = RateLimiter(self.qps)
        semaphore = Semaphore(self.max_concurrent)  # 限制最大并发数为 max_concurrent
        async with aiohttp.ClientSession() as session:
            # 将query和query embedding分别传入异步函数
            tasks = [self.process_item_async(rate_limiter, vital_index,
                                             random_index, semaphore, session,
                                             input_list[index], query_embedding_list[index], max_retries)
                     for index in range(len(input_list))]
            # with open(self.origin_cover_results, 'w', encoding='utf-8') as f_origin:
            with open(self.vital_cover_results, 'w', encoding='utf-8') as f_vital, \
                    open(self.random_cover_results, 'w', encoding='utf-8') as f_random:
                for item, future in tqdm(zip(input_list, asyncio.as_completed(tasks)), total=len(tasks), desc="Writting the results of LLM:"):
                    # 获取两个结果
                    result_vital, result_random = await future
                    # result_origin = await future

                    # f_origin.write(json.dumps(
                    #     result_origin, ensure_ascii=False) + "\n")
                    # f_origin.flush()
                    # 写入vital结果到文件
                    f_vital.write(json.dumps(
                        result_vital, ensure_ascii=False) + "\n")
                    f_vital.flush()

                    # 写入random结果到文件
                    f_random.write(json.dumps(
                        result_random, ensure_ascii=False) + "\n")
                    f_random.flush()

    async def process_item_async(self, rate_limiter, vital_index, random_index, semaphore, session, query, item_embedding, max_retries):
        # 处理vital索引
        vital_item_list = vital_index.search(
            item_embedding, top_k=self.recall_num)
        has_item_vital, analyse_vital, matched_item_vital = await self.do_rank(query, vital_item_list, rate_limiter, semaphore, session, max_retries)
        formatted_vital = {
            "query": query,
            "has_item": has_item_vital,
            "LLM_analyse": analyse_vital,
            "score": float(matched_item_vital["score"]),
            "payload": matched_item_vital["payload"],
        }

        # 处理random索引
        random_item_list = random_index.search(
            item_embedding, top_k=self.recall_num)
        has_item_random, analyse_random, matched_item_random = await self.do_rank(query, random_item_list, rate_limiter, semaphore, session, max_retries)
        formatted_random = {
            "query": query,
            "has_item": has_item_random,
            "LLM_analyse": analyse_random,
            "score": float(matched_item_random["score"]),
            "payload": matched_item_random["payload"],
        }

        return formatted_vital, formatted_random  # 返回两个结果的元组

    def build_index(self, index_path):
        print(f"build_index: {index_path}")
        text_index = MemoryQdrant()
        index_list = read_jsonl_file(index_path)
        for point in tqdm(index_list, desc='Building Index'):
            text_index.add_points([point])
        return text_index

    async def do_rank(self, query, item_list, rate_limiter, semaphore, session, max_retries):
        if len(item_list) == 0:
            return {"", "0", "", "", {}}
        return await self.do_llm_rank(query, item_list, rate_limiter, semaphore, session, max_retries)

    async def do_llm_rank(self, query, item_list, rate_limiter, semaphore, session, max_retries):
        for item in item_list:
            history = [
                SYSTEM_PROMPT_EVAL_CLUSTER,
                USER_PROMPT_EVAL_CLUSTER.format(
                    question=query, target_q=item['payload']["question"][0])
            ]
            try:
                payload, response_data = await request_llm_async(rate_limiter, semaphore, session, max_retries, history, model=self.model_name, n=1, temperature=0)
                # print(json.dumps({"payload": payload, "response": response_data}, ensure_ascii=False))
                question_new_str = response_data["choices"][0]["message"]["content"]
                question_new_list = json.loads(question_new_str)
            except Exception as e:
                print("LLM原来回复直接Json加载失败，对回复进行标准化后加载")
                try:
                    question_new_list = json.loads(question_new_str.strip().strip(
                        '`').replace("json", '').replace("\n", ""))
                except Exception as e:
                    print(f'两种解析方式均失败：{e}')
                    continue
            if question_new_list["result"] == 1:
                return "1", question_new_list["analyse"], item
            break  # TODO: 当前只处理了第一条
        return "0", question_new_list["analyse"], item_list[-1]

    # 构建新的数据库
    def build_new_knowledge(self):
        print(f"Building New Knowledge")
        new_knowledge_list = read_jsonl_file(self.vital_query)
        # 逐条处理knowledge生成索引数据
        with open(self.origin_knowledge, 'r', encoding='utf-8') as f_in, \
                open(self.new_knowledge, 'w', encoding='utf-8') as f_out:
            # 先将原有的知识存入f_out中
            for line in tqdm(f_in, desc="Copy origin knowledge"):
                f_out.write(line)

            for i in tqdm(range(0, len(new_knowledge_list), BATCH_SIZE), desc="index"):
                # 获取Knowledge字段
                batch_question_list = []
                for knowledge_item in new_knowledge_list[i: (i + BATCH_SIZE)]:
                    query = knowledge_item.get("query")
                    batch_question_list.append(query)
                # 获取索引文本对应的向量
                try:
                    batch_embedding_list = get_batch_embedding(
                        batch_question_list, DIM, BATCH_SIZE)
                except:
                    print("get_batch_embedding failed:", batch_question_list)
                    continue
                if len(batch_question_list) != len(batch_embedding_list):
                    continue
                # 逐条生成qdrant索引数据
                for i, batch_question in enumerate(batch_question_list):
                    index_id = self.generate_index_id(batch_question)
                    batch_embedding = batch_embedding_list[i]
                    qdrant_item = {
                        "id": index_id,
                        "vector": batch_embedding,
                        "payload": {"question": [batch_question]}
                    }
                    f_out.write(json.dumps(
                        qdrant_item, ensure_ascii=False) + "\n")

    def generate_index_id(self, question):
        index_id_origin = question.lower()
        index_id = hashlib.md5(index_id_origin.encode("utf-8")).hexdigest()
        return index_id


if __name__ == "__main__":
    obj = EvalCluster()
    # obj.build_new_knowledge()
    # obj.process()
    obj.count_cover_rate()
    # obj.analyse_tool()
