import json
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D  # 必须导入3D绘图模块
from sklearn.manifold import TSNE
from sklearn.metrics.pairwise import rbf_kernel
from sklearn.mixture import GaussianMixture
from search.qa_bot.service_bot_analyse.meta import *
import os
from collections import defaultdict


class Distribution_Tool:
    """分布评判工具：评判两天之间问题的分布是否一致"""

    def __init__(self):
        self.uncover_query1 = f"{DATA_DIR}/20250321/step9_uncover_query.jsonl"
        self.uncover_query2 = f"{DATA_DIR}/20250306/step9_uncover_query.jsonl"

    def load_jsonl_to_array(self, file_path):
        vectors = []
        queries = []
        with open(file_path, 'r') as f:
            for line in f:
                data = json.loads(line)
                vectors.append(data['vector'])
                queries.append(data.get('query', ''))  # 假设JSON包含 "query" 字段
        return np.array(vectors), queries

    def select_n_components(self, X, auto=True, max_components=90):
        if auto:
            bic = []
            for n in range(70, max_components+1):
                gmm = GaussianMixture(n_components=n, random_state=42)
                gmm.fit(X)
                bic.append(gmm.bic(X))
            return np.argmin(bic) + 70
        else:
            return max_components

    def process(self):
        # 加载数据并获取查询文本
        vectors_day1, queries_day1 = self.load_jsonl_to_array(
            self.uncover_query1)
        vectors_day2, queries_day2 = self.load_jsonl_to_array(
            self.uncover_query2)

        n_components_day1 = self.select_n_components(
            vectors_day1, auto=False, max_components=100)
        n_components_day2 = self.select_n_components(
            vectors_day2, auto=False, max_components=100)
        n_components = min(n_components_day1, n_components_day2)

        # 聚类
        gmm_day1 = GaussianMixture(n_components=n_components, random_state=42)
        labels_day1 = gmm_day1.fit_predict(vectors_day1)

        gmm_day2 = GaussianMixture(n_components=n_components, random_state=42)
        labels_day2 = gmm_day2.fit_predict(vectors_day2)

        # 新增：保存查询和标签到JSONL文件（按簇ID排序）
        self.write_clustered_queries(
            queries_day1, labels_day1, "day1", n_components)
        self.write_clustered_queries(
            queries_day2, labels_day2, "day2", n_components)

        gamma = 0.5
        mmd_value = self.compute_mmd(vectors_day1, vectors_day2, gamma=gamma)

        perplexity = 15
        tsne = TSNE(n_components=3, perplexity=perplexity,
                    random_state=42)  # 修改为3D

        combined_X = np.concatenate([vectors_day1, vectors_day2])
        embedded = tsne.fit_transform(combined_X)
        embedded_day1 = embedded[:len(vectors_day1)]
        embedded_day2 = embedded[len(vectors_day1):]

        save_dir = f"{DATA_DIR}/distribution_img"
        os.makedirs(save_dir, exist_ok=True)
        save_path = os.path.join(
            save_dir,
            f"tsne3d_gmm_comparison_n{n_components}_gamma{gamma}_perplex{perplexity}.png"
        )

        # 新增三维可视化实现
        fig = plt.figure(figsize=(14, 6), dpi=100)  # 增大画布尺寸

        # 第一天的3D分布
        ax1 = fig.add_subplot(121, projection='3d')
        sc1 = ax1.scatter(
            embedded_day1[:, 0],
            embedded_day1[:, 1],
            embedded_day1[:, 2],
            c=labels_day1,
            cmap='viridis',
            alpha=0.6,
            s=15
        )
        ax1.set_title(f'Day1 Clustering (n={n_components})')
        ax1.view_init(elev=30, azim=45)  # 设置视角
        fig.colorbar(sc1, ax=ax1, shrink=0.6, label='Cluster ID')

        # 第二天的3D分布
        ax2 = fig.add_subplot(122, projection='3d')
        sc2 = ax2.scatter(
            embedded_day2[:, 0],
            embedded_day2[:, 1],
            embedded_day2[:, 2],
            c=labels_day2,
            cmap='viridis',
            alpha=0.6,
            s=15
        )
        ax2.set_title(f'Day2 Clustering (n={n_components})')
        ax2.view_init(elev=30, azim=45)  # 保持相同视角
        fig.colorbar(sc2, ax=ax2, shrink=0.6, label='Cluster ID')

        plt.suptitle(
            f'MMD: {mmd_value:.4f} | n_components: {n_components}', y=1.05)
        plt.tight_layout()

        plt.savefig(save_path, bbox_inches='tight', dpi=300)
        plt.close()

        print(
            f"动态选择簇数: {n_components}（Day1: {n_components_day1}, Day2: {n_components_day2}）")
        print(f"MMD值: {mmd_value:.4f}")
        print(f"三维图像已保存至: {os.path.abspath(save_path)}")

    def write_clustered_queries(self, queries, labels, date_str, n_components):
        """将查询按簇大小排序后写入JSONL文件（簇越大越先写）"""
        save_dir = f"{DATA_DIR}/cluster_result_for_compare"
        os.makedirs(save_dir, exist_ok=True)
        save_path = os.path.join(
            save_dir,
            f"clustered_queries_{date_str}_n{n_components}_sorted.jsonl"
        )

        # 按簇分组并统计大小
        clusters = defaultdict(list)
        for query, label in zip(queries, labels):
            clusters[label].append(query)

        # 按簇大小降序排序簇ID（簇ID相同则按数字升序排列）
        sorted_clusters = sorted(
            clusters.keys(),
            key=lambda x: (-len(clusters[x]), x)  # 先按大小降序，再按簇ID升序
        )

        with open(save_path, 'w') as f:
            for cluster_id in sorted_clusters:
                for query in clusters[cluster_id]:
                    json_line = {
                        "query": query,
                        "cluster_id": int(cluster_id)
                    }
                    f.write(json.dumps(json_line, ensure_ascii=False) + '\n')

        print(f"已保存 {date_str} 的聚类结果到: {os.path.abspath(save_path)}")

    def compute_mmd(self, X, Y, gamma=1.0):
        K_XX = rbf_kernel(X, X, gamma)
        K_YY = rbf_kernel(Y, Y, gamma)
        K_XY = rbf_kernel(X, Y, gamma)

        m, n = X.shape[0], Y.shape[0]
        mmd2 = (np.sum(K_XX)/(m*m) + np.sum(K_YY)/(n*n)
                - 2*np.sum(K_XY)/(m*n))
        return mmd2


if __name__ == "__main__":
    obj = Distribution_Tool()
    # obj.process()
