import pandas as pd
from collections import Counter
import time
import json
from search.qa_bot.service_bot_miner.meta import *


class QueryCounter:
    """Query统计工具：用于统计CSV文件中指定列的query出现频率（PV）"""

    def __init__(self):
        # --- 配置参数 ---
        # 输入文件路径（CSV格式）
        self.input_csv_path = DATA_MINER_FILE_PATHS["step2"]["input"]  # <--- 修改为你的输入文件名
        # 输出文件路径（CSV格式）
        self.output_csv_path = DATA_MINER_FILE_PATHS["step2"]["output"]  # <--- 输出文件名
        # 每次处理的行数（内存优化参数）
        self.chunk_size = 100000  # 根据实际内存调整，建议10万-100万行
        # query所在列的索引（从0开始计数）
        self.query_column_index = 1  # 第一列为0，需要根据实际CSV结构调整
        # 输入文件编码格式（常见值：utf-8, gbk）
        self.input_encoding = 'utf-8'  # 若出现乱码请修改为实际编码格式
        # 输出文件编码格式
        self.output_encoding = 'utf-8'  # 推荐使用统一编码格式
        # --- 初始化计数器 ---
        self.total_counts = Counter()  # 用于累计所有query的出现次数

    def process_file(self):
        """执行文件处理流程：读取CSV -> 提取query -> 统计PV -> 保存结果"""
        print(f"开始处理文件: {self.input_csv_path}")
        start_time = time.time()
        processed_rows = 0
        api_to_orig = {}
        try:
            # 使用分块方式读取大CSV文件（避免内存溢出）
            # usecols=[query_column_index] 只读取需要的列
            # names=['slot_li'] 为读取的列指定临时列名
            # on_bad_lines='skip' 跳过格式错误的行（可选：'warn'警告或'error'报错）
            reader = pd.read_csv(
                self.input_csv_path,
                chunksize=self.chunk_size,
                usecols=[self.query_column_index, 0],
                header=0,  # 如果CSV有表头请保留header=0，否则设为None
                names=['query', 'slot_li'],  # 列名需与usecols对应
                encoding=self.input_encoding,
                on_bad_lines='skip'
            )

            # 逐块处理CSV数据
            for i, chunk in enumerate(reader):
                query_list = []
                chunk = chunk.dropna()
                for index, row in chunk.iterrows():
                    content_str = row['slot_li']
                    # 提取API查询内容
                    try:
                        slot_li = json.loads(content_str)
                        if len(slot_li) > 1:
                            continue  # 跳过包含多个slot的情况
                        api_query = slot_li[0].get('QUERY', None)
                        if api_query is None:
                            continue  # 跳过没有QUERY字段的数据
                    except Exception as e:
                        print(f'解析出现错误，错误slot_li为:{content_str}')
                        continue
                    if api_query in api_to_orig:
                        if api_query not in api_to_orig[api_query]:
                            api_to_orig[api_query].append(row['query'])
                    else:
                        api_to_orig[api_query] = [row['query']]
                    query_list.append(api_query)  # 将提取的query加入列表
                # 对当前块中的query进行计数
                chunk_counts = Counter(query_list)
                # 更新总统计结果
                self.total_counts.update(chunk_counts)

                processed_rows += len(chunk)
                print(f"已处理 {processed_rows} 行 (块 {i + 1})...")

            print("所有块处理完毕，正在整理结果...")

            # 将统计结果转换为DataFrame
            # output_df = pd.DataFrame(self.total_counts.items(), columns=['query', 'pv'])
            output_df = pd.DataFrame({
                "query": list(api_to_orig.keys()),
                "orig_query": list(api_to_orig.values()),
                "pv": [len(i) for i in api_to_orig.values()]
            })
            # 按PV降序排序（可选）
            output_df = output_df.sort_values(by='pv', ascending=False)

            # 保存结果到CSV文件
            output_df.to_csv(self.output_csv_path, index=False, encoding=self.output_encoding)

            end_time = time.time()
            print(f"处理完成！结果已保存到: {self.output_csv_path}")
            print(f"总耗时: {end_time - start_time:.2f} 秒")
            print(f"共统计出 {len(output_df)} 条独立 query。")

        except FileNotFoundError:
            print(f"错误：输入文件 '{self.input_csv_path}' 未找到。")
        except Exception as e:
            print(f"处理过程中发生错误: {e}")


if __name__ == "__main__":
    counter = QueryCounter()
    counter.process_file()
