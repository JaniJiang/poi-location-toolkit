from pathlib import Path
from datetime import datetime, timedelta

IF_RUN_LOW_PV = bool(True)
MINE_DAY_START = datetime(2025, 5, 12)
MINE_DAY_END = MINE_DAY_START + timedelta(days=30)
MODEL_VERSION = 'v3_20250424'  # v3_20250424, v1_20250411
# 数据存储路径（各step处理的数据，频繁变动的数据）
if IF_RUN_LOW_PV:
    MINE_BASE_DATA_DIR = Path(
        f'data/cloud_share/qabot_miner/wuzhenyan/mine_data_{MINE_DAY_START.strftime("%m_%d")}_{MINE_DAY_END.strftime("%m_%d")}/lowpv')
else:
    MINE_BASE_DATA_DIR = Path(
        f'data/cloud_share/qabot_miner/wuzhenyan/mine_data_{MINE_DAY_START.strftime("%m_%d")}_{MINE_DAY_END.strftime("%m_%d")}')
# low pv和high pv公用数据存储路径
PUBLIC_DATA_DIR = Path(
    f'data/cloud_share/qabot_miner/wuzhenyan/mine_data_{MINE_DAY_START.strftime("%m_%d")}_{MINE_DAY_END.strftime("%m_%d")}')
# 固定数据存储路径（数据索引等，不频繁变动的数据）
INDEX_DIR = Path("data/cloud_share/qabot_miner/qa_index")
# 文件路径映射
DATA_MINER_FILE_PATHS = {
    "step2": {
        "input": PUBLIC_DATA_DIR / "autosearch_data_2025-05-13_to_2025-06-11.csv",
        "output": MINE_BASE_DATA_DIR / "mine_after_2.csv"
    },
    "step3": {
        "input": MINE_BASE_DATA_DIR / "mine_after_2.csv",
        "output": MINE_BASE_DATA_DIR / "mine_after_3.csv",
        "cluster_output": MINE_BASE_DATA_DIR / "mine_after_3_clustered.csv"
    },
    "step3.5": {
        "autosearch_info": PUBLIC_DATA_DIR / "autosearch_data_2025-05-13_to_2025-06-11.csv",
        "input": MINE_BASE_DATA_DIR / "mine_after_3.csv",
        "output_csv": MINE_BASE_DATA_DIR / "mine_ready_for_4.csv",
        "output_jsonl": MINE_BASE_DATA_DIR / "mine_ready_for_4.jsonl"
    },
    "step4": {
        "input": MINE_BASE_DATA_DIR / "mine_ready_for_4.jsonl",
        "output": MINE_BASE_DATA_DIR / "mine_after_4.jsonl"
    },
    "step5": {
        "input": MINE_BASE_DATA_DIR / "mine_after_4.jsonl",
        "output": MINE_BASE_DATA_DIR / "mine_after_5.jsonl"
    },
    "step6_GMM": {
        "input": MINE_BASE_DATA_DIR / "mine_after_5.jsonl",
        "output": MINE_BASE_DATA_DIR / "mine_after_6_GMM.jsonl"
    },
    "step6_LLM": {
        "input": MINE_BASE_DATA_DIR / "mine_after_6_GMM.jsonl",
        "pv_info": MINE_BASE_DATA_DIR / "mine_after_3.csv",
        "output": MINE_BASE_DATA_DIR / "mine_after_6_LLM.jsonl"
    },
    "step7": {
        "input": MINE_BASE_DATA_DIR / "data.jsonl",
        "output": INDEX_DIR / "step5_knowledge_index.qa.jsonl"
    },
    "step7_SEMFIL": {
        "input": MINE_BASE_DATA_DIR / "mine_after_6_LLM.jsonl",
        "output": MINE_BASE_DATA_DIR / "mine_after_6_LLM_filtered.jsonl"
    },
    "step7_GETINFO": {
        "input": MINE_BASE_DATA_DIR / "mine_after_6_LLM_filtered.jsonl",
        "metadata_path": MINE_BASE_DATA_DIR / "mine_after_2.csv",
        "output": MINE_BASE_DATA_DIR / "mine_after_6_LLM_filtered_metaData.jsonl"
    },
    "step8": {
        "input": MINE_BASE_DATA_DIR / "mine_after_6_LLM_filtered_metaData.jsonl",
        "knowledge_info": INDEX_DIR / "step5_knowledge_index.qa.jsonl",
        "output": MINE_BASE_DATA_DIR / "mine_all_done_test.csv"
    },
    "step8_Process": {
        "input": MINE_BASE_DATA_DIR / "mine_all_done_test.csv",
        "output": MINE_BASE_DATA_DIR / "mine_after_6_LLM_filtered_metaData_processed.jsonl"
    },
    "step9_Generate": {
        "input": MINE_BASE_DATA_DIR / "mine_after_6_LLM_filtered_metaData_processed.jsonl",
        "output": MINE_BASE_DATA_DIR / "general_question_generate.jsonl"
    }
}
