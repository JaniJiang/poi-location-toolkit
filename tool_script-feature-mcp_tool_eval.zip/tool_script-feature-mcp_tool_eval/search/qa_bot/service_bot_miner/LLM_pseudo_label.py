import json
from tqdm import tqdm
from tqdm.asyncio import tqdm_asyncio
import pandas as pd
import asyncio
import aiohttp

from utils.file_utils import read_jsonl_file
from utils.llm_utils.serverless_function import request_llm, request_llm_async, RateLimiter
from search.qa_bot.service_bot_miner.prompt import *
from asyncio import Semaphore, gather

DATA_DIR = 'data/cloud/search/qa_bot/qa_data_analyse/bert_analyse'


class Pseudo_Label:
    """LLM制作伪标签：通过LLM标注服务专家query"""

    def __init__(self):
        self.input_path = f"{DATA_DIR}/intent_data.csv"
        self.output_path = f"{DATA_DIR}/new_intent_data.csv"
        self.model_name = "gpt-4o"  # gpt-4o | claude-3_5-sonnet | deepseek-v3 | deepseek-r1 | deepseek-r1-distill-qwen-32b
        self.max_concurrent = 10
        self.qps = 4    # 推荐不大于4

    def process(self):
        # 提取&解析线上日志结果
        df = pd.read_csv(self.input_path, encoding="utf-8")
        text_data_list = df['text'].tolist()[20000:]
        print("input list:", len(text_data_list))
        input_list = []
        for i in range(0, len(text_data_list), 10):
            batch_data = text_data_list[i:i + 10]
            input_list.append(batch_data)
        # 多线程调用
        loop = asyncio.get_event_loop()
        loop.run_until_complete(self.process_async(input_list, max_retries=3))

    async def process_async(self, input_list, max_retries):
        rate_limiter = RateLimiter(self.qps)
        semaphore = Semaphore(self.max_concurrent)  # 限制最大并发数为 max_concurrent
        async with aiohttp.ClientSession() as session:
            tasks = [self.process_item_async(rate_limiter, semaphore, session, batch_querys, max_retries) for
                     batch_querys in input_list]
            results = await gather(*tqdm_asyncio(tasks, desc="Processing batches", total=len(tasks)), return_exceptions=True)
            with open(self.output_path, 'w', encoding='utf-8') as f:
                f.write("text,new_label,confidence\n")
                for response in tqdm(results, total=len(results), desc="Writing results"):
                    # 处理可能的异常（如果 return_exceptions=True）
                    if isinstance(response, Exception):
                        print(f"一个任务发生异常，跳过该结果：{response}")
                        continue  # 跳过发生异常的任务结果
                    # 检查响应是否为空列表
                    if response == []:
                        continue
                    # response 是 process_item_async 返回的结果列表
                    # 遍历 response 中的每一个 item
                    for item in response:
                        f.write(f"{item['query']},{item['label']},{item['confidence']}\n")

    async def process_item_async(self, rate_limiter, semaphore, session, batch_querys, max_retries):
        history = [
            SYSTEM_PROMPT_INTENT,
            USER_PROMPT_INTENT.format(querys=batch_querys)
        ]
        try:
            payload, response_data = await request_llm_async(rate_limiter, semaphore, session, max_retries, history, model=self.model_name, n=1, temperature=0)
            question_new_str = response_data["choices"][0]["message"]["content"]
            question_new_list = json.loads(question_new_str)
        except Exception as e:
            try:
                question_new_list = json.loads(question_new_str.strip().strip(
                    '`').replace("json", '').replace("\n", ""))
            except Exception as e:
                question_new_list = []
                print(f'直接解析出错:{e}')
        # 回写判断
        return question_new_list


if __name__ == "__main__":
    print("############## Processing ##############")
    obj = Pseudo_Label()
    obj.process()

# python -m search.qa_bot.qa_data_analyse.step2_query_intent
