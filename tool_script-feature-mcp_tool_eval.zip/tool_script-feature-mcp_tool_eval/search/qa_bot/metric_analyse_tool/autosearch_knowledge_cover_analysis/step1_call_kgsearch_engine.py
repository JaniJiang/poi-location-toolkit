import json
import pandas as pd
from utils.search_utils.call_kgsearch import get_response_with_api

if __name__ == "__main__":
    input_path = "data/cloud_share/search/rag/autosearch_knowledge_cover_analysis/公司品牌汽车问答专项测试集-0827-v1.xlsx"
    output_path = "data/cloud_share/search/rag/autosearch_knowledge_cover_analysis/1_result.csv"
    df = pd.read_excel(input_path)
    response_list = []
    for i in range(len(df)):
        print(i)
        api = json.loads(df["model_1b_output"][i])
        response = get_response_with_api(api)
        if response:
            response_list.append(response["data"]["bot_data"])
        else:
            response_list.append(None)
    df["recall_response"] = response_list
    df.to_csv(output_path, index=False)

# python -m search.qa_bot.metric_analyse_tool.recall_benefit_eval.step1_call_kgsearch_engine
