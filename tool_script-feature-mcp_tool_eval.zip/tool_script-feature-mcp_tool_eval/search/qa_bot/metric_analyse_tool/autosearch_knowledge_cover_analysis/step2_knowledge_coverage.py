from search.qa_bot.service_bot_analyse.steps.step6_knowledge_coverage import KnowledgeCoverage
from search.qa_bot.service_bot_analyse.utils.prompt import *
from utils.llm_utils.serverless_function import request_llm, request_llm_async, RateLimiter
from tqdm.asyncio import tqdm_asyncio
from asyncio import Semaphore
import asyncio
import aiohttp
import pandas as pd
import json
import ast


class Coverage(KnowledgeCoverage):
    def __init__(self):
        super().__init__()

    async def do_rank_async(self, query, item_list, rate_limiter, semaphore, session, max_retries):
        if len(item_list) == 0:
            return "0", "", {}
        if self.rank_type == "llm":  # 通过LLM判断相关性
            return await self.do_llm_ran_async(query, item_list, rate_limiter, semaphore, session, max_retries)
        else:  # 通过相关性阈值阶段
            return await self.do_relevance_rank(query, item_list, rate_limiter, semaphore, session, max_retries)

    async def process_item_async(self, rate_limiter, qa_item_list, rag_item_list, semaphore, session, index, item, max_retries):
        # inference
        has_item, explain, matched_item = await self.do_rank_async(item, rag_item_list, rate_limiter, semaphore, session, max_retries)
        # rag inference
        # has_item_rag, matched_item_rag = await self.do_rank(item, rag_item_list, rate_limiter, semaphore, session, max_retries)
        try:
            qid = matched_item["payload"]["question_id"]
        except Exception as e:
            qid = matched_item
        formated_item = {
            "query": item,
            "explain": explain,
            "has_item": has_item,
            "score": 0.0,
            "payload": {},
            "question_id": qid,
            "recall_list": json.dumps(qa_item_list, ensure_ascii=False),
        }
        return formated_item, index

    async def do_llm_ran_async(self, query, item_list, rate_limiter, semaphore, session, max_retries):
        item_list = ast.literal_eval(item_list)
        # query_list = ast.literal_eval(query)
        if not item_list:
            return "0", "", item
        # 选择top1推理
        obs = []
        for item in item_list:
            obs.append({
                "title": item.get("title"),
                "content": item.get("content")
            })
        history = [
            SYSTEM_PROMPT_STAGE_6_NEW,
            USER_PROMPT_STAGE_6_NEW.format(
                question=query,  knowledge=obs)
        ]
        # 推理
        try:
            payload, response_data = await request_llm_async(rate_limiter, semaphore, session, max_retries, history, model=self.model_name, n=1, temperature=0)
            # print(json.dumps({"payload": payload, "response": response_data}, ensure_ascii=False))
            question_new_str = response_data["choices"][0]["message"]["content"]
            question_new_list = json.loads(question_new_str)
        except Exception as e:
            print(e)
            try:
                question_new_list = json.loads(question_new_str.strip().strip(
                    '`').replace("json", '').replace("\n", ""))
            except Exception as e:
                print(e)
                # 推理失败返回空
                return "0", "", item
        return question_new_list.get("result"), question_new_list["analyse"], question_new_list.get("id")


def process(input_path, output_path):
    df = pd.read_csv(input_path)
    query_text_list = df[["api_query"]]
    recall_list_rag = df["recall_response"].apply(lambda x: x if pd.notnull(x) else [])
    # 多线程调用
    loop = asyncio.get_event_loop()
    result = loop.run_until_complete(process_async(
        output_path, query_text_list, recall_list_rag, recall_list_rag))


async def process_async(output_path, input_list, recall_list_qa, recall_list_rag, max_retries=3, kc_tool=Coverage()):
    rate_limiter = RateLimiter(kc_tool.qps)
    semaphore = Semaphore(kc_tool.max_concurrent)  # 限制最大并发数为 max_concurrent
    async with aiohttp.ClientSession() as session:
        # 将query和query embedding分别传入异步函数
        tasks = [kc_tool.process_item_async(rate_limiter, recall_list_rag[index],
                                            recall_list_rag[index], semaphore, session,
                                            index, input_list["api_query"].iloc[index], max_retries)
                 for index in range(len(input_list))]
        results = [None] * len(tasks)
        task_objects = [asyncio.create_task(task) for task in tasks]
        # tqdm_asyncio按index返回并发结果
        for _, task in tqdm_asyncio(zip(range(len(tasks)), task_objects), total=len(tasks)):
            response, index = await task
            # 根据任务的索引存储结果
            results[index] = response

        with open(output_path, 'w', encoding='utf-8') as f:
            # results = await asyncio.gather(*tasks)  # 使用 asyncio.gather 获取结果
            for item, response in zip(input_list.iloc, results):
                try:
                    f.write(json.dumps(dict(pd.concat([item, response])), ensure_ascii=False) + "\n")
                except Exception as e:
                    f.write(json.dumps(dict(response), ensure_ascii=False) + "\n")
        return results

if __name__ == "__main__":
    input_path = "data/cloud_share/search/rag/autosearch_knowledge_cover_analysis/1_result.csv"
    output_path = "data/cloud_share/search/rag/autosearch_knowledge_cover_analysis/knowledge_coverage_result.jsonl"
    process(input_path, output_path)
