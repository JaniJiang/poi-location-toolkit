"""
review每周的数据闭环数据，从2k条/day，降级到1k条/month
"""
from datetime import datetime, timedelta
import os
from utils.file_utils import read_jsonl_file
import pandas as pd
from search.qa_bot.service_bot_analyse.step3_real_and_relevance_for_incar import RealAndRelevanceForICA
from search.qa_bot.service_bot_analyse.step6_knowledge_coverage import KnowledgeCoverage
from search.qa_bot.service_bot_analyse.step1_parse_ica_logs import log_parser
import json
WEEK2DATE = {
    "W24": [datetime(2025, 6, 9), datetime(2025, 6, 15)],
    "W23": [datetime(2025, 6, 2), datetime(2025, 6, 8)],
    "W22": [datetime(2025, 5, 29), datetime(2025, 6, 1)],
    "W21": [datetime(2025, 5, 19), datetime(2025, 5, 24)],
    "W20": [datetime(2025, 5, 11), datetime(2025, 5, 15)],
    "W18": [datetime(2025, 4, 28), datetime(2025, 5, 2)],
    "W17": [datetime(2025, 4, 22), datetime(2025, 4, 26)],
    "W16": [datetime(2025, 4, 16), datetime(2025, 4, 20)],
    "W15": [datetime(2025, 4, 10), datetime(2025, 4, 14)],
    "W15": [datetime(2025, 4, 2), datetime(2025, 4, 6)],
}


class handleWeeklyTestData():
    def __init__(self):
        pass

    def read_week2date(self, week) -> list:
        """
        输入week数，返回从起始日期到结束日期的日期列表，并以指定格式存储日期。
        """
        datetimeList = WEEK2DATE[week]
        if len(datetimeList) != 2:
            raise ValueError("date_range 必须包含两个 datetime 对象。")

        start_date, end_date = datetimeList
        if start_date > end_date:
            raise ValueError("起始日期不能晚于结束日期。")

        date_list = []
        current_date = start_date
        while current_date <= end_date:
            date_list.append(current_date.strftime("%Y%m%d"))
            current_date += timedelta(days=1)

        return date_list

    def save_df_to_excel(self, df: pd.DataFrame, week: str, postfix: str = ""):
        """
        将 DataFrame 保存为 Excel 文件。

        :param df: 要保存的 Pandas DataFrame
        :param week: 表示周的字符串，例如 "week_1"
        """
        # 指定保存路径
        base_dir = "data/cloud/search/qa_bot/qa_bot_test_by_week"
        week_dir = os.path.join(base_dir, week)

        # 确保目标目录存在
        if not os.path.exists(week_dir):
            os.makedirs(week_dir)  # 如果目录不存在，则创建目录

        # 构造文件路径
        if postfix:
            postfix = "_"+postfix
        file_path = os.path.join(week_dir, "real_and_relevance"+postfix+".xlsx")

        try:
            # 保存为 Excel 文件
            df.to_excel(file_path, index=False)  # 设置 index=False 避免保存索引列
            print(f"文件已成功保存到 {file_path}")
        except Exception as e:
            print(f"保存文件时出错: {e}")

    def process(self, week, n=500):
        """
        处理指定日期列表中的数据文件，并将它们合并为一个 DataFrame。

        :param datelist: 包含日期字符串的列表，例如 ['20250101', '20250102']
        :return: 合并后的 DataFrame
        """
        datelist = self.read_week2date(week)
        orig_data_dir = "data/cloud/search/qa_bot/qa_bot_test"
        df = pd.DataFrame()  # 初始化一个空的 DataFrame

        for date in datelist:
            handled_dir = os.path.join(orig_data_dir, date)
            real_relevance_path = os.path.join(handled_dir, "step3_real_and_relevance.jsonl")

            # 读取 JSONL 文件
            data = read_jsonl_file(real_relevance_path)
            if data:
                df_tmp = pd.DataFrame(data)
                df = pd.concat([df, df_tmp], ignore_index=True)  # 使用 pd.concat 合并 DataFrame
            else:
                print(f"日期 {date} 的数据为空或文件无法读取。")
        df.dropna(subset=["if_inner"], inplace=True)
        self.save_df_to_excel(df.sample(n), week)
        return df

    def process_ica(self, week, n=500):
        """
        处理指定日期列表中的数据文件，并将它们合并为一个 DataFrame。

        :param datelist: 包含日期字符串的列表，例如 ['20250101', '20250102']
        :return: 合并后的 DataFrame
        """
        datelist = self.read_week2date(week)
        orig_data_dir = "data/cloud/search/qa_bot/qa_bot_test"
        df = pd.DataFrame()  # 初始化一个空的 DataFrame

        for date in datelist:
            handled_dir = os.path.join(orig_data_dir, date)
            real_relevance_path = os.path.join(handled_dir, "step3_real_and_relevance_ica_out.jsonl")
            if not os.path.exists(real_relevance_path):
                print(real_relevance_path, " not exists")
                real_relevance_path = os.path.join(handled_dir, "step3_real_and_relevance_ica.jsonl")

            # 读取 JSONL 文件
            data = read_jsonl_file(real_relevance_path)
            if data:
                df_tmp = pd.DataFrame(data)
                df = pd.concat([df, df_tmp], ignore_index=True)  # 使用 pd.concat 合并 DataFrame
            else:
                print(f"日期 {date} 的数据为空或文件无法读取。")

        self.save_df_to_excel(df.sample(n), week, "ica")
        return df

    def real_and_relevance_by_week(self, week):
        print("start labeling week", week)
        input_path = f"data/cloud/search/qa_bot/qa_bot_test_by_week/{week}/in_car_assistant.csv"
        output_path = f"data/cloud/search/qa_bot/qa_bot_test_by_week/{week}/step3_real_and_relevance_ica.jsonl"
        if not os.path.exists(output_path):
            obj = RealAndRelevanceForICA(input_path=input_path, output_path=output_path)
            obj.process()
        # transfer to dataframe
        data = read_jsonl_file(output_path)
        pd.DataFrame(data).to_excel(output_path.replace("jsonl", "xlsx"), index=False)

    def verified_ica_query(self, week):
        # download data from two sheet
        DATA_DATE = WEEK2DATE[week][0].strftime("%Y-%m-%d")
        DATA_DATE_END = WEEK2DATE[week][1].strftime("%Y-%m-%d")
        DATA_DIR = "data/cloud/search/qa_bot/qa_bot_test_by_week"

        # 第一步选出真实的用户日志，及其msg_id
        SQL_STRING_IC = f"select msg_id, query, content from dwd_vechile_merge_prod_di where (dt between '{DATA_DATE}' and '{DATA_DATE_END}') AND domain='in_car_assistant' and vehicle_category = '1' order by RAND() limit 2000"
        CSV_FILE_IC = f"{DATA_DIR}/{week}/in_car_assistant_log_original.csv"
        if not os.path.exists(CSV_FILE_IC):
            command = f"data/cloud_share/tool/adt --token 731a63a43618b0b444a2b86f36cf3e14 ark2csv --sql-string \"{SQL_STRING_IC}\" --csv-file \"{CSV_FILE_IC}\""
            sucess = os.system(command=command)
        else:
            sucess = 0
            print(f"File {CSV_FILE_IC} already exists, skip download.")
        if sucess == 0:
            try:
                msg_id_list = pd.read_csv(CSV_FILE_IC).dropna()["msg_id"].to_list()
            except Exception as e:
                print(e)
            # 第二部根据msg_id列表选出包含真实input query的数据
            msg_id_list_str = ""
            for msg_id in msg_id_list:
                msg_id_list_str += f"\'{msg_id}\', "
            msg_id_list_str = msg_id_list_str[:-2]
            SQL_STRING_VERIFIED = f"select msg_id, message from ods_service_expert_log_v1_prod_rt where (dt between '{DATA_DATE}' and '{DATA_DATE_END}') and msg_id IN ({msg_id_list_str}) AND logger_name='com.lixiang.voice.cockpit.faqse.utils.filter.AccessLogFilter'"
            CSV_FILE_VERIFIED = f"{DATA_DIR}/{week}/in_car_assistant_log_verified.csv"
            command = f"data/cloud_share/tool/adt --token 731a63a43618b0b444a2b86f36cf3e14 ark2csv --sql-string \"{SQL_STRING_VERIFIED}\" --csv-file \"{CSV_FILE_VERIFIED}\""
            if not os.path.exists(CSV_FILE_VERIFIED):
                sucess = os.system(command=command)
            else:
                print(f"File {CSV_FILE_VERIFIED} already exists, skip download.")
        # process two sheets
        # 使用默认的输入路径
        parser = log_parser(
            original_path=f"data/cloud/search/qa_bot/qa_bot_test_by_week/{week}/in_car_assistant_log_original.csv",
            verified_path=f"data/cloud/search/qa_bot/qa_bot_test_by_week/{week}/in_car_assistant_log_verified.csv",
            save_path=f"data/cloud/search/qa_bot/qa_bot_test_by_week/{week}/in_car_assistant.csv"
        )
        parser.parse_ica_logs_and_save_by_path()

    def re_compute_knowledge_coverage_for_gpt_autoqa(self, week):
        def excel2jsonl(input_path, output_path):
            df = pd.read_excel(input_path, sheet_name="Sheet1")
            df = df.dropna(subset=['output'])
            with open(output_path, 'w', encoding='utf-8') as jsonl_file:
                for _, row in df.iterrows():
                    row_dict = row.to_dict()
                    json_str = json.dumps(row_dict, ensure_ascii=False)
                    jsonl_file.write(json_str + '\n')
            print(f"Conversion complete. JSONL file saved as {output_path}")
        # convert the .xlsx to .jsonl
        print("start labeling week", week)
        input_path = f"data/cloud/search/qa_bot/qa_bot_test_by_week/{week}/real_and_relevance.xlsx"
        output_path = f"data/cloud/search/qa_bot/qa_bot_test_by_week/{week}/real_and_relevance.jsonl"
        if not os.path.exists(output_path):
            excel2jsonl(input_path, output_path)
        else:
            print("Json file already exists")
        # re_compute
        knowledge_coverage_output_path = f"data/cloud/search/qa_bot/qa_bot_test_by_week/{week}/knowledge_coverage_autoqa.jsonl"
        if not os.path.exists(knowledge_coverage_output_path):
            obj = KnowledgeCoverage(output_path, knowledge_coverage_output_path)
            obj.query_path = output_path
            obj.output_path = knowledge_coverage_output_path
            obj.process()
        else:
            print("Knowledge coverage file already exists")
        # compute the metric
        data = read_jsonl_file(knowledge_coverage_output_path)
        knowledge_coverage = 0
        for d in data:
            if d["has_item"] == "1":
                knowledge_coverage += 1
        print(f"knowledge coverage ratio is {knowledge_coverage} / {len(data)} = {knowledge_coverage/len(data)}")
        return knowledge_coverage, len(data)


if __name__ == "__main__":
    obj = handleWeeklyTestData()
    kc = 0
    total = 0
    for week in WEEK2DATE.keys():
        if week != "W25":
            continue
        # aggregate weekly data
        df = obj.process(week)
        # df = obj.process_ica(week)

        # re_load in_car_assistant data
        # obj.verified_ica_query(week)

        # re_label real and relevance in_car_assistant
        # obj.real_and_relevance_by_week(week)

        # re_label knowledge coverage
        kc_sub, total_sub = obj.re_compute_knowledge_coverage_for_gpt_autoqa(week)
        kc += kc_sub
        total += total_sub
        pass
