from utils.search_utils.semantic_deduplicate import compute_similarity
import pandas as pd
import math
from tqdm import tqdm
import time

if __name__ == "__main__":
    query_df_1 = pd.read_csv("data/cloud_share/qabot_miner/compare_overlap_rate/query_v3.txt",
                             sep='\t', on_bad_lines='skip')
    query_df_4 = pd.read_csv("data/cloud_share/qabot_miner/compare_overlap_rate/query_v5.txt",
                             sep='\t', on_bad_lines='skip')
    is_dup_4 = [False] * len(query_df_4)
    is_dup_1 = [False] * len(query_df_1)
    for i, item_4 in tqdm(query_df_4.iterrows(), total=len(query_df_4)):
        kg_id_1 = [str(i).replace(".0", "") for i in query_df_1['knowledge_id'].to_list()]
        if item_4['knowledge_id'] in kg_id_1:
            is_dup_4[i] = True
            for j in range(len(kg_id_1)):
                if kg_id_1[j] == item_4['knowledge_id']:
                    is_dup_1[j] = True
        else:
            start = time.time()
            prob = compute_similarity(item_4["representative_query"],
                                      query_df_1["representative_query"].to_list())[0, :, 1]
            end = time.time()
            print('generate cost time:', (end - start))
            if max(prob) > 0.5:
                is_dup_4[i] = True
                print(item_4["representative_query"])
                for j in range(len(prob)):
                    if prob[j] > 0.5:
                        is_dup_1[j] = True
                        print(query_df_1["representative_query"][j], prob[j])
    dup_1 = query_df_1[is_dup_1]
    dup_4 = query_df_4[is_dup_4]
    dup_1.to_csv("data/cloud_share/qabot_miner/compare_overlap_rate/res_1.csv")
    dup_4.to_csv("data/cloud_share/qabot_miner/compare_overlap_rate/res_4.csv")
    print(f"duplicated rate in query_v3 is {len(dup_1)/len(query_df_1)}")
    print(f"duplicated rate in query_v5 is {len(dup_4)/len(query_df_4)}")
