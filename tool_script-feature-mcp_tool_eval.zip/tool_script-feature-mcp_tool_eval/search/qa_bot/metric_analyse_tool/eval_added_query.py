"""
process主函数流程：
1. 计算发布日期前后，上线问题id的pv数；并保存完整的命中上线问题id的日志
2. 对上线前后的完整日志，采样n条计算完成率
    2.1. 采样n条，反查服务专家表中正确的原始query
    2.2. LLM标注真实相关性
!注意：需注意路径是否已存在文件导致数据下载被跳过
"""
from search.qa_bot.service_bot_analyse.meta import *
import os
from datetime import datetime, timedelta
import pandas as pd
import json
from collections import Counter
import time
from typing import List
from utils.file_utils import read_jsonl_file
from search.qa_bot.service_bot_analyse.step3_real_and_relevance_for_incar import RealAndRelevanceForICA
from search.qa_bot.service_bot_analyse.step1_parse_ica_logs import log_parser
import random


class eval_added_query():
    def __init__(self):
        self.online_date: datetime = datetime(2025, 6, 6)
        self.added_query_id_path = "data/cloud/search/qa_bot/metric_count/added_query.txt"
        self.output_csv_dir = os.path.join("data/cloud/search/qa_bot/metric_count",
                                           self.online_date.strftime("%Y-%m-%d"))
        if not os.path.exists(self.output_csv_dir):
            os.mkdir(self.output_csv_dir)
        self.new_query = True  # 是否新增知识
        pre_days = 7  # 计算前后x天的日期范围
        self.gaptime = 0
        self.start_date = self.online_date - timedelta(days=pre_days+self.gaptime)
        self.end_date = self.online_date + timedelta(days=pre_days+self.gaptime)
        self.before_prefix = "pv_res_before"
        self.after_prefix = "pv_res_after"

    def load_query(self, standard_query_path="data/cloud_share/qabot_miner/qa_index/data.json") -> List[int]:
        if self.new_query:  # 新增知识通过标准问查qid
            addedId = pd.read_csv(self.added_query_id_path)['服务专家标准问'].to_list()  # 列名为 服务专家标准问
            data = read_jsonl_file(standard_query_path)
            id_list = []
            for d in data[0]:
                if 'answerGroup' in d.keys():
                    for query in addedId:
                        if query in d['question']:
                            id_list.append(d['answerGroup'][0]['questionId'])
                            break
            addedId = id_list
        else:
            addedId = pd.read_csv(self.added_query_id_path)['id'].to_list()  # 列名为 id
        addedId = list(set(addedId))
        print(len(addedId), "新增条知识")
        return addedId

    def compute_pv_distribution(self, addedId: List[int]) -> tuple:
        tmpPath = "data/cloud/search/qa_bot/metric_count/tmp_data_before.csv"  # 把融合表的筛选结果存到本地的csv
        # Load logs
        print("............开始下载上线前的全量日志，存储在tmp文件中............")
        status = download_logs(self.start_date, self.online_date - timedelta(days=1+self.gaptime), tmpPath)
        if status:
            counter_before = count_logs_pv(tmpPath,
                                           os.path.join(self.output_csv_dir, f"{self.before_prefix}_pv_count.txt"),
                                           os.path.join(self.output_csv_dir, f"{self.before_prefix}_full_data.csv"),
                                           addedId)
            pv_add_before = 0
            for id in addedId:
                pv_add_before += counter_before[str(id)]

        # after
        print("............开始下载上线后的全量日志，存储在tmp文件中............")
        tmpPath = "data/cloud/search/qa_bot/metric_count/tmp_data_after.csv"  # 把融合表的筛选结果存到本地的csv
        status = download_logs(self.online_date + timedelta(days=1+self.gaptime), self.end_date, tmpPath)
        if status:
            counter_after = count_logs_pv(tmpPath,
                                          os.path.join(self.output_csv_dir, f"{self.after_prefix}_pv_count.txt"),
                                          os.path.join(self.output_csv_dir, f"{self.after_prefix}_full_data.csv"),
                                          addedId)
            pv_add_after = 0
            for id in addedId:
                pv_add_after += counter_after[str(id)]
        return pv_add_before, sum(counter_before.values()), pv_add_after, sum(counter_after.values())

    def compute_real_and_relevance(self, n=500):
        # before & after
        for starttime, endtime, prefix in ([self.start_date, self.online_date - timedelta(days=1+self.gaptime), self.before_prefix],
                                           [self.online_date + timedelta(days=1+self.gaptime), self.end_date, self.after_prefix]):
            # 替换正确的输入query
            print(f"............{prefix}: 替换正确的输入query............")
            path = os.path.join(self.output_csv_dir, f"{prefix}_full_data.csv")
            msg_id_list = pd.read_csv(path)['msg_id'].to_list()
            msg_id_list = random.sample(msg_id_list, min(n, len(msg_id_list)))
            if len(msg_id_list) < 1:
                print("zero message is matched")
                continue
            verified_path = os.path.join(self.output_csv_dir, f"{prefix}_verified_full_data.csv")
            verified_ica_query(msg_id_list=msg_id_list,
                               tmp_file=verified_path,
                               start_date=starttime,
                               end_date=endtime)

            input_csv_path = os.path.join(self.output_csv_dir, "tmp_real.csv")  # 真实相关的input_path
            parser = log_parser(original_path=path, verified_path=verified_path, save_path=input_csv_path)
            parser.parse_ica_logs_and_save_by_path()
            print(f"............{prefix}: 开始真实相关性标注............")

            output_jsonl_path = os.path.join(self.output_csv_dir,
                                             f"{prefix}_real_relevance.jsonl")
            if not os.path.exists(output_jsonl_path):
                print(f"File {output_jsonl_path} already exists")
                # continue
            obj = RealAndRelevanceForICA(input=input_csv_path, output_path=output_jsonl_path)
            obj.process()
            # transfer to dataframe
            # compute the real and relevance rate
            data = read_jsonl_file(output_jsonl_path)
            df = pd.DataFrame(data)
            print(f"The real and relevance ratio is {df['label'].sum()} / {len(df)} = {df['label'].sum() / len(df)}")
            df.to_excel(output_jsonl_path.replace("jsonl", "xlsx"), index=False)

    def process(self) -> List[int]:
        addedId = self.load_query()
        pv_add_before, pv_all_before, pv_add_after, pv_all_after = self.compute_pv_distribution(addedId)
        print("发布前pv数:", pv_all_before, "\n发布前优化pv数:", pv_add_before)
        print("发布后pv数:", pv_all_after, "\n发布后优化pv数:", pv_add_after)
        # 计算前后真实相关性
        self.compute_real_and_relevance()


def download_logs(start_date: datetime, end_date: datetime, csvPath: str) -> bool:
    if os.path.exists(csvPath):
        print("............全量日志已经存在............")
        return True
    formated_start_date = start_date.strftime("%Y-%m-%d")
    formated_end_date = end_date.strftime("%Y-%m-%d")
    print(f"Processing from {formated_start_date} to {formated_end_date}")
    sqlString = f"select query, content, dialogue_response, msg_id from dwd_vechile_merge_prod_di where \
(dt between '{formated_start_date}' and '{formated_end_date}') \
AND domain = 'in_car_assistant' \
AND vehicle_category = '1' \
AND ota_version > '5' \
AND query is not null and query != '' \
"
    # save into a tmp file and read for each date
    command = f"data/cloud_share/tool/adt --token 731a63a43618b0b444a2b86f36cf3e14 ark2csv --sql-string \"{sqlString}\" --csv-file \"{csvPath}\""
    sucess = os.system(command=command)
    return True if sucess == 0 else False


def count_logs_pv(csvFile: str, output_csv_path: str, full_output_csv_path: str, addedId: List[int]) -> (Counter):
    print("............筛选命中上线泛化id的日志............")
    total_counter = Counter()
    start_time = time.time()
    # 使用分块方式读取大CSV文件（避免内存溢出
    reader = pd.read_csv(
        csvFile,
        chunksize=10000,
        usecols=[0, 1, 3],
        header=0,  # 如果CSV有表头请保留header=0，否则设为None
        names=['query', 'content', 'msg_id'],  # 列名需与usecols对应
        encoding='utf-8',
        on_bad_lines='warn',
    )
    processed_rows = 0
    # 逐块处理CSV数据
    msg_id_list = []
    query_list = []
    content_list = []
    try:
        for i, chunk in enumerate(reader):
            id_list = []
            chunk = chunk.dropna()
            for index, row in chunk.iterrows():
                content_str = row['content']
                # 提取API查询内容
                try:
                    slot = json.loads(content_str)
                    hitId = slot.get('hitQuestionId', None)
                    if hitId is None:
                        continue  # 跳过没有QUERY字段的数据
                    hitId = hitId.split('_')[0]
                    if hitId == "2012364":
                        # 6.1特殊问题,跳过
                        continue
                    if int(hitId) in addedId:
                        try:
                            msg_id_list.append(row['msg_id'])
                            query_list.append(row['query'])
                            content_list.append(row['content'])
                        except Exception as e:
                            print("query info added failed")
                            print(e)
                except Exception as e:
                    if type(e) == json.decoder.JSONDecodeError:
                        pass
                        # print(e, f'解析出现错误:{content_str}')
                    else:
                        print(e, f"出现其他报错: {content_str}")
                    continue
                id_list.append(hitId)  # 将提取的query加入列表
            # 对当前块中的query进行计数
            chunk_counts = Counter(id_list)
            # 更新总统计结果
            total_counter.update(chunk_counts)

            processed_rows += len(chunk)
            print(f"已处理 {processed_rows} 行 (块 {i + 1})...")
    except FileNotFoundError:
        print(f"错误：输入文件 '{csvFile}' 未找到。退出筛选流程")
    except Exception as e:
        print(f"处理过程中发生错误: {e}。退出筛选流程")
    print("正在整理结果...")

    # 将统计结果转换为DataFrame
    output_df = pd.DataFrame(total_counter.items(), columns=['id', 'pv'])

    # 按PV降序排序（可选）
    output_df = output_df.sort_values(by='pv', ascending=False)

    # 保存结果到CSV文件
    output_df.to_csv(output_csv_path, index=False, encoding='utf-8')

    # 详细结果保存到另外的CSV文件
    pd.DataFrame({
        "query": query_list,
        "msg_id": msg_id_list,
        "content": content_list,
    }).to_csv(full_output_csv_path, index=False, encoding='utf-8')

    end_time = time.time()
    print(f"处理完成！结果已保存到: {output_csv_path}\n完整数据保存到: {full_output_csv_path}")
    print(f"总耗时: {end_time - start_time:.2f} 秒")
    print(f"共统计出 {len(output_df)} 条独立 query。")
    return total_counter


def verified_ica_query(msg_id_list: list, tmp_file: str, start_date: datetime, end_date: datetime):
    formated_start_date = start_date.strftime("%Y-%m-%d")
    formated_end_date = end_date.strftime("%Y-%m-%d")
    # 根据msg_id列表选出包含真实input query的数据
    msg_id_list_str = ""
    for msg_id in msg_id_list:
        msg_id_list_str += f"\'{msg_id}\', "
    msg_id_list_str = msg_id_list_str[:-2]
    SQL_STRING_VERIFIED = f"select msg_id, message from ods_service_expert_log_v1_prod_rt where (dt between '{formated_start_date}' and '{formated_end_date}') and msg_id IN ({msg_id_list_str}) AND logger_name='com.lixiang.voice.cockpit.faqse.utils.filter.AccessLogFilter'"
    CSV_FILE_VERIFIED = tmp_file
    command = f"data/cloud_share/tool/adt --token 731a63a43618b0b444a2b86f36cf3e14 ark2csv --sql-string \"{SQL_STRING_VERIFIED}\" --csv-file \"{CSV_FILE_VERIFIED}\""
    if os.path.exists(CSV_FILE_VERIFIED):
        print(f"File {CSV_FILE_VERIFIED} already exists")
        # return True
    print("............从服务专家表中下载包含正确输入query的日志............")
    sucess = os.system(command=command)
    return True if sucess == 0 else False


if __name__ == "__main__":
    obj = eval_added_query()
    res = obj.process()
    pass
