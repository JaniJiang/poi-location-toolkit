import requests
import json
import pandas as pd
import time
from tqdm import tqdm
import subprocess
from utils.search_utils.call_cockpit_qabot import request_qabot


def process(input_path, output_path):

    # load
    df = pd.read_excel(input_path).head(10)
    input_text_list = df['api_query'].to_list()
    # request
    with open(output_path, 'w', encoding='utf-8') as f:
        for query in tqdm(input_text_list):
            retries = 0
            response = request_qabot(query)
            while (len(response['data']) < 1) and retries < 3:
                retries += 1
                print(f"retries {retries}...")
                response = request_qabot(query)
                time.sleep(1)
            f.write(json.dumps(dict(response), ensure_ascii=False) + "\n")
            time.sleep(1)


if __name__ == "__main__":
    input_path = "search/qa_bot/metric_analyse_tool/benefit_eval/tmp.xlsx"
    output_path = "search/qa_bot/metric_analyse_tool/benefit_eval/res.jsonl"
    process(input_path, output_path)
