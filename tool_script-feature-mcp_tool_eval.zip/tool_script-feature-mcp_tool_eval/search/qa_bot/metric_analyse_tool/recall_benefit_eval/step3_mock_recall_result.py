"""
考虑到lpai调本地服务容易出现超时，导致向量召回结果为空，step3建议在本地运行
"""
import requests
import json
import time
import os
import pandas as pd

url = "http://10.240.251.96:12561/recall/query"

payload = json.dumps({
    "msgId": "platform_kk",
    "aiUserId": "kk",
    "timestamp": 1730168715678,
    "voiceVersion": "6.0.0.0",
    "topK": 3,
    "extendData": {
        "vehicleConfigCode": "255,51,29,99,67,59,255,104,253,255,95,123,57,230,226,43,207",
        "vehicleModel": "X01",
        "userManualVersion": "10",
        "appVersion": {
            "help": "5000001"
        },
        "huOtaVersion": "1.0",
        "nightMode": 0,
        "spu": "ss2pro",
        "vehicleAccountId": "full"
    },
    "input": {
        "text": "本车车长度",
        "voiceImage": {
            "position": 0
        }
    },
    "config": {
        "appInfo": {
            "category": "com.chehejia.car.voice"
        }
    }
})
headers = {
    'User-Agent': 'Apifox/1.0.0 (https://www.apifox.cn)',
    'Content-Type': 'application/json'
}


def read_jsonl_file(file_path: str):
    """
    Read a JSONL file and return a list of Python dictionaries.
    :param file_path: String denoting the path to the JSONL file
    :return: List of dictionaries parsed from JSON lines in the file
    """
    # Prepare an empty list to hold the JSON objects
    data = []
    if os.path.exists(file_path) is False:
        return data
    # Open the file and read line by line
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            # Each line is a complete JSON object
            json_obj = json.loads(line.strip())
            # Add the parsed JSON object to the list
            data.append(json_obj)
    # Return the list of JSON objects
    return data


def get_recall_res():
    df = pd.DataFrame(read_jsonl_file("data/cloud/search/qa_bot/my_temp/knowledge_coverage_result.jsonl"))

    full_res_list = []
    rrf_res_list = []
    for data in df.iloc:
        # 仅考虑有知识覆盖的问题
        if data["has_item"] == 1:
            query = data["text"]
            target = data["question_id"]

            payload["input"]["text"] = query
            response = requests.request("POST", url, headers=headers, data=payload)
            time.sleep(1)

            full_res_list.append({
                "query": query,
                "target": target,
                "recall_list": [data['questionId'] for data in response["data"]],
                "source_list": [data['source'] for data in response["data"]]
            })

            payload["extendData"]["vehicleAccountId"] = "rrf"
            response = requests.request("POST", url, headers=headers, data=payload)
            time.sleep(1)

            rrf_res_list.append({
                "query": query,
                "target": target,
                "recall_list": [data['questionId'] for data in response["data"]],
                "source_list": [data['source'] for data in response["data"]]
            })

    full_res_df = pd.DataFrame(full_res_list)
    rrf_res_df = pd.DataFrame(rrf_res_list)

    # full_res_df.to_csv("data/cloud/search/qa_bot/my_temp/full_recall_result.jsonl")
    # rrf_res_df.to_csv("data/cloud/search/qa_bot/my_temp/rrf_recall_result.jsonl")
    return full_res_df, rrf_res_df


if __name__ == "__main__":
    full_res_df, rrf_res_df = get_recall_res()
    num_search_problem = len(full_res_df)
    num_rrf = 0
    num_recall = 0
    num_es = 0
    num_vec = 0

    for i in range(num_search_problem):
        target = full_res_df["target"][i]
        # 判断rrf是否已召回
        if target in rrf_res_df["recall_list"]:
            num_rrf += 1
        # 判断es/vec是否已召回
        if target in full_res_df["recall_list"]:
            num_recall += 1
            index_list = full_res_df[full_res_df['recall_list'].apply(lambda x: target in x)].index.tolist()
            for i in index_list:
                if full_res_df["source_list"][i] == "SOURCE_VECTOR":
                    num_vec += 1
                    break

            for i in index_list:
                if full_res_df["source_list"][i] == "SOURCE_WORD":
                    num_es += 1
                    break
    # calculate the figure
    rank_rate = num_rrf / num_search_problem
    rrf_rate = (num_recall - num_rrf) / num_search_problem
    recall_rate = 1 - num_recall / num_search_problem
    print(f"排序问题比例：{rank_rate}\n粗排问题比例：{rrf_rate}\n召回问题比例{recall_rate}")
# python -m search.qa_bot.metric_analyse_tool.recall_benefit_eval.step3_mock_recall_result
