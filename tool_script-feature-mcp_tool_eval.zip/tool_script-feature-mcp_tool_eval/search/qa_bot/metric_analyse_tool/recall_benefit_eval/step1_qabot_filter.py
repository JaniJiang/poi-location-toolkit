import pandas as pd
from sklearn.cluster import MiniBatchKMeans
from FlagEmbedding import FlagModel
from search.qa_bot.service_bot_intent.step3_onnx_infer import onnx_inference
from search.qa_bot.service_bot_intent.meta_info import MODEL_VERSION
from search.qa_bot.service_bot_miner.meta import *
from tqdm import tqdm
# 防止聚类时OpenBLAS使用的线程数超过了它在编译时设定的最大限制
import os
os.environ['OPENBLAS_NUM_THREADS'] = '64'


class Coarse_Filter:
    """粗筛模块：基于BERT模型过滤样本并进行聚类分析"""

    def __init__(self):
        # --- 配置参数 ---
        # 输入输出相关配置
        self.column_name = 'query'  # 需要处理的查询字段名称
        self.file_encoding = 'utf-8'  # 文件编码格式
        self.base_model_dir = "data/cloud_share/qabot_miner/bert_model/model/base_model/bert-base-chinese"  # 基础BERT模型路径
        # 导出的ONNX模型路径
        self.save_onnx_model_path = f"data/cloud_share/qabot_miner/bert_model/onnx_model/{MODEL_VERSION}/bert_model.onnx"

        # 初始化BGE模型配置
        self.bge_model_path = "data/cloud_share/qabot_miner/bge_model"

        # 数据文件路径
        self.query_data = "data/cloud/search/qa_bot/my_temp/result.xlsx"  # 输入数据源
        self.bert_output = "data/cloud/search/qa_bot/my_temp/filtered_result.csv"  # BERT处理结果输出

    def bert_filter(self):
        """BERT过滤流程：过滤低频样本并保存模型推理结果"""
        # 1. 读取原始数据（包含query和pv字段）
        df = pd.read_excel(self.query_data, header=0)
        # 3. 过滤理想one
        df = df.dropna(subset=[self.column_name])
        df = df[['理想one' not in query.lower() for query in df[self.column_name]]]
        data_list = df.to_dict("records")  # 转换为字典列表
        text_list = [item[self.column_name] for item in data_list]  # 提取query文本列表

        # 3. 调用ONNX模型进行推理
        predictions = onnx_inference(
            self.base_model_dir,
            self.save_onnx_model_path,
            text_list
        )

        # 4. 保存推理结果到ccSV文件
        with open(self.bert_output, "w") as f:
            # 写入表头
            f.write("text,pv,pred_label,pred_prob,probs\n")
            # 按格式写入每条记录
            for idx, (text, pred_label, pred_prob, probs) in enumerate(predictions):
                item = data_list[idx]
                pv = item["pv"]
                f.write(f"{text.replace(',','')},{pv},{pred_label},{pred_prob},{probs}\n")
        print(f'bert粗筛结果已存储至：{self.bert_output}')


if __name__ == "__main__":
    filter = Coarse_Filter()
    filter.bert_filter()
    # 统计指标
    df = pd.read_csv("/mnt/volumes/ss-sai-bd-ga/wuzhenyan/tool_script/data/cloud/search/qa_bot/my_temp/filtered_result.csv")
    qa_df = df[df['pred_label'] == 1]
    print(f"{len(qa_df)} / {len(df)} = {len(qa_df)/len(df)} data belongs to service bot")

# python -m search.qa_bot.metric_analyse_tool.recall_benefit_eval.step1_qabot_filter
