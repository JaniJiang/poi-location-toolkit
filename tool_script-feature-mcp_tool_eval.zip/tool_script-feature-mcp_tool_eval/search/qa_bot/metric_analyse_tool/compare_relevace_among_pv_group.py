"""
计算不同pv段数据的完成率
1. 获取pv段的query_list
2. 遍历原始文件，获取真实相关标注所需要的参数
3. 随机采样500条标注真实相关
"""
from search.qa_bot.service_bot_analyse.data_miner.step4_real_and_relevance import RealAndRelevance
import pandas as pd
import json
from search.qa_bot.service_bot_intent.step3_onnx_infer import onnx_inference
import os
from search.qa_bot.service_bot_intent.meta_info import MODEL_VERSION
import asyncio
from tqdm import tqdm


class comapre_rr_among_pv_group():
    def __init__(self):
        self.input_csv_path = "data/cloud_share/qabot_miner/wuzhenyan/mine_data_05_12_06_11/autosearch_data_2025-05-13_to_2025-06-11.csv"
        self.query_pv_path = "data/cloud_share/qabot_miner/wuzhenyan/mine_data_05_12_06_11/mine_after_2.csv"
        self.output_dir = "data/cloud/search/qa_bot/pv_compare"
        self.base_model_dir = "data/cloud_share/qabot_miner/bert_model/model/base_model/bert-base-chinese"  # 基础BERT模型路径
        # 导出的ONNX模型路径
        self.save_onnx_model_path = f"data/cloud_share/qabot_miner/bert_model/onnx_model/{MODEL_VERSION}/bert_model.onnx"

    def get_origin_info(self):
        df_service = pd.read_csv(
            self.query_pv_path, encoding='utf-8', header=0)
        candidates = df_service[(df_service['pv'] < 10)]['query'].tolist()
        pv_candidate_list = df_service[(df_service['pv'] < 10)]['pv'].tolist()
        # pv过滤
        query_list = []
        output_list = []
        knowledge_res_list = []
        pv_list = []
        chunksize = 10000  # 每次处理的行数，可以根据内存情况调整
        # 分块读取文件，指定 slot_li 列的数据类型为 str
        for chunk in pd.read_csv(self.input_csv_path, encoding='utf-8', header=0, chunksize=chunksize, dtype={'slot_li': str}):
            chunk = chunk.dropna()
            for _, row in tqdm(chunk.iterrows(), total=len(chunk)):
                try:
                    content_list = json.loads(row['slot_li'])
                    if len(content_list) > 1:
                        continue
                    query = content_list[0].get('QUERY')
                except json.JSONDecodeError as e:
                    query = None
                    print(f"解析错误, 无法获取 query, 原始内容: {row['slot_li']}, 行号：{row.name}")
                    continue
                if query and query in candidates:
                    pv_list.append(pv_candidate_list[candidates.index(query)])
                    query_list.append(query)
                    output_list.append(row['output'])
                    knowledge_res_list.append(row['knowledge_search_result'])
            break

        print("Filtering for matches...")
        results = {
            "pv": pv_list,
            "query": query_list,
            "output": output_list,
            "knowledge_search_result": knowledge_res_list
        }
        df_result = pd.DataFrame(results)
        for i in range(9):
            save_path = os.path.join(self.output_dir, f"pv_{i+1}.csv")
            df_pv = df_result[df_result['pv'] == (i+1)]
            df_pv.to_csv(save_path, encoding='utf-8')
            print(f"{len(df_pv)} sample with pv {i+1}")
        return df_result

    def is_qabot(self):
        for i in range(9):
            df = pd.read_csv(os.path.join(self.output_dir, f"pv_{i+1}.csv"))
            df = df.sample(min(2000, len(df)))
            df = df.dropna(subset=['query'])
            df = df[['理想one' not in query.lower() for query in df['query']]]
            data_list = df.to_dict("records")  # 转换为字典列表
            text_list = [item["query"] for item in data_list]  # 提取query文本列表

            predictions = onnx_inference(
                self.base_model_dir,
                self.save_onnx_model_path,
                text_list
            )
            df['if_serviceBot'] = pd.DataFrame(predictions).iloc[:, 1].to_list()
            bert_output = os.path.join(self.output_dir, f"pv_{i+1}_bert_output.csv")
            df.to_csv(bert_output)
            print(f'bert粗筛结果已存储至：{bert_output}')

    def real_and_relevance(self):
        for i in range(9):
            input_csv_path = os.path.join(self.output_dir, f"pv_{i+1}_bert_output.csv")
            df = pd.read_csv(input_csv_path)
            input_list = df[df['if_serviceBot'] == 1]
            print(f"Total {len(input_list)} qabot queries in {len(df)} queries with pv {i+1}")
            input_list = input_list.sample(min(200, len(input_list)))
            dict_list = pd.read_csv("search/qa_bot/service_bot_analyse/vocab/car-company-other.txt",
                                    sep='\t').iloc[:, 1].to_list()
            obj = RealAndRelevance()
            obj.output_path = os.path.join(self.output_dir, f"pv_{i+1}_real_relevance.jsonl")
            # loop = asyncio.get_event_loop()
            # loop.run_until_complete(obj.process_async(input_list.iloc, max_retries=5, dict_list=dict_list))

    def process(self):
        # self.get_origin_info()
        # self.is_qabot()
        self.real_and_relevance()


if __name__ == "__main__":
    obj = comapre_rr_among_pv_group()
    obj.process()
