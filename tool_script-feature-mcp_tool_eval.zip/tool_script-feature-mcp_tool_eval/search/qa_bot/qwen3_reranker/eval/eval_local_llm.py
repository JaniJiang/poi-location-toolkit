import torch
from modelscope import AutoTokenizer, AutoModelForCausalLM
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from search.qa_bot.qwen3_reranker.eval.eval_lpai_llm import *


class EvalLocalLLM(EvalLpaiLLM):

    def __init__(self, env):
        self.env = env
        self.dataset_name_list = ["eval_v5"]
        self.model_path = f"{DATA_DIR}/model/qa_bot_v2_20250805_1"
        # 设备检查和设置
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        logger.info(f"[EvalLocalLLM] use device: {self.device}")
        # 本地模型参数
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_path, padding_side="left")
        self.model = AutoModelForCausalLM.from_pretrained(self.model_path, device_map="auto").eval()
        self.max_length = 4096
        self.token_true_id = self.tokenizer.convert_tokens_to_ids(POS_LABEL)
        self.token_false_id = self.tokenizer.convert_tokens_to_ids(NEG_LABEL)
        self.batch_size = 128
        self.thres = 0.03

    def process(self):
        for dataset_name in tqdm(self.dataset_name_list, total=(len(self.dataset_name_list))):
            input_path = f"{EVAL_DIR}/input/{dataset_name}.tsv"
            output_path = f"{EVAL_DIR}/output/{EVAL_VERSION}/{dataset_name}.{self.env}.tsv"
            # 校验输出路径
            check_output_path(output_path)
            # 读取输入数据
            sample_df = pd.read_csv(input_path, sep="\t")
            sample_list = sample_df.to_dict("records")
            # 分批处理
            output_list = []
            for i in tqdm(range(0, len(sample_list), self.batch_size)):
                batch_sample_list = sample_list[i: (i + self.batch_size)]
                instructions = []
                for sample_dict in batch_sample_list:
                    instruction, output = build_prompt(sample_dict)
                    if instruction == "" or output == "":
                        continue
                    instructions.append(instruction)
                if len(batch_sample_list) != len(instructions):
                    continue
                try:
                    inputs = self.process_inputs(instructions)
                    scores = self.compute_logits(inputs)
                    if len(batch_sample_list) != len(scores):
                        continue
                    for idx, sample_dict in enumerate(batch_sample_list):
                        sample_dict["pred_score"] = round(scores[idx], 6)
                        output_list.append(sample_dict)
                except Exception as e:
                    logger.warning("[EvalLocalLLM] process failed: " + str(e))
                    continue
            # 保存结果
            output_df = pd.DataFrame(output_list)
            output_df.to_csv(output_path, sep="\t", index=False, header=True)
            # 计算指标
            self.eval_metric(output_df, self.thres)

    def process_inputs(self, instructions):
        inputs = self.tokenizer(
            instructions, padding=False, truncation="longest_first",
            return_attention_mask=False, max_length=self.max_length
        )
        inputs = self.tokenizer.pad(inputs, padding=True, return_tensors="pt", max_length=self.max_length)
        for key in inputs:
            inputs[key] = inputs[key].to(self.model.device)
        return inputs

    @torch.no_grad()
    def compute_logits(self, inputs, **kwargs):
        batch_scores = self.model(**inputs).logits[:, -1, :]
        true_vector = batch_scores[:, self.token_true_id]
        false_vector = batch_scores[:, self.token_false_id]
        batch_scores = torch.stack([false_vector, true_vector], dim=1)
        batch_scores = torch.nn.functional.log_softmax(batch_scores, dim=1)
        scores = batch_scores[:, 1].exp().cpu().tolist()
        return scores

    def eval_metric(self, df, thres):
        label_list = df["label"]
        score_list = df["pred_score"]
        pred_list = [POS_LABEL if s >= thres else NEG_LABEL for s in score_list]
        accuracy = accuracy_score(label_list, pred_list)
        precision = precision_score(label_list, pred_list, average='binary', pos_label=POS_LABEL)
        recall = recall_score(label_list, pred_list, average='binary', pos_label=POS_LABEL)
        f1 = f1_score(label_list, pred_list, average='binary', pos_label=POS_LABEL)
        eval_res = {"f1score": f1, "recall": recall, "precision": precision, "accuracy": accuracy}
        print("f1score:", {eval_res["f1score"]})
        print("recall:", {eval_res["recall"]})
        print("precision:", {eval_res["precision"]})
        print("accuracy:", {eval_res["accuracy"]})
        return eval_res


if __name__ == "__main__":
    obj = EvalLocalLLM("local")
    obj.process()

# CUDA_VISIBLE_DEVICES=1,2 python -m search.qa_bot.qwen3_reranker.eval.eval_local_llm
# CUDA_VISIBLE_DEVICES=1,2 nohup python -m search.qa_bot.qwen3_reranker.eval.eval_local_llm > log/search/qa_bot/qwen3_reranker/eval/eval_local_llm.log 2>&1 &
