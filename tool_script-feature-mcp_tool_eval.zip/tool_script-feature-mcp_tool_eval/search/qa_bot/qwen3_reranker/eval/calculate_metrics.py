import os
import pandas as pd
from utils.metrics_utils.common_metrics_utils import cal_metrics
from search.qa_bot.qwen3_reranker.meta import *
from search.qa_bot.qwen3_reranker.prompt import *


class CalculateMetrics:

    def __init__(self):
        self.env_list = ["local"]
        self.dataset_name_list = ["high_supplement", "medium_supplement"]
        # 分类阈值
        self.thres = 0.00415

    def process(self):
        output_path_prefix = f"{EVAL_DIR}/output/{EVAL_VERSION}/metrics"
        for env in self.env_list:
            for dataset_name in self.dataset_name_list:
                input_path = f"{EVAL_DIR}/output/{EVAL_VERSION}/{dataset_name}.{env}.tsv"
                if not os.path.exists(input_path):
                    print(f"[WARN] File not found: {input_path}")
                    continue

                print(f"[INFO] Processing file: {input_path}")
                df = pd.read_csv(input_path, sep="\t").fillna("")

                # 将标签转为数值标签（仅供计算使用，不输出）
                df["int_label"] = df["label"].map({POS_LABEL: 1, NEG_LABEL: 0})

                # 生成预测标签
                df["pred_label"] = df["pred_score"].apply(
                    lambda s: POS_LABEL if s >= self.thres else NEG_LABEL
                )

                # === 保存时移除 int_label，仅保留原始列 + pred_label ===
                output_columns = [col for col in df.columns if col != "int_label"]
                labeled_output_path = (
                    f"{EVAL_DIR}/output/{EVAL_VERSION}/{dataset_name}.{env}.with_pred_label.tsv"
                )
                df[output_columns].to_csv(labeled_output_path, sep="\t", index=False)
                print(f"[INFO] Saved file with pred_label → {labeled_output_path}")

                # === 调用通用指标计算函数 ===
                cal_metrics(df, f"{output_path_prefix}.{dataset_name}.{env}",
                            "pred_score", "int_label", self.thres)

                print(f"[INFO] Metrics calculation done for {dataset_name}.{env}\n")


if __name__ == "__main__":
    obj = CalculateMetrics()
    obj.process()

# python -m search.qa_bot.qwen3_reranker.eval.calculate_metrics
