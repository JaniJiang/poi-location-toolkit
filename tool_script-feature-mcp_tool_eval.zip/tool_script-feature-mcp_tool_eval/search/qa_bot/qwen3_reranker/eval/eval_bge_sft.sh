#!/bin/bash
# bash search/qa_bot/qwen3_reranker/eval/eval_bge_sft.sh

eval_version="v1-20250815"
tokenizer_dir="data/cloud_share/qabot_relevance_model/bge-base-zh-v1.5"
model_dir="data/cloud_share/qabot_relevance_model/bge-base-sft/v1-20250721/pytorch_model.bin_optimal_epoch"
onnx_dir="data/cloud_share/qabot_relevance_model/online_onnx_model.onnx"
eval_dataset_dir="data/cloud_share/qabot_relevance_data/qwen3_reranker/eval/input/eval_v5.tsv"
output_json="data/cloud_share/qabot_relevance_data/qwen3_reranker/eval/output_bge_sft/${eval_version}/sft_model_score.json"
output_excel="data/cloud_share/qabot_relevance_data/qwen3_reranker/eval/output_bge_sft/${eval_version}/sft_model_score"

python -m search.qa_bot.service_bot_relevance.src.eval.eval \
    --tokenizer_dir ${tokenizer_dir} \
    --model_dir ${model_dir} \
    --onnx_dir ${onnx_dir} \
    --eval_dataset_dir ${eval_dataset_dir} \
    --output_json ${output_json} \
    --output_excel ${output_excel} \
    --eval_time ${eval_version} \
    --eval_onnx "false"
