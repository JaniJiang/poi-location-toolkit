import os
import re
import csv
import threading
import pandas as pd
from tqdm import tqdm
from typing import List
from loguru import logger
from joblib import Parallel, delayed
from utils.file_utils import check_output_path
from utils.llm_utils.openai_style_api import OpenAIStyleAPI
from search.qa_bot.qwen3_reranker.meta import *
from search.qa_bot.qwen3_reranker.prompt import *

API_DICT = {
    "lpai_llm": {
        "model": "qabot-qwen3-reranker",
        "url": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/qabot-qwen3-reranker-a11a-ltuhqp/v1/completions",
    },
}


class EvalLpaiLLM:

    def __init__(self, env):
        self.env = env
        self.dataset_name_list = ["incarassistant_query"]
        # 推理接口参数
        self.model, self.url = API_DICT[env]["model"], API_DICT[env]["url"]
        self.api_obj = OpenAIStyleAPI(self.url)
        # 设置并发控制参数
        self.n_jobs = 20  # 并发度
        self.file_lock = threading.Lock()  # 文件锁

    def process(self):
        for dataset_name in tqdm(self.dataset_name_list, total=(len(self.dataset_name_list))):
            input_path = f"{EVAL_DIR}/input/{dataset_name}.tsv"
            output_path = f"{EVAL_DIR}/output/{EVAL_VERSION}/{dataset_name}.{self.env}.tsv"
            # 校验输出路径
            check_output_path(output_path)
            # 读取输入数据
            sample_df = pd.read_csv(input_path, sep="\t")
            # 并发处理
            # Parallel(n_jobs=self.n_jobs, prefer="threads")(
            #     delayed(self.process_sample_one)(output_path, sample_row)
            #     for _, sample_row in tqdm(sample_df.iterrows(), total=len(sample_df))
            # )
            # 非并发，保持原有顺序
            for _, sample_row in tqdm(sample_df.iterrows(), total=len(sample_df)):
                self.process_sample_one(output_path, sample_row)

    def process_sample_one(self, output_path: str, sample_row: pd.Series) -> bool:
        sample_dict = sample_row.to_dict()
        instruction, output = build_prompt(sample_dict)
        if instruction == "" or output == "":
            return False
        # 请求推理接口
        pred_str = self.do_predict(instruction)
        pred_label = self.parse_pred_str(pred_str)
        acc = "1" if sample_row["label"] == pred_label else "0"
        # 保存推理结果
        sample_dict["pred_score"] = ""
        sample_dict["pred_label"] = pred_label
        sample_dict["acc"] = acc
        print("ACC: {}".format(sum(acc)/len(acc)))
        self.save_result(output_path, [sample_dict])
        return True

    def do_predict(self, instruction):
        try:
            return self.api_obj.v1_completions(self.model, instruction.rstrip("\n") + "\n")
        except Exception as e:
            logger.warning("[EvalLpaiLLM] do_predict failed: " + str(e))
            return ""

    def parse_pred_str(self, pred_str: str) -> str:
        label_pred = ""
        pattern = r'<think>\n\n</think>\n\n(.*)'
        match = re.search(pattern, pred_str, re.DOTALL)
        if match:
            label_pred = match.group(1)
        return label_pred

    def save_result(self, output_path: str, result_list: List[Dict[str, str]]):
        with self.file_lock:
            fieldnames = result_list[0].keys()
            file_exists = os.path.isfile(output_path) and os.path.getsize(output_path) > 0
            with open(output_path, "a", encoding="utf-8", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter="\t")
                if not file_exists:
                    writer.writeheader()
                writer.writerows(result_list)


if __name__ == "__main__":
    obj = EvalLpaiLLM("lpai_llm")
    obj.process()

# python -m search.qa_bot.qwen3_reranker.eval.eval_lpai_llm
