import json
import asyncio
import aiohttp
import pandas as pd
from asyncio import Semaphore
from tqdm.asyncio import tqdm_asyncio
from utils.llm_utils.serverless_function import request_llm_async, RateLimiter
from search.qa_bot.qwen3_reranker.bak.train.prompt import *


class GetGPTLabel():
    def __init__(self,
                 input_path="data/cloud_share/qabot_relevance_data/trainset/formal_shuffled/autoqa_0715.tsv",
                 output_path="data/cloud_share/qabot_relevance_data/trainset/formal_shuffled/autoqa_0715_labelled_gpt4o_v3_train.tsv"):
        self.input_path = input_path
        self.output_path = output_path
        self.model_name = "gpt-4o"  # gpt-4o | claude-3_5-sonnet | deepseek-v3 | deepseek-r1 | deepseek-r1-distill-qwen-32b
        self.max_concurrent = 10
        self.qps = 3    # 推荐不大于4

    def load_data(self):
        df = pd.read_csv(self.input_path, sep='\t').drop_duplicates().iloc[:, :2]
        df.columns = ["query", "title"]
        return df

    def process(self, input_list=None):
        if not input_list:
            input_list = self.load_data().iloc[-5000:]
            # input_list = input_list.sample(min(1000, len(input_list)))
        loop = asyncio.get_event_loop()
        res = loop.run_until_complete(self.process_async(input_list, max_retries=3))
        res = pd.DataFrame(res)
        res["label"] = res["label"].map({"相关": "yes", "不相关": "no"})
        res.to_csv(self.output_path, sep='\t', index=False)
        return res

    async def process_async(self, input_list, max_retries):
        rate_limiter = RateLimiter(self.qps)
        semaphore = Semaphore(self.max_concurrent)  # 限制最大并发数为 max_concurrent
        async with aiohttp.ClientSession() as session:
            tasks = [self.process_item_async(rate_limiter, semaphore, session, item, max_retries) for
                     item in input_list.iloc]
            results = [None] * len(tasks)
            task_objects = [asyncio.create_task(task) for task in tasks]
            for idx, task in tqdm_asyncio(zip(range(len(tasks)), task_objects), total=len(tasks)):
                response = await task
                # 根据任务的索引存储结果
                results[idx] = response
        return results

    async def process_item_async(self, rate_limiter, semaphore, session, item, max_retries):
        """单条数据处理流程：规则过滤→LLM判断→结果回写"""

        history = [
            PROMPT_STATE,
            USER_PROMPT_STATE.format(query=item['query'],
                                     question=item['title'])
        ]

        try:
            _, response_data = await request_llm_async(
                rate_limiter,
                semaphore,
                session,
                max_retries,
                history,
                model=self.model_name,
                n=1,
                temperature=0
            )
            question_new_str = response_data["choices"][0]["message"]["content"]
            question_new_list = json.loads(question_new_str)
        except Exception as e:
            question_new_list = []
            print(e)
            try:
                # 尝试修复格式错误
                question_new_list = json.loads(question_new_str.strip().strip(
                    '`').replace("json", '').replace("\n", ""))
            except Exception as e:
                print("llm-api调用失败")
                return item

        # 5. 回写判断结果
        try:
            item["label"] = question_new_list["result"]
            item["analyse_query"] = question_new_list["实体是否相关"]
            item["analyse_question"] = question_new_list["语义是否相关"]
        except Exception as e:
            pass
        # print(item)
        # print(question_new_list)
        return item


if __name__ == "__main__":
    obj = GetGPTLabel()
    res = obj.process()
