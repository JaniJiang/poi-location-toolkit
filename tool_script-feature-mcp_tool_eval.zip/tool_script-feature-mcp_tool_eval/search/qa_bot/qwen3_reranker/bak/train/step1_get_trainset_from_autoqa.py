import os
import json
import pandas as pd
from utils.file_utils import read_jsonl_file


class GetTrainsetFromQa():
    def __init__(self,
                 data_dir="",
                 data_path="data/cloud/search/qa_bot/qa_bot_test_by_week/W15",
                 suffix="real_and_relevance.jsonl",
                 output_path="data/cloud_share/qabot_relevance_data/trainset/formal_shuffled/new_train_from_autoqa.tsv"):
        self.data_dir = data_dir
        self.data_path = data_path
        # 优先data_dir
        if os.path.isdir(self.data_dir):
            self.data_path_list = [os.path.join(self.data_dir, path) for path in os.listdir(self.data_dir)]
        else:
            self.data_path_list = [self.data_path]
        self.suffix = suffix
        self.output_path = output_path

    def load_data(self, path):
        data = read_jsonl_file(os.path.join(path, self.suffix))
        query_list = []
        question_list = []
        for item in data:
            try:
                if "qabot" in item["knowledge_search_result"]:
                    kg_search_res = json.loads(item["knowledge_search_result"])[0]["data"][0]['bot_data']
                    for res in kg_search_res:
                        if "qabot" not in str(res):
                            continue
                        else:
                            question_list.append(res["title"])
                            query_list.append(item["query"])
                            break
            except Exception as e:
                print(e)

        return query_list, question_list

    def process(self):
        df = pd.DataFrame()
        for path in self.data_path_list:
            query_list, question_list = obj.load_data(path)
            df = pd.concat([df, pd.DataFrame({"query": query_list,
                                              "title": question_list,
                                              })], ignore_index=True)
        df.drop_duplicates(inplace=True)
        df.to_csv(self.output_path, sep='\t', index=False, header=None)
        return df


if __name__ == "__main__":
    obj = GetTrainsetFromQa(
        data_dir="data/cloud/search/qa_bot/qa_bot_test",
        suffix="step3_real_and_relevance.jsonl",
        output_path="data/cloud_share/qabot_relevance_data/trainset/formal_shuffled/autoqa_0715.tsv",
    )
    obj.process()
