#!/bin/bash
# sh search/qa_bot/qwen3_reranker/train/train_bge.sh

train_version="v1-20250721"
python -m search.qa_bot.service_bot_relevance.src.train.train \
    --train_stage 1 \
    --tokenizer_dir "data/cloud_share/qabot_relevance_model/bge-base-zh-v1.5" \
    --model_dir "data/cloud_share/qabot_relevance_model/bge-base-zh-v1.5" \
    --data_dir "data/cloud_share/qabot_relevance_data/qwen3_reranker/eval/input/train_v1.tsv" \
    --outmodel_dir "data/cloud_share/qabot_relevance_model/bge-base-sft/${train_version}/pytorch_model.bin" \
    --has_pretrained "false" \
    --epochs 8 \
    --eval_dataset_dir "data/cloud_share/qabot_relevance_data/qwen3_reranker/eval/input/eval_v1.tsv" \
    --lr 5e-6 \
    --train_batch_size 32 \
    --eval_batch_size 32