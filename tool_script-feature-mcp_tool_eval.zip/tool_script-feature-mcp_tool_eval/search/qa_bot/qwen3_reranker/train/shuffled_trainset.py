import pandas as pd
import argparse
from search.qa_bot.qwen3_reranker.meta import *

if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument("--data_dir", help="input dataset path", type=str)
    args = parser.parse_args()

    df = pd.read_csv(args.data_dir, sep='\t')
    rows = df.values.tolist()
    my_random.shuffle(rows)
    df = pd.DataFrame(rows, columns=df.columns)
    df[["query", "title", "label"]].to_csv(args.data_dir, sep='\t', encoding='utf-8', index=False)
