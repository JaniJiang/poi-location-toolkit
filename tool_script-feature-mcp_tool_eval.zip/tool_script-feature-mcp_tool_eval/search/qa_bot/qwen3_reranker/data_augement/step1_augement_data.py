import pandas as pd
from tqdm import tqdm
from search.qa_bot.qwen3_reranker.meta import *
from search.qa_bot.qwen3_reranker.sample.retriever.step3_search_data import SearchData


class FindNeedData():
    def __init__(self, eval_data_path, train_data_path, augement_data_path, log_size, qa_size):
        self.augement_data_path = augement_data_path
        self.dataset = pd.read_csv(eval_data_path, sep="\t").fillna("").to_dict(orient="records")
        self.augement_dataset = pd.read_csv(train_data_path, sep="\t").fillna("").to_dict(orient="records")
        self.log_size = log_size
        self.qa_size = qa_size
        self.Searcher = SearchData()

    def augement_data(self, search_dict, title):

        for key, values in search_dict.items():
            if key == LOG_INDEX_NAME:
                for data in values:
                    item = {
                        "query": data["text_rewrite"],
                        "title": title,
                        "label": "yes",
                    }
                    self.augement_dataset.append(item)

            elif key == QA_INDEX_NAME:
                for data in values:
                    for alias in data.get("text_alias", []):
                        item = {
                            "query": alias,
                            "title": data["text"],
                            "label": "yes",
                        }
                        self.augement_dataset.append(item)

    def run(self):
        for _, data in tqdm(enumerate(self.dataset), desc="Processing", total=len(self.dataset)):
            query = data["query"]
            title = data["title"]
            if data["label"] != data["pred_label"]:
                search_dict = self.Searcher.search(query, self.log_size, self.qa_size)
                self.augement_data(search_dict, title)

        df_save = pd.DataFrame(self.augement_dataset)
        df_save.to_csv(self.augement_data_path, sep="\t", index=False)
        print(f"增强数据已经保存至： {self.augement_data_path}")


if __name__ == "__main__":
    eval_data_path = "data/cloud_share/qabot_relevance_data/qwen3_reranker/data_augement_base_data/eval_v3_pred.tsv"
    train_data_path = "data/cloud_share/qabot_relevance_data/qwen3_reranker/eval/input/train_v2.tsv"
    augement_data_path = "data/cloud_share/qabot_relevance_data/qwen3_reranker/eval/input/train_v4.tsv"
    log_size = 1
    qa_size = 1
    FindNeedData(eval_data_path, train_data_path, augement_data_path, log_size, qa_size).run()
    # python -m search.qa_bot.qwen3_reranker.data_augement.step1_augement_data
