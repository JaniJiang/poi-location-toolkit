

class GridSearch():
    def __init__(self):
        pass

    def grid(self):
        ...
        # 阈值搜索
        # 数据集构建：STEP1
        # 训练数据
