import random

# 数据目录
DATA_DIR = "data/cloud_share/qabot_relevance_data/qwen3_reranker"
# 样本配置
SAMPLE_DIR = f"{DATA_DIR}/sample"
DATA_VERSION = "train_0919"
SAMPLE_VERSION = "train_0919"
# 评估配置
EVAL_DIR = f"{DATA_DIR}/eval"
EVAL_VERSION = "train_0918"

# 设置随机数种子
my_random = random.Random()
my_random.seed(42)

# ES索引
CLUSTER_NAME = "tool_offline_algorithm"
LOG_INDEX_NAME = f"qa_bot_log_data_v1"
QA_INDEX_NAME = f"qa_bot_qa_data_v1"
