from tqdm import tqdm
from utils.file_utils import check_output_path, read_jsonl_file, write_json_file
from search.qa_bot.qwen3_reranker.meta import *
from search.qa_bot.qwen3_reranker.prompt import *


class BuildDataset:

    def __init__(self):
        self.input_path = f"{SAMPLE_DIR}/train/{SAMPLE_VERSION}.jsonl"
        self.output_path = f"{SAMPLE_DIR}/train/{SAMPLE_VERSION}.json"
        check_output_path(self.output_path)
        # 样本重复次数
        self.repeat_times = 4

    def process(self):
        # 读取输入数据
        sample_list = read_jsonl_file(self.input_path)
        # 格式化数据到训练格式
        result_list = []
        for sample_one in tqdm(sample_list, total=len(sample_list)):
            instruction, output = build_prompt(sample_one)
            if instruction == "" or output == "":
                continue
            # 先把种子样本重复几次，观察模型能否收敛
            for _ in range(self.repeat_times):
                result_list.append({"instruction": instruction, "input": "", "output": output})
        # 随机打乱数据顺序
        my_random.shuffle(result_list)
        # 保存处理结果
        write_json_file(result_list, self.output_path)


if __name__ == "__main__":
    obj = BuildDataset()
    obj.process()

# python -m search.qa_bot.qwen3_reranker.sample.build_train_dataset.step2_build_dataset
