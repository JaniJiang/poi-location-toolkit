#!/bin/bash
# sh search/qa_bot/qwen3_reranker/sample/build_train_dataset/run_pipeline.sh

python -m search.qa_bot.qwen3_reranker.sample.build_train_dataset.step1_build_sample
python -m search.qa_bot.qwen3_reranker.sample.build_train_dataset.step2_build_dataset
