import pandas as pd
from utils.file_utils import check_output_path, write_jsonl_file
from search.qa_bot.qwen3_reranker.meta import *
from search.qa_bot.qwen3_reranker.prompt import *


class BuildSample:

    def __init__(self):
        self.input_path = f"{EVAL_DIR}/input/{DATA_VERSION}.tsv"
        self.output_path = f"{SAMPLE_DIR}/train/{SAMPLE_VERSION}.jsonl"
        check_output_path(self.output_path)

    def process(self):
        input_df = pd.read_csv(self.input_path, sep="\t")
        input_df["label"] = input_df["label"].map({
            1: POS_LABEL, 0: POS_LABEL,
            POS_LABEL: POS_LABEL, NEG_LABEL: NEG_LABEL,
        })
        sample_list = input_df.to_dict("records")
        write_jsonl_file(sample_list, self.output_path)


if __name__ == "__main__":
    obj = BuildSample()
    obj.process()

# python -m search.qa_bot.qwen3_reranker.sample.build_train_dataset.step1_build_sample
