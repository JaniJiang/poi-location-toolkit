import random
import itertools
import pdb
import json
import time
from tqdm import tqdm
import pandas as pd
from utils.file_utils import read_jsonl_file
from utils.search_utils.call_cockpit_qabot import request_qabot

if __name__ == "__main__":
    path = "data/cloud_share/qabot_relevance_data/qwen3_reranker/sample/manual/qadata_0912_full.json"
    with open(path, "r") as file:
        data = json.load(file)
    # data = read_jsonl_file(path)
    all_sample = []
    for id, question_list in tqdm(data.items()):
        try:
            question = random.choice(question_list).strip()
            res = request_qabot(query=question, url="http://10.125.136.1:12561/recall/query")
            pos_list = []
            neg_list = []
            for d in res["data"]:
                if d["questionId"] == id and len(pos_list) <= 3:
                    pos_list.append(d["expandQuestion"].strip())
                elif d["questionId"] != id and len(neg_list) <= 5:
                    neg_list.append(d["expandQuestion"].strip())
                elif len(neg_list) > 5 and len(pos_list) > 3:
                    break
            cur_pos_sample = [list(x)+["yes"] for x in itertools.combinations(pos_list, 2)] if len(pos_list) > 1 else []
            cur_neg_sample = [[random.choice(pos_list), x, "no"]
                              for x in neg_list] if len(neg_list) > 0 and len(pos_list) > 0 else []
            all_sample += cur_pos_sample
            all_sample += cur_neg_sample
            time.sleep(0.1)
        except Exception as e:
            print(e)
            pdb.set_trace()
    pdb.set_trace()
    df = pd.DataFrame(all_sample, columns=["query", "title", "label"])
    df.to_csv("data/cloud_share/qabot_relevance_data/qwen3_reranker/sample/manual/manual_from_platform.tsv", sep='\t', index=False)

# python -m search.qa_bot.qwen3_reranker.sample.manual_sample.construct
