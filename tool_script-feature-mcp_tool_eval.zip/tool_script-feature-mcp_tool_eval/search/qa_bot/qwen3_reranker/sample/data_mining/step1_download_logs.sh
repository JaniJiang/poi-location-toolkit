SQL_STRING="select query,slot_li,count(1) as pv from dwd_vechile_merge_prod_di where (dt between  '2025-01-01' and '2025-07-16') AND \
(domain in ('gpt_autoqa'))and vehicle_category = '1' and ota_version > '5' \
and query is not null and query != '' and content NOT like '%大朋友小朋友们，六一儿童节快乐%' \
and record_id is not null and record_id != '' \
group by query, slot_li \
order by pv desc"

CSV_FILE="data/cloud_share/qabot_relevance_data/qwen3_reranker/active_learning/gpt_autoqa_log.csv"

# --- 执行查询并导出数据 ---
echo "开始执行SQL查询并导出CSV文件..."
echo "SQL语句: $SQL_STRING"
echo "输出路径: $CSV_FILE"

# 使用adt工具执行查询（需配置有效token）
adt --token 731a63a43618b0b444a2b86f36cf3e14 ark2csv --sql-string "$SQL_STRING" --csv-file "$CSV_FILE"

if [ $? -eq 0 ]; then
  echo "数据已成功导出至 $CSV_FILE"
else
  echo "数据导出过程中发生错误。"
  exit 1
fi

echo "脚本执行完成。"