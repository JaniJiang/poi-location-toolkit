import json
import math
import pandas as pd
from tqdm import tqdm
from collections import defaultdict
from utils.file_utils import check_output_path
from search.qa_bot.qwen3_reranker.meta import *


class CalculateIDF:

    def __init__(self):
        self.input_path_list = [
            {
                "name": "in_car_assistant",
                "enable": True,
                "path": f"{DATA_DIR}/data_mining/step1_in_car_assistant_log.csv",
            },
            {
                "name": "gpt_autoqa",
                "enable": True,
                "path": f"{DATA_DIR}/data_mining/step1_gpt_autoqa_log.csv",
            },
        ]
        self.output_path = f"{DATA_DIR}/data_mining/step2_calculate_idf.tsv"
        check_output_path(self.output_path)
        self.need_pv = True

    def process(self):
        all_pv_count = 0
        tag_pv_dict = defaultdict(lambda: 0)
        tag_idf_dict = defaultdict(lambda: 0)
        # 首先统计每个词在多少个文档中出现
        for input_path_item in self.input_path_list:
            if input_path_item["enable"] is False:
                continue
            input_df = pd.read_csv(input_path_item["path"])
            for _, row in tqdm(input_df.iterrows(), total=len(input_df), desc=input_path_item["name"]):
                try:
                    slot_li = json.loads(row["slot_li"])
                    tag_list = slot_li[0]["tag"].split("&")
                except:
                    tag_list = []
                if len(tag_list) == 0:
                    continue
                pv = row["pv"] if self.need_pv is True else 1
                all_pv_count += pv
                for tag in tag_list:
                    tag_pv_dict[tag] += pv
        # 根据公式计算IDF值
        for tag, tag_pv in tag_pv_dict.items():
            tag_idf_dict[tag] = math.log(all_pv_count / float(tag_pv))
        # 保存处理结果
        sorted_idf = sorted(tag_idf_dict.items(), key=lambda x: x[1], reverse=True)
        with open(self.output_path, "w", encoding="utf-8") as f:
            for tag, tag_idf in sorted_idf:
                tag_pv = tag_pv_dict[tag]
                f.write(f"{tag}\t{tag_pv}\t{tag_idf:.6f}\n")


if __name__ == "__main__":
    obj = CalculateIDF()
    obj.process()

# python -m search.qa_bot.qwen3_reranker.sample.data_mining.step2_calculate_idf
# nohup python -m search.qa_bot.qwen3_reranker.sample.data_mining.step2_calculate_idf > log/search/qa_bot/qwen3_reranker/sample/data_mining/step2_calculate_idf.log 2>&1 &
