from loguru import logger
from utils.file_utils import read_jsonl_file
from utils.search_utils.es_client import ElasticSearchClient
from search.qa_bot.qwen3_reranker.meta import *


class PushData:

    def __init__(self, index_name, input_path, refresh_index):
        self.index_name = index_name
        self.input_path = input_path
        self.refresh_index = refresh_index
        # init es client
        self.es_client = ElasticSearchClient(CLUSTER_NAME)
        self.mapping = {
            "properties": {
                "id": {"type": "keyword"},
                "text": {"type": "text"},
                "text_rewrite": {"type": "text"},
                "text_alias": {"type": "text"},
                "pv": {"type": "integer"},
            }
        }

    def process(self):
        # create index
        code = self.es_client.check_and_create_index(self.index_name, self.refresh_index, self.mapping)
        if code is False:
            logger.error(f"[PushData] check_and_create_index {self.index_name} failed")
            return False
        logger.info(f"[PushData] check_and_create_index {self.index_name} success")
        # read data
        data_list = read_jsonl_file(self.input_path)
        # load data
        success, failed = self.es_client.load_data(self.index_name, data_list)
        logger.info(f"[PushData] {success} documents loaded successfully, {failed} documents failed to load.")
        return True

    def append(self):
        # read data
        data_list = read_jsonl_file(self.input_path)
        # load data
        success, failed = self.es_client.load_data(self.index_name, data_list)
        logger.info(f"[PushData] {success} documents loaded successfully, {failed} documents failed to load.")
        return True


if __name__ == "__main__":
    index2data_list = [
        (LOG_INDEX_NAME, f"{DATA_DIR}/retriever/step1_build_log_data_0916.jsonl"),
        # (QA_INDEX_NAME, f"{DATA_DIR}/retriever/step1_build_qa_data.jsonl"),
    ]
    refresh_index = True
    for index_name, input_path in index2data_list:
        obj = PushData(index_name, input_path, refresh_index)
        obj.append()

# python -m search.qa_bot.qwen3_reranker.sample.retriever.step2_push_data
# nohup python -m search.qa_bot.qwen3_reranker.sample.retriever.step2_push_data > log/search/qa_bot/qwen3_reranker/sample/retriever/step2_push_data.log 2>&1 &
