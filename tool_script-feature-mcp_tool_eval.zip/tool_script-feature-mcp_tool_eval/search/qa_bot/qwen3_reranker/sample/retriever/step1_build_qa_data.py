import json
from utils.file_utils import read_json_file_union
from search.qa_bot.qwen3_reranker.meta import *


class BuildQaData:

    def __init__(self):
        self.input_path = "data/cloud_share/qabot_miner/qa_index/data.json"
        self.output_path = f"{DATA_DIR}/retriever/step1_build_qa_data.jsonl"

    def process(self):
        with open(self.output_path, "w", encoding="utf-8") as f:
            input_list = read_json_file_union(self.input_path)
            for item in input_list:
                question_list = [x.strip() for x in item.get("question", []) if x.strip() != ""]
                if len(question_list) == 0:
                    continue
                try:
                    question_id = str(item["answerGroup"][0]["questionId"])
                except:
                    continue
                # 拼装建库数据
                item = {
                    "id": question_id,
                    "text": question_list[0],
                    "text_rewrite": "",
                    "text_alias": question_list[1:],
                    "pv": 0,
                }
                f.write(json.dumps(item, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    obj = BuildQaData()
    obj.process()

# python -m search.qa_bot.qwen3_reranker.sample.retriever.step1_build_qa_data
