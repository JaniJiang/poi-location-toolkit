import json
from utils.search_utils.es_client import ElasticSearchClient
from search.qa_bot.qwen3_reranker.meta import *


class SearchData:

    def __init__(self):
        self.es_client = ElasticSearchClient(CLUSTER_NAME)

    def search(self, text: str, log_size: int = 100, qa_size: int = 10):
        # 查询日志数据
        log_query_dsl_dict = self.log_query_recall_strategy(text, log_size)
        log_item_list = self.es_client.search(log_query_dsl_dict, LOG_INDEX_NAME, need_parse=True)
        # 查询qa数据
        qa_query_dsl_dict = self.qa_query_recall_strategy(text, qa_size)
        qa_item_list = self.es_client.search(qa_query_dsl_dict, QA_INDEX_NAME, need_parse=True)
        # 拼装结果
        result_dict = {
            LOG_INDEX_NAME: log_item_list,
            QA_INDEX_NAME: qa_item_list,
        }
        return result_dict

    def log_query_recall_strategy(self, text, size):
        """日志query召回策略"""
        query_dsl_dict = {
            "query": {
                "bool": {
                    "should": [
                        {"match": {"text": {"query": text, "boost": 1.0}}},
                        {"match": {"text_rewrite": {"query": text, "boost": 1.0}}},
                    ],
                    "minimum_should_match": 1
                }
            },
            "_source": ["text", "text_rewrite", "pv"],
            "size": size
        }
        return query_dsl_dict

    def qa_query_recall_strategy(self, text, size):
        """问答库query召回策略"""
        query_dsl_dict = {
            "query": {
                "bool": {
                    "should": [
                        {"match": {"text": {"query": text, "boost": 1.0}}},
                        {"match": {"text_alias": {"query": text, "boost": 1.0}}},
                    ],
                    "minimum_should_match": 1
                }
            },
            "_source": ["text", "text_alias", "pv"],
            "size": size
        }
        return query_dsl_dict


if __name__ == "__main__":
    obj = SearchData()
    result_dict = obj.search("本车有无carplay", log_size=10, qa_size=200)["qa_bot_log_data_v1"]
    print(json.dumps(result_dict, ensure_ascii=False, indent=4))

# python -m search.qa_bot.qwen3_reranker.sample.retriever.step3_search_data
