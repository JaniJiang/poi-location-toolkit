import os
import json
import hashlib
import pandas as pd
from tqdm import tqdm
from typing import List
from search.qa_bot.qwen3_reranker.meta import *


class BuildLogData:

    def __init__(self):
        self.input_path_list = [
            f"{DATA_DIR}/data_mining/step1_in_car_assistant_log.csv",
            f"{DATA_DIR}/data_mining/step1_gpt_autoqa_log.csv",
        ]
        self.output_path = f"{DATA_DIR}/retriever/step1_build_log_data.jsonl"

    def process_new_log(self):
        input_path = "data/cloud_share/qabot_relevance_data/qwen3_reranker/data_mining/step1_in_car_assistant_log_0916.tsv"
        output_path = f"{DATA_DIR}/retriever/step1_build_log_data_0916.jsonl"
        with open(output_path, "w", encoding="utf-8") as f:
            # 读取输入数据
            input_df = pd.read_csv(input_path, sep='\t').fillna("")
            # 逐条处理生成索引数据
            for _, row in tqdm(input_df.iterrows(), total=len(input_df), desc=os.path.basename(input_path)):
                text = text_rewrite = row["input_query"]
                if text.lower() in ["", "-", "_", "null", "none"]:
                    continue
                pv = 0
                try:
                    pv = int(row["pv"])
                except:
                    pass
                data_id = self.generate_data_id([text, text_rewrite])  # TODO: data_id去重
                # 拼装建库数据
                item = {
                    "id": data_id,
                    "text": text,
                    "text_rewrite": text_rewrite,
                    "text_alias": [],
                    "pv": pv,
                }
                f.write(json.dumps(item, ensure_ascii=False) + "\n")

    def process(self):
        with open(self.output_path, "w", encoding="utf-8") as f:
            for input_path in self.input_path_list:
                # 读取输入数据
                input_df = pd.read_csv(input_path).fillna("")
                # 逐条处理生成索引数据
                for _, row in tqdm(input_df.iterrows(), total=len(input_df), desc=os.path.basename(input_path)):
                    text = row["query"]
                    if text.lower() in ["", "-", "_", "null", "none"]:
                        continue
                    pv = 0
                    text_rewrite = ""
                    try:
                        slot_li = json.loads(row["slot_li"])[0]
                        if "QUERY" in slot_li:
                            text_rewrite = slot_li["QUERY"]
                        elif "query" in slot_li:
                            text_rewrite = slot_li["query"]
                        pv = int(row["pv"])
                    except:
                        pass
                    data_id = self.generate_data_id([text, text_rewrite])  # TODO: data_id去重
                    # 拼装建库数据
                    item = {
                        "id": data_id,
                        "text": text,
                        "text_rewrite": text_rewrite,
                        "text_alias": [],
                        "pv": pv,
                    }
                    f.write(json.dumps(item, ensure_ascii=False) + "\n")

    def generate_data_id(self, text_list: List[str]) -> str:
        join_text = "|".join(text_list)
        data_id = hashlib.md5(join_text.encode("utf-8")).hexdigest()
        return data_id


if __name__ == "__main__":
    obj = BuildLogData()
    obj.process_new_log()

# python -m search.qa_bot.qwen3_reranker.sample.retriever.step1_build_log_data
# nohup python -m search.qa_bot.qwen3_reranker.sample.retriever.step1_build_log_data > log/search/qa_bot/qwen3_reranker/sample/retriever/step1_build_log_data.log 2>&1 &
