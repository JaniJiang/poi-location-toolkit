主动学习步骤
1. 测试集/训练集badcase【e.g. data/cloud_share/qabot_relevance_data/qwen3_reranker/eval/output/v1-20250713】
2. 线上用户日志query作为数据集，badcase作为query对数据集进行召回，构造文本对
3. 用原模型进行标注，得到伪标签，进行训练：

    3.1. 单独训练
    
    3.2. 合并进原有的训练集进行训练