from search.qa_bot.service_bot_analyse.utils.meta import *
from utils.nlp_utils.embedding import get_batch_embedding
import json
from tqdm import tqdm
import pandas as pd

BATCH_SIZE = 32


class KnowledgeIndex:
    """构建知识的索引数据"""

    def __init__(self):
        self.input_path_list = [
            {
                "path": "data/cloud_share/qabot_relevance_data/qwen3_reranker/active_learning/in_car_assistant_log.csv",
                "from": "qa",
                "enable": True,
                "need_dedup": False,
            }
        ]
        self.output_path = "data/cloud_share/qabot_relevance_data/qwen3_reranker/active_learning/knowledge_index"

    def process(self):
        for input_path_item in self.input_path_list:
            if input_path_item["enable"] is False:
                continue
            input_path = input_path_item["path"]
            input_from = input_path_item["from"]
            # 读取knowledge数据
            knowledge_list = pd.read_csv(input_path)
            print("origin knowledge_list len:", input_from, len(knowledge_list))
            # 去重策略
            if input_path_item["need_dedup"] is True:
                knowledge_list = self.dedup_strategy(knowledge_list)
                print("dedup knowledge_list len:", len(knowledge_list))
            # 逐条处理knowledge生成索引数据
            with open(f"{self.output_path}.{input_from}.jsonl", "w", encoding="utf-8") as f:
                for i in tqdm(range(0, len(knowledge_list), BATCH_SIZE), desc="index"):
                    batch_question_list = knowledge_list['query'][i: (i + BATCH_SIZE)].to_list()
                    batch_slot_list = knowledge_list['slot_li'][i: (i + BATCH_SIZE)].to_list()
                    batch_pv_list = knowledge_list['pv'][i: (i + BATCH_SIZE)].to_list()
                    # 获取索引文本对应的向量
                    try:
                        batch_embedding_list = get_batch_embedding(batch_question_list, DIM, BATCH_SIZE)
                    except:
                        print("get_batch_embedding failed:")
                        continue
                    if len(batch_question_list) != len(batch_embedding_list):
                        continue
                    # 逐条生成qdrant索引数据
                    for j, batch_question in enumerate(batch_question_list):
                        index_id = i+j
                        batch_embedding = batch_embedding_list[j]
                        qdrant_item = {
                            "id": index_id,
                            "vector": batch_embedding,
                            "query": batch_question,
                            "pv": batch_pv_list[j],
                            "slot": batch_slot_list[j]
                        }
                        f.write(json.dumps(qdrant_item, ensure_ascii=False) + "\n")

    def dedup_strategy(self, knowledge_list):
        dedup_knowledge_list = []
        question_dict = {}
        for knowledge_item in tqdm(knowledge_list, total=len(knowledge_list), desc="dedup"):
            feature_dict = knowledge_item.get("feature_dict", {})
            question = feature_dict.get("question", "")
            if question == "" or question in question_dict:
                continue
            dedup_knowledge_list.append(knowledge_item)
            question_dict[question] = True
        return dedup_knowledge_list


if __name__ == "__main__":
    obj = KnowledgeIndex()
    obj.process()

# python -m search.qa_bot.qa_data_analyse.knowledge_index
# nohup python -m search.qa_bot.qa_data_analyse.knowledge_index > log/search/qa_bot/qa_data_analyse/knowledge_index.log 2>&1 &
