"""
data/cloud_share/qabot_relevance_data/qwen3_reranker/eval/output/v1-20250713
获取badcase
"""
import pandas as pd

# badcase输入路径（模型预测结果）
input_path = "data/cloud_share/qabot_relevance_data/qwen3_reranker/eval/output/v1-20250713/trainset_0716.local.tsv"
# 人工基于规则筛选，待进行数据增强的query路径
output_path = "data/cloud_share/qabot_relevance_data/qwen3_reranker/active_learning/augmented_train.tsv"
# 模型对应的阈值
thres = 0.03
# 阈值规则区间，hardcase区间
range_left = 0.01
range_right = 0.08

if __name__ == "__main__":
    df = pd.read_csv(input_path, sep='\t')
    # acc
    acc = [1 if ((item['pred_score'] > thres) & (item['label'] == "yes")) or (
        (item['pred_score'] < thres) & (item['label'] == "no")) else 0 for item in df.iloc]
    df['acc'] = acc
    # 筛选错误的case
    df = df[df['acc'] == 0]
    # 筛选hardcase
    df_filtered = df[(df['pred_score'] > range_left) & (df['pred_score'] < range_right)]
    print(f"{len(df_filtered)} data leaved")
    # 保存
    df_filtered.to_csv(output_path, sep='\t', index=False)
