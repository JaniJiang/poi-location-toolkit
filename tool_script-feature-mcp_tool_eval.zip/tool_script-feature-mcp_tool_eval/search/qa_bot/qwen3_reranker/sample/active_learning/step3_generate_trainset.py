from search.qa_bot.qwen3_reranker.eval.eval_local_llm import *
from search.qa_bot.qwen3_reranker.eval.eval_lpai_llm import *
from search.qa_bot.service_bot_analyse.utils.prompt import *
from search.qa_bot.service_bot_analyse.utils.meta import *
from utils.nlp_utils.embedding import get_batch_embedding
from utils.search_utils.memory_qdrant import MemoryQdrant
from utils.file_utils import read_jsonl_file
import os
import pandas as pd
from tqdm import tqdm


class GenerateTrainset:
    """知识覆盖工具：未完成的Query请求离线索引库获取候选知识，通过LLM判断候选知识能否回答Query"""

    def __init__(self, query_path="data/cloud_share/qabot_relevance_data/qwen3_reranker/active_learning/augmented_train.tsv",
                 output_path="data/cloud_share/qabot_relevance_data/qwen3_reranker/active_learning/augmented_train_labelled.tsv",
                 index_path="data/cloud_share/qabot_relevance_data/qwen3_reranker/active_learning/knowledge_index.qa_platform.jsonl"):
        self.query_path = query_path
        self.index_path = index_path
        self.output_path = output_path
        self.recall_num = 3
        self.batch_size = 64
        self.thres = 0.108

    def process(self, query_text_list=pd.DataFrame()):
        # 读取query数据
        query_text_list = pd.read_csv(self.query_path, sep='\t')
        if len(query_text_list) < 1:
            print("Empty Input")
            return

        # 读取index数据
        if os.path.exists(self.index_path):
            index_path = self.build_index(self.index_path)
        else:
            print("Empty Index")
            return
        query_list = query_text_list["query"].to_list()
        # 计算embed，选择与原query区分度最大的改写query，进行召回
        emb_list = get_batch_embedding(query_list, DIM, BATCH_SIZE)
        # 遍历emb_list
        query_list = []
        title_list = []
        label_list = []     # pseudo label list
        for i in tqdm(range(len(emb_list))):
            query_embb = emb_list[i]
            item = query_text_list.iloc[i]
            qa_item_list = index_path.search(query_embb, top_k=self.recall_num, deduplicate=True)
            for j in range(len(qa_item_list)):
                k = 1
                if j == 0:
                    k = 2
                title_list += qa_item_list[j]['query_list'][:k]
                query_list += [item['query']]*len(qa_item_list[j]['query_list'][:k])
                label_list += [item['label']]*len(qa_item_list[j]['query_list'][:k])

        to_compute_score = pd.DataFrame({
            "query": query_list,
            "title": title_list,
            "label": label_list
        })
        score_df = self.get_label(to_compute_score)
        score_df['label'] = ["yes" if item['pred_score'] > self.thres else "no" for item in score_df.iloc]
        score_df.to_csv(self.output_path, sep="\t", index=False, header=True)
        return

    def build_index(self, index_path):
        print(f"build_index: {index_path}")
        text_index = MemoryQdrant()
        index_list = read_jsonl_file(index_path)
        for point in tqdm(index_list):
            text_index.add_points([point])
        return text_index

    def get_label(self, sample_df):
        obj = EvalLocalLLM("local")
        # 校验输出路径
        check_output_path(self.output_path)
        # 读取输入数据
        sample_list = sample_df.to_dict("records")
        # 分批处理
        output_list = []
        for i in tqdm(range(0, len(sample_list), self.batch_size)):
            batch_sample_list = sample_list[i: (i + self.batch_size)]
            instructions = []
            for sample_dict in batch_sample_list:
                instruction, output = build_prompt(sample_dict)
                if instruction == "" or output == "":
                    continue
                instructions.append(instruction)
            if len(batch_sample_list) != len(instructions):
                continue
            try:
                inputs = obj.process_inputs(instructions)
                scores = obj.compute_logits(inputs)
                if len(batch_sample_list) != len(scores):
                    continue
                for idx, sample_dict in enumerate(batch_sample_list):
                    sample_dict["pred_score"] = round(scores[idx], 6)
                    output_list.append(sample_dict)
            except Exception as e:
                logger.warning("[EvalLocalLLM] process failed: " + str(e))
                continue
        # 保存结果
        output_df = pd.DataFrame(output_list)
        return output_df


if __name__ == "__main__":
    print("############## Step3 Processing ##############")
    obj = GenerateTrainset()
    obj.process()

# python -m search.qa_bot.qa_data_analyse.step3_generate_trainset
