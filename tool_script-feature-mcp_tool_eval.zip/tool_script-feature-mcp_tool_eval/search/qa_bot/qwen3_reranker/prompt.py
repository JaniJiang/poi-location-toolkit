from typing import Dict, Tuple

# 标签类别
POS_LABEL = "yes"
NEG_LABEL = "no"

# Qwen官方Prompt
PREFIX = "<|im_start|>system\nJudge whether the Document meets the requirements based on the Query and the Instruct provided. Note that the answer can only be \"yes\" or \"no\".<|im_end|>\n<|im_start|>user\n"
SUFFIX = "<|im_end|>\n<|im_start|>assistant\n"
TASK_DEFAULT = "Given a web search query, retrieve relevant passages that answer the query"


def build_prompt(sample_one: Dict[str, str]) -> Tuple[str, str]:
    instruction = ""
    output = ""
    # 校验字段
    query = sample_one.get("query", "").strip()
    title = sample_one.get("title", "").strip()
    label = sample_one.get("label", "").strip()
    # 将 0/1 标签转为 yes/no
    if label == "0":
        label = NEG_LABEL
    elif label == "1":
        label = POS_LABEL
    if query == "" or title == "" or label not in [POS_LABEL, NEG_LABEL]:
        return instruction, output
    # 拼装prompt
    instruction = PREFIX + format_instruction(TASK_DEFAULT, query, title) + SUFFIX
    output = f"<think>\n\n</think>\n\n{label}<|im_end|>"
    return instruction, output


def format_instruction(instruction, query, doc):
    output = "<Instruct>: {instruction}\n<Query>: {query}\n<Document>: {doc}".format(
        instruction=instruction, query=query, doc=doc)
    return output
