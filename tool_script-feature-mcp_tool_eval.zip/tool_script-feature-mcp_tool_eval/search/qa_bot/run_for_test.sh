#!/bin/bash
# 工具pipeline
# 定义日期列表

# 定义数据目录路径
DATA_DIR="data/cloud/search/qa_bot/qa_bot_test"

# 定义起始日期和结束日期
start_date="20250511"
end_date="20250515"

# 转换为时间戳
start_timestamp=$(date -d "$start_date" +%s)
end_timestamp=$(date -d "$end_date" +%s)
# 生成日期范围列表
date_list=()
current_date="$start_date"
echo "Start date: $start_date"
echo "End date: $end_date"
while [[ "$current_date"<"$(date -d "$end_date + 1 day" +%Y%m%d)" ]]; do
    echo "Processing date: $current_date"
    date_list+=("$current_date")
    current_date=$(date -d "$current_date + 1 day" +%Y%m%d)
done
# 将日期列表转换为 Python 列表格式
python_date_list=$(printf ',"%s"' "${date_list[@]}")
python_date_list="[${python_date_list:1}]"

# 遍历日期范围
for (( timestamp = start_timestamp; timestamp <= end_timestamp; timestamp += 86400 ))
do
    # 将时间戳转换回日期格式
    date=$(date -d "@$timestamp" +%Y%m%d)
    
    # 创建日期目录
    mkdir -p "$DATA_DIR/$date"

    # 使用 sed 命令修改 meta.py 文件中的 DATE & DATA_DIR & DATE_LIST 变量
    sed -i "s/^DATE = .*/DATE = \"$date\"/" search/qa_bot/qa_data_analyse/meta.py
    sed -i "s|^DATA_DIR = .*|DATA_DIR = \"$DATA_DIR\"|" search/qa_bot/qa_data_analyse/meta.py
    # 使用 sed 命令更新 meta.py 文件中的 DATE_LIST 变量
    sed -i "s|^DATELIST = .*|DATELIST = $python_date_list|" search/qa_bot/qa_data_analyse/meta.py
    echo "DATELIST has been updated in search/qa_bot/qa_data_analyse/meta.py"

    # 执行你的 Python 脚本或其他操作
    echo "Running for date: $date"

    # 获取日志
    # 将日期格式从 YYYYMMDD 转换为 YYYY-MM-DD
    formatted_date=$(date -d "$date" +%Y-%m-%d)
    echo $formatted_date
    export NUM=2000
    SQL_STRING_AS="select query, contents, output, knowledge_search_result from dwd_vechile_merge_prod_di where (dt between '$formatted_date' and '$formatted_date') AND content like '%AUTOSearch%' and vehicle_category = '1' order by RAND() limit $NUM"
    export NUM=200
    SQL_STRING_QA="select query, content, dialogue_response from dwd_vechile_merge_prod_di where (dt between '$formatted_date' and '$formatted_date') AND domain='in_car_assistant' and vehicle_category = '1' order by RAND() limit $NUM"

    CSV_FILE_AS="$DATA_DIR/$date/autosearch.csv"
    CSV_FILE_QA="$DATA_DIR/$date/in_car_assistant.csv"

    adt --token 731a63a43618b0b444a2b86f36cf3e14 ark2csv --sql-string "$SQL_STRING_AS" --csv-file "$CSV_FILE_AS"
    adt --token 731a63a43618b0b444a2b86f36cf3e14 ark2csv --sql-string "$SQL_STRING_QA" --csv-file "$CSV_FILE_QA"

    # 已知step4&step5
    # 完成率
    python -m search.qa_bot.qa_data_analyse.step2_query_intent
    python -m search.qa_bot.qa_data_analyse.step3_real_and_relevance
    python -m search.qa_bot.qa_data_analyse.step3_real_and_relevance_for_incar

    SOURCE_DIR="data/cloud/search/qa_bot/qa_bot_test/20250519"
    
    target_file="$DATA_DIR/$date/step5_knowledge_index.jsonl"
    if [ ! -f "$target_file" ]; then
    # 如果文件不存在，执行复制操作
    echo "File $target_file does not exist. Copying from source directory..."
    scp "$SOURCE_DIR/step5_knowledge_index.jsonl" "$target_file"
    else
        echo "File $target_file already exists. Skipping copy."
    fi
    # 知识覆盖率
    # python -m search.qa_bot.qa_data_analyse.step6_knowledge_coverage_for_incar

done

# 计算测试指标
python -m search.qa_bot.qa_data_analyse.eval_res