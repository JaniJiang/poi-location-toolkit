import os
from typing import TypedDict, Annotated, List
from langchain_core.messages import BaseMessage
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, END
import gradio as gr
from utils.llm_utils.serverless_function import request_llm
from utils.search_utils.call_cockpit_qabot import request_qabot

# 确保你已经设置了 OpenAI API 密钥
# os.environ["OPENAI_API_KEY"] = "YOUR_API_KEY"

# --- 1. 定义状态 (State) ---
# State 是所有节点共享的数据结构。
# 它包含了流程中需要传递的所有信息。


class GraphState(TypedDict):
    """
    表示我们图的状态。

    Attributes:
        query: 要研究的主题
        query_list: 研究员生成的研究摘要
        report: 报告撰写员生成的最终报告
        log: 记录每个步骤的日志信息
    """
    query: str
    query_list: List[str]
    obs_list: List[str]
    report: str
    log: Annotated[List[str], lambda x, y: x + y]  # 使用 lambda 函数来追加日志，而不是替换

# --- 2. 定义 Agent (节点) ---
# 每个节点都是一个函数，接收 state 作为输入，返回一个字典来更新 state。


def understanding_node(state: GraphState):
    """
    研究员节点：根据主题生成研究摘要。
    """
    print("--- 节点: Planner ---")
    query = state['query']

    # 创建一个提示模板
    prompt_template = PromptTemplate(
        template="尝试在汽车使用的场景下理解query，并对query进行改写，输出一个在汽车领域有意义的query，改写后的query和explain分别已json的形式输出，可以改写多个query，返回多个json即可，单个query不需要太复杂，不要带标点符号，尽量使用专业的术语\n已知知识：1. 理想汽车刚刚发布了理想i8车型。2. 在理想i8上将标配司机大模型VLA \nquery: {query}",
        input_variables=["query"],
    )

    formatted_prompt = prompt_template.format(query=query)

    # 执行研究
    summary = request_llm([formatted_prompt])
    summary = summary[1]["choices"][0]["message"]["content"]

    import json

    s = summary

    # 先按换行分割，过滤空白行
    items = [block.strip() for block in s.strip().split('\n\n') if block.strip()]

    dicts = [json.loads(item.replace("```json","").replace("\n","").replace("```","")) for item in items]
    query_list = [query] + [d['query'] for d in dicts]
    print(f"改写query:\n{query_list}")

    # 返回更新后的状态
    return {
        "query_list": query_list,
        "log": ["已完成改写"]
    }


def search_node(state: GraphState):
    """
    报告撰写员节点：根据研究摘要撰写报告。
    """
    print("--- 节点: 报告撰写员 ---")
    query_list = state['query_list']
    obs_list = []
    for query in query_list:
        res = request_qabot(query=query, url="http://cockpit-qabot-lids-testtwo.ssai-apis-staging.chj.cloud:80/expert/query")
        obs_list += res["data"][:3]
    filtered_list = []
    question_list = []
    for obs in obs_list:
        if obs['question'] not in question_list:
            filtered_list.append(f"question:{obs["question"]}\nanswer:{obs['answer']}")
            question_list.append(obs['question'])
    print(f"搜索结果:\n{obs_list}")

    # 返回更新后的状态
    return {
        "obs_list": obs_list,
        "log": ["已完成搜索"]
    }

def reply_node(state: GraphState):
    """
    报告撰写员节点：根据研究摘要撰写报告。
    """
    print("--- 节点: 报告撰写员 ---")
    query_list = state['query_list']
    obs_list = state['obs_list']

    prompt_template = PromptTemplate(
        template="你是一名专业的理想汽车问答专员。请根据以下用户问题，和官方数据库中的资料，撰写给用户的回复。\nquery:\n{query_list[0]}\n已知知识:\n{obs_list}",
        input_variables=["query_list","obs_list"],
    )

    # 格式化 prompt
    formatted_prompt = prompt_template.format(query_list=query_list, obs_list=obs_list)

    # 撰写报告
    report = request_llm([formatted_prompt])
    report = report[1]["choices"][0]["message"]["content"]

    print(f"生成的报告:\n{report}")

    # 返回更新后的状态
    return {
        "report": report,
        "log": ["报告撰写员已完成报告。"]
    }

# --- 3. 构建图 (Graph) ---


# 创建一个 StateGraph 实例，并绑定我们定义的状态
workflow = StateGraph(GraphState)

# 添加节点到图中
workflow.add_node("planner", understanding_node)
workflow.add_node("searcher", search_node)
workflow.add_node("replier", reply_node)

# 设置入口点
workflow.set_entry_point("planner")

# 添加边来定义流程
# 研究员 (researcher) 完成后，流程进入报告撰写员 (writer)
workflow.add_edge("planner", "searcher")
workflow.add_edge("searcher", "replier")
# 报告撰写员 (writer) 完成后，流程结束 (END)
workflow.add_edge("replier", END)

# 编译图，生成一个可执行的 LangChain Runnable
app = workflow.compile()
# --- 4. 执行流程 ---

if __name__ == "__main__":
    # 定义初始输入
    inputs = {
        "query": "现在i8交付已经带v大模型为什么现在的老车不给我们推送",
        "log": ["流程开始"]  # 初始化日志
    }

    # 使用 stream 方法可以清晰地看到每一步的状态变化
    print("--- 开始执行 Multi-Agent 流程 ---")
    for event in app.stream(inputs, stream_mode="values"):
        # event 是每一步执行后完整的 GraphState
        print("\n--- 流程步骤输出 ---")
        print(event)
        print("-" * 20)

    # 获取最终结果
    final_state = app.invoke(inputs)
    print("\n\n--- 最终报告 ---")
    print(final_state['report'])

# python -m search.qa_bot.multi_agent.demo
