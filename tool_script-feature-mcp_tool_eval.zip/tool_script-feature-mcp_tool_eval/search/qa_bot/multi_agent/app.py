import os
from typing import TypedDict, Annotated, List
from langchain_core.messages import BaseMessage
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, END
import gradio as gr
from utils.llm_utils.serverless_function import request_llm
from utils.search_utils.call_cockpit_qabot import request_qabot

# 确保你已经设置了 OpenAI API 密钥
# os.environ["OPENAI_API_KEY"] = "YOUR_API_KEY"

# --- 1. 定义状态 (State) ---
# State 是所有节点共享的数据结构。
# 它包含了流程中需要传递的所有信息。


class GraphState(TypedDict):
    """
    表示我们图的状态。

    Attributes:
        query: 要研究的主题
        query_list: 研究员生成的研究摘要
        report: 报告撰写员生成的最终报告
        log: 记录每个步骤的日志信息
    """
    query: str
    query_list: List[str]
    obs_list: List[str]
    report: str
    log: Annotated[List[str], lambda x, y: x + y]  # 使用 lambda 函数来追加日志，而不是替换

# --- 2. 定义 Agent (节点) ---
# 每个节点都是一个函数，接收 state 作为输入，返回一个字典来更新 state。


def understanding_node(state: GraphState):
    """
    研究员节点：根据主题生成研究摘要。
    """
    print("--- 节点: Planner ---")
    query = state['query']

    # 创建一个提示模板
    prompt_template = PromptTemplate(
        template="尝试在汽车使用的场景下理解query，并对query进行改写、拆分，输出在汽车领域有意义的query，改写后的query和explain分别已json的形式输出，可以改写多个query，返回多个json即可。单个query不能太复杂，不能带标点符号，尽量使用专业的术语\n 已知实体：VLA大模型 \nquery: {query}",
        input_variables=["query"],
    )

    formatted_prompt = prompt_template.format(query=query)

    # 执行研究
    summary = request_llm([formatted_prompt])
    summary = summary[1]["choices"][0]["message"]["content"]

    import json

    s = summary

    # 先按换行分割，过滤空白行
    items = [block.strip() for block in s.strip().split('\n\n') if block.strip()]

    dicts = [json.loads(item.replace("```json","").replace("\n","").replace("```","")) for item in items]
    query_list = [query] + [d['query'] for d in dicts]
    print(f"改写query:\n{query_list}")

    # 返回更新后的状态
    return {
        "query_list": query_list,
        "log": ["已完成改写"]
    }


def search_node(state: GraphState):
    """
    报告撰写员节点：根据研究摘要撰写报告。
    """
    print("--- 节点: 报告撰写员 ---")
    query_list = state['query_list']
    obs_list = []
    for query in query_list:
        res = request_qabot(query=query, url="http://cockpit-qabot-lids-testtwo.ssai-apis-staging.chj.cloud:80/expert/query")
        obs_list += res["data"][:3]
    filtered_list = []
    question_list = []
    for obs in obs_list:
        if obs['question'] not in question_list:
            filtered_list.append(f"question:{obs["question"]}\nanswer:{obs['answer']}")
            question_list.append(obs['question'])
    print(f"搜索结果:\n{obs_list}")

    # 返回更新后的状态
    return {
        "obs_list": obs_list,
        "log": ["已完成搜索"]
    }

def reply_node(state: GraphState):
    """
    报告撰写员节点：根据研究摘要撰写报告。
    """
    print("--- 节点: 报告撰写员 ---")
    query_list = state['query_list']
    obs_list = state['obs_list']

    prompt_template = PromptTemplate(
        template="你是一名专业的理想汽车问答专员。请根据以下用户问题，和官方数据库中的资料，撰写给用户的回复。\nquery:\n{query_list[0]}\n已知知识:\n{obs_list}",
        input_variables=["query_list","obs_list"],
    )

    # 格式化 prompt
    formatted_prompt = prompt_template.format(query_list=query_list, obs_list=obs_list)

    # 撰写报告
    report = request_llm([formatted_prompt])
    report = report[1]["choices"][0]["message"]["content"]

    print(f"生成的报告:\n{report}")

    # 返回更新后的状态
    return {
        "report": report,
        "log": ["报告撰写员已完成报告。"]
    }

# --- 3. 构建图 (Graph) ---


# 创建一个 StateGraph 实例，并绑定我们定义的状态
workflow = StateGraph(GraphState)

# 添加节点到图中
workflow.add_node("planner", understanding_node)
workflow.add_node("searcher", search_node)
workflow.add_node("replier", reply_node)

# 设置入口点
workflow.set_entry_point("planner")

# 添加边来定义流程
# 研究员 (researcher) 完成后，流程进入报告撰写员 (writer)
workflow.add_edge("planner", "searcher")
workflow.add_edge("searcher", "replier")
# 报告撰写员 (writer) 完成后，流程结束 (END)
workflow.add_edge("replier", END)

# 编译图，生成一个可执行的 LangChain Runnable
app = workflow.compile()

def run_graph_workflow(query: str):
    """
    这个函数是 Gradio 和 LangGraph 之间的桥梁。
    它接收用户输入，执行图，并逐步 yield 结果以更新UI。
    """
    # 初始化一个用于在聊天窗口中显示的列表
    # 格式是 [(user_message, bot_message), ...]
    chat_history = []

    # 1. 立即显示用户的输入
    chat_history.append((query, None))
    yield chat_history

    # 2. 准备 LangGraph 的输入
    inputs = {"query": query, "log": ["流程开始"]}

    # 3. 使用 stream() 方法执行图，并实时处理输出
    # stream_mode="values" 意味着每一步都返回完整的 GraphState
    for state in app.stream(inputs, stream_mode="values"):
        # 获取最新的日志信息来判断当前状态
        last_log_message = state.get("log", [])[-1] if state.get("log") else ""

        if "研究员已完成摘要" in last_log_message:
            # 研究员完成工作，更新聊天窗口
            summary = state.get("research_summary", "未能生成摘要...")
            bot_message = f"**🤖 研究员已完成工作**\n\n---\n\n**研究要点:**\n{summary}"
            chat_history.append((None, bot_message))
            yield chat_history

        elif "报告撰写员已完成报告" in last_log_message:
            # 报告撰写员完成工作，更新聊天窗口
            report = state.get("report", "未能生成报告...")
            bot_message = f"**✍️ 报告撰写员已完成工作**\n\n---\n\n**最终报告:**\n{report}"
            chat_history.append((None, bot_message))
            yield chat_history

    # 流程结束
    chat_history.append((None, "**✅ 流程已结束**"))
    yield chat_history


# --- 3. 前端: Gradio UI 界面 ---

with gr.Blocks(theme=gr.themes.Soft(), title="Multi-Agent Workflow") as demo:
    gr.Markdown("# 🤖 服务专家 Multi-Agent 协作流程演示")
    # gr.Markdown("输入一个您感兴趣的主题，后台的“研究员”和“报告撰写员”Agent将协同为您生成一份简报。")

    # 使用 Chatbot 组件来展示流程
    chatbot = gr.Chatbot(
        label="工作流实时展示",
        bubble_full_width=False,
        height=500,
    )

    # 用户输入区域
    with gr.Row():
        txt_input = gr.Textbox(
            label="请输入问题",
            placeholder="例如：这辆车的自驾路程半径是多少",
            scale=4,
        )
        btn_submit = gr.Button("🚀 开始执行", variant="primary", scale=1)

    # 绑定事件
    # 当用户点击按钮时，调用 run_graph_workflow 函数
    # 输入是文本框内容，输出是聊天机器人组件
    btn_submit.click(
        fn=run_graph_workflow,
        inputs=[txt_input],
        outputs=[chatbot]
    )
    txt_input.submit(
        fn=run_graph_workflow,
        inputs=[txt_input],
        outputs=[chatbot]
    )

# 启动 Gradio 应用
if __name__ == "__main__":
    demo.launch(share=True)

# python -m search.qa_bot.multi_agent.app