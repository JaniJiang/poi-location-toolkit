# coding: utf-8
"""
语义一致性判断：判断 query 与 title 是否表达相同语义（仅输出 yes / no）
"""
import pdb
import json
import pandas as pd
from tqdm import tqdm
from utils.llm_utils.serverless_function import request_llm
import time

# ======== 中文 Prompt ========
SYSTEM_PROMPT_CLASS_LABEL = """
你是一名严格的语义匹配专家，专注于汽车智能问答场景的语义一致性判断。
你的任务是判断 query 和 title 是否在询问**完全相同的问题**或**寻求完全相同的信息**。
必须采用严格标准，只有核心语义完全一致时才判定为 yes。
"""

USER_PROMPT_RAW = """
请严格判断以下 query 与 title 是否表达**完全相同的语义**。

【query】：
{query}

【title】：
{title}

## 判断规则（必须全部满足才能判 yes）：

### ✅ 判定为 "yes" 的条件（需同时满足）：
1. **核心意图完全一致**：两者询问的是同一个问题或同一类信息
2. **关键信息点相同**：涉及的车辆、功能、部件、属性必须一致
3. **不改变语义的改写**：仅仅是表达方式不同，如：
   - 主被动转换："副驾座椅可以放倒吗" ≈ "副驾驶座位可不可以放倒"
   - 同义词替换："节能模式是哪一个" ≈ "最节能的能源模式是哪个"（节能模式 = 最节能的能源模式）
   - 同义词替换："麦克" ≈ "麦克风"
   - 同义词替换："ota" ≈ "系统"
   - 语气词差异："雨刷器是不是自动的" ≈ "雨刷器功能是否有自动"

### ❌ 判定为 "no" 的情况（任一满足即判 no）：
1. **关键词不同**：
   - "品牌" vs "厂商"（概念不同）
   - "推荐" vs "介绍"（动作不同）
   - "功率" vs "发动机功率"（范围不同）
2. **限定范围不同**：
   - "wifi连接方法" vs "手机连接理想WIFI的方法"（缺少限定词"手机"和"理想"）
   - "l9尺寸" vs "车辆长宽高"（尺寸 ≠ 仅长宽高，"车辆" != "l9"）
3. **问题粒度不同**：
   - "空调没了原因" vs "为什么空调没用了"（"没了"可能指关闭，"没用了"指故障）
   - "二排座椅可以放倒吗" vs "二排座椅怎么放倒"（是否 vs 如何）
   - "后视镜怎么没打开" vs "外后视镜打不开了怎么办"（原因 vs 怎么解决）
   - "座椅按摩模式可以调整吗" vs "这个座椅按摩模式怎么调"（是否 vs 如何）
   - "行驶了多少公里" vs "总共行驶了多少公里"（单次 vs 总次数）

4. **单位或属性不同**：
   - "千瓦" 不等于 "马力"（虽然都是功率，但用户可能需要特定单位）
5. **缺少关键上下文**：
   - query 过于简略而 title 有明确限定时，判为 no

## 特殊注意：
- 即使两者相关，只要**不是在问同一个问题**，就判为 no
- 宁可严格，不可宽松

请严格按照以下 JSON 格式输出：
```json
{{"label": "yes" | "no"}}
"""






def do_llm_rank(item_list, title_list, history_list, max_retries=5, base_delay=2):
    """
    调用 LLM 对每个 query-title 对进行语义一致性判断（带自动重试机制）

    Args:
        item_list: query 列表
        title_list: title 列表
        history_list: 包含 system 和 user prompt 的历史记录列表
        max_retries: 每条请求最大重试次数（默认5）
        base_delay: 初始重试等待时间（秒），指数增长
    
    Returns:
        res_list: 包含判断结果的字典列表
    """
    if len(history_list) != len(item_list):
        print("⚠️ 警告：history_list 长度与 item_list 不匹配")
        return []

    res_list = []
    for i in tqdm(range(len(history_list))):
        history = history_list[i]
        success = False
        question_new_str = ""
        
        for attempt in range(1, max_retries + 1):
            try:
                payload, response_data = request_llm(history, model="gpt-4o", n=1, temperature=0)
                question_new_str = response_data["choices"][0]["message"]["content"].strip()

                # 清理 markdown 代码块
                if question_new_str.startswith("```json"):
                    question_new_str = question_new_str[7:]
                elif question_new_str.startswith("```"):
                    question_new_str = question_new_str[3:]
                if question_new_str.endswith("```"):
                    question_new_str = question_new_str[:-3]
                question_new_str = question_new_str.strip()

                # 尝试解析 JSON
                question_new_dict = json.loads(question_new_str)
                res_list.append(question_new_dict)
                success = True
                break  # ✅ 成功，退出重试循环

            except json.JSONDecodeError as e:
                print(f"⚠️ JSON 解析失败 (索引 {i}, 第 {attempt}/{max_retries} 次): {e}")
                try:
                    cleaned_str = question_new_str.strip().strip('`').replace("json", '').replace("\n", "")
                    question_new_dict = json.loads(cleaned_str)
                    res_list.append(question_new_dict)
                    success = True
                    break
                except Exception as e2:
                    print(f"⚠️ 再次解析失败 (索引 {i}): {e2}")
                    print(f"原始响应: {question_new_str[:200]}")
            
            except Exception as e:
                print(f"🚨 请求失败 (索引 {i}, 第 {attempt}/{max_retries} 次): {e}")

            # 失败时等待并重试
            if not success and attempt < max_retries:
                sleep_time = base_delay * (2 ** (attempt - 1))  # 指数回退
                print(f"⏳ 等待 {sleep_time:.1f}s 后重试...")
                time.sleep(sleep_time)
        
        # 若全部尝试失败
        if not success:
            print(f"❌ 最终失败 (索引 {i})，标记为 error")
            res_list.append({"label": "error"})

    return res_list

if __name__ == "__main__":
    # ======== 读取数据 ========
    path = "/mnt/volumes/ss-sai-bd-ga/public_qiaojiaqi/save_files/datasets/train_0924_300.tsv"
    df = pd.read_csv(path, sep="\t")
    
    # 假设 test.tsv 中有两列：query 和 title
    query_list = df["query"].to_list()
    title_list = df["title"].to_list()
    
    print(f"📊 共读取 {len(query_list)} 条数据")

    # ======== 构建 prompt 历史 ========
    history_list = []
    for query, title in zip(query_list, title_list):
        history_list.append([
            SYSTEM_PROMPT_CLASS_LABEL,
            USER_PROMPT_RAW.format(query=query, title=title)
        ])

    # ======== 调用 LLM ========
    print("🚀 开始调用 LLM 进行语义判断...")
    res = do_llm_rank(query_list, title_list, history_list)

    # ======== 保存结果 ========
    result_labels = []
    for r in res:
        label = r.get("label", "error")
        if label not in ["yes", "no"]:
            label = "no"  # 默认修正为 no
        result_labels.append(label)

    df["pred_label"] = result_labels
    save_path = path.replace(".tsv", "_with_pred.tsv")
    df.to_csv(save_path, sep="\t", index=False)
    print(f"✅ 已保存预测结果到：{save_path}")

    # ======== 统计结果 ========
    yes_count = result_labels.count("yes")
    no_count = result_labels.count("no")
    error_count = result_labels.count("error")
    print(f"\n📈 预测统计：")
    print(f"   - yes: {yes_count} ({yes_count/len(result_labels)*100:.2f}%)")
    print(f"   - no: {no_count} ({no_count/len(result_labels)*100:.2f}%)")
    print(f"   - error: {error_count} ({error_count/len(result_labels)*100:.2f}%)")

    # ======== 计算准确率 ========
    if "label" in df.columns:
        true_labels = df["label"].astype(str).str.lower().tolist()
        acc = sum([1 for t, p in zip(true_labels, result_labels) if t == p]) / len(true_labels)
        print(f"\n🎯 模型预测准确率：{acc:.4f}")
    else:
        print("\n⚠️ 数据集中未找到 true_label 列，无法计算准确率。")