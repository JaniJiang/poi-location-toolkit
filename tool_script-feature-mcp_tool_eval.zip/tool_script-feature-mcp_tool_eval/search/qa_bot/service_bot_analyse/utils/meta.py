# 固定数据存储路径（数据索引等，不频繁变动的数据）
INDEX_DIR = "data/cloud_share/qabot_miner/qa_index"
# 路径参数
DATA_DIR = "data/cloud/search/qa_bot/qa_bot_test"
DATE = "20250617"
DATELIST = ["20250616", "20250617", "20250618", "20250619", "20250620", "20250621", "20250622"]
WEEK = "W26"
# 向量模型参数
DIM = 128  # 768 | 128
BATCH_SIZE = 8
# 服务专家处理数据量
NUM_QA = "500"
