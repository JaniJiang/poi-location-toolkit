#!/bin/bash
# 工具pipeline

# —————————————————————————————— 基本配置 ——————————————————————————————

# 定义数据目录路径
DATA_DIR="data/cloud/search/qa_bot/qa_bot_test"
# 更改配置文件中的数据目录路径
sed -i "s/^DATA_DIR = .*/DATA_DIR = \"$DATA_DIR\"/" search/qa_bot/service_bot_analyse/utils/meta.py

# 定义起始日期和结束日期
start_date="20250630"
end_date="20250706"
week="W27"
# 更改配置文件中的week变量，用于存储数据
sed -i "s/^WEEK = .*/WEEK = \"$week\"/" search/qa_bot/service_bot_analyse/utils/meta.py
mkdir -p "$DATA_DIR/$week"

# —————————————————————————————— gpt_autoqa 日志单独下载 ——————————————————————————————
export NUM=2000
formatted_start_date=$(date -d "$start_date" +%Y-%m-%d)
formatted_end_date=$(date -d "$end_date" +%Y-%m-%d)

SQL_STRING_AS="select query, contents, output, knowledge_search_result from dwd_vechile_merge_prod_di where (dt between '$formatted_start_date' and '$formatted_end_date') AND content like '%AUTOSearch%' and vehicle_category = '1' order by RAND() limit $NUM"
CSV_FILE_AS="$DATA_DIR/$week/autosearch.csv"

data/cloud_share/tool/adt --token 731a63a43618b0b444a2b86f36cf3e14 ark2csv --sql-string "$SQL_STRING_AS" --csv-file "$CSV_FILE_AS"

# —————————————————————————————— 计算 ——————————————————————————————
# in_car_assistant采样的日志数量，并存在meta.py中
export NUM_QA=500
sed -i "s/^NUM_QA = .*/NUM_QA = \"$NUM_QA\"/" search/qa_bot/service_bot_analyse/utils/meta.py

python -m search.qa_bot.service_bot_analyse.controller.week

# export PYTHONPATH=$PYTHONPATH:/mnt/volumes/ss-sai-lx-my/wuzhenyan/qabot_agent/tool_script
# nohup bash search/qa_bot/service_bot_analyse/run_pipeline.sh > weekly.log 2>&1 &