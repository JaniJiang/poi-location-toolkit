import csv
from tqdm import tqdm
from utils.file_utils import read_jsonl_file
from search.qa_bot.service_bot_analyse.utils.meta import *


class Jsonl2Tsv:

    def __init__(self):
        self.input_path = f"{DATA_DIR}/{DATE}/step7_question_generate.jsonl"
        self.output_path = f"{DATA_DIR}/{DATE}/step8_jsonl2tsv.tsv"

    def process(self):
        # 读取数据
        input_list = read_jsonl_file(self.input_path)
        print("input list:", len(input_list))
        # 处理数据
        output_list = []
        for item in tqdm(input_list, total=len(input_list)):
            feature_dict = item["feature_dict"]
            if feature_dict["question_new_flag"] == 0 or len(feature_dict["question_new"]) == 0:
                continue
            output_list.append([
                feature_dict["category_lv_0_1_2"],
                str(feature_dict["question_id"]),
                "\n".join(feature_dict["question"]),
                feature_dict["answer"],
                "\n".join(feature_dict["question_new"]),
            ])
        print("output list:", len(output_list))
        # 保存tsv文件
        with open(self.output_path, "w", encoding="utf-8", newline="") as f:
            writer = csv.writer(f, delimiter="\t")
            writer.writerows(output_list)


if __name__ == "__main__":
    obj = Jsonl2Tsv()
    obj.process()

# python -m search.qa_bot.qa_data_analyse.step8_jsonl2tsv
