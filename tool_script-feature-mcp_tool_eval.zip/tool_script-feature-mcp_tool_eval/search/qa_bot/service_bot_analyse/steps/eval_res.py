from search.qa_bot.service_bot_analyse.utils.prompt import *
from search.qa_bot.service_bot_analyse.utils.meta import *
import pandas as pd


class EvalRes:
    """计算测试指标"""

    def __init__(
        self,
        input_path_list_qi=[
            f"data/cloud/search/qa_bot/qa_bot_test/{date}/step2_question_intent.jsonl" for date in DATELIST],
        input_path_list_rr_ica=[
            f"data/cloud/search/qa_bot/qa_bot_test/{date}/step3_real_and_relevance_ica.jsonl" for date in DATELIST],
        input_path_list_rr=[
            f"data/cloud/search/qa_bot/qa_bot_test/{date}/step3_real_and_relevance.jsonl" for date in DATELIST],
        input_path_list_kc=[
            f"data/cloud/search/qa_bot/qa_bot_test/{date}/step6_knowledge_coverage.jsonl" for date in DATELIST],
        input_path_list_kc_ica=[
            f"data/cloud/search/qa_bot/qa_bot_test/{date}/step6_knowledge_coverage_ica.jsonl" for date in DATELIST]
    ):
        self.input_path_list_qi = input_path_list_qi
        self.input_path_list_rr_ica = input_path_list_rr_ica
        self.input_path_list_rr = input_path_list_rr
        self.input_path_list_kc = input_path_list_kc
        self.input_path_list_kc_ica = input_path_list_kc_ica

    def process(self):
        # 计算服务专家query比例
        df_for_qi = pd.DataFrame()
        for path in self.input_path_list_qi:
            if len(df_for_qi) < 1:
                df_for_qi = pd.read_json(path, lines=True)
            else:
                df_for_qi = pd.concat([df_for_qi, pd.read_json(path, lines=True)], axis=0, ignore_index=True)
        total_valid = len(df_for_qi.dropna(subset=["if_serviceBot"]))
        num_ica = len(df_for_qi[[i["一级分类"] == "服务专家" if i != []
                      else False for i in df_for_qi['if_serviceBot'].dropna().iloc]])
        print(f"The rate for in_car_assistant query in autoqa is {num_ica}/{total_valid} = {num_ica / total_valid}")

        # 计算解决率
        # in car assistant
        df_for_ica = pd.DataFrame()
        for path in self.input_path_list_rr_ica:
            if len(df_for_ica) < 1:
                df_for_ica = pd.read_json(path, lines=True)
            else:
                df_for_ica = pd.concat([df_for_ica, pd.read_json(path, lines=True)], axis=0, ignore_index=True)
        total_valid = len(df_for_ica.dropna(subset=["list_score"]))
        print(
            f"The solution rate for in_car_assistant is {df_for_ica['label'].sum()}/{total_valid} = {df_for_ica['label'].sum() / total_valid}")
        # gpt autoqa
        df_for_gpt = pd.DataFrame()
        for path in self.input_path_list_rr:
            if len(df_for_gpt) < 1:
                df_for_gpt = pd.read_json(path, lines=True)
            else:
                df_for_gpt = pd.concat([df_for_gpt, pd.read_json(path, lines=True)], axis=0, ignore_index=True)
        num_solverd = len(df_for_gpt[df_for_gpt["gpt_label"] == "完全可解"])
        df_for_gpt = df_for_gpt[["服务专家" in str(i) for i in df_for_gpt['if_serviceBot']]]
        num_all = len(df_for_gpt["output"].dropna())
        print(f"The solution rate for gpt_autoqa is {num_solverd}/{num_all} = {num_solverd / num_all}")
        # 计算知识覆盖率
        df_for_knowledge = pd.DataFrame()
        for path in self.input_path_list_kc:
            if len(df_for_knowledge) < 1:
                df_for_knowledge = pd.read_json(path, lines=True)
            else:
                df_for_knowledge = pd.concat([df_for_knowledge, pd.read_json(
                    path, lines=True)], axis=0, ignore_index=True)
        print(
            f"The rate of knowledge uncovered problems for autoqa is 1 - {len(df_for_knowledge) - df_for_knowledge['has_item'].sum()}/{num_all} = {1 - (len(df_for_knowledge) - df_for_knowledge['has_item'].sum()) / num_all}")
        # 计算知识覆盖率
        df_for_knowledge_ica = pd.DataFrame()
        for path in self.input_path_list_kc_ica:
            if len(df_for_knowledge_ica) < 1:
                df_for_knowledge_ica = pd.read_json(path, lines=True)
            else:
                df_for_knowledge_ica = pd.concat(
                    [df_for_knowledge_ica, pd.read_json(path, lines=True)], axis=0, ignore_index=True)
        print(
            f"The rate of knowledge uncovered problems for ica is 1 - {df_for_knowledge_ica[df_for_knowledge_ica['has_item'] == 0]['if_qabot'].sum()}/{total_valid} = {1 - (df_for_knowledge_ica[df_for_knowledge_ica['has_item'] == 0]['if_qabot'].sum()) / total_valid}")
        pass


if __name__ == "__main__":
    print("############## Evaluation Processing ##############")
    obj = EvalRes()
    obj.process()

# python -m search.qa_bot.qa_data_analyse.step3_real_and_relevance
