from asyncio import Semaphore
from search.qa_bot.service_bot_analyse.utils.prompt import *
from search.qa_bot.service_bot_analyse.utils.meta import *
from utils.llm_utils.serverless_function import request_llm_async, RateLimiter
import json
from tqdm import tqdm
import pandas as pd
import asyncio
import aiohttp


class QueryIntent:
    """Query意图识别工具：通过LLM识别是否服务专家Query"""

    def __init__(self, input_path="", output_path=""):
        self.input_path = input_path if input_path else f"{DATA_DIR}/{DATE}/autosearch.csv"
        self.output_path = output_path if output_path else f"{DATA_DIR}/{DATE}/step2_question_intent.jsonl"
        self.model_name = "gpt-4o"  # gpt-4o | claude-3_5-sonnet | deepseek-v3 | deepseek-r1 | deepseek-r1-distill-qwen-32b
        self.max_concurrent = 10
        self.qps = 4    # 推荐不大于4

    def process(self, test=False):
        # 提取&解析线上日志结果
        input_list = pd.read_csv(self.input_path, encoding="utf-8")
        if test:
            test_path = "data/cloud/search/qa_bot/qa_data_analyse/testset/意图识别工具测试集.xlsx"
            self.output_path = "data/cloud/search/qa_bot/qa_data_analyse/testset/意图识别工具测试集_res.jsonl"
            input_list = pd.read_excel(test_path)
        print("input list:", len(input_list))
        input_list = input_list.iloc
        # 多线程调用
        loop = asyncio.get_event_loop()
        loop.run_until_complete(self.process_async(input_list, max_retries=3))

    async def process_async(self, input_list, max_retries):
        rate_limiter = RateLimiter(self.qps)
        semaphore = Semaphore(self.max_concurrent)  # 限制最大并发数为 max_concurrent
        async with aiohttp.ClientSession() as session:
            tasks = [self.process_item_async(rate_limiter, semaphore, session, item, max_retries) for
                     item in input_list]

            with open(self.output_path, 'w', encoding='utf-8') as f:
                for item, future in tqdm(zip(input_list, asyncio.as_completed(tasks)), total=len(tasks)):
                    response = await future
                    f.write(json.dumps(response.to_dict(), ensure_ascii=False) + "\n")
                    f.flush()  # ensure the data is written to disk after each iteration

    async def process_item_async(self, rate_limiter, semaphore, session, item, max_retries):
        # 调用LLM判断服务专家query
        history = [
            SYSTEM_PROMPT_STAGE_2,
            USER_PROMPT_STAGE_2.format(question="".join(item["query"]))
        ]
        try:
            payload, response_data = await request_llm_async(rate_limiter, semaphore, session, max_retries, history, model=self.model_name, n=1, temperature=0)
            question_new_str = response_data["choices"][0]["message"]["content"]
            question_new_list = json.loads(question_new_str)
        except Exception as e:
            question_new_list = []
            print(e)
        # 回写判断
        item["if_serviceBot"] = question_new_list
        return item


if __name__ == "__main__":
    print("############## Step2 Processing ##############")
    obj = QueryIntent()
    obj.process(test=False)

# python -m search.qa_bot.qa_data_analyse.step2_query_intent
