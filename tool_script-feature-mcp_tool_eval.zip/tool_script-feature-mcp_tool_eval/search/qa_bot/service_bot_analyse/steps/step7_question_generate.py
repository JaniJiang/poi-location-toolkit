from tqdm.asyncio import tqdm_asyncio
from asyncio import Semaphore
from search.qa_bot.service_bot_analyse.utils.prompt import *
from search.qa_bot.service_bot_analyse.utils.meta import *
from utils.llm_utils.serverless_function import request_llm_async, RateLimiter
import json
import asyncio
import aiohttp
import pandas as pd


class QuestionGenerate:
    """Query泛化工具"""

    def __init__(self):
        DATA_DIR = "data/cloud/search/qa_bot/qa_data_analyse"
        DATELIST = ["20250322", "20250323", "20250324", "20250325", "20250326",
                    "20250327", "20250328", "20250329", "20250330", "20250331"]
        self.input_path_list = [f"{DATA_DIR}/{date}/step6_knowledge_coverage.jsonl" for date in DATELIST]
        # self.input_path_list = [f"{DATA_DIR}/{DATE}/step6_knowledge_coverage.jsonl"]
        self.output_path = f"{DATA_DIR}/step7_question_generate.jsonl"
        self.model_name = "claude-3_5-sonnet"  # gpt-4o | claude-3_5-sonnet | deepseek-v3 | deepseek-r1 | deepseek-r1-distill-qwen-32b
        self.max_concurrent = 2000
        self.qps = 3    # 推荐不大于4

    def agg_query_tobe_generate(self, df):
        grouped = df.groupby("question_id")
        agg_dict = {
            "query": list,                      # 合并所有 query 为列表
            "explain": list,
            "category_lv_0": "first",           # 取第一个分类值（假设同 ID 下分类一致）
            "category_lv_1": "first",
            "category_lv_2": "first",
            "category_lv_0_1": "first",
            "category_lv_0_1_2": "first",
            "question": "first",                # 取第一个标准问和答案
            "answer": "first",
            "answer_nums": "first",
        }
        new_df = grouped.agg(agg_dict).reset_index()
        new_df["frequency"] = grouped.size().values  # 直接统计分组后的行数
        new_df = new_df.sort_values("frequency", ascending=False).reset_index(drop=True)
        # 重命名列以匹配目标格式
        new_df = new_df.rename(columns={"frequency": "question_nums"})
        new_df = new_df.rename(columns={"query": "query_list"})
        new_df = new_df.rename(columns={"explain": "explain_list"})
        # 调整列顺序为目标格式
        target_columns = [
            "query_list",
            "explain_list",
            "category_lv_0",
            "category_lv_1",
            "category_lv_2",
            "category_lv_0_1",
            "category_lv_0_1_2",
            "question_id",
            "question_nums",
            "answer_nums",
            "question",
            "answer"
        ]
        new_df = new_df[target_columns]
        return new_df

    def process(self):
        # Load all the data
        df = pd.DataFrame()
        for path in self.input_path_list:
            if len(df) < 1:
                df = pd.read_json(path, lines=True)
            else:
                df = pd.concat([df, pd.read_json(path, lines=True)], axis=0, ignore_index=True)
        # 保留已覆盖的q进行泛化
        df = df[df['has_item'] == 1].reset_index()
        # 计算频率 筛选top200
        normalized_df = pd.json_normalize(df["payload"])
        df = pd.concat([df.drop(columns=["payload"]), normalized_df], axis=1, ignore_index=False)
        # 删除重复列
        df = df.loc[:, ~df.columns.duplicated()]
        # agg
        input_list = self.agg_query_tobe_generate(df).head(200)
        print("input list:", len(input_list))
        # 多线程调用
        loop = asyncio.get_event_loop()
        loop.run_until_complete(self.process_async(input_list, max_retries=5))
        # with open(self.output_path, mode="w", encoding="utf-8") as f:
        #     for item in tqdm(input_list.iloc, total=len(input_list)):
        #         item = self.process_item(item)
        #         f.write(json.dumps(item.to_dict(), ensure_ascii=False) + "\n")

    async def process_async(self, input_list, max_retries):
        rate_limiter = RateLimiter(self.qps)
        semaphore = Semaphore(self.max_concurrent)  # 限制最大并发数为 max_concurrent
        async with aiohttp.ClientSession() as session:
            tasks = [self.process_item_async(rate_limiter, semaphore, session,
                                             item, max_retries)
                     for item in input_list.iloc]
            results = [None] * len(tasks)
            task_objects = [asyncio.create_task(task) for task in tasks]
            # tqdm_asyncio按index返回并发结果
            for index, task in tqdm_asyncio(zip(range(len(tasks)), task_objects), total=len(tasks)):
                response = await task
                # 根据任务的索引存储结果
                results[index] = response

            with open(self.output_path, 'w', encoding='utf-8') as f:
                for item, response in zip(input_list.iloc, results):
                    f.write(json.dumps(response.to_dict(), ensure_ascii=False) + "\n")
                    f.flush()  # ensure the data is written to disk after each iteration

    async def process_item_async(self, rate_limiter, semaphore, session, item, max_retries):
        # 调用LLM泛化question
        history = [
            SYSTEM_PROMPT,
            USER_PROMPT.format(query=[item["query_list"]], question=item["question"][:10], answer=item["answer"])
        ]
        try:
            payload, response_data = await request_llm_async(rate_limiter, semaphore, session, max_retries, history, model=self.model_name, n=1, temperature=0)
            # print(json.dumps({"payload": payload, "response": response_data}, ensure_ascii=False))
            question_new_str = response_data["choices"][0]["message"]["content"]
            question_new_list = json.loads(question_new_str.replace('，', ','))
        except Exception as e:
            question_new_list = []
            print(e)
        # 回写处理结果
        item.loc["question_new"] = '\n'.join(map(str, question_new_list))
        return item


if __name__ == "__main__":
    print("############## Step7 Processing ##############")
    obj = QuestionGenerate()
    obj.process()

# python -m search.qa_bot.qa_data_analyse.step7_question_generate
