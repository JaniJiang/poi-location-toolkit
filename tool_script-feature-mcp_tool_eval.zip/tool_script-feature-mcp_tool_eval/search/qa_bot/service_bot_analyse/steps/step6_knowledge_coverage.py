from tqdm.asyncio import tqdm_asyncio
from asyncio import Semaphore
from utils.llm_utils.serverless_function import request_llm, request_llm_async, RateLimiter
from utils.synonym_utils.find_match_word import find_hit_words, read_txt_to_dataframe
from search.qa_bot.service_bot_analyse.utils.prompt import *
from search.qa_bot.service_bot_analyse.utils.meta import *
from utils.nlp_utils.embedding import get_batch_embedding
from utils.search_utils.memory_qdrant import MemoryQdrant
from utils.file_utils import read_jsonl_file
import os
import sys
import json
import asyncio
import aiohttp
import torch
import requests
import time
import pandas as pd
import numpy as np
import torch.nn as nn
import onnxruntime as ort
from tqdm import tqdm
from typing import List


class KnowledgeCoverage:
    """知识覆盖工具：未完成的Query请求离线索引库获取候选知识，通过LLM判断候选知识能否回答Query"""

    def __init__(self, query_path="", output_path="", qa_index_path="", synonym_path=""):
        self.query_path = query_path if query_path else f"{DATA_DIR}/{DATE}/step3_real_and_relevance.jsonl"
        self.qa_index_path = qa_index_path if qa_index_path else f"{INDEX_DIR}/step5_knowledge_index.qa.jsonl"
        self.output_path = output_path if output_path else f"{DATA_DIR}/{DATE}/step6_knowledge_coverage.jsonl"
        self.synonym_path = synonym_path if synonym_path else "search/qa_bot/service_bot_analyse/vocab/synonym.tsv"
        self.recall_num = 5
        self.model_name = "gpt-4o"  # gpt-4o | claude-3_5-sonnet | deepseek-v3 | deepseek-r1 | deepseek-r1-distill-qwen-32b
        self.rank_type = "llm"  # relevance | llm
        self.max_concurrent = 2000
        self.qps = 2   # 推荐不大于4

    def filter_unsolved_data(self, query_data_list):
        try:
            query_list = []
            for data in query_data_list:
                try:
                    if_serviceBot = data['if_serviceBot']['一级分类']
                except Exception as e:
                    # 非服务专家query
                    try:
                        if_serviceBot = json.loads(data['if_serviceBot'].replace("\'", '\"'))['一级分类']
                    except Exception as e:
                        continue
                if (data['gpt_label'] != "完全可解") and (if_serviceBot == '服务专家'):
                    query_list.append(data)
        except Exception as e:
            print(f"{e}\nWarning:过滤失败，使用原始queryList")
            return query_data_list
        return query_list

    def process(self, test=False, query_text_list=pd.DataFrame()):
        # 读取query数据
        if test:
            query_text_list = pd.read_excel(
                "data/cloud/search/qa_bot/qa_data_analyse/testset/知识覆盖工具测试集.xlsx").dropna(subset=["人工标注"]).reset_index(drop=True)
            query_text_list = query_text_list[query_text_list["prediction"] == 1]
            self.output_path = "data/cloud/search/qa_bot/qa_data_analyse/testset/知识覆盖工具测试集_res.jsonl"
        elif (type(query_text_list) is not pd.DataFrame) or (len(query_text_list) < 1):
            query_data_list = read_jsonl_file(self.query_path)
            query_text_list = self.filter_unsolved_data(query_data_list)
            query_text_list = pd.DataFrame(query_text_list)
        if len(query_text_list) < 1:
            print("Empty Input")
            return

        # 读取index数据
        if os.path.exists(self.qa_index_path):
            qa_text_index = self.build_index(self.qa_index_path)
        else:
            qa_text_index = self.build_index(
                "data/cloud/search/qa_bot/qa_data_analyse/testset/step5_knowledge_index.jsonl")
        # 多线程调用
        loop = asyncio.get_event_loop()
        result = loop.run_until_complete(self.process_async(
            query_text_list, qa_text_index, qa_text_index, max_retries=3))
        # 若为测试 回收指标
        if test:
            df = pd.DataFrame(read_jsonl_file(self.output_path))
            # 目标label
            target_label = query_text_list["人工标注"].to_list()
            target_id = query_text_list["target_id"].to_list()
            # 预测label
            pred_label = df["has_item"].astype(int).to_list()
            pred_id = df["question_id"].to_list()
            # 输出acc指标
            acc = 0
            for i in range(len(df)):
                if (target_label[i] != 0 and pred_label[i] != 0 and pred_id[i] == target_id[i]) or (target_label[i] == 0 and pred_label[i] == 0):
                    acc += 1
            print(f"ACC: {acc / len(df)}")
        return result

    async def process_async(self, input_list, qa_text_index, rag_text_index, max_retries):
        # 增加改写
        # 读取同义词列表
        outer_df = read_txt_to_dataframe(self.synonym_path)
        outer_dict = outer_df.set_index(outer_df.columns[0])[outer_df.columns[1]].to_dict()
        # 生成同义词替换query列表
        id_list = []
        query_list = []
        for id, input_query in enumerate(input_list["query"]):
            input_query = input_query.replace(" ", "").lower()
            match_result = find_hit_words(input_query, outer_dict, True)
            query_list.append(input_query)
            id_list.append(id)
            if match_result:
                for replace_word in outer_dict[match_result[0].replace]:
                    if match_result[0].word != replace_word:
                        query_list.append(input_query.replace(match_result[0].word.lower(), replace_word))
                        id_list.append(id)
        # 计算embed，选择与原query区分度最大的改写query，进行召回
        emb_list = get_batch_embedding(query_list, DIM, BATCH_SIZE)
        # 整理成dict形式 {id:[emb1,emb2,...]}
        emb_dict = self.twoListtoDict(id_list, emb_list)
        # 计算与原query相似度最小的query_emb

        def cosine_similarity(vec1, vec2):
            dot_product = np.dot(vec1, vec2)
            norm_vec1 = np.linalg.norm(vec1)
            norm_vec2 = np.linalg.norm(vec2)
            return dot_product / (norm_vec1 * norm_vec2)

        id_list, emb_list = [], []
        for id, candidate_emb_list in emb_dict.items():
            id_list.append(id)
            emb_list.append(candidate_emb_list[0])
            if len(candidate_emb_list) == 1:
                continue
            first_embedding = candidate_emb_list[0]
            min_score = 2
            min_embedding = candidate_emb_list[1]
            for other_embedding in candidate_emb_list[1:]:
                cosine_score = cosine_similarity(first_embedding, other_embedding)
                if cosine_score < min_score:
                    min_embedding = other_embedding
                    min_score = cosine_score
            id_list.append(id)
            emb_list.append(min_embedding)
        # 整理成dict形式 {id:[emb1,emb2]}
        emb_dict = self.twoListtoDict(id_list, emb_list)

        # 先检索，每个query得到一个recall_list
        print("############## Step6 start Retrieval ##############")
        # todo:增加并行
        recall_list_qa = []
        recall_list_rag = []
        for id, query_embbs in tqdm(emb_dict.items()):
            try:
                qa_item_list = []
                # 遍历emb_list
                for query_embb in query_embbs:
                    qa_item_list += qa_text_index.search(query_embb, top_k=self.recall_num, deduplicate=True)
                # 对 qa_item_list 去重
                # 使用字典来存储每个 id 对应的数据
                id_dict = {}
                for item in qa_item_list:
                    item_id = item['id']
                    if item_id not in id_dict:
                        id_dict[item_id] = item     # 如果 id 不存在，直接添加到字典中
                    else:
                        continue        # 如果 id 已存在 跳过
                # 将字典的值转换为列表
                unique_data_list = list(id_dict.values())
                recall_list_qa.append(unique_data_list)
            except Exception as e:
                recall_list_qa.append([])
                print(e)
            recall_list_rag.append([])
        # 并行推理
        # todo:增加同义词推理
        print("############## Step6 start Inference ##############")
        rate_limiter = RateLimiter(self.qps)
        semaphore = Semaphore(self.max_concurrent)  # 限制最大并发数为 max_concurrent
        async with aiohttp.ClientSession() as session:
            # 将query和query embedding分别传入异步函数
            tasks = [self.process_item_async(rate_limiter, recall_list_qa[index],
                                             recall_list_rag[index], semaphore, session,
                                             index, input_list["query"].iloc[index], max_retries)
                     for index in range(len(input_list))]
            results = [None] * len(tasks)
            task_objects = [asyncio.create_task(task) for task in tasks]
            # tqdm_asyncio按index返回并发结果
            for _, task in tqdm_asyncio(zip(range(len(tasks)), task_objects), total=len(tasks)):
                response, index = await task
                # 根据任务的索引存储结果
                results[index] = response

            with open(self.output_path, 'w', encoding='utf-8') as f:
                # results = await asyncio.gather(*tasks)  # 使用 asyncio.gather 获取结果
                for item, response in zip(input_list.iloc, results):
                    try:
                        f.write(json.dumps(dict(pd.concat([item, response])), ensure_ascii=False) + "\n")
                    except Exception as e:
                        f.write(json.dumps(dict(response), ensure_ascii=False) + "\n")
            return results

    async def process_item_async(self, rate_limiter, qa_item_list, rag_item_list, semaphore, session, index, item, max_retries):
        # inference
        has_item, explain, matched_item = await self.do_rank_async(item, qa_item_list, rate_limiter, semaphore, session, max_retries)
        # rag inference
        # has_item_rag, matched_item_rag = await self.do_rank(item, rag_item_list, rate_limiter, semaphore, session, max_retries)
        try:
            qid = matched_item["payload"]["question_id"]
        except Exception as e:
            qid = 0
        formated_item = {
            "query": item,
            "explain": explain,
            "has_item": has_item,
            "score": float(matched_item["score"]) if "score" in matched_item.keys() else 0.0,
            "payload": matched_item["payload"] if "payload" in matched_item.keys() else {},
            "question_id": qid,
            "recall_list": json.dumps(qa_item_list, ensure_ascii=False),
        }
        return formated_item, index

    def build_index(self, index_path):
        print(f"build_index: {index_path}")
        text_index = MemoryQdrant()
        index_list = read_jsonl_file(index_path)
        for point in index_list:
            text_index.add_points([point])
        return text_index

    def do_retriever(self, data_type, text_index: MemoryQdrant, query_text_list: List[str]):
        print(f"do_retriever: {data_type}")
        retriever_result = []
        query_embedding_list = get_batch_embedding(query_text_list, DIM, BATCH_SIZE)
        for query_idx, query in tqdm(enumerate(query_text_list), total=len(query_text_list)):
            # 召回
            query_embedding = query_embedding_list[query_idx]
            item_list = text_index.search(query_embedding, top_k=self.recall_num)
            # 排序
            has_item, explain, matched_item = self.do_rank(query, item_list)
            formated_item = {
                "explain": explain,
                "has_item": has_item,
                "score": float(matched_item["score"]),
                "payload": matched_item["payload"],
            }
            retriever_result.append(formated_item)
        return retriever_result

    async def do_rank_async(self, query, item_list, rate_limiter, semaphore, session, max_retries):
        if len(item_list) == 0:
            return "0", "", {}
        if self.rank_type == "llm":  # 通过LLM判断相关性
            return await self.do_llm_ran_async(query, item_list, rate_limiter, semaphore, session, max_retries)
        else:  # 通过相关性阈值阶段
            return await self.do_relevance_rank(query, item_list, rate_limiter, semaphore, session, max_retries)

    def do_rank(self, query, item_list):
        if len(item_list) == 0:
            return "0", "", {}
        if self.rank_type == "llm":  # 通过LLM判断相关性
            return self.do_llm_rank(query, item_list)
        else:  # 通过相关性阈值阶段
            return self.do_relevance_rank(query, item_list)

    async def do_relevance_rank(self, query, item_list, rate_limiter, semaphore, session, max_retries):
        item_list = self.rank_http(query, item_list)
        item_list = sorted(item_list, key=lambda x: x["score"])
        return await self.do_llm_ran_async(query, item_list[:1], rate_limiter, semaphore, session, max_retries)
        # return "1", "", item_list[0]

    async def do_llm_ran_async(self, query, item_list, rate_limiter, semaphore, session, max_retries):
        if not item_list:
            return "0", "", item
        # 选择top1推理
        item = item_list[0]
        history = [
            SYSTEM_PROMPT_STAGE_6,
            USER_PROMPT_STAGE_6.format(
                question=query, answer=item['payload']["answer"], target_q=item['payload']["question"][0])
        ]
        # 输入topn
        qid_list = []
        answer_list = []
        question_list = []
        for item in item_list:
            question = ", ".join(item["query_list"][:10])
            answer = item["payload"]["answer"]
            if question in question_list:   # 去重
                continue
            answer_list.append(answer)
            question_list.append(question)
            qid_list.append(item["payload"]["question_id"])
        history = [
            SYSTEM_PROMPT_STAGE_6_NEW,
            USER_PROMPT_STAGE_6_NEW.format(
                question=query, knowledge="\n".join([str({"id": qid_list[index], "question": question_list[index], "answer": answer_list[index]}) for index in range(len(answer_list))]))
        ]
        # 推理
        try:
            payload, response_data = await request_llm_async(rate_limiter, semaphore, session, max_retries, history, model=self.model_name, n=1, temperature=0)
            # print(json.dumps({"payload": payload, "response": response_data}, ensure_ascii=False))
            question_new_str = response_data["choices"][0]["message"]["content"]
            question_new_list = json.loads(question_new_str)
        except Exception as e:
            print(e)
            try:
                question_new_list = json.loads(question_new_str.strip().strip(
                    '`').replace("json", '').replace("\n", ""))
            except Exception as e:
                print(e)
                # 推理失败返回空
                return "0", "", item
        # qid校验
        try:
            id = int(question_new_list["id"])
            if (id == 0) | (id not in qid_list):
                return "0", question_new_list["analyse"], item
            else:
                # find corresonding item
                for item in item_list:
                    if item["payload"]["question_id"] == id:
                        break
                if "analyse_res" in question_new_list.keys():
                    return str(question_new_list["result"]), str(question_new_list["analyse"]) + question_new_list["analyse_res"], item
                else:
                    return str(question_new_list["result"]), question_new_list["analyse"], item
        except Exception as e:
            print(e)
        return "0", question_new_list["analyse"], item

    def rank_onnx(self, query, item_list, tokenizer, onnx_path="/mnt/pfs-guan-ssai/nlu/wuzhenyan/model/onnx_model/online_onnx_model.onnx"):
        softmax = nn.Softmax(dim=-1)
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

        text_list = ["[SEP]".join(query, i) for i in item_list]
        text_batch = {
            "text": text_list
        }
        # Load Data
        train_text_encodings = tokenizer(text_batch["texts"], padding=True,
                                         truncation=True, max_length=128, return_tensors="pt")
        train_text_encodings = train_text_encodings.to(device)

        input_ids = train_text_encodings['input_ids'].cpu().numpy()
        attention_mask = train_text_encodings['attention_mask'].cpu().numpy()
        token_type_ids = train_text_encodings['token_type_ids'].cpu().numpy()
        sess = ort.InferenceSession(onnx_path, None)  # 加载onnx模型
        onnx_output = sess.run(['output'],
                               {'input_ids': input_ids,
                                'attention_mask': attention_mask,
                                "token_type_ids": token_type_ids
                                })
        logits = torch.tensor(onnx_output)[0].to(device)

        prob = softmax(logits)
        similarity_tensor = torch.narrow(prob, 1, 1, 1)
        similarity_tensor = torch.squeeze(similarity_tensor, 1)
        return similarity_tensor.to("cpu").detach().numpy()

    def rank_http(self, query, item_list):
        url = "http://nlu-tritonserver-inference-http.ssai-apis-staging.chj.cloud/v2/models/qabot-rescore-ensemble/infer"
        payload = {
            "id": "1234545",
            "inputs": [
                {
                    "name": "user_query",
                    "shape": [
                        1
                    ],
                    "datatype": "BYTES",
                    "data": [
                        [
                            query
                        ]
                    ]
                },
                {
                    "name": "candidate_query_list",
                    "shape": [
                        1,
                        3
                    ],
                    "datatype": "BYTES",
                    "data": [
                        "1",
                        "item",
                        "1"
                    ]
                }
            ]
        }
        for index in tqdm(range(len(item_list))):
            payload["inputs"][1]["data"][1] = item_list[index]['payload']['question'][0]
            response = requests.request("POST", url, data=json.dumps(payload, ensure_ascii=False)).json()
            item_list[index]["score"] = response["outputs"][1]["data"][0]
            time.sleep(0.3)
        return item_list

    def do_llm_rank(self, query, item_list):
        for item in item_list:
            history = [
                SYSTEM_PROMPT_STAGE_6,
                USER_PROMPT_STAGE_6.format(
                    question=query, answer=item['payload']["answer"], target_q=item['payload']["question"][0])
            ]
            try:
                payload, response_data = request_llm(history, model=self.model_name, n=1, temperature=0)
                # print(json.dumps({"payload": payload, "response": response_data}, ensure_ascii=False))
                question_new_str = response_data["choices"][0]["message"]["content"]
                question_new_list = json.loads(question_new_str)
            except Exception as e:
                print(e)
                try:
                    question_new_list = json.loads(question_new_str.strip().strip(
                        '`').replace("json", '').replace("\n", ""))
                except Exception as e:
                    print(e)
                    continue
            if question_new_list["result"] == 1:
                return "1", question_new_list["analyse"], item
            else:
                return "0", question_new_list["analyse"], item
        return "0", "", item_list[0]

    def twoListtoDict(self, key_list, value_list):
        out_dict = {}
        for key, value in zip(key_list, value_list):
            if key in out_dict:
                # 如果键已经存在，则将值追加到对应的列表中
                out_dict[key].append(value)
            else:
                # 如果键不存在，则创建一个新的列表
                out_dict[key] = [value]
        return out_dict


if __name__ == "__main__":
    print("############## Step6 Processing ##############")
    obj = KnowledgeCoverage()
    obj.process(test=False)

# python -m search.qa_bot.qa_data_analyse.step6_knowledge_coverage
