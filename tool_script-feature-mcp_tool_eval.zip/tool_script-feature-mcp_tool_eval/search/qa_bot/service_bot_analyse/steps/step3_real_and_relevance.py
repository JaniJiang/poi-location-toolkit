from tqdm.asyncio import tqdm_asyncio
from asyncio import Semaphore
from search.qa_bot.service_bot_analyse.utils.prompt import *
from search.qa_bot.service_bot_analyse.utils.meta import *
from utils.llm_utils.serverless_function import request_llm_async, RateLimiter
from utils.file_utils import read_jsonl_file
import json
import pandas as pd
import asyncio
import aiohttp


class RealAndRelevance:
    """真实相关判断工具：通过LLM+策略规则判断回复是否真实相关"""

    def __init__(
        self,
        input_path=f"{DATA_DIR}/{DATE}/step2_question_intent.jsonl",
        output_path=f"{DATA_DIR}/{DATE}/step3_real_and_relevance.jsonl",
        dict_path="search/qa_bot/service_bot_analyse/vocab/car-company-other.txt",
    ):
        self.input_path = input_path
        self.output_path = output_path
        self.dict_path = dict_path
        self.model_name = "deepseek-r1"  # gpt-4o | claude-3_5-sonnet | deepseek-v3 | deepseek-r1 | deepseek-r1-distill-qwen-32b
        self.max_concurrent = 10
        self.qps = 3    # 推荐不大于4

    def analyse_result(self):
        with open(self.output_path, 'r', encoding='utf-8') as file:
            acc = 0
            acc_inner = 0
            all = 0
            for line in file:
                all += 1
                try:
                    data = json.loads(line)
                    # 处理严格label
                    if data["if_inner"] == 0:
                        # 严格情况
                        label = 0
                    else:
                        label = 1 if data['gpt_label'] == "完全可解" else 0
                    if label == data["label"]:
                        acc_inner += 1
                    # 处理不严格label
                    label = 1 if data['gpt_label'] == "完全可解" else 0
                    if label == data['label']:
                        acc += 1
                except json.JSONDecodeError as e:
                    print(f"解析错误: {e}")
                    print(f"问题行: {line}")
            print(f"严格结果acc{acc_inner / all}")
            print(f"宽松结果acc{acc / all}")

    def process(self, test=False):
        # 提取服务专家结果
        input_list = read_jsonl_file(self.input_path)
        # 加载词表
        dict_list = pd.read_csv(self.dict_path, sep='\t').iloc[:, 1].to_list()
        if test:
            test_path = "data/cloud/search/qa_bot/qa_data_analyse/testset/真实相关工具测试集.xlsx"
            self.output_path = "data/cloud/search/qa_bot/qa_data_analyse/testset/真实相关工具测试集_res.jsonl"
            input_list = pd.read_excel(test_path)
            input_list = input_list.dropna(subset=["label"]).head(125).iloc

        # 多线程调用
        loop = asyncio.get_event_loop()
        results = loop.run_until_complete(self.process_async(input_list, max_retries=5, dict_list=dict_list))

        if test:
            self.analyse_result()

    async def process_async(self, input_list, max_retries, dict_list):
        rate_limiter = RateLimiter(self.qps)
        semaphore = Semaphore(self.max_concurrent)  # 限制最大并发数为 max_concurrent
        async with aiohttp.ClientSession() as session:
            tasks = [self.process_item_async(rate_limiter, semaphore, session, item, max_retries, dict_list) for
                     item in input_list]
            results = [None] * len(tasks)
            task_objects = [asyncio.create_task(task) for task in tasks]
            for idx, task in tqdm_asyncio(zip(range(len(tasks)), task_objects), total=len(tasks)):
                response = await task
                # 根据任务的索引存储结果
                results[idx] = response
            with open(self.output_path, 'w', encoding='utf-8') as f:
                for item, response in zip(input_list, results):
                    if not response['gpt_label']:
                        continue
                    f.write(json.dumps(response.to_dict() if type(response)
                            != dict else response, ensure_ascii=False) + "\n")
                    f.flush()  # ensure the data is written to disk after each iteration
            return results

    async def process_item_async(self, rate_limiter, semaphore, session, item, max_retries, dict_list):
        try:
            # 过滤非服务专家的query
            step2_res = item['if_serviceBot']
            if type(step2_res) is str:
                try:
                    step2_res = json.loads(step2_res.replace('\'', '"'))
                except Exception as e:
                    print(e)
            if step2_res["一级分类"] != "服务专家":
                item["gpt_label"] = []
                item["label_analyse"] = []
                return item
            # 基于规则判断是否属于理想汽车query
            # obs中没有理想知识 --> 对于服务专家，默认不相关
            search_res_list = []
            for search_res in json.loads(item['knowledge_search_result']):
                search_res_list += search_res['data'][0]['bot_data']
        except Exception as e:
            print(e)
            item["gpt_label"] = []
            item["label_analyse"] = []
            return item

        if_skip = True
        search_obs = ""
        outer_list = []
        for res in search_res_list:
            if "content" in res.keys() & "source_domain" in res.keys():
                if ("lixiang" in res["source_domain"]) or ("理想" in res["content"].replace("该知识来自理想汽车", "")):
                    # 只添加 理想 的知识
                    if_skip = False
                    search_obs += res["content"]
                else:
                    # 所有外部公司都不包含的也可以添加进search_obs
                    flag = 0
                    for outer_company in dict_list:
                        # 遍历所有公司
                        for o in outer_company.split('，'):
                            # 遍历所有公司的别名
                            if o in res["content"]:
                                outer_list.append(o)
                                flag = 1
                                continue
                    if flag == 0:
                        # 所有外部公司都不包含的也可以添加进search_obs
                        search_obs += res["content"]
        # 大模型判断相关性
        # 调用LLM判断服务专家query

        if if_skip:
            # obs没有理想知识
            # if len(outer_list) < 1:
            history = [
                SYSTEM_PROMPT_STAGE_3_TMP,
                USER_PROMPT_STAGE_3_TMP.format(
                    question=item["query"], answer=item["output"], obs=search_obs, outer=outer_list)
            ]
            item["if_inner"] = 0
            # else:
            #     item["label"] = "不可解"
            #     item["label_analyse"] = "无理想汽车内容"
            #     return item
        else:
            # obs有理想知识
            history = [
                SYSTEM_PROMPT_STAGE_3_TMP,
                USER_PROMPT_STAGE_3_TMP.format(
                    question=item["query"], answer=item["output"], obs=search_obs, outer=outer_list)
            ]
            item["if_inner"] = 1

        # if (len(outer_list) < 1) and if_skip:
        #     # obs没有外部公司  且  没有理想知识
        #     history = [
        #         SYSTEM_PROMPT_STAGE_3_OUTER,
        #         USER_PROMPT_STAGE_3.format(question=item["query"], answer=item["output"], obs=search_obs)
        #     ]

        try:
            payload, response_data = await request_llm_async(rate_limiter, semaphore, session, max_retries, history, model=self.model_name, n=1, temperature=0)
            # print(json.dumps({"payload": payload, "response": response_data}, ensure_ascii=False))
            question_new_str = response_data["choices"][0]["message"]["content"]
            question_new_list = json.loads(question_new_str)
        except Exception as e:
            question_new_list = []
            print(e)
            try:
                question_new_list = json.loads(question_new_str.strip().strip(
                    '`').replace("json", '').replace("\n", ""))
            except Exception as e:
                print("llm-api调用失败")
                print(e)
                item["gpt_label"] = "不可解"
                item["label_analyse"] = "llm-api调用失败"
                return item
        # 回写判断
        item["gpt_label"] = question_new_list["result"]
        item["label_analyse"] = question_new_list["analyse"]
        return item


if __name__ == "__main__":
    print("############## Step3 Processing ##############")
    obj = RealAndRelevance()
    obj.process(test=False)

# python -m search.qa_bot.qa_data_analyse.step3_real_and_relevance
