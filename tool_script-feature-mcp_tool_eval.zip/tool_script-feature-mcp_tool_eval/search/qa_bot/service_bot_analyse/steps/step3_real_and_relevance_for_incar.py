from asyncio import Semaphore
from search.qa_bot.service_bot_analyse.utils.prompt import *
from search.qa_bot.service_bot_analyse.utils.meta import *
from utils.llm_utils.serverless_function import request_llm_async, RateLimiter
import json
import pandas as pd
import asyncio
import aiohttp
from tqdm.asyncio import tqdm_asyncio


class RealAndRelevanceForICA:
    """真实相关判断工具：通过LLM+策略规则判断回复是否真实相关"""

    def __init__(self, input_path="", output_path=""):
        self.input_path = input_path if input_path else f"{DATA_DIR}/{DATE}/in_car_assistant.csv"
        self.output_path = output_path if output_path else f"{DATA_DIR}/{DATE}/step3_real_and_relevance_ica.jsonl"
        self.model_name = "gpt-4o"  # gpt-4o | claude-3_5-sonnet | deepseek-v3 | deepseek-r1 | deepseek-r1-distill-qwen-32b
        self.max_concurrent = 10
        self.qps = 2    # 推荐不大于4,大于2回部分超时

    def process(self):
        # 提取服务专家结果
        input_list = pd.read_csv(self.input_path)
        print("input list:", len(input_list))
        # 多线程调用
        loop = asyncio.get_event_loop()
        results = loop.run_until_complete(self.process_async(input_list.iloc, max_retries=3))
        return results

    async def process_async(self, input_list, max_retries):
        rate_limiter = RateLimiter(self.qps)
        semaphore = Semaphore(self.max_concurrent)  # 限制最大并发数为 max_concurrent
        async with aiohttp.ClientSession() as session:
            tasks = [self.process_item_async(rate_limiter, semaphore, session, item, max_retries) for
                     item in input_list]
            results = [None] * len(tasks)
            task_objects = [asyncio.create_task(task) for task in tasks]
            for idx, task in tqdm_asyncio(zip(range(len(tasks)), task_objects), total=len(tasks)):
                response = await task
                # 根据任务的索引存储结果
                results[idx] = response
            with open(self.output_path, 'w', encoding='utf-8') as f:
                for item, response in zip(input_list, results):
                    if "label" not in response.keys():
                        continue
                    f.write(json.dumps(dict(response), ensure_ascii=False) + "\n")
                    f.flush()  # ensure the data is written to disk after each iteration
            return results

    async def process_item_async(self, rate_limiter, semaphore, session, item, max_retries):
        item = item.to_dict()  # convert to dict to avoid
        try:
            hitContent = json.loads(item["content"])
        except Exception as e:
            print(e)
            return item
        # 调用LLM判断服务专家query
        history = [
            QABOT_TASK,
            USER_PROMPT_QA_BOT.format(query=item["query"],
                                      question=hitContent["hitQuestion"] if "hitQuestion" in hitContent.keys() else "",
                                      answer=hitContent["speak"] if "speak" in hitContent.keys() else "")
        ]
        item["hitQuestion"] = hitContent["hitQuestion"] if "hitQuestion" in hitContent.keys() else ""
        item["answer"] = hitContent["speak"] if "speak" in hitContent.keys() else ""
        try:
            payload, response_data = await request_llm_async(rate_limiter, semaphore, session, max_retries, history, model=self.model_name, n=1, temperature=0)
            # print(json.dumps({"payload": payload, "response": response_data}, ensure_ascii=False))
            question_new_str = response_data["choices"][0]["message"]["content"]
            question_new_list = json.loads(question_new_str)
        except Exception as e:
            question_new_list = []
            print(e)
            try:
                question_new_list = json.loads(question_new_str.strip().strip(
                    '`').replace("json", '').replace("\n", ""))
            except Exception as e:
                print(e)
        # 回写判断
        # 判断是否可解逻辑
        try:
            label = question_new_list["results"]
            if label[0]["是否兜底"] == 1:      # 若兜底则忽略内容可解的打分（最后一项）
                list_score = list(label[0]["指令遵循"].values())[:-1]
            else:
                list_score = list(label[0]["指令遵循"].values())
            item["list_score"] = label[0]["指令遵循"]
            # 存在不相关的标注项==不相关 --> 不可解
            if bool([x for x in list_score if x == 0]):
                if label[0]["是否兜底"] == 0 and list_score[-2] != 0 and list_score[-1] == 0:
                    # 若不为兜底，且问题遵循情况下，忽略内容可解
                    item["label"] = 1
                else:
                    item["label"] = 0
            else:
                item["label"] = 1
        except Exception as e:
            item["label"] = 0
        return item


if __name__ == "__main__":
    print("############## Step3 Processing for incarassistant ##############")
    obj = RealAndRelevanceForICA()
    obj.process()

# python -m search.qa_bot.qa_data_analyse.step3_real_and_relevance
