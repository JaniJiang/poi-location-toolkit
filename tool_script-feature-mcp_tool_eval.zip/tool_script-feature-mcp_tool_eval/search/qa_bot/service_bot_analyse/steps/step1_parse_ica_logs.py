"""
解析incarassistant_log_verified.csv的结构
适配step_3真实相关工具
"""
from datetime import datetime
import pandas as pd
import json
from search.qa_bot.service_bot_analyse.utils.meta import *
import os
import warnings


def force_convert_to_date(date_string):
    """
    强制将输入的字符串转换为 %Y-%m-%d 格式的日期字符串。

    参数:
        date_string (str): 需要转换的日期字符串。

    返回:
        str: 转换后的日期字符串，格式为 %Y-%m-%d。
        如果输入的字符串无法解析为日期，返回 None。
    """
    # 定义可能的输入格式
    possible_formats = [
        '%Y%m%d',    # 20240611
        '%Y-%m-%d',  # 2024-06-11
        '%Y/%m/%d',  # 2024/06/11
        '%d-%m-%Y',  # 11-06-2024
        '%d/%m/%Y',  # 11/06/2024
        '%m-%d-%Y',  # 06-11-2024
        '%m/%d/%Y',  # 06/11/2024
    ]

    for fmt in possible_formats:
        try:
            # 尝试将字符串解析为日期
            date_obj = datetime.strptime(date_string, fmt)
            # 将日期对象格式化为指定的字符串格式
            formatted_date = date_obj.strftime('%Y-%m-%d')
            return formatted_date
        except ValueError:
            # 如果当前格式解析失败，尝试下一个格式
            continue

    # 如果所有格式都无法解析，返回 None
    return None


class log_parser():
    def __init__(
        self,
        original_path=f"{DATA_DIR}/{WEEK}/in_car_assistant_original.csv",
        verified_path=f"{DATA_DIR}/{WEEK}/in_car_assistant_verified.csv",
        save_path="",
        start_date=DATELIST[0],
        end_date=DATELIST[-1],
        num_sample=500,
        max=2000
    ):
        self.original_path = original_path
        self.verified_path = verified_path
        self.save_path = save_path
        self.start_date = force_convert_to_date(start_date)
        self.end_date = force_convert_to_date(end_date)
        # 检查转换后的日期是否有效
        if not self.start_date or not self.end_date:
            raise ValueError("输入不合法")
        self.num_sample = num_sample
        self.max = max

    def parse_ica_logs_and_save_by_path(self, n=500):
        """
        支持根据输入输出路径，保存处理好的DataFrame
        """
        df_verified = pd.read_csv(self.verified_path)
        df_original = pd.read_csv(self.original_path)
        df_processed = self.parse_ica_logs(df_verified, df_original, n)
        if self.save_path == "":
            print(f"Warning: None saved path, ignore saved {len(df_processed)} data.")
            return df_processed
        else:
            df_processed.to_csv(self.save_path, index=False)
            print(f"saved {len(df_processed)} data.")
            return df_processed
        # save_path = f"data/cloud/search/qa_bot/qa_bot_test_by_week/{week}/in_car_assistant.csv"
        # df_processed = self.parse_ica_logs(df_verified, df_original, save_path)

    def parse_ica_logs(self, df_verified, df_original, n=500):
        """
        支持直接输入DataFrame，返回处理好的DataFrame
        """
        true_query = []
        true_msg_id = []
        true_content = []
        for i in range(len(df_verified)):
            verified_msg_id = df_verified['msg_id'][i]
            if verified_msg_id in df_original['msg_id'].to_list():
                true_msg_id.append(verified_msg_id)
                true_content.append(df_original[df_original['msg_id'] == verified_msg_id]['content'].values[0])
                message = df_verified[df_verified['msg_id'] == verified_msg_id]["message"]
                try:
                    message = json.loads(message.values[0].split("request=")[1].split(",response")[0])
                    query = message["input"]["text"]
                    true_query.append(query)
                except Exception as e:
                    print(e)
        df_processed = pd.DataFrame({
            "query": true_query,
            "content": true_content,
        })
        df_processed.sample(min(n, len(df_processed)), replace=True)

        return df_processed

    def process(self):
        """
        max:采样原始数据的数据量，不建议太大，第二步通过msg_id反查原始query时容易报错
        """
        if self.max > 2000:
            warnings.warn(f"第一步采样的数据量过大，容易造成报错，请关注{self.verified_path}的处理结果，避免影响后续流程", UserWarning)
        # download data from two sheet

        # 第一步选出真实的用户日志，及其msg_id
        SQL_STRING_IC = f"select msg_id, query, content from dwd_vechile_merge_prod_di where (dt between '{self.start_date}' and '{self.end_date}') AND domain='in_car_assistant' and vehicle_category = '1' order by RAND() limit {self.max}"
        if not os.path.exists(self.original_path):
            command = f"data/cloud_share/tool/adt --token 731a63a43618b0b444a2b86f36cf3e14 ark2csv --sql-string \"{SQL_STRING_IC}\" --csv-file \"{self.original_path}\""
            sucess = os.system(command=command)
        else:
            sucess = 0
            print(f"File {self.original_path} already exists, skip download.")
            print(f"如果需要处理新数据，请先将{self.original_path}删除")
        if sucess == 0:
            try:
                msg_id_list = pd.read_csv(self.original_path).dropna()["msg_id"].to_list()
            except Exception as e:
                print(e)
            # 第二部根据msg_id列表选出包含真实input query的数据
            msg_id_list_str = ""
            for msg_id in msg_id_list:
                msg_id_list_str += f"\'{msg_id}\', "
            msg_id_list_str = msg_id_list_str[:-2]
            SQL_STRING_VERIFIED = f"select msg_id, message from ods_service_expert_log_v1_prod_rt where (dt between '{self.start_date}' and '{self.end_date}') and msg_id IN ({msg_id_list_str}) AND logger_name='com.lixiang.voice.cockpit.faqse.utils.filter.AccessLogFilter'"
            command = f"data/cloud_share/tool/adt --token 731a63a43618b0b444a2b86f36cf3e14 ark2csv --sql-string \"{SQL_STRING_VERIFIED}\" --csv-file \"{self.verified_path}\""
            if not os.path.exists(self.verified_path):
                sucess = os.system(command=command)
            else:
                print(f"File {self.verified_path} already exists, skip download.")
                print(f"如果需要处理新数据，请先将{self.verified_path}删除")
        # process two sheets
        self.parse_ica_logs_and_save_by_path(n=self.num_sample)


if __name__ == "__main__":
    obj = log_parser(
        save_path=f"{DATA_DIR}/{WEEK}/in_car_assistant.csv"
    )
    obj.process()
    pass
