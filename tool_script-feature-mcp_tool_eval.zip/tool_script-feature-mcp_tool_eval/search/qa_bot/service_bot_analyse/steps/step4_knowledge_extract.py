from search.qa_bot.service_bot_analyse.utils.meta import *
from utils.file_utils import read_json_file_union
import os
import json
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor


class KnowledgeExtract:
    """知识抽取：定期将内部知识（QA库+知识库）同步至离线索引库"""

    def __init__(self):
        # 服务专家数据先从QA配置管理平台下载: https://voice-platform.ssai.lixiangoa.com/qa/library
        # RAG知识库数据离线提供
        self.input_path_list = [
            {
                "path": f"{INDEX_DIR}/data.json",
                "type": "file",
                "from": "qa",
                "enable": True,
            },
            {
                "path": f"{DATA_DIR}/../../car_knowledge",
                "type": "dir",
                "from": "rag",
                "enable": False,
            },
        ]
        self.output_path = f"{INDEX_DIR}/step4_knowledge_extract"

    def process(self):
        for input_path_item in self.input_path_list:
            if input_path_item["enable"] is False:
                continue
            input_path = input_path_item["path"]
            input_type = input_path_item["type"]
            input_from = input_path_item["from"]
            # 读取原始输入数据
            input_list = []
            if input_type == "file":
                input_list = read_json_file_union(input_path)
            else:
                file_name_list = os.listdir(input_path)
                with ThreadPoolExecutor(max_workers=10) as executor:
                    # 使用map方法，结合tqdm显示进度
                    results = list(tqdm(
                        executor.map(self.process_file, file_name_list, [input_path] * len(file_name_list)),
                        total=len(file_name_list)
                    ))
                    # 将所有结果合并到input_list
                    for result in results:
                        input_list.extend(result)
            print(input_from, "input_list", len(input_list))
            # 统计分析 & 保存结果
            with open(f"{self.output_path}.{input_from}.jsonl", mode="w", encoding="utf-8") as f:
                for item in input_list:
                    if input_from == "qa":
                        item = self.process_qa_item(item, input_from)
                    else:
                        item = self.process_rag_item(item, input_from)
                    f.write(json.dumps(item, ensure_ascii=False) + "\n")

    def process_file(self, file_name, input_path):
        file_path = f"{input_path}/{file_name}"
        return read_json_file_union(file_path)

    def process_qa_item(self, item, input_from):
        # 处理question
        question_list = [x.strip() for x in item.get("question", [])]
        # 处理answer
        try:
            choose_answer = item["answerGroup"][0]["answers"][0]["ttsContent"].strip()
            question_id = item["answerGroup"][0]["questionId"]
        except:
            choose_answer = ""
            question_id = ""
        if choose_answer == "":
            answer_nums = 0
        else:
            answer_nums = len(item.get("answerGroup", []))
        # 处理category
        category_list = item.get("category").split(",")
        category_lv_0, category_lv_1, category_lv_2 = "NONE", "NONE", "NONE"
        if len(category_list) > 0:
            category_lv_0 = category_list[0]
        if len(category_list) > 1:
            category_lv_1 = category_list[1]
        if len(category_list) > 2:
            category_lv_2 = category_list[2]
        # 统一返回特征字段
        item["feature_dict"] = {
            "category_lv_0": category_lv_0,
            "category_lv_1": category_lv_1,
            "category_lv_2": category_lv_2,
            "category_lv_0_1": ",".join([category_lv_0, category_lv_1]),
            "category_lv_0_1_2": ",".join([category_lv_0, category_lv_1, category_lv_2]),
            "question_id": question_id,
            "question_nums": len(question_list),
            "answer_nums": answer_nums,
            "question": question_list,
            "answer": choose_answer,
            "from": input_from,
        }
        return item

    def process_rag_item(self, item, input_from):
        feature_dict = {
            "category_lv_0": "",
            "question_id": item["id"],
            "question_nums": 1,
            "answer_nums": 1,
            "question": item["title"],
            "answer": item["content"],
            "from": input_from,
        }
        if "category" in item:
            category_lv_0 = ""
            category = item["category"]
            if type(category) is str:
                category_lv_0 = category
            elif type(category) is list:
                if len(category) > 0:
                    category_lv_0 = category[0]
            feature_dict["category_lv_0"] = category_lv_0
        item_new = {"feature_dict": feature_dict}
        return item_new


if __name__ == "__main__":
    obj = KnowledgeExtract()
    obj.process()

# python -m search.qa_bot.qa_data_analyse.step4_knowledge_extract
# nohup python -m search.qa_bot.qa_data_analyse.step4_knowledge_extract > log/search/qa_bot/qa_data_analyse/step4_knowledge_extract.log 2>&1 &
