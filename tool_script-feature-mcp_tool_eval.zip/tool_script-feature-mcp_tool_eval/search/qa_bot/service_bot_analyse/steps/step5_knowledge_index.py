from search.qa_bot.service_bot_analyse.utils.meta import *
from utils.nlp_utils.embedding import get_batch_embedding
from utils.file_utils import read_jsonl_file
import json
import hashlib
from tqdm import tqdm


class KnowledgeIndex:
    """构建知识的索引数据"""

    def __init__(self):
        self.input_path_list = [
            {
                # "path": f"{DATA_DIR}/{DATE}/step4_knowledge_extract.qa.shuf_100.jsonl",
                "path": f"{INDEX_DIR}/step4_knowledge_extract.qa.jsonl",
                "from": "qa",
                "enable": True,
                "need_dedup": False,
            },
            {
                # "path": f"{DATA_DIR}/{DATE}/step4_knowledge_extract.rag.shuf_100.jsonl",
                "path": f"{DATA_DIR}/{DATE}/step4_knowledge_extract.rag.jsonl",
                "from": "rag",
                "enable": False,
                "need_dedup": True,
            },
        ]
        self.output_path = f"{INDEX_DIR}/step5_knowledge_index"

    def process(self):
        for input_path_item in self.input_path_list:
            if input_path_item["enable"] is False:
                continue
            input_path = input_path_item["path"]
            input_from = input_path_item["from"]
            # 读取knowledge数据
            knowledge_list = read_jsonl_file(input_path)
            print("origin knowledge_list len:", input_from, len(knowledge_list))
            # 去重策略
            if input_path_item["need_dedup"] is True:
                knowledge_list = self.dedup_strategy(knowledge_list)
                print("dedup knowledge_list len:", len(knowledge_list))
            # 逐条处理knowledge生成索引数据
            with open(f"{self.output_path}.{input_from}.jsonl", "w", encoding="utf-8") as f:
                for i in tqdm(range(0, len(knowledge_list), BATCH_SIZE), desc="index"):
                    # 获取Knowledge字段
                    batch_question_list = []
                    batch_question_id_list = []
                    batch_question_dict = {}
                    for knowledge_item in knowledge_list[i: (i + BATCH_SIZE)]:
                        feature_dict = knowledge_item.get("feature_dict", {})
                        question_id = str(feature_dict.get("question_id", ""))
                        answer = feature_dict.get("answer", "")
                        if question_id == "" or answer == "":
                            continue
                        if input_from == "qa":
                            question_list = feature_dict.get("question", [])
                        else:
                            question_list = [feature_dict.get("question", "")]
                        question_list = [i for i in question_list if i]     # 剔除空字符串
                        if len(question_list) == 0:
                            continue
                        batch_question_list.extend(question_list)
                        batch_question_id_list.extend([question_id] * len(question_list))
                        batch_question_dict[question_id] = feature_dict
                    # 获取索引文本对应的向量
                    try:
                        batch_embedding_list = get_batch_embedding(batch_question_list, DIM, BATCH_SIZE)
                    except:
                        print("get_batch_embedding failed:", batch_question_dict.keys())
                        continue
                    if len(batch_question_list) != len(batch_embedding_list):
                        continue
                    # 逐条生成qdrant索引数据
                    for i, batch_question in enumerate(batch_question_list):
                        batch_question_id = batch_question_id_list[i]
                        index_id = self.generate_index_id(batch_question_id, batch_question)
                        batch_embedding = batch_embedding_list[i]
                        qdrant_item = {
                            "id": index_id,
                            "vector": batch_embedding,
                            "query": batch_question,
                            "payload": batch_question_dict.get(batch_question_id, {})
                        }
                        f.write(json.dumps(qdrant_item, ensure_ascii=False) + "\n")

    def generate_index_id(self, question_id, question):
        index_id_origin = "_".join([question_id, question]).replace(" ", "_").lower()
        index_id = hashlib.md5(index_id_origin.encode("utf-8")).hexdigest()
        return index_id

    def dedup_strategy(self, knowledge_list):
        dedup_knowledge_list = []
        question_dict = {}
        for knowledge_item in tqdm(knowledge_list, total=len(knowledge_list), desc="dedup"):
            feature_dict = knowledge_item.get("feature_dict", {})
            question = feature_dict.get("question", "")
            if question == "" or question in question_dict:
                continue
            dedup_knowledge_list.append(knowledge_item)
            question_dict[question] = True
        return dedup_knowledge_list


if __name__ == "__main__":
    obj = KnowledgeIndex()
    obj.process()

# python -m search.qa_bot.qa_data_analyse.step5_knowledge_index
# nohup python -m search.qa_bot.qa_data_analyse.step5_knowledge_index > log/search/qa_bot/qa_data_analyse/step5_knowledge_index.log 2>&1 &
