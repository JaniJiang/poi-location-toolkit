"""
流程控制器，控制每一步使用的参数
"""
from search.qa_bot.service_bot_analyse.utils.meta import *
from search.qa_bot.service_bot_analyse.steps.step1_parse_ica_logs import log_parser
from search.qa_bot.service_bot_analyse.steps.step2_query_intent import QueryIntent
from search.qa_bot.service_bot_analyse.steps.step3_real_and_relevance import RealAndRelevance
from search.qa_bot.service_bot_analyse.steps.step3_real_and_relevance_for_incar import RealAndRelevanceForICA
from search.qa_bot.service_bot_analyse.steps.step6_knowledge_coverage import KnowledgeCoverage
from search.qa_bot.service_bot_analyse.steps.step6_knowledge_coverage_for_incar import KnowledgeCoverageForICA
from search.qa_bot.service_bot_analyse.steps.eval_res import EvalRes


class Controller:
    def __init__(self, week_or_day, start_date, end_date):
        """初始化各阶段处理工具实例"""
        # 处理in_car_assistant链路所需的工具
        self.log_parser = log_parser(
            original_path=f"{DATA_DIR}/{week_or_day}/in_car_assistant_original.csv",
            verified_path=f"{DATA_DIR}/{week_or_day}/in_car_assistant_verified.csv",
            save_path=f"{DATA_DIR}/{week_or_day}/in_car_assistant.csv",
            start_date=start_date,
            end_date=end_date,
            num_sample=int(NUM_QA)
        )
        self.ica_relevance_tool = RealAndRelevanceForICA(
            input_path=f"{DATA_DIR}/{week_or_day}/in_car_assistant.csv",
            output_path=f"{DATA_DIR}/{week_or_day}/step3_real_and_relevance_ica.jsonl"
        )
        self.ica_knowledge_coverage_tool = KnowledgeCoverageForICA(
            query_path=f"{DATA_DIR}/{week_or_day}/step3_real_and_relevance_ica.jsonl",
            qa_index_path=f"{INDEX_DIR}/step5_knowledge_index.qa.jsonl",    # 数据默认取最新的索引
            output_path=f"{DATA_DIR}/{week_or_day}/step6_knowledge_coverage_ica.jsonl",
            synonym_path="search/qa_bot/service_bot_analyse/vocab/synonym.tsv"
        )

        # 处理gpt_autoqa链路所需的工具
        self.query_intent = QueryIntent(
            input_path=f"{DATA_DIR}/{week_or_day}/autosearch.csv",
            output_path=f"{DATA_DIR}/{week_or_day}/step2_question_intent.jsonl"
        )
        self.rag_relevance_tool = RealAndRelevance(
            input_path=f"{DATA_DIR}/{week_or_day}/step2_question_intent.jsonl",
            output_path=f"{DATA_DIR}/{week_or_day}/step3_real_and_relevance.jsonl"
        )
        self.rag_knowledge_coverage_tool = KnowledgeCoverage(
            query_path=f"{DATA_DIR}/{week_or_day}/step3_real_and_relevance.jsonl",
            qa_index_path=f"{INDEX_DIR}/step5_knowledge_index.qa.jsonl",    # 数据默认取最新的索引
            output_path=f"{DATA_DIR}/{week_or_day}/step6_knowledge_coverage.jsonl",
            synonym_path="search/qa_bot/service_bot_analyse/vocab/synonym.tsv"
        )

        # 指标统计器
        self.evaluator = EvalRes(
            input_path_list_qi=[self.query_intent.output_path],  # gpt_autoqa 服务专家query占比
            input_path_list_rr_ica=[self.ica_relevance_tool.output_path],   # in_car_assistant 服务专家完成率
            input_path_list_rr=[self.rag_relevance_tool.output_path],   # gpt_autoqa 服务专家完成率
            input_path_list_kc=[self.rag_knowledge_coverage_tool.output_path],  # gpt_autoqa 知识覆盖率
            input_path_list_kc_ica=[self.ica_knowledge_coverage_tool.output_path]   # in_car_assistant 知识覆盖率
        )

    def process(self):
        print("开始处理in_car_assistant数据")
        self.log_parser.process()
        self.ica_relevance_tool.process()
        self.ica_knowledge_coverage_tool.process()

        print("开始处理gpt_autoqa数据")
        self.query_intent.process()
        self.rag_relevance_tool.process()
        self.rag_knowledge_coverage_tool.process()

        print("计算指标")
        self.evaluator.process()


if __name__ == "__main__":
    pass
