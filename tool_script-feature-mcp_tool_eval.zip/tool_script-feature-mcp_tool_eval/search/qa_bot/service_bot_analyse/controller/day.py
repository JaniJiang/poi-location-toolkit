from search.qa_bot.service_bot_analyse.controller.controller import Controller
from search.qa_bot.service_bot_analyse.utils.meta import *

if __name__ == "__main__":
    controller = Controller(DATE, DATE, DATE)
    controller.process()
