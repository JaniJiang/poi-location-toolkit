# QA Bot 指标生产工具

## 概述
这是一个用于计算 QA Bot 指标的自动化工具 Pipeline。流程代码在run_pipeline.sh文件中，配置在meta.py文件中

## 文件结构
- **`data/cloud/search/qa_bot/qa_bot_test`**：存储处理后的数据。
- **`data/cloud_share/tool/adt`**：用于执行 SQL 查询并导出数据的工具。
- **`search/qa_bot/service_bot_analyse/meta.py`**：包含日期和数据目录配置的 Python 文件。
- **`search/qa_bot/service_bot_analyse/`**：包含数据处理和分析的 Python 脚本。

## 流程描述

### 1. 初始化和日期范围设置
- 脚本定义了数据目录路径 `DATA_DIR` 和日期范围（`start_date` 和 `end_date`）。
- 使用 `date` 命令将起始和结束日期转换为时间戳。
- 生成日期范围列表，并将其转换为 Python 列表格式。

### 2. 遍历日期范围
- 脚本遍历从起始日期到结束日期的每一天。
- 对于每一天：
  - 创建对应的日期目录。
  - 使用 `sed` 命令更新 `meta.py` 文件中的日期和数据目录配置。
  - 更新 `meta.py` 文件中的日期列表。
  - 执行 SQL 查询，提取相关数据并保存为 CSV 文件。
  - 运行 Python 脚本进行数据处理和分析。
  - 复制知识索引文件到目标目录。

### 3. 数据提取和处理
- 使用 `data/cloud_share/tool/adt` 工具执行 SQL 查询，提取数据并保存为 CSV 文件。
- 运行 Python 脚本进行数据处理和分析

### 4. 知识索引文件处理
- 检查目标目录中是否存在知识索引文件。如果不存在，则从源目录（保存了最新（n-1周）的知识索引）复制该文件。

### 5. 测试指标计算
- 在所有日期处理完成后，运行 `eval_res` 脚本计算测试指标。

## 使用指南

### 运行前准备
- 确保bash文件中配置的数据路径正确

- 确保服务专家的数据索引是否符合需求
  - `data/cloud_share/qabot_miner/qa_index/step5_knowledge_index.qa.jsonl`

### 脚本修改
可以根据需求，调整计算周期，以及每天采样的数据量，注意week会决定数据的存储路径，请注意是否与周期匹配，并注意可能的数据冲突


### 运行脚本
   ```bash
   bash run_pipeline.sh
   ```
