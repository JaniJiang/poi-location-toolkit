import pandas as pd
import json
import ast
from search.qa_bot.service_bot_relevance.sample.meta import *


class SampleTrans:
    def __init__(self):
        self.df = None

    def load_tsv(self, input_path):
        """加载 TSV 文件"""
        self.df = pd.read_csv(input_path, sep="\t", dtype=str).fillna("")
        print(f"已加载 {len(self.df)} 条数据")

    def convert(self) -> list:
        """
        将数据转换为指定格式的字典列表
        只保留 '与原标签一致' == 'TRUE' 的行
        """
        output_data = []
        for _, row in self.df.iterrows():
            if row["与原标签一致"] == "TRUE":
                try:
                    neg_list = ast.literal_eval(row["neg_title"]) if row["neg_title"] else [""]*5
                except Exception:
                    neg_list = [""]*5  # 读取失败模型neg_title为五个空str

                item = {
                    "query": row["query1"],
                    "response": row["query2"],
                    "rejected_response": neg_list
                }
                output_data.append(item)
        return output_data

    def process(self, input_path: str, output_path: str):
        self.load_tsv(input_path)
        data = self.convert()
        with open(output_path, "w", encoding="utf-8") as f:
            for entry in data:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        print(f"已保存 {len(data)} 条数据到 {output_path}")


# 使用示例
if __name__ == "__main__":
    input_path = f"{SAMPLE_PATH}/result/{SAMPLE_VERSION}.tsv"
    output_path = f"{DATA_PATH}/{DATA_VERSION}.jsonl"
    obj = SampleTrans()
    obj.process(input_path, output_path)

# python -m search.qa_bot.service_bot_relevance.sample.trans_sample
