# 服务专家知识
KNOWLEDGE_PATH = "data/cloud_share/qabot_relevance_data/qa_bot_knowledge"
KNOWLEDGE_DATE = "20250813"

# reranker原始数据
SAMPLE_PATH = "data/cloud_share/qabot_relevance_data/sample"
SAMPLE_VERSION = "20250814"

# 训练数据集
DATA_PATH = "data/cloud_share/qabot_relevance_data/dataset"
DATA_VERSION = "20250814"