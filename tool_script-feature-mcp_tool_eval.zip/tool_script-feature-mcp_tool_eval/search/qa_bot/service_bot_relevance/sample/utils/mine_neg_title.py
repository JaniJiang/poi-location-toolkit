import json
import pandas as pd
import numpy as np
from typing import List, Dict
from tqdm import tqdm
from utils.search_utils.memory_qdrant import MemoryQdrant
from utils.nlp_utils.embedding_new import get_batch_embedding
from search.qa_bot.service_bot_relevance.sample.meta import *
from search.qa_bot.service_bot_analyse.steps.step4_knowledge_extract import KnowledgeExtract
from search.qa_bot.service_bot_analyse.steps.step5_knowledge_index import KnowledgeIndex


class NegRetriever:
    def __init__(self):
        self.qdrant = MemoryQdrant()

    def load_jsonl_to_qdrant(self, jsonl_path: str):
        """从 JSONL 文件加载数据到 MemoryQdrant 索引"""
        points = []
        with open(jsonl_path, "r", encoding="utf-8") as f:
            for line in f:
                obj = json.loads(line)
                points.append({
                    "id": obj["id"],           # 唯一 ID
                    "vector": obj["vector"],   # 向量
                    "payload": obj["payload"],  # 额外信息 (含 question_id)
                    "query": obj["query"],     # 原始文本
                })
        self.qdrant.add_points(points)
        print(f"已加载 {len(points)} 条数据到 MemoryQdrant.")

    def process_tsv(self, tsv_path: str, output_path: str, batch_size: int = 32):
        """对 TSV 中的 query1/query2 做两轮检索并保存结果"""
        df = pd.read_csv(tsv_path, sep="\t", dtype=str)
        df = df.fillna("")

        # Step 1: 对 query2 检索，取相似度最高的 id
        query2_embs = get_batch_embedding(df["query2"].tolist(), batch_size=batch_size)
        query2_results = self.qdrant.search_batch(query2_embs, top_k=1, deduplicate=False)
        df["knowledge_id"] = [r[0]["payload"]["question_id"] if r else None for r in query2_results]

        # Step 2: 对 query1 检索，去掉 query2 对应 id，再取 top5
        query1_embs = get_batch_embedding(df["query1"].tolist(), batch_size=batch_size)
        query1_results = self.qdrant.search_batch(query1_embs, top_k=40, deduplicate=False)

        top5_filtered_queries = []
        for i, results in enumerate(query1_results):
            exclude_id = df.loc[i, "knowledge_id"]
            filtered = [r for r in results if r["payload"]["question_id"] != exclude_id]

            # 从 payload 或 query 字段获取 query 文本
            queries = []
            for r in filtered[:5]:
                queries.append(self.qdrant.querys[r["id"]])
            # 如果不足 5 个结果，用空字符串补齐
            while len(queries) < 5:
                queries.append("")
            top5_filtered_queries.append(queries)
        df["neg_title"] = top5_filtered_queries
        # 保存
        df.to_csv(output_path, sep="\t", index=False)
        print(f"结果已保存到 {output_path}")


if __name__ == "__main__":
    # 服务专家知识抽取
    # know_extra = KnowledgeExtract()
    # know_extra.input_path_list = [
    #     {
    #         "path": f"{KNOWLEDGE_PATH}/source/{KNOWLEDGE_DATE}_data.json",
    #         "type": "file",
    #         "from": "qa",
    #         "enable": True,
    #     }
    # ]
    # know_extra.output_path = f"{KNOWLEDGE_PATH}/result/{KNOWLEDGE_DATE}_extract"
    # know_extra.process()

    # 服务专家知识索引
    # know_index = KnowledgeIndex()
    # know_index.input_path_list = [
    #     {
    #         "path": f"{KNOWLEDGE_PATH}/result/{KNOWLEDGE_DATE}_extract.qa.jsonl",
    #         "from": "qa",
    #         "enable": True,
    #         "need_dedup": False,
    #     }
    # ]
    # know_index.output_path = f"{KNOWLEDGE_PATH}/result/{KNOWLEDGE_DATE}_index"
    # know_index.process()

    # title负样本挖掘
    know_path = f"{KNOWLEDGE_PATH}/result/{KNOWLEDGE_DATE}_index.qa.jsonl"
    origin_data = f"{SAMPLE_PATH}/source/{SAMPLE_VERSION}.tsv"
    output_data = f"{SAMPLE_PATH}/result/{SAMPLE_VERSION}.tsv"
    neg_retriever = NegRetriever()
    neg_retriever.load_jsonl_to_qdrant(know_path)
    neg_retriever.process_tsv(origin_data, output_data, 32)

    # python -m search.qa_bot.service_bot_relevance.sample.utils.mine_neg_title
