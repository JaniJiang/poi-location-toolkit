import os
import torch
import pandas as pd
from tqdm import tqdm
from typing import Dict
import matplotlib.pyplot as plt
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from search.qa_bot.service_bot_relevance.query_bert.meta import *
from transformers import BertConfig, BertTokenizer, BertForSequenceClassification
from search.qa_bot.service_bot_intent.step1_train import (
    create_data_loader,
    train_epoch,
    eval_model,
    calculate_metrics,
    device
)

NUM_LABELS = 13  # 类别数量
VAL_SIZE = 0.11  # 验证集比例
LR = 2e-5

def main(base_model_dir, sample_path, save_model_path):
    # 读取数据
    df = pd.read_csv(sample_path, sep="\t", encoding="utf-8")
    if "sample_type" in df.columns:
        train_df = df[df["sample_type"] == "train"].copy()
        val_df = df[df["sample_type"] == "val"].copy()
        print("按照 sample_type 列划分数据集")
    else:
        train_df, val_df = train_test_split(
            df,
            test_size=VAL_SIZE, 
            random_state=42,
            stratify=df['new_label']
        )
        print("使用 train_test_split 和分层采样划分数据集")
    # 参数
    MAX_LEN = 128
    BATCH_SIZE = 16

    tokenizer = BertTokenizer.from_pretrained(base_model_dir)
    train_loader = create_data_loader(train_df, tokenizer, MAX_LEN, BATCH_SIZE)
    val_loader = create_data_loader(val_df, tokenizer, MAX_LEN, BATCH_SIZE)

    # 模型
    # 配置模型 (加大Dropout防止过拟合)
    config = BertConfig.from_pretrained(
        base_model_dir,
        num_labels=NUM_LABELS,
        hidden_dropout_prob=0.3,
        attention_probs_dropout_prob=0.3
    )
    model = BertForSequenceClassification.from_pretrained(
        base_model_dir,
        config=config
    ).to(device)
    # 优化器
    no_decay = ["bias", "LayerNorm.weight"]
    optimizer_grouped_parameters = [
        {
            "params": [p for n, p in model.named_parameters() if not any(nd in n for nd in no_decay)],
            "weight_decay": 0.01
        },
        {
            "params": [p for n, p in model.named_parameters() if any(nd in n for nd in no_decay)],
            "weight_decay": 0.0
        }
    ]
    optimizer = torch.optim.AdamW(optimizer_grouped_parameters, lr=LR)
    # 训练
    history = []
    best_accuracy = 0
    best_val_metrics_report = None

    for epoch in range(EPOCHS):
        print(f"\nEpoch {epoch + 1}/{EPOCHS}\n" + "-" * 10)
        train_loss, train_acc, train_metrics_report = train_epoch(
            model, train_loader, optimizer, device
        )
        print(f"Train loss: {train_loss:.4f}, Acc: {train_acc:.4f}\n" + "-" * 10)
        print("Train classification report:")
        print(train_metrics_report)

        val_loss, val_acc, val_metrics_report = eval_model(model, val_loader, device)
        print(f"Valid loss: {val_loss:.4f}, Acc: {val_acc:.4f}")
        print("Valid classification report:")
        print(val_metrics_report)

        history.append(
            {
                "epoch": epoch+1,
                "train_acc": train_acc,
                "val_acc": val_acc
            }
        )

        if val_acc > best_accuracy:
            torch.save(model.state_dict(), save_model_path)
            best_accuracy = val_acc
            best_val_metrics_report = val_metrics_report
            print("Best model saved.")

    print("\n===== 最优模型在验证集上的指标 =====")
    print(f"Best Accuracy: {best_accuracy:.4f}")
    if best_val_metrics_report:
        print(best_val_metrics_report)

    # 绘制并保存loss曲线
    epochs_list = [r['epoch'] for r in history]
    train_acces = [r['train_acc'] for r in history]
    val_acces = [r['val_acc'] for r in history]

    plt.figure(figsize=(8, 6))
    plt.plot(epochs_list, train_acces, label="Train ACC", marker='o')
    plt.plot(epochs_list, val_acces, label="Validation ACC", marker='o')
    plt.xlabel("Epoch")
    plt.ylabel("ACC")
    plt.title("Training & Validation ACC Curve")
    plt.legend()
    plt.grid(True)
    plt.savefig(f"{MODEL_OUTPUT}/{MODEL_VERSION}/acc_curve.png", dpi=300)
    plt.close()

    print(f"\nACC曲线已保存至 acc_curve.png")


if __name__ == "__main__":
    sample_path = f"{SAMPLE_DIR}/processed/{SAMPLE_VERSION}.tsv"  # 训练集路径
    save_model_path = f"{MODEL_OUTPUT}/{MODEL_VERSION}/best_model_state.bin"  
    os.makedirs(os.path.dirname(save_model_path), exist_ok=True)
    # 基座模型: BASE_MODEL_DIR, ROBERTA_MODEL_DIR
    main(ROBERTA_MODEL_DIR, sample_path, save_model_path)

# python -m search.qa_bot.service_bot_relevance.query_bert.step4_train
