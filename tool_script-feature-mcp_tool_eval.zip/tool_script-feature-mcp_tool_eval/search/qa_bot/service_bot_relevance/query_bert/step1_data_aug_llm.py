import os
import csv
import json
import random
import threading
from tqdm import tqdm
from search.qa_bot.service_bot_relevance.query_bert.meta import *
from utils.llm_utils.openai_style_api import OpenAIStyleAPI
from utils.file_utils import check_output_path

API_DICT = {
    "gpt-4o": {
        "model": "gpt-4o",
        "url": "https://xuzhou1-tool-llm.ontest.fc.chj.cloud/gpt-4o",
    },
    'qwen-32b': {
        "model": "deepseek-r1-distill-qwen-32b",
        "url": "https://xuzhou1-tool-llm.ontest.fc.chj.cloud/deepseek-r1-distill-qwen-32b"
    },
    'deepseek-v3': {
        "model": "deepseek-v3",
        "url": "https://xuzhou1-tool-llm.ontest.fc.chj.cloud/deepseek-v3"
    },
    'deepseek-r1': {
        "model": "deepseek-r1",
        "url": "https://xuzhou1-tool-llm.ontest.fc.chj.cloud/deepseek-r1"
    },
}

label_info = {
    "健康查询": {
        "def": "用户咨询某操作对于车辆是否会更健康，用户询问query的目的是想用更健康的方式使用车辆。",
        "num": 299,  # 指定让LLM生成的样本数量
        "examples": [
            "一直使用增程器行驶而不进行充电对电池有没有影响？",
            "车辆长期闲置会不会对电池造成影响？",
            "车辆可以在过热或者过冷的情况下频繁充电吗？",
            "夏天胎压应该打多少合适？"
        ]
    },
    "整车介绍": {
        "def": "用户希望理想同学对本车或者理想汽车品牌某个指定车型进行完备的介绍，问题类型包括但不限于询问让理想同学介绍车辆、让理想同学说一下车辆的特色、让理想同学说一下车辆的功能。",
        "num": 307,
        "examples": [
            "介绍一下理想L9。",
            "你觉得L8 Pro这个车怎么样？",
            "评价一下L7。",
            "说一下理想MEGA的特点。",
            "这辆车有什么功能啊。",
        ]
    },
    "专有名词": {
        "def": "用户咨询和汽车相关的某个专有名词的含义，这类专有名词适用于各个品牌汽车，其范围包括但不限于动力系统（例如涡轮增压、增程器、电驱动系统）、传动系统（手动变速箱、自动变速箱、无级变速箱）、底盘与操控（悬架、转向助力系统）、制动与安全（EBD、TCS、SRS安全气囊）、新能源与智能化（SOC、OTA升级、L2/L3自动驾驶）。",
        "num": 333,
        "examples": [
            "介绍一下城市NOA。",
            "EID是什么功能？",
            "什么是车辆的悬挂系统？",
            "介绍一下车辆的ABS系统。",
        ]
    },
    "售前问题": {
        "def": "用户买车之前对于汽车购车政策、复购政策、二手车价格, 购买服务等相关问题的提问。",
        "num": 341,
        "examples": [
            "我朋友要买一台理想，我作为车主推荐，会给我什么福利？",
            "理想L8目前售价",
            "现在买理想有优惠吗",
            "当前理想汽车市场价是多少",
            "理想汽车有价保吗",
        ]
    },
    "其他问题": {
        "def": "用户的提问与汽车无关, 或者用户的提问是关于理想以外的其他汽车品牌",
        "num": 326,
        "examples": [
            "今天天气怎么样？",
            "中山路现在是否拥堵？",
            "帮我推荐一下附近好吃的餐厅。",
            "siri的简介",
            "特斯拉model Y这辆车怎么样？介绍一下",
        ]
    },
    "售后维保": {
        "def": "用户买理想汽车之后对于汽车售后保养、维修、取送车、用车服务包等相关的问题提问。",
        "num": 302,
        "examples": [
            "车辆保养是否需要提前预约？",
            "取送车是否需要付费？",
            "用车服务包有哪些权益？",
            "官方回收二手车吗？",
        ]
    },
    "充电网络": {
        "def": "用户询问理想充电桩、理想充电站相关的问题。",
        "num": 153,
        "examples": [
            "介绍一下理想汽车无锡充电站？",
            "充电站怎么开通免费停车服务？",
            "介绍一下5C超充站。",
            "附近哪里有充电站？",
        ]
    },
    "通用知识": {
        "def": "用户询问的问题与汽车有关，且该问题的答案不会随着汽车的品牌变化而变化",
        "num": 304,
        "examples": [
            "该类别无示例, 请你自行想象"
        ]
    },
}


class LLMDataAugmentor:
    def __init__(self, model_name="deepseek-v3", n_jobs=3, batch_size=20, temp_range=(0.6, 1.0)):
        self.n_jobs = n_jobs  # 进程并发数量（还未使用）
        self.batch_size = batch_size  # 一次性生成self.batch_size个样本
        self.temp_range = temp_range  # 随机温度区间
        self.file_lock = threading.Lock()
        self.model, self.url = API_DICT[model_name]["model"], API_DICT[model_name]["url"]
        self.api_obj = OpenAIStyleAPI(self.url)

        # prompt 框架
        self.system_prompt = """
        你是一个数据增强助手。现在我有一类用户问题数据，类别名称是【{label_name}】。
        这个类别的定义是：
        {label_definition}

        以下是该类别的一些真实示例：
        {examples}


        请你基于以上定义和示例，生成更多与该类别相关、但语句多样化的问题。
        要求：
        1. 保持问题属于该类别，不要生成跨类别的问题。
        2. 新的问题要尽量避免和示例重复。
        3. 表达方式要多样，可以换用不同的说法，但含义要一致。
        4. 生成 {num_samples} 条新的问题。
        输出一个 JSON 数组，每个元素是一个问题字符串。
        """

    def process_from_dict(self, label_name: str, output_path: str):
        """从 label_info 字典生成增强样本"""
        check_output_path(output_path)
        self.process_one_category(label_name, label_info[label_name], output_path)

        print(f"已成功生成增强数据到 '{output_path}'")

    def process_one_category(self, label_name, info, output_path):
        label_definition = info["def"]
        examples = info["examples"]
        num_samples = info["num"]

        example_text = "\n".join([f"{i+1}. {ex}" for i, ex in enumerate(examples)])

        total_samples = set()  # 用 set 去重
        rounds = (num_samples + self.batch_size - 1) // self.batch_size  # 批次数

        # 显示批次进度条
        with tqdm(total=rounds, desc=f"{label_name} 批次进度", leave=False) as pbar:
            for i in range(rounds):
                need_num = min(self.batch_size, num_samples - len(total_samples))
                sys_prompt = self.system_prompt.format(
                    label_name=label_name,
                    label_definition=label_definition,
                    examples=example_text,
                    num_samples=need_num
                )

                # 每次随机温度
                temperature = round(random.uniform(*self.temp_range), 2)
                prompt = [{"role": "system", "content": sys_prompt}]
                answer = self.api_obj.v1_chat_completions(self.model, prompt, temperature=temperature)

                try:
                    new_samples = json.loads(answer)
                except:
                    try:
                        answer = answer.replace("json", "").replace("`", "").strip()
                        new_samples = json.loads(answer)
                    except:
                        print(f"解析失败, 模型回复:{answer}")
                        new_samples = []

                # 加入 set 去重
                total_samples.update(new_samples)

                # 更新批次进度条
                pbar.update(1)

                # 如果已经够了可以提前结束
                if len(total_samples) >= num_samples:
                    break

        result_list = [{"类别名称": label_name,
                        "生成样本": sample} for sample in total_samples]

        self.save_result(output_path, result_list)

    def save_result(self, output_path, result_list):
        with self.file_lock:
            fieldnames = ["类别名称", "生成样本"]
            file_exists = os.path.isfile(output_path) and os.path.getsize(output_path) > 0
            with open(output_path, "a", encoding="utf-8", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter="\t")
                if not file_exists:
                    writer.writeheader()
                writer.writerows(result_list)


# --- 使用示例 ---
if __name__ == "__main__":
    model_name = 'deepseek-v3'  # 调用的LLM
    obj = LLMDataAugmentor(model_name, batch_size=20, temp_range=(0.6, 1.0))

    label_name = "通用知识"  # 想让LLM生成这个分类的样本
    output_path = f"{AUGMENT_DIR}/LLM_aug/{AUGMENT_VERSION}_{label_name}.tsv"
    obj.process_from_dict(label_name, output_path)

# python -m search.qa_bot.service_bot_relevance.query_bert.step1_data_aug_llm
