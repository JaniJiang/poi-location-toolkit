import os
import json
import csv
import re
import threading
import pandas as pd
from loguru import logger
from tqdm import tqdm
from joblib import Parallel, delayed
from utils.file_utils import check_output_path
from utils.llm_utils.openai_style_api import OpenAIStyleAPI
from search.qa_bot.service_bot_relevance.query_bert.meta import *
from search.qa_bot.service_bot_relevance.query_bert.qwen3.data_trans_qwen3 import label_dict, system_text, instruction_text

API_DICT = {
    "qwen3": {
        "model": "qa-bot-query-qwen3",
        "url": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/qa-bot-query-qwen3-d490-bijqmf/v1/chat/completions",
    },
    "qwen3_local": {
        "model": "data/cloud_share/qabot_relevance_model/bert_model/qwen3-1.7/v1-20250823-004735/checkpoint-1990-merged",
        "url": "http://0.0.0.0:8000/v1/chat/completions",
    }
}


class EvalTextClassification:
    def __init__(self, env):
        self.env = env
        self.model = API_DICT[env]["model"]
        self.url = API_DICT[env]["url"]
        self.api_obj = OpenAIStyleAPI(self.url)
        self.file_lock = threading.Lock()
        self.n_jobs = 10 

    def process(self, input_path, output_path):
        check_output_path(output_path)

        df = pd.read_csv(input_path, sep="\t")  # 数据有 text, label_ch, 来源

        Parallel(n_jobs=self.n_jobs, prefer="threads")(
            delayed(self.process_one)(row, output_path)
            for _, row in tqdm(df.iterrows(), total=len(df))
        )

    def process_one(self, row, output_path):
        text = row["text"]
        label_ch = row["label_ch"]
        source = row["来源"]

        # 构造输入 prompt
        messages = [
            {"role": "system", "content": system_text},
            {"role": "user", "content": f"{instruction_text}\n{text} + '/no_think'"}
        ]

        try:
            pred_str = self.api_obj.v1_chat_completions(self.model, messages, temperature=0)
        except Exception as e:
            logger.error(f"接口调用失败: {e}")
            return

        query_label = self.parse_pred(pred_str)
        if query_label is None:
            logger.warning(f"无法解析模型输出: {pred_str}")
            return

        # 将模型输出的标准类别 映射回 label_dict 的key（简写形式）
        label_model = None
        for k, v in label_dict.items():
            if v == query_label:
                label_model = k
                break
        if label_model is None:
            label_model = "其他问题"  # 兜底

        result_list = [{
            "text": text,
            "label_ch": label_ch,
            "label_model": label_model,
            "来源": source
        }]
        self.save_result(output_path, result_list)

    def parse_pred(self, pred_str):
        try:
            # 先尝试用正则找 {"query_label": "..."} 这一段
            match = re.search(r'\{[^{}]*"query_label"\s*:\s*"([^"]+)"[^{}]*\}', pred_str)
            if match:
                return match.group(1).strip()

            # 如果没匹配到，就尝试从 </think> 之后截取
            if "</think>" in pred_str:
                json_part = pred_str.split("</think>")[-1].strip()
            else:
                json_part = pred_str.strip()

            # 再尝试直接 json.loads
            data = json.loads(json_part)
            if isinstance(data, dict) and "query_label" in data:
                return data["query_label"].strip()

        except Exception as e:
            logger.warning(f"模型输出解析失败: {e}")
            logger.warning(f"模型原始输出: {pred_str}")

        return None

    def save_result(self, output_path, result_list):
        with self.file_lock:
            fieldnames = result_list[0].keys()
            file_exists = os.path.isfile(output_path) and os.path.getsize(output_path) > 0
            with open(output_path, "a", encoding="utf-8", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter="\t")
                if not file_exists:
                    writer.writeheader()
                writer.writerows(result_list)


if __name__ == "__main__":
    env = "qwen3"

    input_path = f"{EVAL_DIR}/source/20250818.tsv"
    output_path = f"{EVAL_DIR}/result/20250818_qwen3.tsv"

    eval_obj = EvalTextClassification(env)
    eval_obj.process(input_path, output_path)

# python -m search.qa_bot.service_bot_relevance.query_bert.qwen3.test_qwen3
