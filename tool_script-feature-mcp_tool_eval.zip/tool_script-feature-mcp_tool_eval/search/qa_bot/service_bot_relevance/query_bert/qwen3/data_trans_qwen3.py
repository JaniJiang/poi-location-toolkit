import json
import pandas as pd
from typing import Optional
from search.qa_bot.service_bot_relevance.query_bert.meta import *

label_dict = {
    "整车介绍": "理想汽车整车介绍",
    "车辆功能": "车辆功能咨询",
    "功能步骤": "功能使用咨询",
    "专有知识": "理想汽车专有知识",
    "状态查询": "汽车软硬件实时信息",
    "故障诊断": "故障咨询",
    "健康查询": "用车建议",
    "充电网络": "理想充电桩/站",
    "售前问题": "售前问题",
    "售后维保": "售后问题",
    "通用知识": "通用知识",
    "其他问题": "其他问题"
}

# 定义system和instruction
system_text = """你是一个文本分类模型，你需要将输入文本分类到以下 12 个类别之一：
1. 理想汽车整车介绍：文本想从整车宏观角度上来了解理想的某款汽车（未指代车型默认为理想汽车）
2. 车辆功能咨询：文本想了解该车是否具备某种功能
3. 功能使用咨询：文本想了解如何使用某一项功能
4. 理想汽车专有知识：文本所提问的问题与理想汽车高度挂钩（比如问某个硬件位置等）
5. 汽车软硬件实时信息：文本提问某个硬件当前所处状态，或是软件信息（如wifi密码和车机更新内容）
6. 故障咨询：文本对于车辆异常状态的咨询
7. 用车建议：文本意图为想了解如何更健康的使用车辆
8. 理想充电桩/站：文本咨询与理想充电桩或者充电站的相关问题
9. 售前问题：文本为购买理想汽车前所可能涉及到的购买问题
10. 售后问题：文本为购买理想汽车后关于售后服务方面的问题
11. 通用知识：文本为与汽车相关的问题，但是该问题答案所有汽车通用
12. 其他问题：文本与汽车无关，或是问了非理想汽车品牌其他品牌汽车的问题，或是在做不通车型之间比较
返回格式: {"query_label": "<类别名称>"}
"""
instruction_text = "请阅读输入文本并返回JSON格式的分类标签"


class TSV2Alpaca:
    def __init__(self, system_prompt: str, instruction: str):
        """
        :param system_prompt: 固定的 system 字符串
        :param instruction: 固定的 instruction 字符串
        """
        self.system_prompt = system_prompt
        self.instruction = instruction

    def convert(self, tsv_path: str, output_json_path: str, text_col: str = "text",
                label_col: str = "label_ch", encoding: str = "utf-8"):
        """
        读取TSV并转换为Alpaca格式

        :param tsv_path: 输入TSV文件路径
        :param output_json_path: 输出 JSON 格式的文件路径（JSONL，每行一条数据）
        :param text_col: TSV中文本列列名
        :param label_col: TSV中标签列列名
        :param encoding: 文件编码
        """
        # 读取TSV
        df = pd.read_csv(tsv_path, sep="\t", encoding=encoding)

        # 检查列是否存在
        if text_col not in df.columns or label_col not in df.columns:
            raise ValueError(f"TSV 文件缺少必要列: {text_col} 或 {label_col}")

        results = []

        for _, row in df.iterrows():
            query_input = str(row[text_col]).strip()
            label_value = str(row[label_col]).strip()

            label_value = label_dict[label_value]
            # 把label用{"query_label": "<label_ch>"}的形式放到response
            response_obj = {"query_label": label_value}

            record = {
                "system": self.system_prompt,
                "instruction": self.instruction,
                "input": query_input + "/no_think",
                "output": "<think>\n\n</think>\n" + json.dumps(response_obj, ensure_ascii=False)
            }
            results.append(record)

        # 写入 JSONL
        with open(output_json_path, "w", encoding="utf-8") as f:
            for record in results:
                f.write(json.dumps(record, ensure_ascii=False) + "\n")

        print(f"已成功转换 {len(results)} 条数据到 {output_json_path}")


if __name__ == "__main__":
    converter = TSV2Alpaca(system_prompt=system_text,
                           instruction=instruction_text)

    # 转换数据
    converter.convert(
        tsv_path=f"{SAMPLE_DIR}/source/{SAMPLE_VERSION}.tsv",
        output_json_path=f"{SAMPLE_DIR}/processed/alpaca_train.jsonl",
        text_col="text",
        label_col="label_ch"
    )

# python -m search.qa_bot.service_bot_relevance.query_bert.qwen3.data_trans_qwen3
