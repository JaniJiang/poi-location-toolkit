# 基座模型
BASE_MODEL_DIR = "data/cloud_share/qabot_miner/bert_model/model/base_model/bert-base-chinese"
ROBERTA_MODEL_DIR = "data/cloud_share/qabot_miner/roberta_model/chinese-roberta-wwm-ext"

# 数据集
SAMPLE_DIR = "data/cloud_share/qabot_relevance_data/bert_data/train"
SAMPLE_VERSION = "20250902"

# 数据增强
AUGMENT_DIR = "data/cloud_share/qabot_relevance_data/bert_data/augment"  # 文件夹
AUGMENT_VERSION = "20250826"  # 标注一下哪一天增强的样本

# 模型训练
EPOCHS = 20
MODEL_OUTPUT = "data/cloud_share/qabot_relevance_model/bert_model"
MODEL_VERSION = "20250902-roberta"

# eval
EVAL_DIR = "data/cloud_share/qabot_relevance_data/bert_data/eval"
EVAL_DATA_VERSION = "v2"
# EVAL_MODEL_VERSION = "20250826-roberta"
# EVAL_QWEN3_MODEL_VERSION = "20250825"


# 类别编号
label2id = {
    "语义不明": 0,
    "整车介绍": 1,
    "故障诊断": 2,
    "车辆功能": 3,
    "状态查询": 4,
    "健康查询": 5,
    "功能步骤": 6,
    "充电网络": 7,
    "售前售后": 8,
    "专有知识": 9,
    "汽车行业专有知识": 10,
    "汽车行业通用知识": 11,
    "其他问题": 12
}

id2label = {
    0: "语义不明",
    1: "整车介绍",
    2: "故障诊断",
    3: "车辆功能",
    4: "状态查询",
    5: "健康查询",
    6: "功能步骤",
    7: "充电网络",
    8: "售前售后",
    9: "专有知识",
    10: "汽车行业专有知识",
    11: "汽车行业通用知识",
    12: "其他问题"
}
