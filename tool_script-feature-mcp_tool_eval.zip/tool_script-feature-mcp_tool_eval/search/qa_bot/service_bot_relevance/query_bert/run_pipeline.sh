#!/bin/bash
# bash search/qa_bot/service_bot_relevance/query_bert/run_pipeline.sh

# 数据处理
python -m search.qa_bot.service_bot_relevance.query_bert.data_process

# 数据划分
python -m search.qa_bot.service_bot_relevance.query_bert.data_splitter

# 训练
python -m search.qa_bot.service_bot_relevance.query_bert.step1_train
echo "step1_train done"

# 导出为onnx
python -m search.qa_bot.service_bot_relevance.query_bert.step2_export_onnx
echo "step2_export_onnx done"

# 测试推理
# python -m search.qa_bot.service_bot_relevance.query_bert.step3_onnx_infer
# echo "step3_onnx_infer done"

# 预测样本
python -m search.qa_bot.service_bot_relevance.query_bert.step4_predict_sample
echo "step4_predict_sample done"
