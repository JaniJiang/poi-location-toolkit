'''
用于给测试集标注label
'''

import pandas as pd
from search.qa_bot.service_bot_relevance.query_bert.meta import *
from search.qa_bot.service_bot_intent.step3_onnx_infer import onnx_inference

def main(save_onnx_model_path: str, test_dataset_path: str, output_path: str):
    df = pd.read_csv(test_dataset_path, sep='\t')
    texts = df.iloc[:, 0].tolist()
    
    predictions = onnx_inference(ROBERTA_MODEL_DIR, save_onnx_model_path, texts)

    result_df = pd.DataFrame(columns=['text', 'pred_label', 'pred_prob'])
    for text, pred_label, pred_prob, _ in predictions:
        result_df.loc[len(result_df)] = [
            text, 
            id2label[pred_label], 
            round(pred_prob, 4)
        ]
    result_df.to_csv(output_path, sep='\t', index=False)


if __name__ == '__main__':
    save_onnx_model_path = f"{MODEL_OUTPUT}/{MODEL_VERSION}/bert_model.onnx"  # onnx模型存放路径

    # 测试集
    # test_dataset_path = f"{EVAL_DIR}/source/{EVAL_DATA_VERSION}.tsv"  # 待标注label测试集
    # output_path = f"{EVAL_DIR}/result/{EVAL_DATA_VERSION}.tsv"  # 结果路径

    test_dataset_path = "data/cloud_share/qabot_relevance_data/bert_data/augment/aug_samples.tsv"
    output_path = "data/cloud_share/qabot_relevance_data/bert_data/augment/aug_samples.tsv"
    
    main(save_onnx_model_path, test_dataset_path, output_path)

# python -m search.qa_bot.service_bot_relevance.query_bert.make_label
