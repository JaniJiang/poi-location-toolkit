import os
import ast
import random
import pandas as pd
from utils.llm_utils.serverless_function import *
from search.qa_bot.service_bot_relevance.query_bert.meta import *

'''
可选模型：
gpt-4o
deepseek-r1-distill-qwen-32b
deepseek-v3
deepseek-r1
'''

# 这个prompt用于解决悬架问题
# PROMPT = '''
# 我需要训练一个分类模型，这个分类模型能够区分用户query的类别。
# 我现在已经定义好了一个类别，类别名称是“理想汽车悬架问题”。
# 我需要你根据已知的信息，构造一批类似的样本。
# 已知信息：
# 1. 理想汽车可以设置这么几个和悬架相关的东西：动力模式、魔毯空气悬架、舒适度、悬架高度。
# 2. 动力模式分为：后排舒适、舒适、标准、运动、高性能；魔毯空气悬架可以分为：舒适魔毯、运动魔毯；舒适度可以分为：舒适、标准、运动；悬架高度可以分为：舒适、标准、运动。
# 请你根据已知信息，生成若干与理想汽车悬架相关的问题，语句尽可能的多样化。
# 要求：
# 1. 保持问题属于该类别，不要生成跨类别的问题。
# 2. 新的问题要尽量避免和示例重复。
# 3. 表达方式要多样，可以换用不同的说法。
# 4. 用户的query基本上围绕相关功能的介绍、使用等等。
# 5. 生成{sample_num}条新的中文query。
# 输出一个json数组，其中每个元素是一条query，除了json数组，不要输出其他内容。
# '''

# 这个prompt用于解决和其他品牌车辆相关的问题
# PROMPT = '''
# 我需要训练一个分类模型，这个分类模型能够区分用户query的类别。
# 我现在已经定义好了一个类别，类别名称是“其他品牌问题”。
# 我需要你根据已知的信息，构造一批类似的样本。
# 已知信息：
# 1. 我们品牌的名称是“理想汽车”。
# 要求：
# 1. 我需要你生成若干与其他品牌相关的问题。
# 2. 问题可以包括但不限于：
#     (1)介绍某款汽车。
#     (2)某款汽车是否有某某功能。
#     (3)某某品牌有哪些车型。
#     (4)某款车的价格、历史最低价。
#     (5)某款车型的参数，比如车长多少米，车宽多少米等等。
# 3. 问题要包含具体的品牌名称，除了理想汽车，其他品牌都可以。
# 4. 保持问题属于该类别，不要生成跨类别的问题。
# 5. 新的问题要尽量避免和示例重复。
# 6. 表达方式要多样，可以换用不同的说法。
# 7. 生成{sample_num}条新的中文query。
# 输出一个json数组，其中每个元素是一条query，除了json数组，不要输出其他内容。
# '''

# 这个prompt用于解决满电续航问题
# PROMPT = '''
# 我需要训练一个分类模型，这个分类模型能够区分用户query的类别。
# 我现在已经定义好了一个类别，类别名称是“满电续航问题”。
# 我需要你根据已知的信息，构造一批类似的样本。
# 已知信息：
# 1. 这个问题涉及到的品牌是“理想汽车”。
# 要求：
# 1. 你生成的样本中50%不包含品牌名称，20%包含“理想”这个品牌名称，30%包含“理想汽车”某个具体的车型。
# 2. 问题的主要内容是，当前车辆（或者某个具体的车型）充满电续航大概多久。
# 3. 保持问题属于该类别，不要生成跨类别的问题。
# 4. 新的问题要尽量避免和示例重复。
# 5. 表达方式要多样，可以换用不同的说法。
# 6. 生成{sample_num}条新的中文query。
# query示例：
# 1. 充满电最长续航是多少
# 2. l七充满电能跑多少公里
# 3. l9满电状态下最长能跑多少
# 4. 理想l六充满电可以走多少公里
# 5. 充满电可跑多少
# 输出一个json数组，其中每个元素是一条query，除了json数组，不要输出其他内容。
# '''

# 这个prompt用于同义改写
PROMPT = '''
我需要你对以下query进行同义改写。
原query：手势交互怎么使用
改写要求:
1. 生成的中文query与原query相似，但表达形式更加多样化。
2. 生成的中文query中不要有标点符号
3. 新的问题要尽量避免和示例重复。
4. 你要站在用户的角度，想一想用户在车机系统上会用什么样的方式来表达这种问题。
5. 生成{sample_num}条新的中文query。
输出一个json数组，其中每个元素是一条query，除了json数组，不要输出其他内容。
'''

SAMPLE_NUM = 15  # 一共需要增强的样本数
OUTPUT_PATH = os.path.join(AUGMENT_DIR, 'aug_samples.tsv')  # 样本存放路径
MAX_BATCH_SIZE = 25  # LLM单次生成的样本数

class sample_augmentor:
    def __init__(self, model_name="gpt-4o", temp_range=(0.6, 1.0)):
        self.model_name = model_name
        self.temp_range = temp_range
    def func(self, sample_num, output_path):
        error_num = 0
        sample_set = set()
        while sample_num > len(sample_set):  # sample_num是接下来还需要增强的样本数
            try:
                # 1. 使用LLM生成内容
                batch_size = MAX_BATCH_SIZE  # 本次需要增强的样本数
                prompt = PROMPT.format(sample_num=batch_size)
                history = ["你是一个数据增强助手。", prompt]
                temp = round(random.uniform(self.temp_range[0], self.temp_range[1]), 2)
                _, response_data = request_llm(history, model=self.model_name, n=1, temperature=temp)
                content = response_data['choices'][0]['message']['content']
                
                # 2. 提取列表
                start_idx = content.find('[')
                end_idx = content.find(']')
                list_str = content[start_idx: end_idx + 1]
                data_list = ast.literal_eval(list_str)
                for item in data_list:
                    sample_set.add(item)
                    if sample_num == len(sample_set):
                        break

                print(f"成功得到{len(sample_set)}条数据。")
            except KeyboardInterrupt:
                print("\n检测到人为中断，程序退出。")
                break
            except Exception as e:
                print(f'发生异常：{e}')
                error_num += 1
                print(f"Error num: {error_num}")
        df = pd.DataFrame(list(sample_set), columns=["text"])
        df.to_csv(output_path, sep='\t', index=False, encoding="utf-8")
        print("数据保存成功。")
        
if __name__ == '__main__':
    aug = sample_augmentor()
    aug.func(sample_num=SAMPLE_NUM, output_path=OUTPUT_PATH)

# python -m search.qa_bot.service_bot_relevance.query_bert.step1_LLM_sample_aug

