'''
此.py文件用于同步两个表格。
'''

import pandas as pd
from openpyxl import load_workbook
import os

# 正确的样本在correct_samples的AB列中，待修改的样本在original_samples的AB列中
FILE_PATH = './sample_revision.xlsx'

# 处理正确的样本
correct_samples_df = pd.read_excel(FILE_PATH, sheet_name='correct_samples')
cor_sam_dict = {}
for i in range(len(correct_samples_df)):
    print(f'\rReading correct samples: {i + 1}/{len(correct_samples_df)}', end='')
    cor_sam_dict[correct_samples_df.iloc[i, 0]] = correct_samples_df.iloc[i, 1]
print('')

# 对原始样本进行修改
original_samples_df = pd.read_excel(FILE_PATH, sheet_name='original_samples')
for i in range(len(original_samples_df)):
    print(f'\rRevising original samples: {i + 1}/{len(original_samples_df)}', end='')
    if original_samples_df.iloc[i, 0] in cor_sam_dict:
        original_samples_df.iloc[i, 1] = cor_sam_dict[original_samples_df.iloc[i, 0]]
print('')

# 将修改后的样本写入到原.xlsx文件的新表格中
with pd.ExcelWriter(FILE_PATH, engine='openpyxl', mode='a', if_sheet_exists="new") as writer:
    original_samples_df.to_excel(writer, index=False, sheet_name='revised_samples')


