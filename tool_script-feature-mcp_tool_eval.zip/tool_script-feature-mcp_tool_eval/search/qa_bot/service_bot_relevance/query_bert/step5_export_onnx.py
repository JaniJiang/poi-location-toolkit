'''
.bin模型导出为.onnx模型，路径不发生改变，导入到原路径下
'''

import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification
from search.qa_bot.service_bot_intent.step2_export_onnx import device
from search.qa_bot.service_bot_relevance.query_bert.meta import *


def export_onnx(base_model_dir, save_model_path, save_onnx_model_path, max_len=128):
    # 加载保存的模型权重
    model = AutoModelForSequenceClassification.from_pretrained(base_model_dir, num_labels=13)
    model.load_state_dict(torch.load(save_model_path, map_location=device))
    model.to(device)
    model.eval()
    tokenizer = AutoTokenizer.from_pretrained(base_model_dir)
    # 定义输入示例
    dummy_text = "这是一个示例文本。"
    encoding = tokenizer.encode_plus(
        dummy_text,
        add_special_tokens=True,
        max_length=max_len,
        truncation=True,
        padding="max_length",
        return_attention_mask=True,
        return_tensors="pt",
    )
    input_ids = encoding["input_ids"].to(device)
    attention_mask = encoding["attention_mask"].to(device)
    # ONNX导出
    input_names = ["input_ids", "attention_mask"]
    output_names = ["output"]
    dynamic_axes = {"input_ids": {0: "batch_size"},
                    "attention_mask": {0: "batch_size"},
                    "output": {0: "batch_size"}}
    torch.onnx.export(
        model,
        (input_ids, attention_mask),
        save_onnx_model_path,
        input_names=input_names,
        output_names=output_names,
        dynamic_axes=dynamic_axes,
        opset_version=14
    )
    print(f"Model has been exported to {save_onnx_model_path}")


if __name__ == "__main__":
    save_model_path = f"{MODEL_OUTPUT}/{MODEL_VERSION}/best_model_state.bin"
    save_onnx_model_path = f"{MODEL_OUTPUT}/{MODEL_VERSION}/bert_model.onnx"
    # 基座模型: BASE_MODEL_DIR, ROBERTA_MODEL_DIR
    export_onnx(ROBERTA_MODEL_DIR, save_model_path, save_onnx_model_path)

# python -m search.qa_bot.service_bot_relevance.query_bert.step5_export_onnx
