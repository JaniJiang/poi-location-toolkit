import pandas as pd
from search.qa_bot.service_bot_relevance.query_bert.meta import *

class LabelMapper:
    def convert_file(self, input_path, output_path):
        # 读取原始TSV文件
        df = pd.read_csv(input_path, sep="\t")

        # 映射label_ch -> new_label
        df["new_label"] = df["label_ch"].map(label2id)

        # 检查是否有未映射成功的
        if df["new_label"].isnull().any():
            missing_labels = df[df["new_label"].isnull()]["label_ch"].unique()
            print(f"警告：以下标签没有映射成功: {missing_labels}")

        # 保存为新的TSV文件
        df.to_csv(output_path, sep="\t", index=False)
        print(f"转换完成，已保存到: {output_path}")


# 使用示例
if __name__ == "__main__":
    # input_path = f"{SAMPLE_DIR}/source/{SAMPLE_VERSION}.tsv"
    # output_path = f"{SAMPLE_DIR}/processed/{SAMPLE_VERSION}_unsplit.tsv"
    # mapper = LabelMapper()
    # mapper.convert_file(input_path, output_path)

    '''
    针对原始的训练集和测试集，根据样本的类别，标注类别对应的索引值
    '''
    train_path = f"{SAMPLE_DIR}/processed/{SAMPLE_VERSION}.tsv"
    eval_path = f"{EVAL_DIR}/source/{EVAL_DATA_VERSION}.tsv"
    mapper = LabelMapper()
    mapper.convert_file(train_path, train_path)
    # mapper.convert_file(eval_path, eval_path)

# python -m search.qa_bot.service_bot_relevance.query_bert.step2_data_process
