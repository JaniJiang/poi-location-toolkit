'''
此.py文件用于检查.xlsx文件中，同样的query是否会对应不同的label。
query放在A列，label放在B列。
错误的样本会存放在原.xlsx文件的新表格中，sheet_name见全局变量SHEET_NAME。
'''

import pandas as pd
from openpyxl import load_workbook
import os

FILE_PATH = './sample.xlsx'  # 文件路径
COLUMNS_NAME = 'error_samples'  # 错误query对应的列名
SHEET_NAME = 'error_samples'  # 错误query存放的表格名

df = pd.read_excel(FILE_PATH, sheet_name='total_samples')

sample_dict = {}  # 存放遍历过的样本
error_set = set()  # 存放存在问题的error

for i in range(len(df)):
    print(f"\r{i + 1}/{len(df)}", end="")
    if df.iloc[i, 0] in sample_dict:  # 这条样本已经出现过
        if df.iloc[i, 1] == sample_dict[df.iloc[i, 0]]:
            continue
        else:
            error_set.add(df.iloc[i, 0])
    else:
        sample_dict[df.iloc[i, 0]] = df.iloc[i, 1]
print("")

error_df = pd.DataFrame(list(error_set), columns=[COLUMNS_NAME])
with pd.ExcelWriter(FILE_PATH, engine="openpyxl", mode="a", if_sheet_exists="new") as writer:
    error_df.to_excel(writer, index=False, sheet_name=SHEET_NAME)




