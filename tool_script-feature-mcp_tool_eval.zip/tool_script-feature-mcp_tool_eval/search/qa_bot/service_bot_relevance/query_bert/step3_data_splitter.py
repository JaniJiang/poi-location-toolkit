'''
用于将xxx_unsplit.tsv文件（全部数据集）分割成训练集和测试集，分别放在指定路径下
'''

import pandas as pd
from search.qa_bot.service_bot_relevance.query_bert.meta import *
from sklearn.model_selection import train_test_split


class StratifiedDataSplitter:
    """
    一个用于对TSV文件进行分层抽样，并将数据集划分为训练集和测试集的类。
    """

    def __init__(self, input_file_path, train_output_path, test_output_path, test_size=0.2, random_state=42):
        """
        初始化数据集划分器。

        Args:
            input_file_path (str): 原始TSV文件的路径。
            train_output_path (str): 训练集保存的TSV文件路径。
            test_output_path (str): 测试集保存的TSV文件路径。
            test_size (float, optional): 测试集占总样本的比例。默认为0.2 (20%)。
            random_state (int, optional): 随机数种子，用于保证每次划分结果一致。默认为42。
        """
        self.input_file_path = input_file_path
        self.train_output_path = train_output_path
        self.test_output_path = test_output_path
        self.test_size = test_size
        self.random_state = random_state

    def _load_data(self):
        """加载数据并进行基本验证。"""
        print(f"正在加载文件: {self.input_file_path}...")
        try:
            df = pd.read_csv(self.input_file_path, sep='\t', encoding='utf-8')
            if 'text' not in df.columns or 'new_label' not in df.columns:
                raise ValueError("TSV文件必须包含 'text' 和 'new_label' 两列。")
            return df
        except FileNotFoundError:
            raise FileNotFoundError(f"错误: 找不到文件 {self.input_file_path}。请检查文件路径是否正确。")

    def split_and_save(self):
        """执行分层抽样，并保存训练集和测试集。"""
        try:
            df = self._load_data()

            print(f"原始数据集大小: {len(df)} 条")
            print("原始类别分布:\n", df['new_label'].value_counts(normalize=True))

            # 使用分层抽样划分整个 DataFrame
            train_df, test_df = train_test_split(
                df,
                test_size=self.test_size,
                random_state=self.random_state,
                stratify=df['new_label']  # 以 new_label 为分层依据
            )

            print(f"训练集大小: {len(train_df)} 条")
            print(f"测试集大小: {len(test_df)} 条")

            # 保存为新的TSV文件（保留所有列）
            print(f"\n正在保存训练集到: {self.train_output_path}...")
            train_df.to_csv(self.train_output_path, sep='\t', index=False, encoding='utf-8')

            print(f"正在保存测试集到: {self.test_output_path}...")
            test_df.to_csv(self.test_output_path, sep='\t', index=False, encoding='utf-8')

            print("\n数据集划分并保存成功!")
            print("---------------------------------------")
            print("训练集类别分布:\n", train_df['new_label'].value_counts(normalize=True))
            print("\n测试集类别分布:\n", test_df['new_label'].value_counts(normalize=True))

        except (FileNotFoundError, ValueError) as e:
            print(f"操作失败: {e}")
        except Exception as e:
            print(f"发生未知错误: {e}")


if __name__ == "__main__":
    input_tsv = f'{SAMPLE_DIR}/processed/{SAMPLE_VERSION}_unsplit.tsv'       # 原始文件
    train_tsv = f'{SAMPLE_DIR}/processed/{SAMPLE_VERSION}.tsv'        # 训练集保存路径（其中包含了验证集）
    test_tsv = f'{EVAL_DIR}/source/{EVAL_DATA_VERSION}.tsv'        # 测试集保存路径
    test_split_ratio = 0.1            # 测试集比例 (20%)
    seed = 42                         # 随机种子

    splitter = StratifiedDataSplitter(
        input_file_path=input_tsv,
        train_output_path=train_tsv,
        test_output_path=test_tsv,
        test_size=test_split_ratio,
        random_state=seed
    )
    splitter.split_and_save()

# python -m search.qa_bot.service_bot_relevance.query_bert.step3_data_splitter
