import onnxruntime
import numpy as np
from tqdm import tqdm
from transformers import BertTokenizer
from search.qa_bot.service_bot_intent.step3_onnx_infer import onnx_inference
from search.qa_bot.service_bot_relevance.query_bert.meta import *
import pandas as pd
from typing import List

def test_prediction(skipped_label: List[int], if_output_result: bool, detail_idx: List[int]):
    save_onnx_model_path = f"{MODEL_OUTPUT}/{MODEL_VERSION}/bert_model.onnx"  # onnx模型存放路径
    test_dataset_path = f"{EVAL_DIR}/source/{EVAL_DATA_VERSION}.tsv"  # 测试集存放路径
    result_path = f"{EVAL_DIR}/result/{EVAL_DATA_VERSION}.tsv"  # 最终结果存放路径

    test_dataset_df = pd.read_csv(test_dataset_path, sep='\t')  # 读取测试集.tsv文件
    queries = test_dataset_df.iloc[:, 0].tolist()  # 得到text列表
    
    predictions = onnx_inference(ROBERTA_MODEL_DIR, save_onnx_model_path, queries)  # 全部的预测数据

    if if_output_result:
        # 结果存放在result_df中
        result_df = pd.DataFrame(columns=["text", "true_label", "pre_label", "is_correct", "true_label_prob", "wrong_label_prob", "diff"])
        label_acc = [0] * 13  # 记录每个类别预测正确的次数
        label_nums = [0] * 13  # 记录每个类别出现的次数
        for idx, (text, pred_label, pred_prob, probs) in tqdm(
            enumerate(predictions), 
            desc="导出结果中", 
            total=len(predictions)
        ):
            label_nums[test_dataset_df.iloc[idx, -1]] += 1
            is_correct = None
            if test_dataset_df.iloc[idx, 1] == id2label[pred_label]:  # 预测正确
                is_correct = "right"
                label_acc[pred_label] += 1
                true_label_prob = round(float(probs[0][test_dataset_df.iloc[idx, -1]]), 4)  # 预测正确标签的概率
                wrong_label_prob = -1  # 这个值不存在
                diff = -1  # 这个值不存在
            else:
                is_correct = "wrong"
                true_label_prob = round(float(probs[0][test_dataset_df.iloc[idx, -1]]), 4)  # 预测正确标签的概率
                wrong_label_prob = round(pred_prob, 4)  # 预测错误标签的概率
                diff = round(wrong_label_prob - true_label_prob, 4)  # 预测错误的概率比正确的概率大多少
            result_df.loc[len(result_df)] = [
                text,  # 文本
                test_dataset_df.iloc[idx, 1],  # 真实类别（文字）
                id2label[pred_label],  # 预测分类（文字）
                is_correct,  # 是否预测正确
                true_label_prob,  # 预测正确标签的概率
                wrong_label_prob,  # 预测错误标签的概率
                diff  # 预测错误的概率比正确的概率大多少
            ]
        result_df.to_csv(result_path, sep='\t', index=False)  # 将结果存入.tsv文件中
        
        # 打印准确率
        print(f"总样本数：{len(test_dataset_df)}")
        print(f"预测正确样本数：{sum(label_acc)}")
        print(f"预测错误样本数：{len(test_dataset_df) - sum(label_acc)}")
        print(f"总准确率：{sum(label_acc) / len(test_dataset_df):.4f}")
        
        for i in range(len(label_acc)):
            if i in skipped_label:
                label_acc[i] = None
                continue
            label_acc[i] = round(label_acc[i] / label_nums[i], 4)
        print(f"各类别预测准确率：")
        for i in range(len(label_acc)):
            if i in skipped_label:
                continue
            print(f"{id2label[i]}: {label_acc[i]}")
    else:
        for id in detail_idx:
            print(f"id: {id}")
            print(f"text: {predictions[id - 2][0]}")
            print(f"classification of number: {predictions[id - 2][1]}")
            print(f"classification: {id2label[predictions[id - 2][1]]}")
            print(f"classification probability distribution: {predictions[id - 2][3]}", end='\n\n')


if __name__ == "__main__":
    # 测试代码
    # save_onnx_model_path = f"{MODEL_OUTPUT}/{MODEL_VERSION}/bert_model.onnx"
    # input_list = [
    #     ["请问如何更改手机的锁屏密码？", 12], 
    #     ["嗯车上自带的网络用完了吗", 4], 
    #     ["这个是什么车", 1]
    # ]
    # text_list = [item[0] for item in input_list]

    # predictions = onnx_inference(ROBERTA_MODEL_DIR, save_onnx_model_path, text_list)
    # print(type(predictions))
    # print(predictions[0], end='\n\n')
    # for idx, (text, pred_label, pred_prob, probs) in enumerate(predictions):
    #     print(f"idx：{idx}")
    #     print(f"文本：{text}")
    #     print(f"真实标签：{input_list[idx][1]}")
    #     print(f"预测标签：{pred_label}")  # 数字
    #     print(f"预测概率：{pred_prob}")  # float类型数据
    #     print(f"概率分布：{probs}")  # numpy array
    #     print("-" * 30)
    
    # 根据指定的模型、测试集，计算模型在测试集上的表现
    skipped_label = [0, 10]  # 跳过0、10分类
    if_output_result = True
    detail_idx = [11, 15]  # 飞书表格行号对应的样本，查看其细节
    test_prediction(skipped_label, if_output_result, detail_idx)

# python -m search.qa_bot.service_bot_relevance.query_bert.step6_onnx_infer
