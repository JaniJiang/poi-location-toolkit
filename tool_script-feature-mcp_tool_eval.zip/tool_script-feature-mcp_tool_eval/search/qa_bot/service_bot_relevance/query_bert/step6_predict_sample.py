import os
import pandas as pd
import numpy as np
from collections import defaultdict
from search.qa_bot.service_bot_intent.step3_onnx_infer import onnx_inference
from search.qa_bot.service_bot_relevance.query_bert.meta import *


def predict_for_eval(
    sample_path: str,
    predict_path: str,
    save_onnx_model_path: str,
    base_model_dir: str,
):
    """
    用于测试集上的推理，并打印总准确率与各类别准确率
    """
    os.makedirs(os.path.dirname(predict_path), exist_ok=True)

    # 读取样本数据
    df = pd.read_csv(sample_path, sep="\t", encoding="utf-8")
    data_list = df.to_dict("records")

    # 预测
    text_list = [item["text"] for item in data_list]
    predictions = onnx_inference(base_model_dir, save_onnx_model_path, text_list)

    # 类别统计
    class_total = defaultdict(int)
    class_correct = defaultdict(int)

    # 写入预测结果
    with open(predict_path, "w", encoding="utf-8") as f:
        f.write("text\ttrue_label\tpred_label\tis_accuracy\tpred_prob\tprobs\n")
        correct_predictions = 0
        total_predictions = len(predictions)

        for idx, (text, pred_label, pred_prob, probs) in enumerate(predictions):
            item = data_list[idx]
            true_label = item["new_label"]
            is_accuracy = int(true_label == pred_label)

            # 总体统计
            correct_predictions += is_accuracy

            # 类别统计
            class_total[true_label] += 1
            class_correct[true_label] += is_accuracy

            # 写文件
            true_label_str = f"{id2label[true_label]}({true_label})"
            pred_label_str = f"{id2label[pred_label]}({pred_label})"
            pred_prob_str = f"{pred_prob:.4f}"
            probs_str = np.array2string(probs, precision=4, separator=',', suppress_small=True)

            f.write(f'"{text}"\t{true_label_str}\t{pred_label_str}\t{is_accuracy}\t{pred_prob_str}\t"{probs_str}"\n')

    # 打印总体准确率
    accuracy = correct_predictions / total_predictions if total_predictions > 0 else 0
    print("-" * 50)
    print(f"总样本数: {total_predictions}")
    print(f"正确预测数: {correct_predictions}")
    print(f"预测准确率: {accuracy:.4f}")
    print("-" * 50)

    # 打印每个类别准确率
    print("各类别准确率:")
    class_acc_list = []
    for label_id, total in class_total.items():
        correct = class_correct[label_id]
        acc = correct / total if total > 0 else 0
        class_acc_list.append({"label_id": label_id, "label": id2label[label_id], "accuracy": acc, "total": total})
        print(f"{id2label[label_id]}({label_id}) -> {correct}/{total} = {acc:.4f}")


def predict_for_aug(
    sample_path: str,
    predict_path: str,
    save_onnx_model_path: str,
    base_model_dir: str,
):
    """
    用于数据增强上的推理
    """
    os.makedirs(os.path.dirname(predict_path), exist_ok=True)

    # 读取数据
    df = pd.read_csv(sample_path, sep="\t", encoding="utf-8")
    text_list = df["text"].tolist()

    # 预测
    predictions = onnx_inference(base_model_dir, save_onnx_model_path, text_list)

    # 写入结果
    with open(predict_path, "w", encoding="utf-8") as f:
        f.write("text\tpred_label\n")
        for text, pred_label, pred_prob, probs in predictions:
            pred_label_str = f"{id2label[pred_label]}({pred_label})"
            f.write(f'"{text}"\t{pred_label_str}\n')

    print(f"预测结果已保存到: {predict_path}")


if __name__ == "__main__":
    save_onnx_model_path = f"{MODEL_OUTPUT}/{MODEL_VERSION}/bert_model.onnx"
    # 预测-测试集
    sample_path = f"{EVAL_DIR}/source/{EVAL_DATA_VERSION}.tsv"
    predict_path = f"{EVAL_DIR}/result/data_{EVAL_DATA_VERSION[-4:]}_model_{EVAL_MODEL_VERSION[-4:]}.tsv"
    # 基座模型: BASE_MODEL_DIR, ROBERTA_MODEL_DIR
    predict_for_eval(sample_path, predict_path, save_onnx_model_path, ROBERTA_MODEL_DIR)

    # 预测-数据增强
    # aug_input = f"{AUGMENT_DIR}/bert_pred/source/{AUGMENT_VERSION}.tsv"
    # aug_output = f"{AUGMENT_DIR}/bert_pred/result/{AUGMENT_VERSION}.tsv"
    # predict_for_aug(aug_input, aug_output, save_onnx_model_path, BASE_MODEL_DIR)

    # python -m search.qa_bot.service_bot_relevance.query_bert.step6_predict_sample
