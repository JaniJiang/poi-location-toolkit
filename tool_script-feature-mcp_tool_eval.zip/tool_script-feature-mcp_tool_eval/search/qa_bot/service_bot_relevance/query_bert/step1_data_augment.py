import pandas as pd
from tqdm import tqdm
from search.qa_bot.service_bot_relevance.query_bert.meta import *
from search.qa_bot.qwen3_reranker.sample.retriever.step3_search_data import SearchData

num_dict = {
    "专有名词": 6,
    "健康查询": 2,
    "充电网络": 4,
    "售前问题": 2,
    "售后维保": 3,
    "整车介绍": 3,
    "通用知识": 2,
}


class DataAugmenter:
    def __init__(self):
        self.search_obj = SearchData()

    def read_tsv(self, input_tsv: str) -> pd.DataFrame:
        df = pd.read_csv(input_tsv, sep='\t')
        if not {"text", "label_ch"}.issubset(df.columns):
            raise ValueError("输入文件必须包含 'text' 和 'label_ch' 两列")
        return df

    def expand_category(self, df: pd.DataFrame) -> pd.DataFrame:
        label_counts = df['label_ch'].value_counts()
        print("各类别数量：\n", label_counts)

        expanded_rows = []

        for label, count in label_counts.items():
            if label in num_dict:
                log_size = num_dict.get(label, 2)
                subset_df = df[df['label_ch'] == label]
                for _, row in tqdm(subset_df.iterrows(), total=len(subset_df), desc=f"扩充类别 {label}"):
                    try:
                        search_result = self.search_obj.search(
                            row['text'],
                            log_size=log_size,
                            qa_size=200
                        )["qa_bot_log_data_v1"]

                        for item in search_result:
                            search_text = item.get("text_rewrite", "")
                            if search_text == row['text'] or search_text == "":
                                continue
                            expanded_rows.append({
                                "original_text": row['text'],
                                "text": search_text,
                                "label_ch": label
                            })

                    except Exception as e:
                        print(f"检索出错: {row['text']} - {e}")
        expanded_df = pd.DataFrame(expanded_rows)
        expanded_df.drop_duplicates(subset=["text", "label_ch"], inplace=True, ignore_index=True)
        return expanded_df

    def save_tsv(self, df: pd.DataFrame, output_tsv: str):
        df.to_csv(output_tsv, sep='\t', index=False)
        print(f"结果已保存到 {output_tsv}")

    def process(self, input_tsv: str, output_tsv: str):
        df = self.read_tsv(input_tsv)
        expanded_df = self.expand_category(df)
        self.save_tsv(expanded_df, output_tsv)


if __name__ == "__main__":
    processor = DataAugmenter()
    input_path = f"{AUGMENT_DIR}/human_reviewed/20250813.tsv"
    output_path = f"{AUGMENT_DIR}/search_result/{AUGMENT_VERSION}.tsv"
    processor.process(input_path, output_path)

# python -m search.qa_bot.service_bot_relevance.query_bert.step1_data_augment
