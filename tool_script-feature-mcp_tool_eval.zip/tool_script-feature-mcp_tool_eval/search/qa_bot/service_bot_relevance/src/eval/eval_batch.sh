# 批量评测(目录下的)模型效果
#!/bin/bash

# 定义模型文件夹路径
model_folder="../../../../../data/cloud_share/qabot_relevance_model/trained_model"

# 定义其他固定参数
tokenizer_dir="../../../../../data/cloud_share/qabot_relevance_model/model/bge-base-zh-v1.5"
eval_dataset_dir="../../../../../data/cloud_share/qabot_relevance_data/testset/v2/processed_dataset/in_car_assistant.csv"
output_json_base="../../../../../data/cloud_share/qabot_relevance_data/onxx_model_score/"
output_excel_base="../../../../../data/cloud_share/qabot_relevance_data/test_model_excel"
eval_time="20250701"
#!!!!!!!!!!!!!!!注意eval非onnx文件时设为false，onnx文件路径在eval.py中更改
eval_onnx="false"   

# 遍历模型文件夹中的所有文件
for model_file in "$model_folder"/*.bin; do
    model_dir="$model_file"
    model_version=$(basename "$model_file" .bin)  # 提取模型版本信息
    output_json="$output_json_base/${model_version}_score.json"
    output_excel="$output_excel_base/$model_version"

    # 构造命令
    command="python -u eval.py \
        --tokenizer_dir $tokenizer_dir \
        --model_dir $model_dir \
        --eval_dataset_dir $eval_dataset_dir \
        --output_json $output_json \
        --output_excel $output_excel \
        --eval_time $eval_time \
        --eval_onnx $eval_onnx"

    # 打印并执行命令
    echo "Running command for model: $model_dir"
    echo "$command"
    eval $command
    echo "Finished evaluating model: $model_dir"

done