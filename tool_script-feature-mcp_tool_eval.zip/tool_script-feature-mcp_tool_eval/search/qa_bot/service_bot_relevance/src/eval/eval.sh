model_dir="../../../../../data/cloud_share/qabot_relevance_model/workspace/v6.2_bge_base_qa_platform_710.bin_optimal_epoch"
tokenizer_dir="../../../../../data/cloud_share/qabot_relevance_model/model/bge-base-zh-v1.5"
eval_dataset_dir="../../../../../data/cloud_share/qabot_relevance_data/testset/v2/processed_dataset/20%/hard_case_autoqa.csv"

output_json_base="../../../../../data/cloud_share/qabot_relevance_data/onxx_model_score"
output_excel_base="../../../../../data/cloud_share/qabot_relevance_data/test_model_excel"

model_version=$(basename "$model_dir" .bin)
eval_onnx="true"
if [[ "$eval_onnx" == "true" ]]; then
    output_excel="$output_excel_base/online_onnx_model"
    output_json="$output_json_base/online_onnx_model_score.json"
else
    output_excel="$output_excel_base/$model_version"
    output_json="$output_json_base/${model_version}_score.json"
fi
echo $output_excel
python -u eval.py \
    --tokenizer_dir $tokenizer_dir \
    --model_dir $model_dir \
    --eval_dataset_dir $eval_dataset_dir \
    --output_json $output_json \
    --output_excel $output_excel \
    --onnx_dir "../../../../../data/cloud_share/qabot_relevance_model/online_onnx_model.onnx" \
    --eval_time "20250701" \
    --eval_onnx $eval_onnx

# --model_dir "../../../../../data/cloud_share/qabot_relevance_model/workspace/v2_bge_base_train_613_augmented_703.bin" \
# data/cloud_share/qabot_relevance_data/testset/v1/processed_dataset/badcase.csv
# --eval_dataset_dir "../../../../../data/cloud_share/qabot_relevance_data/testset/v2_human_labelled.tsv" \v1_test_badcase general_special_from_original_trainset
# 未返修v2_human_labelled
# nohup step1_eval.sh > ../../../../../data/cloud_share/qabot_relevance_model/log/v5_test_0703.log 2>&1 &
