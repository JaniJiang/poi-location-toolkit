# coding: utf-8
import os
import json
import numpy as np
import pandas as pd
from tqdm import tqdm
import argparse
import onnxruntime as ort
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from transformers import BertTokenizerFast

# ==============================
# 设置设备
# ==============================
os.environ['CUDA_VISIBLE_DEVICES'] = '0,1,2,3,4,5,6'
print("当前可见 GPU 数量：", len(os.environ["CUDA_VISIBLE_DEVICES"].split(',')))

# ==============================
# ONNX 二分类评估函数
# ==============================
# ==============================
# ONNX 二分类评估函数（增加设备打印）
# ==============================
def eval_binary_classification_onnx(sess, tokenizer, text_batch):
    # 编码文本
    encodings = tokenizer(
        text_batch["texts"], padding=True, truncation=True,
        max_length=128, return_tensors="np"
    )
    input_ids = encodings["input_ids"].astype(np.int64)
    attention_mask = encodings["attention_mask"].astype(np.int64)
    token_type_ids = encodings["token_type_ids"].astype(np.int64)
    
    targets = np.array([int(t) for t in text_batch["target"]])

    # ONNX 推理
    try:
        onnx_output = sess.run(
            ['output'],
            {
                'input_ids': input_ids,
                'attention_mask': attention_mask,
                'token_type_ids': token_type_ids
            }
        )
        provider_used = sess.get_providers()[0]  # 实际使用的 provider
    except Exception as e:
        print("### ONNX 推理出错，可能 fallback 到 CPU:", e)
        provider_used = "CPU (fallback)"

    # print(f"当前 batch 使用 provider: {provider_used}, batch_size={len(text_batch['texts'])}")

    logits = np.array(onnx_output[0])

    # softmax 概率
    exp_logits = np.exp(logits - np.max(logits, axis=1, keepdims=True))
    prob = exp_logits / np.sum(exp_logits, axis=1, keepdims=True)
    similarity_tensor = prob[:, 1]  # 正类概率

    # Cross-entropy loss
    eps = 1e-8
    ce_loss = -np.mean(np.log(prob[np.arange(len(targets)), targets] + eps))

    return ce_loss, similarity_tensor



# ==============================
# 流式评估
# ==============================
def eval_on_the_fly_onnx(sess, tokenizer, eval_dataset_dir, eval_batch_size=512, output_excel_path="output.xlsx"):
    text_list, label_list, type_list, pred_list = [], [], [], []
    final_label_list, final_text_list = [], []
    count = batch_id = total_loss = 0

    label2tensor = {"0": 0, "1": 1}

    # ==============================
    # 用 pandas 读取数据并清洗 label
    # ==============================
    df = pd.read_csv(
        eval_dataset_dir,
        sep='\t',
        header=None,
        dtype=str,           # 全部作为字符串
        low_memory=False,
        on_bad_lines='skip'  # 跳过格式错误行
    )
    df = df.iloc[:, :4]  # 只取前四列

    if df.shape[1] == 4:
        df.columns = ["query", "title", "label", "data_source"]
    elif df.shape[1] == 3:
        df.columns = ["query", "title", "label"]
    else:
        raise ValueError(f"Unexpected number of columns: {df.shape[1]}")

    # 清洗 label
    def convert_label(label_str):
        try:
            label_value = float(label_str)
            return 1 if label_value >= 0.5 else 0
        except (ValueError, TypeError):
            if isinstance(label_str, str):
                if label_str.lower() in ['yes', '1', 'true']:
                    return 1
                elif label_str.lower() in ['no', '0', 'false']:
                    return 0
            print(f"Warning: Invalid label '{label_str}', skipping this row")
            return None

    df['label'] = df['label'].apply(convert_label)
    df = df.dropna(subset=['label'])
    df['label'] = df['label'].astype(int)
    records = df.to_dict(orient='records')

    # ==============================
    # 流式预测
    # ==============================
    for record in tqdm(records, desc="Evaluating", ncols=100, unit="lines"):
        label = str(record['label'])
        type_ = record.get('data_source', 'unKnown')
        type_list.append(type_)

        user_query = record['query']
        for ch in ['的', '啊', '呀', '我', '哎', '唉']:
            user_query = user_query.replace(ch, '')
        user_query = user_query.replace('流量信息', '流量')

        # text_list.append("[SEP]".join([user_query, record['title']]))
        text_list.append("[SEP]".join([user_query, str(record['title']) if record['title'] is not None else '']))
        label_list.append(label)
        count += 1

        if count >= eval_batch_size:
            batch = {"texts": text_list, "target": [label2tensor[i] for i in label_list]}
            loss, pred = eval_binary_classification_onnx(sess, tokenizer, batch)
            pred_list += list(pred)
            final_label_list += label_list
            final_text_list += text_list
            total_loss += loss
            batch_id += 1
            count = 0
            text_list, label_list = [], []

    # 处理剩余数据
    if count > 0:
        batch = {"texts": text_list, "target": [label2tensor[i] for i in label_list]}
        loss, pred = eval_binary_classification_onnx(sess, tokenizer, batch)
        pred_list += list(pred)
        final_label_list += label_list
        final_text_list += text_list
        total_loss += loss
        batch_id += 1

    # 构建 DataFrame 和计算指标（保持原逻辑）
    df = pd.DataFrame({
        "label": final_label_list,
        "type": type_list[:len(final_label_list)],
        "text": final_text_list,
        "pred_score": pred_list
    })

    y_true = df["label"].astype(int).tolist()
    threshold = 0.7
    y_pred = [1 if p > threshold else 0 for p in df["pred_score"]]

    eval_res = {
        "f1score": f1_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred),
        "recall": recall_score(y_true, y_pred),
        "accuracy": accuracy_score(y_true, y_pred)
    }

    df["pred"] = y_pred
    # 保存 TSV 文件
    os.makedirs(os.path.dirname(output_excel_path), exist_ok=True)
    output_tsv_path = output_excel_path.replace(".xlsx", "_online.tsv")
    df.to_csv(output_tsv_path, index=False, sep='\t', encoding='utf-8-sig')
    print(f"### Results saved to {output_tsv_path} ###")


    avg_loss = total_loss / max(1, batch_id)
    return avg_loss, eval_res


# ==============================
# 主函数
# ==============================
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--tokenizer_dir", type=str, required=True)
    parser.add_argument("--onnx_dir", type=str, required=True)
    parser.add_argument("--eval_dataset_dir", type=str, required=True)
    parser.add_argument("--output_excel", type=str, required=True)
    parser.add_argument("--output_json", type=str, required=True)
    parser.add_argument("--eval_batch_size", type=int, default=64)
    args = parser.parse_args()

    tokenizer = BertTokenizerFast.from_pretrained(args.tokenizer_dir, do_lower_case=True)
    sess_options = ort.SessionOptions()

    print("系统可用的ExecutionProvider:", ort.get_available_providers())

    sess = ort.InferenceSession(
        args.onnx_dir,
        providers=['CUDAExecutionProvider', 'CPUExecutionProvider']
    )

    print("实际使用的ExecutionProvider:", sess.get_providers())
    sess = ort.InferenceSession(
        args.onnx_dir, sess_options,
        providers=['CUDAExecutionProvider']
    )

    avg_loss, eval_res = eval_on_the_fly_onnx(
        sess=sess,
        tokenizer=tokenizer,
        eval_dataset_dir=args.eval_dataset_dir,
        eval_batch_size=args.eval_batch_size,
        output_excel_path=args.output_excel
    )

    # 保存 JSON
    with open(args.output_json, 'w') as f:
        json.dump(eval_res, f, indent=4)

    print("### ONNX Evaluation Finished ###")
