# coding: utf-8
import onnxruntime as ort
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from transformers import BertTokenizerFast, BertModel, T5EncoderModel, T5ForConditionalGeneration, AutoModelForSequenceClassification
import json
import numpy as np
import pandas as pd
from torch.utils.data import DataLoader, Dataset
import torch.nn as nn
import argparse
import torch
import os
import copy
import time
import pdb
os.environ['CUDA_VISIBLE_DEVICES'] = '6, 7'
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


class MyDataset(Dataset):
    def __init__(self, data_pairs):
        super().__init__()
        # data_pairs is a list of dict
        self.data = data_pairs

    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        return self.data[index]


class BertForClassification(nn.Module):
    """封装Bert类模型计算相似度的类
    """

    def __init__(self, bert, decoder=nn.Linear(768, 2)):
        super(BertForClassification, self).__init__()
        self.bert = bert
        self.decoder = decoder
        self.dropout = nn.Dropout(0.1)

    def forward(self, input_ids, attention_mask=None, token_type_ids=None):
        """输入文本encodings，输出logits
        Args:
            1. **encodings (`Tensor`): 文本encodings (batch_size, seq_len） 

        Returns:
            logits (`Tensor`): logits (batch_size, 2) 
                [
                    [1.23, -2.34],
                    [-3.45, 4.56],
                    ... ...
                ]
        """
        outputs = self.bert(input_ids, attention_mask=attention_mask, token_type_ids=token_type_ids).pooler_output
        logits = self.decoder(self.dropout(outputs))
        return logits


class BertForMultiClassification(nn.Module):
    def __init__(self, bert, decoder_0=nn.Linear(768, 2), decoder_1=nn.Linear(768, 2)):
        super(BertForMultiClassification, self).__init__()
        self.encoder = bert
        self.decoder_0 = decoder_0
        self.decoder_1 = decoder_1
        self.dropout_0 = nn.Dropout(0.1)
        self.dropout_1 = nn.Dropout(0.1)

    def forward(self, input_ids, attention_mask=None, token_type_ids=None):
        outputs = self.encoder(input_ids=input_ids, attention_mask=attention_mask,
                               token_type_ids=token_type_ids).pooler_output
        logits_0 = self.decoder_0(self.dropout_0(outputs))
        logits_1 = self.decoder_1(self.dropout_1(outputs))
        return logits_0, logits_1


class CrossEncoderForSimilarity(nn.Module):
    """封装单塔模型计算相似度的类
    """

    def __init__(self, model, tokenizer):
        super(CrossEncoderForSimilarity, self).__init__()
        self.model = model
        self.tokenizer = tokenizer
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, text_pair_list):
        """输入文本对列表，输出相似度Tensor
        Args:
            1. text_pair_list (`list[list[str]]`): 待计算相似度文本对列表 (batch_size, 2) 
                [
                    ["你好", "您好"],
                    ["你好", "你还好吗"],
                    ... ...
                ]
        Returns:
            similarity_tensor (`Tensor`): 相似度Tensor (batch_size, ) 
                [
                    0.123,
                    0.234,
                    ... ...
                ]
        """
        text_pair_list = ["[SEP]".join(_) for _ in text_pair_list]
        text_encodings = self.tokenizer(
            text_pair_list, padding=True, truncation=True, max_length=64, return_tensors='pt').to(device)
        self.model.to(device)
        logits = self.model(**text_encodings)
        # prob = self.softmax(logits.logits)
        # similarity_tensor = torch.narrow(prob, 1, 1, 1)
        # similarity_tensor = torch.squeeze(similarity_tensor, 1)
        return logits


def eval_cross_encoder_on_the_fly(tokenizer_dir="./mengzi-bert-base",
                                  input_model_dir="./mengzi-bert-base",
                                  eval_dataset_dir="./data/eval_shuffle.tsv",
                                  eval_batch_size=512,
                                  data_type="pair",
                                  has_pretrained=True,
                                  is_multi_task=True,
                                  onnx_path="",
                                  output_excel_path=""):
    """通过流式加载数据方式 & cross-encoder架构微调相似度计算模型。

    Args:
        data_type:

            `"pair"`: 表示输入格式为 [CLS]text_a[SEP]text_b[SEP]

            `"reference"`: 表示输入格式为 [CLS]text_a[SEP]text_b[SEP]reference_text[SEP]

        model_type:

            `"bert"`: 表示输入模型为bert类

            `"t5_encoder"`: 表示输入模型为t5_encoder类

        is_multi_task: 表示是否为多任务学习
    """

    # Timer
    start = time.time()
    print('### Evaluation {} Started! ###'.format(input_model_dir))
    if onnx_path:
        model = ort.InferenceSession(onnx_path, None)  # 加载onnx模型
    else:
        # Load Model Parameters
        if has_pretrained:
            pretrained_model = torch.load(input_model_dir, map_location=device, weights_only=False)
        else:
            bert = BertModel.from_pretrained(input_model_dir)
            pretrained_model = BertForClassification(bert)

        # model parallel
        model = pretrained_model
        # model = nn.DataParallel(model)
        model = model.to(device)
        model.dropout = nn.Dropout(0.2)

    # Initialize Tokenizer & Optimizer
    tokenizer = BertTokenizerFast.from_pretrained(tokenizer_dir, do_lower_case=True)

    # tokenizer = BertTokenizerFast.from_pretrained(tokenizer_dir, do_lower_case=True)
    # model_mengzi = AutoModelForSequenceClassification.from_pretrained(input_model_dir)
    # model = CrossEncoderForSimilarity(model_mengzi, tokenizer)

    # Load Data
    # df = pd.read_csv(eval_dataset_dir, sep='\t', header=None, nrows=10000, on_bad_lines='skip', engine='python')
    df = pd.read_csv(eval_dataset_dir, sep='\t', header=None)
    df = df.iloc[:, :4]
    if df.shape[1] == 4:
        df.columns = ["query", "title", "label", "data_source"]
    elif df.shape[1] == 3:
        df.columns = ["query", "title", "label"]
    else:
        raise ValueError(f"Unexpected number of columns: {df.shape[1]}")

    # df.columns = ["query", "title", "label"]
    df = df.to_dict(orient='records')

    # Eval per epoch
    eval_loss, err_rate, eval_res = eval_on_the_fly(model=model,
                                                    tokenizer=tokenizer,
                                                    data_type=data_type,
                                                    eval_batch_size=eval_batch_size,
                                                    eval_dataset_dir=eval_dataset_dir,
                                                    onnx_path=onnx_path,
                                                    output_excel_path=args.output_excel)
    print('### Evaluation result: loss {} ###'.format(eval_loss))
    print('### Evaluation result: errr_rate {} ###'.format(err_rate))

    # Timer
    duration = (time.time() - start) / 60
    print('### Evaluation {} Finished in {:d} min! ###'.format(input_model_dir, int(duration)))
    return eval_res


cnt = 0


def eval_on_the_fly(model, tokenizer, data_type, eval_batch_size=512, eval_dataset_dir="./data/eval_shuffle.tsv", onnx_path="", output_excel_path=""):
    # Initialize Variables
    global cnt
    text_list = []
    label_list = []
    type_list = []
    pred_list = []
    final_label_list = []
    final_text_list = []
    count = 0
    total_err = 0
    batch_id = 0
    total_loss = 0.0
    label2tensor = {"0": torch.tensor(0), "1": torch.tensor(1)}

    # Evaluate on-the-fly
    with open(eval_dataset_dir, "r+", encoding="utf-8") as eval_dataset_file:
        for line in eval_dataset_file:
            # Load Data
            line_list = line.replace("\n", "").split("\t")

            # check label
            human_label = line_list[2]
            if human_label in ["label"]:
                continue
            human_label = "1" if human_label == "yes" else "0"

            # get type
            if len(line_list) > 3:
                type = line_list[3]
            else:
                type = "unKnown"
            type_list.append(type)

            user_query = line_list[0]
            if onnx_path:
                user_query = user_query.lower()
                user_query = user_query.replace('的', '')
                user_query = user_query.replace('啊', '')
                user_query = user_query.replace('呀', '')
                user_query = user_query.replace('我', '')
                user_query = user_query.replace('哎', '')
                user_query = user_query.replace('唉', '')
                user_query = user_query.replace('流量信息', '流量')

            if data_type == "pair":
                text_list.append("[SEP]".join([user_query, line_list[1]]))
                label_list.append(human_label)
            elif data_type == "reference":
                text_list.append("[SEP]".join([user_query, line_list[1], line_list[3]]))
                label_list.append(human_label)
            else:
                raise ()

            # Evaluate
            # , 0.6, 0.7, 0.8, 0.9, 0.95, 0.97, 0.99]
            threshold_list = [0.7] if onnx_path else [(i+1)*0.1 for i in range(10)]
            count = count + 1
            if count <= eval_batch_size - 1:
                continue
            else:
                text_batch = {
                    "texts": text_list,
                    "target": [label2tensor[i] for i in label_list]
                }
                current_batch_loss, pred = eval_binary_classification_model_with_cross_entropy(
                    model, tokenizer, text_batch, onnx_path)
                s = ""
                error_count = 0
                for i in range(len(label_list)):
                    pred_list.append(pred[i])
                final_label_list += label_list
                final_text_list += text_list
                count = 0
                text_list = []
                label_list = []
                batch_id = batch_id + 1
                total_loss = total_loss + current_batch_loss
                total_err += error_count
        if count != 0:
            text_batch = {
                "texts": text_list,
                "target": [label2tensor[i] for i in label_list]
            }
            current_batch_loss, pred = eval_binary_classification_model_with_cross_entropy(
                model, tokenizer, text_batch, onnx_path)
            error_count = 0
            for i in range(len(label_list)):
                pred_list.append(pred[i])
            final_label_list += label_list
            final_text_list += text_list
            count = 0
            text_list = []
            label_list = []
            batch_id = batch_id + 1
            total_loss = total_loss + current_batch_loss
            total_err += error_count

    df = pd.DataFrame({"label": final_label_list, "type": type_list,
                       "text": final_text_list, "pred_score": pred_list})

    # calculate metric
    y_true = df["label"].astype(int).to_list()

    # 选取最好的阈值,进行预测
    best_f1 = 0
    best_precision = 0
    onnx_precision = 0.89
    best_thres = 0
    for threshold in threshold_list:
        y_pred = [1 if i > threshold else 0 for i in df["pred_score"]]
        accuracy = accuracy_score(y_true, y_pred)
        precision = precision_score(y_true, y_pred, average='binary')
        # pdb.set_trace()
        recall = recall_score(y_true, y_pred, average='binary')
        f1 = f1_score(y_true, y_pred, average='binary')
        if precision < onnx_precision:
            # 准确率不及预期--选择准确率高的阈值
            # print(best_precision)
            if precision > best_precision:
                eval_res = {"f1score": f1,
                            "recall": recall,
                            "precision": precision,
                            "accuracy": accuracy}
                best_precision = precision
                best_thres = threshold
                best_ypred = y_pred
        else:
            # 选最好的f_1
            if f1 > best_f1:
                eval_res = {"f1score": f1,
                            "recall": recall,
                            "precision": precision,
                            "accuracy": accuracy}
                best_precision = precision
                best_thres = threshold
                best_ypred = y_pred
                best_f1 = f1
    print('### Best threshold is {} ###'.format(best_thres))
    print("f1score:", {eval_res["f1score"]})
    print("recall:", {eval_res["recall"]})
    print("precision:", {eval_res["precision"]})
    print("accuracy:", {eval_res["accuracy"]})

    # 选择最优阈值的pred值保存
    df["pred"] = best_ypred

    dir_name = os.path.dirname(output_excel_path)
    # 判断文件夹是否存在，不存在则创建
    if not os.path.exists(dir_name):
        os.makedirs(dir_name, exist_ok=True)
    if onnx_path != "":
        output_excel_path = "".join([output_excel_path.split('.xlsx')[0],
                                     "_online.xlsx"])

    df.to_excel(output_excel_path, index=False)
    print('### Save Evaluation result at {} ###'.format(output_excel_path))

    avg_loss = total_loss / batch_id
    err_rate = total_err / (batch_id * eval_batch_size)
    return avg_loss, err_rate, eval_res


def eval_binary_classification_model_with_cross_entropy(model, tokenizer, text_batch, onnx_path=None):
    if not onnx_path:
        model.eval()
    softmax = nn.Softmax(dim=-1)

    # Load Data
    criterion = nn.CrossEntropyLoss()
    train_text_encodings = tokenizer(text_batch["texts"], padding=True,
                                     truncation=True, max_length=128, return_tensors="pt")
    targets = torch.LongTensor(text_batch["target"])
    train_text_encodings = train_text_encodings.to(device)
    targets = targets.to(device)

    # Forward
    if onnx_path:
        input_ids = train_text_encodings['input_ids'].cpu().numpy()
        attention_mask = train_text_encodings['attention_mask'].cpu().numpy()
        token_type_ids = train_text_encodings['token_type_ids'].cpu().numpy()
        sess = ort.InferenceSession(onnx_path, None)  # 加载onnx模型
        onnx_output = sess.run(['output'],
                               {'input_ids': input_ids,
                                'attention_mask': attention_mask,
                                "token_type_ids": token_type_ids
                                })
        logits = torch.tensor(np.array(onnx_output))[0].to(device)
    else:
        logits = model(**train_text_encodings)

    loss = criterion(logits, targets)
    prob = softmax(logits)
    similarity_tensor = torch.narrow(prob, 1, 1, 1)
    similarity_tensor = torch.squeeze(similarity_tensor, 1)
    return loss.item(), similarity_tensor.to("cpu").detach().numpy()


def pt2onnx(pt_dir, onnx_dir, batch_size=50, text_length=96):
    model = torch.load(pt_dir, map_location=device)
    data = torch.zeros(batch_size, text_length, device=device).long()
    input_ids = attention_mask = token_type_ids = data
    pseudo_input = (input_ids, attention_mask, token_type_ids)
    torch.onnx.export(model,
                      pseudo_input,
                      onnx_dir,
                      opset_version=12,
                      do_constant_folding=True,
                      input_names=['input_ids', 'attention_mask', 'token_type_ids'],
                      output_names=['output'],
                      dynamic_axes={
                          'input_ids': {0: 'N', 1: 'L'},
                          'attention_mask': {0: 'N', 1: 'L'},
                          'token_type_ids': {0: 'N', 1: 'L'},
                          'output': {0: 'N'}
                      }
                      )


def my_collate(batch_line):
    batch_line = copy.deepcopy(batch_line)
    text = []
    label = []

    for line in batch_line:
        text.append("[SEP]".join([line['query'], line["title"]]))  # 我只使用这两个字段，其他的可以不处理不输出
        label.append(line["label"])

    batch = {
        "text": text,
        "label": label,
    }
    return batch


def eval(model, tokenizer, dataset, eval_batch_size=512, onnx=False):
    softmax = nn.Softmax(dim=-1)
    test_loader = DataLoader(dataset, batch_size=eval_batch_size, shuffle=False, collate_fn=my_collate)
    total_loss = 0.0
    datapoint_count = 0
    pred_label_list = []

    with torch.no_grad():  # No need to track gradients for evaluation
        for data in test_loader:
            # Load Data
            criterion = nn.CrossEntropyLoss()
            train_text_encodings = tokenizer(data["text"], padding=True, truncation=True,
                                             max_length=128, return_tensors="pt").to(device)
            targets = torch.LongTensor(data["label"]).to(device)

            # Forward
            if onnx:
                input_ids = train_text_encodings['input_ids'].cpu().numpy()
                attention_mask = train_text_encodings['attention_mask'].cpu().numpy()
                token_type_ids = train_text_encodings['token_type_ids'].cpu().numpy()
                onnx_output = model.run(['output'],
                                        {'input_ids': input_ids,
                                        'attention_mask': attention_mask,
                                         "token_type_ids": token_type_ids
                                         })
                logits = torch.tensor(np.array(onnx_output))[0].to(device)
            else:
                logits = model(**train_text_encodings)
            loss = criterion(logits, targets)

            prob = softmax(logits)
            similarity_tensor = torch.narrow(prob, 1, 1, 1)
            similarity_tensor = torch.squeeze(similarity_tensor, 1)
            pred_label_list += list(similarity_tensor.to("cpu").detach().numpy())

            total_loss += loss.item() * len(data["text"])
            datapoint_count += len(data["text"])
        total_loss /= datapoint_count
    return total_loss, pred_label_list


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Evaluate cross-encoder models.")
    parser.add_argument("--tokenizer_dir", help="directory containing model tokenizer", type=str,
                        default="../data/cloud_share/qabot_relevance_model/finish_model")
    parser.add_argument("--onnx_dir", help="directory containing online onnx model", type=str,
                        default="../data/cloud_share/qabot_relevance_model/online_onnx_model.onnx")
    parser.add_argument("--model_dir", help="directory containing model checkpoints", type=str,
                        default="../data/cloud_share/qabot_relevance_model/finish_model")
    parser.add_argument("--eval_dataset_dir", help="evaluation dataset path", type=str,
                        default="../data/cloud_share/qabot_relevance_data/testset/v2_human_labelled.tsv")
    parser.add_argument("--output_json", help="output JSON file to save results", type=str,
                        default="../data/cloud_share/qabot_relevance_data/onxx_model_score/v2_0701_score.json")
    parser.add_argument("--output_excel", help="output excel file to save results", type=str,
                        default="../data/cloud_share/data_share/qabot_relevance_data/test_model_excel/")
    parser.add_argument("--eval_time", help="time to eval models", type=str, default="20250623")
    parser.add_argument("--eval_onnx", help="whether to use ONNX model for evaluation",
                        type=str, default="false")  # 增加 eval_onnx 参数
    args = parser.parse_args()

    # 根据命令行参数决定是否使用 ONNX 模型
    eval_onnx = args.eval_onnx.lower() == "true"  # 将字符串转换为布尔值
    # 如果 eval_onnx 为 True，则使用固定的 ONNX 路径
    onnx_path = args.onnx_dir if eval_onnx else ""

    res_vs_batch = {}
    eval_res = eval_cross_encoder_on_the_fly(
        tokenizer_dir=args.tokenizer_dir,  # 默认值
        input_model_dir=args.model_dir,
        has_pretrained=True,
        eval_dataset_dir=args.eval_dataset_dir,
        eval_batch_size=64,  # 默认值
        data_type="pair",  # 默认值
        onnx_path=onnx_path,  # 根据 eval_onnx 决定是否使用 ONNX 模型
        output_excel_path=args.output_excel
    )
    res_vs_batch[f"{args.model_dir.split('_')[-1]}".replace("batch", "")] = eval_res

    # 将结果中的 PyTorch 张量转换为可序列化的格式
    res_vs_batch_serializable = {
        k: {k2: v2.item() if isinstance(v2, torch.Tensor) else v2 for k2, v2 in v.items()}
        for k, v in res_vs_batch.items()
    }

    # 将字典保存为 JSON 文件
    with open(args.output_json, 'w') as f:
        json.dump(res_vs_batch_serializable, f, indent=4)
