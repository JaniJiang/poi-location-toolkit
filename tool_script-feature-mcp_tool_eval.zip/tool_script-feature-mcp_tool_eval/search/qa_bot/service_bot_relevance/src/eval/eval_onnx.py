# coding: utf-8
import os
import torch
import numpy as np
import pandas as pd
from tqdm import tqdm
import torch.nn as nn
import onnxruntime as ort
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from transformers import BertTokenizerFast

# ==============================
# 设置设备
# ==============================
onnx = False   # ✅ True 表示使用 ONNX 模型, False 表示使用 PyTorch 模型
os.environ['CUDA_VISIBLE_DEVICES'] = '0,1,2,3,4,5,6'
print("当前可见 GPU 数量：", len(os.environ["CUDA_VISIBLE_DEVICES"].split(',')))

# ==============================
# 定义 PyTorch 模型
# ==============================
class BertForClassification(nn.Module):
    """封装Bert类模型计算相似度的类"""

    def __init__(self, bert, decoder=nn.Linear(768, 2)):
        super(BertForClassification, self).__init__()
        self.bert = bert
        self.decoder = decoder
        self.dropout = nn.Dropout(0.1)

    def forward(self, input_ids, attention_mask=None, token_type_ids=None):
        """输入文本encodings，输出logits"""
        outputs = self.bert(input_ids, attention_mask=attention_mask, token_type_ids=token_type_ids).pooler_output
        logits = self.decoder(self.dropout(outputs))
        return logits


# ==============================
# 通用二分类评估函数（ONNX + PyTorch）
# ==============================
def eval_binary_classification_onnx(sess, tokenizer, text_batch):
    targets = np.array([int(t) for t in text_batch["target"]])

    if onnx:
        # ---------- ONNX 模式 ----------
        encodings = tokenizer(
            text_batch["texts"],
            padding=True,
            truncation=True,
            max_length=128,
            return_tensors="np"
        )
        input_ids = encodings["input_ids"].astype(np.int64)
        attention_mask = encodings["attention_mask"].astype(np.int64)
        token_type_ids = encodings["token_type_ids"].astype(np.int64)

        try:
            onnx_output = sess.run(
                ['output'],
                {
                    'input_ids': input_ids,
                    'attention_mask': attention_mask,
                    'token_type_ids': token_type_ids
                }
            )
            logits = np.array(onnx_output[0])
        except Exception as e:
            print("### ONNX 推理出错:", e)
            raise e

    else:
        # ---------- PyTorch 模式 ----------
        encodings = tokenizer(
            text_batch["texts"],
            padding=True,
            truncation=True,
            max_length=128,
            return_tensors="pt"
        )
        encodings = {k: v.to("cuda") for k, v in encodings.items()}

        with torch.no_grad():
            logits = sess(
                input_ids=encodings["input_ids"],
                attention_mask=encodings["attention_mask"],
                token_type_ids=encodings["token_type_ids"]
            ).detach().cpu().numpy()

    # ---------- softmax + loss ----------
    exp_logits = np.exp(logits - np.max(logits, axis=1, keepdims=True))
    prob = exp_logits / np.sum(exp_logits, axis=1, keepdims=True)
    similarity_tensor = prob[:, 1]

    eps = 1e-8
    ce_loss = -np.mean(np.log(prob[np.arange(len(targets)), targets] + eps))
    return ce_loss, similarity_tensor


# ==============================
# 流式评估函数
# ==============================
def eval_on_the_fly_onnx(sess, tokenizer, eval_dataset_dir, eval_batch_size=512, output_tsv_path="output.tsv"):
    text_list, label_list, type_list, pred_list = [], [], [], []
    final_label_list, final_text_list = [], []
    count = batch_id = total_loss = 0

    label2tensor = {"0": 0, "1": 1}

    # ==============================
    # 加载 TSV 数据
    # ==============================
    df = pd.read_csv(
        eval_dataset_dir,
        sep='\t',
        dtype=str,
        low_memory=False,
        on_bad_lines='skip'
    )

    # ==============================
    # 清洗 label
    # ==============================
    def convert_label(label_str):
        try:
            label_value = float(label_str)
            return 1 if label_value >= 0.5 else 0
        except (ValueError, TypeError):
            if isinstance(label_str, str):
                if label_str.lower() in ['yes', '1', 'true']:
                    return 1
                elif label_str.lower() in ['no', '0', 'false']:
                    return 0
            print(f"Warning: Invalid label '{label_str}', skipping this row")
            return None

    df['label'] = df['label'].apply(convert_label)
    df = df.dropna(subset=['label'])
    df['label'] = df['label'].astype(int)
    records = df.to_dict(orient='records')

    # ==============================
    # 流式批处理评估
    # ==============================
    for record in tqdm(records, desc="Evaluating", ncols=100, unit="lines"):
        label = str(record['label'])
        type_ = record.get('data_source', 'unKnown')
        type_list.append(type_)

        user_query = record['query']
        for ch in ['的', '啊', '呀', '我', '哎', '唉']:
            user_query = user_query.replace(ch, '')
        user_query = user_query.replace('流量信息', '流量')

        text_list.append("[SEP]".join([user_query, str(record['title']) if record['title'] is not None else '']))
        label_list.append(label)
        count += 1

        if count >= eval_batch_size:
            batch = {"texts": text_list, "target": [label2tensor[i] for i in label_list]}
            loss, pred = eval_binary_classification_onnx(sess, tokenizer, batch)
            pred_list += list(pred)
            final_label_list += label_list
            final_text_list += text_list
            total_loss += loss
            batch_id += 1
            count = 0
            text_list, label_list = [], []

    # 处理最后一批
    if count > 0:
        batch = {"texts": text_list, "target": [label2tensor[i] for i in label_list]}
        loss, pred = eval_binary_classification_onnx(sess, tokenizer, batch)
        pred_list += list(pred)
        final_label_list += label_list
        final_text_list += text_list
        total_loss += loss
        batch_id += 1

    # ==============================
    # 计算指标 + 保存结果
    # ==============================
    df_result = pd.DataFrame({
        "label": final_label_list,
        "type": type_list[:len(final_label_list)],
        "text": final_text_list,
        "pred_score": pred_list
    })

    y_true = df_result["label"].astype(int).tolist()
    threshold = 0.7
    y_pred = [1 if p > threshold else 0 for p in df_result["pred_score"]]

    eval_res = {
        "f1score": f1_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred),
        "recall": recall_score(y_true, y_pred),
        "accuracy": accuracy_score(y_true, y_pred)
    }

    df_result["pred"] = y_pred
    df_result.to_csv(output_tsv_path, index=False, sep='\t', encoding='utf-8-sig')
    print(f"### Results saved to {output_tsv_path} ###")

    avg_loss = total_loss / max(1, batch_id)
    return avg_loss, eval_res


# ==============================
# 主函数入口
# ==============================
if __name__ == "__main__":
    onnx_dir = "/mnt/volumes/ss-sai-bd-ga/wuzhenyan/tool_script/data/cloud_share/qabot_relevance_model/model.onnx"
    model_dir = "/mnt/volumes/ss-sai-bd-ga/public_qiaojiaqi/save_files/outmodel_dir/predscore_1014.bin_optimal_epoch"
    tokenizer_dir = "/mnt/volumes/ss-sai-bd-ga/wuzhenyan/tool_script/data/cloud_share/qabot_relevance_model/bge-base-zh-v1.5"
    eval_dataset_dir = "/mnt/volumes/ss-sai-bd-ga/public_qiaojiaqi/save_files/datasets/train_0924_all.tsv"
    output_tsv_path = "/mnt/volumes/ss-sai-bd-ga/public_qiaojiaqi/save_files/datasets/train_0924_pred.tsv"

    tokenizer = BertTokenizerFast.from_pretrained(tokenizer_dir, do_lower_case=True)
    print("系统可用的 Execution Providers:", ort.get_available_providers())

    if onnx:
        # ---------- ONNX 模式 ----------
        sess_options = ort.SessionOptions()
        sess = ort.InferenceSession(
            onnx_dir,
            sess_options,
            providers=['CUDAExecutionProvider', 'CPUExecutionProvider']
        )
        print("实际使用的 Execution Provider:", sess.get_providers())

    else:
        # ---------- PyTorch 模式 ----------
        model = torch.load(model_dir, map_location=torch.device('cuda'), weights_only=False)
        model = model.to(torch.device('cuda'))
        model.eval()
        sess = model

    # 开始评估
    avg_loss, eval_res = eval_on_the_fly_onnx(
        sess=sess,
        tokenizer=tokenizer,
        eval_dataset_dir=eval_dataset_dir,
        eval_batch_size=64,
        output_tsv_path=output_tsv_path
    )

    print(eval_res)
    print("### Evaluation Finished ###")
