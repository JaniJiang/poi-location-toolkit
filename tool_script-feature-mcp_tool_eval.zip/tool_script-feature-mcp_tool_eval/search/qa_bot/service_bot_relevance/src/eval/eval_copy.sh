#!/bin/bash

tokenizer_dir="/mnt/volumes/ss-sai-bd-ga/public_qiaojiaqi/tool_script/data/cloud_share/qabot_relevance_model/bge-base-zh-v1.5"
eval_dataset_dir="/mnt/volumes/ss-sai-bd-ga/wuzhenyan/rescore-data-0913/train_shuffled.tsv"
output_json_base="/mnt/volumes/ss-sai-bd-ga/public_qiaojiaqi/save_files/onxx_model_score"
output_excel_base="/mnt/volumes/ss-sai-bd-ga/public_qiaojiaqi/save_files/test_model_excel"

output_excel="$output_excel_base/online_onnx_model.xlsx"
output_json="$output_json_base/online_onnx_model_score.json"
onnx_model_path="../../../../../data/cloud_share/qabot_relevance_model/online_onnx_model.onnx"

echo "输出 Excel: $output_excel"
echo "输出 JSON: $output_json"

python -u eval_copy.py \
    --tokenizer_dir $tokenizer_dir \
    --onnx_dir $onnx_model_path \
    --eval_dataset_dir $eval_dataset_dir \
    --output_excel $output_excel \
    --output_json $output_json \
    --eval_batch_size 64
