#!/bin/bash

# 计算根目录
ROOT_DIR="../../../../../data"

now_two_train=0  # 设置为 0 或 1 来控制不同训练流程

# LOG_FILE="../../../../../data/cloud_share/qabot_relevance_model/log/my_train_0703_v5.log"

if [ "$now_two_train" -eq 0 ]; then
    echo "Running single model training..."
    python -u /mnt/volumes/ss-sai-bd-ga/public_qiaojiaqi/tool_script/search/qa_bot/service_bot_relevance/src/train/train.py \
        --train_stage 1 \
        --tokenizer_dir "/mnt/volumes/ss-sai-bd-ga/public_qiaojiaqi/tool_script/data/cloud_share/qabot_relevance_model/bge-base-zh-v1.5" \
        --model_dir "/mnt/volumes/ss-sai-bd-ga/public_qiaojiaqi/tool_script/data/cloud_share/qabot_relevance_model/bge-base-zh-v1.5" \
        --data_dir "/mnt/volumes/ss-sai-bd-ga/public_qiaojiaqi/save_files/datasets/onnx_to_train.tsv" \
        --outmodel_dir "/mnt/volumes/ss-sai-bd-ga/public_qiaojiaqi/save_files/outmodel_dir/bge_base_human_labelled_with_mannual_1011.bin" \
        --has_pretrained "false" \
        --epochs 3 \
        --eval_dataset_dir "/mnt/volumes/ss-sai-bd-ga/public_qiaojiaqi/save_files/datasets/v1_eval_labelled.tsv" \
        --lr 5e-6 \
        --train_batch_size 64 \
        --eval_batch_size 1024

else
    echo "Running two-stage model training..."
    python -u train.py \
        --train_stage 2 \
        --model_dir "../../../../../data/cloud_share/qabot_relevance_model/model/bge-base-zh-v1.5" \
        --data_dir "../../../../../data/cloud_share/qabot_relevance_data/trainset/train_616.tsv" \
        --outmodel_dir "../../../../../data/cloud_share/qabot_relevance_model/workspace/bge_base_train512_epoch2_2.bin" \
        --has_pretrained "false" \
        --epochs 1 \
        --eval_dataset_dir "../../../../../data/cloud_share/qabot_relevance_data/evalset/v1_eval_labelled.tsv" \
        --lr 5e-6 \
        --train_batch_size 1024 \
        --eval_batch_size 1024 \
        --two_model_dir "../../../../../data/cloud_share/qabot_relevance_model/model/bge-base-zh-v1.5" \
        --two_data_dir "../../../../../data/cloud_share/qabot_relevance_data/trainset/train_616.tsv" \
        --two_outmodel_dir "../../../../../data/cloud_share/qabot_relevance_model/20250625/bge_base_train64_epoch4_2.bin" \
        --two_epochs 4 \
        --two_eval_dataset_dir "../../../../../data/cloud_share/qabot_relevance_data/evalset/v1_eval_labelled.tsv" \
        --two_lr 5e-6 \
        --two_train_batch_size 64 \
        --two_eval_batch_size 1024

fi

# nohup bash train.sh > model.train.log 2>&1 &