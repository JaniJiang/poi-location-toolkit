import os
os.environ['CUDA_VISIBLE_DEVICES'] = '1,2,3,4,5,6,7'


import time
import torch
import argparse
import torch.nn as nn
import pandas as pd
from transformers import BertTokenizerFast, BertModel
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from tqdm import tqdm


device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
class TransformerForClassification(nn.Module):
    """封装Transformer后交互模型计算相似度的类
    """

    def __init__(self, d_model, nhead, num_layers):
        super(TransformerForClassification, self).__init__()
        self.encoder_layer = nn.TransformerEncoderLayer(d_model, nhead, batch_first=True)
        self.model = nn.TransformerEncoder(self.encoder_layer, num_layers)
        self.decoder = nn.Linear(d_model*2, 2)
        self.dropout = nn.Dropout(0.1)

    def forward(self, vectors):
        """输入向量列表，输出logits
        Args:
            1. vectors (`Tensor`): 待计算相似度文本对列表 (batch_size, 特征向量个数, 特征向量维度） 
                [
                    [
                        [0.123, 0.234, ...],
                        [0.345, 0.456, ...],
                        ... ...
                    ]
                    ... ...
                ]
        Returns:
            logits (`Tensor`): logits (batch_size, 2) 
                [
                    [1.23, -2.34],
                    [-3.45, 4.56],
                    ... ...
                ]
        """
        outputs = self.model(vectors)
        concat_outputs = torch.cat((outputs[:, 0, :], outputs[:, 1, :]), 1)
        logits = self.decoder(self.dropout(concat_outputs))
        return logits


class BertForClassification(nn.Module):
    """封装Bert类模型计算相似度的类
    """

    def __init__(self, bert, decoder=nn.Linear(768, 2)):
        super(BertForClassification, self).__init__()
        self.bert = bert
        self.decoder = decoder
        self.dropout = nn.Dropout(0.1)

    def forward(self, input_ids, attention_mask=None, token_type_ids=None):
        """输入文本encodings，输出logits
        Args:
            1. **encodings (`Tensor`): 文本encodings (batch_size, seq_len） 

        Returns:
            logits (`Tensor`): logits (batch_size, 2) 
                [
                    [1.23, -2.34],
                    [-3.45, 4.56],
                    ... ...
                ]
        """
        outputs = self.bert(input_ids, attention_mask=attention_mask, token_type_ids=token_type_ids).pooler_output
        logits = self.decoder(self.dropout(outputs))
        return logits


class T5EncoderForClassification(nn.Module):
    """封装T5Encoder类模型计算相似度的类
    """

    def __init__(self, t5_encoder, decoder_0=nn.Linear(768, 2)):
        super(T5EncoderForClassification, self).__init__()
        self.encoder = t5_encoder
        self.decoder_0 = decoder_0
        self.dropout_0 = nn.Dropout(0.1)

    def forward(self, input_ids, attention_mask=None, token_type_ids=None):
        """输入文本encodings，输出logits
        Args:
            1. **encodings (`Tensor`): 文本encodings (batch_size, seq_len） 

        Returns:
            logits (`Tensor`): logits (batch_size, 2) 
                [
                    [1.23, -2.34],
                    [-3.45, 4.56],
                    ... ...
                ]
        """
        last_hidden_state = self.encoder(input_ids, attention_mask=attention_mask).last_hidden_state
        outputs = torch.narrow(last_hidden_state, 1, 0, 1).squeeze(1)
        logits = self.decoder_0(self.dropout_0(outputs))
        return logits


class BertForMultiClassification(nn.Module):
    def __init__(self, bert, decoder_0=nn.Linear(768, 2), decoder_1=nn.Linear(768, 2)):
        super(BertForMultiClassification, self).__init__()
        self.encoder = bert
        self.decoder_0 = decoder_0
        self.decoder_1 = decoder_1
        self.dropout_0 = nn.Dropout(0.1)
        self.dropout_1 = nn.Dropout(0.1)

    def forward(self, input_ids, attention_mask=None, token_type_ids=None):
        outputs = self.encoder(input_ids=input_ids, attention_mask=attention_mask,
                               token_type_ids=token_type_ids).pooler_output
        logits_0 = self.decoder_0(self.dropout_0(outputs))
        logits_1 = self.decoder_1(self.dropout_1(outputs))
        return logits_0, logits_1


class T5EncoderForMultiClassification(nn.Module):
    def __init__(self, t5_encoder, decoder_0=nn.Linear(768, 2), decoder_1=nn.Linear(768, 2)):
        super(T5EncoderForMultiClassification, self).__init__()
        self.encoder = t5_encoder
        self.decoder_0 = decoder_0
        self.decoder_1 = decoder_1
        self.dropout_0 = nn.Dropout(0.1)
        self.dropout_1 = nn.Dropout(0.1)

    def forward(self, input_ids, attention_mask=None, token_type_ids=None):
        last_hidden_state = self.encoder(input_ids=input_ids, attention_mask=attention_mask).last_hidden_state
        outputs = torch.narrow(last_hidden_state, 1, 0, 1).squeeze(1)
        logits_0 = self.decoder_0(self.dropout_0(outputs))
        logits_1 = self.decoder_1(self.dropout_1(outputs))
        return logits_0, logits_1


class BertMeanForTextEmbedding(nn.Module):
    """封装Bert类模型输出文本embedding的类，池化方法为Mean。
    """

    def __init__(self, model):
        super(BertMeanForTextEmbedding, self).__init__()
        self.model = model

    def mean_pooling(self, model_output, attention_mask):
        token_embeddings = model_output[0]
        input_mask_expanded = attention_mask.unsqueeze(-1).expand(token_embeddings.size()).float()
        return torch.sum(token_embeddings * input_mask_expanded, 1) / torch.clamp(input_mask_expanded.sum(1), min=1e-9)

    def forward(self, input_ids, attention_mask=None, token_type_ids=None):
        """输入文本encodings，输出文本embeddings
        Args:
            1. **encodings (`Tensor`): 文本encodings (batch_size, seq_len） 

        Returns:
            embeddings (`Tensor`): embeddings (batch_size, hidden_size) 
                [
                    [0.123, 0.234, ...],
                    [0.345, 0.456, ...],
                    ... ...
                ]
        """
        outputs = self.model(input_ids=input_ids, attention_mask=attention_mask, token_type_ids=token_type_ids)
        text_embeddings = self.mean_pooling(outputs, attention_mask)
        return text_embeddings


class BertCLSForTextEmbedding(nn.Module):
    """封装Bert类模型输出句子embedding的类，池化方法为取CLS。
    """

    def __init__(self, model):
        super(BertCLSForTextEmbedding, self).__init__()
        self.model = model

    def forward(self, input_ids, attention_mask=None, token_type_ids=None):
        """输入文本encodings，输出文本embeddings
        Args:
            1. **encodings (`Tensor`): 文本encodings (batch_size, seq_len） 

        Returns:
            embeddings (`Tensor`): embeddings (batch_size, hidden_size) 
                [
                    [0.123, 0.234, ...],
                    [0.345, 0.456, ...],
                    ... ...
                ]
        """
        outputs = self.model(input_ids=input_ids, attention_mask=attention_mask, token_type_ids=token_type_ids)
        text_embeddings = outputs[0][:, 0]
        text_embeddings = torch.nn.functional.normalize(text_embeddings, p=2, dim=1)
        return text_embeddings


def eval_cross_encoder_on_the_fly(tokenizer="./mengzi-bert-base",
                                  model="./mengzi-bert-base",
                                  eval_dataset_dir="./data/eval_shuffle.tsv",
                                  eval_batch_size=512,
                                  data_type="pair"):
    """通过流式加载数据方式 & cross-encoder架构微调相似度计算模型。

    Args:
        data_type:

            `"pair"`: 表示输入格式为 [CLS]text_a[SEP]text_b[SEP]

            `"reference"`: 表示输入格式为 [CLS]text_a[SEP]text_b[SEP]reference_text[SEP]

        model_type:

            `"bert"`: 表示输入模型为bert类

            `"t5_encoder"`: 表示输入模型为t5_encoder类

        is_multi_task: 表示是否为多任务学习
    """

    # Timer
    start = time.time()
    # Load Data
    # df = pd.read_csv(eval_dataset_dir, sep='\t', header=None, nrows=10000, on_bad_lines='skip', engine='python')
    df = pd.read_csv(eval_dataset_dir, sep='\t', header=None)
    df = df.iloc[:, :4]
    if df.shape[1] == 4:
        df.columns = ["query", "title", "label", "data_source"]
    elif df.shape[1] == 3:
        df.columns = ["query", "title", "label"]
    else:
        raise ValueError(f"Unexpected number of columns: {df.shape[1]}")

    # df.columns = ["query", "title", "label"]
    df = df.to_dict(orient='records')
    
    # Eval per epoch
    eval_loss, err_rate, eval_res = eval_on_the_fly(model=model,
                                                    tokenizer=tokenizer,
                                                    data_type=data_type,
                                                    eval_batch_size=eval_batch_size,
                                                    eval_dataset_dir=eval_dataset_dir)
    print('### Evaluation result: loss {} ###'.format(eval_loss))
    print('### Evaluation result: errr_rate {} ###'.format(err_rate))

    # Timer
    duration = (time.time() - start) / 60
    print('### Evaluation Finished in {:d} min! ###'.format(int(duration)))
    return eval_loss, eval_res

def eval_on_the_fly(model, tokenizer, data_type, eval_batch_size=512, eval_dataset_dir="./data/eval_shuffle.tsv"):
    """
    基于回归式二分类模型的 on-the-fly 评估
    """
    
    model.eval()
    device = next(model.parameters()).device

    # 初始化变量
    text_list, label_list, type_list, pred_list, final_label_list, final_text_list = [], [], [], [], [], []
    count, batch_id, total_loss = 0, 0, 0.0
    total_err = 0
    label2tensor = {"0": 0.0, "1": 1.0}  # float 类型
    threshold_list = [0.5, 0.6, 0.7, 0.8, 0.9]

    # 计算总行数用于进度条
    total_lines = sum(1 for _ in open(eval_dataset_dir, "r", encoding="utf-8"))

    with open(eval_dataset_dir, "r", encoding="utf-8") as eval_dataset_file:
        pbar = tqdm(eval_dataset_file, total=total_lines, desc="Evaluating", unit="samples")
        for line in pbar:
            line_list = line.strip().split("\t")

            # 跳过表头
            human_label = line_list[2].strip()
            if human_label.lower() == "label":
                continue

            type_ = line_list[3] if len(line_list) > 3 else "unKnown"
            type_list.append(type_)

            # 构建文本
            if data_type == "pair":
                text_list.append("[SEP]".join([line_list[0], line_list[1]]))
            elif data_type == "reference":
                text_list.append("[SEP]".join([line_list[0], line_list[1], line_list[3]]))
            else:
                raise ValueError(f"Unknown data_type: {data_type}")

            label_list.append(human_label)
            count += 1

            # 达到 batch 大小，进行评估
            if count >= eval_batch_size:
                text_batch = {
                    "texts": text_list,
                    "target": [float(i) for i in label_list]
                }
                current_batch_loss, pred = eval_binary_regression_model(model, tokenizer, text_batch)
                
                pred_list.extend([float(p) for p in pred])
                final_label_list.extend(label_list)
                final_text_list.extend(text_list)

                total_loss += current_batch_loss
                batch_id += 1

                pbar.set_postfix({'batch': batch_id, 'loss': f'{current_batch_loss:.4f}'})

                # 重置 batch
                text_list, label_list = [], []
                count = 0

        # 处理剩余不足一批的数据
        if count > 0:
            text_batch = {
                "texts": text_list,
                "target": [float(i) for i in label_list]
            }
            current_batch_loss, pred = eval_binary_regression_model(model, tokenizer, text_batch)
            pred_list.extend([float(p) for p in pred])
            final_label_list.extend(label_list)
            final_text_list.extend(text_list)
            total_loss += current_batch_loss
            batch_id += 1

    # 构建 DataFrame
    df = pd.DataFrame({
        "label": final_label_list,
        "type": type_list,
        "text": final_text_list,
        "pred_score": pred_list
    })

    y_true = df["label"].astype(int).to_list()

    # 阈值选择
    best_f1, best_precision, best_thres = 0, 0, 0
    eval_res = {"f1score": 0, "recall": 0, "precision": 0, "accuracy": 0}
    best_ypred = [0] * len(y_true)
    onnx_precision = 0.1

    for threshold in threshold_list:
        y_pred = [1 if i > threshold else 0 for i in df["pred_score"]]
        accuracy = accuracy_score(y_true, y_pred)
        precision = precision_score(y_true, y_pred, average='binary', zero_division=0)
        recall = recall_score(y_true, y_pred, average='binary', zero_division=0)
        f1 = f1_score(y_true, y_pred, average='binary', zero_division=0)

        if precision < onnx_precision:
            if precision > best_precision:
                eval_res = {"f1score": f1, "recall": recall, "precision": precision, "accuracy": accuracy}
                best_precision = precision
                best_thres = threshold
                best_ypred = y_pred
        else:
            if f1 > best_f1:
                eval_res = {"f1score": f1, "recall": recall, "precision": precision, "accuracy": accuracy}
                best_precision = precision
                best_thres = threshold
                best_ypred = y_pred
                best_f1 = f1

    print(f'### Best threshold is {best_thres} ###')
    print("f1score:", eval_res["f1score"])
    print("recall:", eval_res["recall"])
    print("precision:", eval_res["precision"])
    print("accuracy:", eval_res["accuracy"])

    df["pred"] = best_ypred
    avg_loss = total_loss / batch_id
    err_rate = total_err / (batch_id * eval_batch_size)  # total_err 目前始终为 0，可根据需要计算

    return avg_loss, err_rate, eval_res




def eval_binary_regression_model(model, tokenizer, text_batch, device="cuda"):
    """
    评估阶段：适用于训练集标签为小数 [0,1] 的回归式二分类模型
    模型输出 logits 为 [batch,2]（不能改模型结构）

    Args:
        model: 输出 logits，shape=[batch,2] 或 [batch,1]
        tokenizer: tokenizer 对象
        text_batch: {"texts": [...], "target": [...]}
        device: 设备

    Returns:
        loss: float
        probs: Tensor, [batch], 概率
    """
    model.eval()
    with torch.no_grad():
        # Tokenize
        text_encodings = tokenizer(
            text_batch["texts"],
            padding=True,
            truncation=True,
            max_length=128,
            return_tensors="pt"
        ).to(device)

        # 目标标签
        targets = torch.FloatTensor(text_batch["target"]).to(device)  # [batch]

        # 前向传播
        logits = model(**text_encodings)  # [batch,2] 或 [batch,1]
        
        if logits.dim() == 2 and logits.size(1) == 1:
            # 原来的 [batch,1] 输出
            logits = logits.squeeze(-1)  # [batch]
            loss = nn.BCEWithLogitsLoss()(logits, targets)
            probs = torch.sigmoid(logits).detach().cpu()
        elif logits.dim() == 2 and logits.size(1) == 2:
            # [batch,2] 输出：取正类 logits
            pos_logits = logits[:, 1]
            loss = nn.BCEWithLogitsLoss()(pos_logits, targets)
            probs = torch.sigmoid(pos_logits).detach().cpu()
        else:
            raise ValueError(f"Unexpected logits shape: {logits.shape}")

    return loss.item(), probs




def train_binary_classification_model_with_cross_entropy(model, tokenizer, optimizer, text_batch, is_multi_task=False):
    """对输入的模型进行二分类训练。

    Args:
        model: 
            要求输出为logits

        text_batch: 
            {
                texts:      ["", "", ...], 

                targets_0:  ["", "", ...],

                ...
            }

        is_multi_task: 
            是否多任务（目前支持两任务）

    Returns:
        loss: 当前batch的平均loss
    """

    # Start Training
    model.train()
    optimizer.zero_grad()
    criterion = nn.CrossEntropyLoss()

    # is_multi_task
    if is_multi_task:
        # Load Data
        text_encodings = tokenizer(text_batch["texts"], padding=True,
                                   truncation=True, max_length=128, return_tensors="pt")
        targets_0 = torch.LongTensor(text_batch["targets_0"])
        targets_1 = torch.LongTensor(text_batch["targets_1"])
        text_encodings = text_encodings.to(device)
        targets_0 = targets_0.to(device)
        targets_1 = targets_1.to(device)

        # Forward
        logits_0, logits_1 = model(**text_encodings)
        loss = criterion(logits_0, targets_0) + criterion(logits_1, targets_1) * 0.5

    else:
        # Load Data
        text_encodings = tokenizer(text_batch["texts"], padding=True,
                                   truncation=True, max_length=128, return_tensors="pt")
        targets_0 = torch.LongTensor(text_batch["targets_0"])
        text_encodings = text_encodings.to(device)
        targets_0 = targets_0.to(device)

        # Forward
        logits = model(**text_encodings)
        loss = criterion(logits, targets_0)

    # Backward
    loss.backward()
    optimizer.step()

    return loss

import torch
import torch.nn as nn

def train_binary_regression_model(model, tokenizer, optimizer, text_batch, is_multi_task=False, device="cuda"):
    """
    对输入的模型进行二分类（回归形式）训练。
    标签为连续值 [0,1]，使用 BCEWithLogitsLoss。

    Args:
        model: 输出为单个logit的模型 (或多任务输出)
        tokenizer: 分词器
        optimizer: 优化器
        text_batch: dict {
            "texts": [...],
            "targets_0": [...],
            "targets_1": [...] (仅多任务模式)
        }
        is_multi_task: 是否多任务
        device: GPU / CPU

    Returns:
        loss: 当前batch的平均loss
    """
    model.train()
    optimizer.zero_grad()
    criterion = nn.BCEWithLogitsLoss()

    # Tokenize 输入文本
    text_encodings = tokenizer(
        text_batch["texts"],
        padding=True,
        truncation=True,
        max_length=128,
        return_tensors="pt"
    ).to(device)

    if is_multi_task:
        # 多任务标签
        targets_0 = torch.FloatTensor(text_batch["targets_0"]).to(device)
        targets_1 = torch.FloatTensor(text_batch["targets_1"]).to(device)

        # 前向传播
        logits_0, logits_1 = model(**text_encodings)
        logits_0 = _reshape_logits(logits_0)
        logits_1 = _reshape_logits(logits_1)

        # 计算 loss
        loss_0 = criterion(logits_0, targets_0)
        loss_1 = criterion(logits_1, targets_1)
        loss = loss_0 + 0.5 * loss_1

    else:
        # 单任务
        targets_0 = torch.FloatTensor(text_batch["targets_0"]).to(device)
        logits = model(**text_encodings)
        logits = _reshape_logits(logits)
        loss = criterion(logits, targets_0)

    # 反向传播
    loss.backward()
    optimizer.step()

    return loss.item()


def _reshape_logits(logits):
    """
    调整模型输出 logits 的形状，保证与 target shape 匹配
    """
    if logits.dim() == 0:
        # batch=1, 输出标量 -> [1]
        logits = logits.unsqueeze(0)
    elif logits.dim() == 2 and logits.size(1) == 1:
        # [batch,1] -> [batch]
        logits = logits.squeeze(-1)
    elif logits.dim() == 2 and logits.size(1) == 2:
        # 二分类 one-hot 输出 [batch,2] -> 取正类 logit
        logits = logits[:, 1]
    return logits



def train_vector_binary_classification_model_with_cross_entropy(vector_model, model, tokenizer, optimizer, text_batch):
    """对输入的模型进行二分类训练。

    Args:
        model: 
            要求输出为logits

        text_batch: 
            {
                texts:      ["", "", ...], 

                targets_0:  ["", "", ...],

                ...
            }

        is_multi_task: 
            是否多任务（目前支持两任务）

    Returns:
        loss: 当前batch的平均loss
    """

    # Start Training
    model.train()
    optimizer.zero_grad()
    criterion = nn.CrossEntropyLoss()

    # is_multi_task
    # if is_multi_task:
    #     # Load Data
    #     text_encodings = tokenizer(text_batch["texts"], padding=True, truncation=True, max_length=128, return_tensors="pt")
    #     targets_0 = torch.LongTensor(text_batch["targets_0"])
    #     targets_1 = torch.LongTensor(text_batch["targets_1"])
    #     text_encodings = text_encodings.to(device)
    #     targets_0 = targets_0.to(device)
    #     targets_1 = targets_1.to(device)

    #     # Forward
    #     logits_0, logits_1 = model(**text_encodings)
    #     loss = criterion(logits_0, targets_0) + criterion(logits_1, targets_1) * 0.5

    # Load Data
    with torch.no_grad():
        text_encodings = tokenizer(text_batch["texts"], padding=True,
                                   truncation=True, max_length=128, return_tensors="pt")
        text_encodings = text_encodings.to(device)
        vectors = vector_model(**text_encodings)
        vectors = torch.reshape(vectors, (-1, 2, 768))
    targets_0 = torch.LongTensor(text_batch["targets_0"])
    targets_0 = targets_0.to(device)

    # Forward
    logits = model(vectors)
    loss = criterion(logits, targets_0)

    # Backward
    loss.backward()
    optimizer.step()

    return loss


def finetune_cross_encoder_on_the_fly(tokenizer_dir="./mengzi-bert-base",
                                      input_model_dir="./mengzi-bert-base",
                                      output_model_dir="./output/mengzi_pretrain_model.bin",
                                      train_dataset_dir="./data/train_shuffle.tsv",
                                      eval_dataset_dir="./data/eval_shuffle.tsv",
                                      lr=5e-5,
                                      epochs=2,
                                      train_batch_size=512,
                                      eval_batch_size=512,
                                      data_type="pair",
                                      model_type="bert",
                                      has_pretrained=True,
                                      is_multi_task=True):
    """通过流式加载数据方式 & cross-encoder架构微调相似度计算模型。

    Args:
        data_type:

            `"pair"`: 表示输入格式为 [CLS]text_a[SEP]text_b[SEP]

            `"reference"`: 表示输入格式为 [CLS]text_a[SEP]text_b[SEP]reference_text[SEP]

        model_type:

            `"bert"`: 表示输入模型为bert类

            `"t5_encoder"`: 表示输入模型为t5_encoder类

        is_multi_task: 表示是否为多任务学习
    """
    # 在 Fine-tune on-the-fly 注释后添加：
    total_lines = sum(1 for _ in open(train_dataset_dir, "r", encoding="utf-8"))

    # Timer
    start = time.time()
    dir_name = os.path.dirname(output_model_dir)
    # 判断文件夹是否存在，不存在则创建
    if not os.path.exists(dir_name):
        os.makedirs(dir_name, exist_ok=True)
    print('### Finetune {} Started! ###'.format(output_model_dir))

    # Load Model Parameters
    if has_pretrained:
        pretrained_model = torch.load(input_model_dir, map_location=device, weights_only=False)
    else:
        bert = BertModel.from_pretrained(input_model_dir)
        pretrained_model = BertForClassification(bert)

    if is_multi_task:
        if model_type == "bert":
            model = BertForMultiClassification(bert=pretrained_model.encoder, decoder_0=pretrained_model.decoder_0)
        elif model_type == "t5_encoder":
            model = T5EncoderForMultiClassification(
                t5_encoder=pretrained_model.encoder, decoder_0=pretrained_model.decoder_0)
        else:
            raise ()
    else:
        model = pretrained_model
        model = nn.DataParallel(model)
        model = model.to(device)
        model.dropout = nn.Dropout(0.2)

    # Initialize Tokenizer & Optimizer
    tokenizer = BertTokenizerFast.from_pretrained(tokenizer_dir, do_lower_case=True)
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
    # label2tensor = {"0": torch.tensor(0), "0.0": torch.tensor(0), "1": torch.tensor(
        # 1), "1.0": torch.tensor(1), "0.1": torch.tensor(0), "0.6": torch.tensor(0), "0.95": torch.tensor(1)}

    # Initialize Variables
    text_list = []
    label_list_0 = []
    label_list_1 = []
    count = 0
    batch_id = 0
    min_loss = 100
    best_checkpoint = model
    # Fine-tune on-the-fly
    for epoch in range(epochs):
        with open(train_dataset_dir, "r", encoding="utf-8") as train_dataset_file:
            pbar = tqdm(train_dataset_file, total=total_lines, 
               desc=f"Epoch {epoch+1}/{epochs}", unit="samples")
            for line in pbar:
                # Load Data
                line_list = line.replace("\n", "").split("\t")
                if len(line_list) < 3:
                    continue

                # check label
                human_label = line_list[2]
                if human_label in ["label"]:
                    continue
                human_label = str(human_label).strip()  # 保持原样，只是确保是字符串并去除空格
                # if human_label not in ["0", "1", "label"]:
                #     continue

                if data_type == "pair":
                    # if human_label in label2tensor:
                    #     pass
                    # else:
                    #     continue
                    if torch.rand(1) < 0.5:
                        text_list.append("[SEP]".join([line_list[0], line_list[1]]))
                    else:
                        text_list.append("[SEP]".join([line_list[1], line_list[0]]))
                    label_list_0.append(float(human_label))
                elif data_type == "reference":
                    # if human_label in label2tensor:
                    #     pass
                    # else:
                    #     continue
                    text_list.append("[SEP]".join([line_list[0], line_list[1], line_list[3]]))
                    label_list_0.append(float(human_label))
                else:
                    raise ()

                if is_multi_task:
                    # if line_list[4] in label2tensor:
                    #     pass
                    # else:
                    #     continue
                    label_list_1.append(line_list[4])

                # Train
                count = count + 1
                if count <= train_batch_size - 1:
                    continue
                else:
                    text_batch = {
                        "texts": text_list,
                        "targets_0": label_list_0,
                        "targets_1": label_list_1
                    }
                    current_batch_loss = train_binary_regression_model(model,
                                                                                              tokenizer,
                                                                                              optimizer,
                                                                                              text_batch,
                                                                                              is_multi_task)
                    # print(
                    #     "|epoch {:2d}|batch {:4d}"
                    #     "|loss {:5.5f}|".format(
                    #         i + 1,
                    #         batch_id,
                    #         current_batch_loss
                    #     )
                    # )
                    # 在原来的 print 语句位置，改为：
                    pbar.set_postfix({
                        'batch': batch_id, 
                        'loss': f'{current_batch_loss:.5f}'
                    })
                    count = 0
                    text_list = []
                    label_list_0 = []
                    label_list_1 = []
                    batch_id = batch_id + 1
                    try:
                        if batch_id % 512 == 0:
                            model_checkpoint = BertForClassification(model.module.bert, model.module.decoder)
                            torch.save(model_checkpoint, output_model_dir+"_"+str(batch_id)+"batch")
                            eval_loss, eval_res = eval_cross_encoder_on_the_fly(model=model_checkpoint,
                                                                                tokenizer=tokenizer,
                                                                                data_type=data_type,
                                                                                eval_batch_size=eval_batch_size,
                                                                                eval_dataset_dir=eval_dataset_dir)
                            # pdb.set_trace()
                            if eval_loss < min_loss:
                                best_checkpoint = model_checkpoint
                                min_loss = eval_loss
                    except Exception as e:
                        print(e)
                        print("Evaluation Failed")
            if count != 0:
                # 不足一个batch加训一轮
                pass
    # 保存最后checkpoint
    model_checkpoint = BertForClassification(model.module.bert, model.module.decoder)
    torch.save(model_checkpoint, output_model_dir)
    # 保存最优checkpoint
    eval_loss, eval_res = eval_cross_encoder_on_the_fly(model=model_checkpoint,
                                                        tokenizer=tokenizer,
                                                        data_type=data_type,
                                                        eval_batch_size=eval_batch_size,
                                                        eval_dataset_dir=eval_dataset_dir)
    # pdb.set_trace()
    if eval_loss < min_loss:
        best_checkpoint = model_checkpoint
    torch.save(best_checkpoint, output_model_dir+"_optimal_epoch")

    # Timer
    duration = (time.time() - start) / 60
    print('### Finetune {} Finished in {:d} min! ###'.format(output_model_dir, int(duration)))


def finetune_vector_encoder_on_the_fly(tokenizer_dir="/workspace/embedding/bge-base-zh",
                                       vector_embedding_model_dir="/workspace/embedding/bge-base-zh",
                                       train_dataset_dir="/workspace/rescore-model-pipeline/rescore-data-0913/train_shuffled.tsv",
                                       output_model_dir="/workspace/rescore-model-pipeline/output/vector_encoder_pair_230919.bin",
                                       lr=5e-6,
                                       epochs=1,
                                       train_batch_size=1024,
                                       data_type="pair",
                                       is_multi_task=False):
    """通过流式加载数据方式 & poly-encoder架构微调相似度计算模型。

    Args:
        data_type:

            `"pair"`: 表示输入格式为 [CLS]text_a[SEP]text_b[SEP]

            `"reference"`: 表示输入格式为 [CLS]text_a[SEP]text_b[SEP]reference_text[SEP]

        model_type:

            `"bert"`: 表示输入模型为bert类

            `"t5_encoder"`: 表示输入模型为t5_encoder类

        is_multi_task: 表示是否为多任务学习
    """

    # Timer
    start = time.time()
    print('### Finetune {} Started! ###'.format(output_model_dir))

    # Load Model Parameters
    vector_model = torch.load(vector_embedding_model_dir, map_location=device)
    model = TransformerForVectorMatching(768, 12, 16)
    model.dropout = nn.Dropout(0.2)
    model = model.to(device)

    # Initialize Tokenizer & Optimizer
    tokenizer = BertTokenizerFast.from_pretrained(tokenizer_dir, do_lower_case=True)
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
    label2tensor = {"0": torch.tensor(0), "0.0": torch.tensor(0), "1": torch.tensor(
        1), "1.0": torch.tensor(1), "0.1": torch.tensor(0), "0.6": torch.tensor(0), "0.95": torch.tensor(1)}

    # Initialize Variables
    text_list = []
    label_list_0 = []
    label_list_1 = []
    count = 0
    batch_id = 0

    # Fine-tune on-the-fly
    for i in range(epochs):
        with open(train_dataset_dir, "r", encoding="utf-8") as train_dataset_file:
            for line in train_dataset_file:
                # Load Data
                line_list = line.replace("\n", "").split("\t")
                if len(line_list) < 3:
                    continue

                # check label
                human_label = line_list[2]
                if human_label in ["label"]:
                    continue
                # human_label = "1" if human_label == "yes" else "0"
                human_label = str(human_label).strip()  # 保持原样，只是确保是字符串并去除空格
                # if human_label not in ["0", "1", "label"]:
                #     continue 

                if data_type == "pair":
                    if human_label in label2tensor:
                        pass
                    else:
                        continue
                    if torch.rand(1) < 0.5:
                        text_list.append(line_list[0])
                        text_list.append(line_list[1])
                    else:
                        text_list.append(line_list[1])
                        text_list.append(line_list[0])
                    label_list_0.append(label2tensor[human_label])
                # elif data_type == "reference":
                #     if human_label in label2tensor:
                #         pass
                #     else:
                #         continue
                #     text_list.append("[SEP]".join([line_list[0], line_list[1], line_list[3]]))
                #     label_list_0.append(label2tensor[human_label])
                else:
                    raise ()

                if is_multi_task:
                    if line_list[4] in label2tensor:
                        pass
                    else:
                        continue
                    label_list_1.append(label2tensor[line_list[4]])

                # Train
                count = count + 1
                if count <= train_batch_size - 1:
                    continue
                else:
                    text_batch = {
                        "texts": text_list,
                        "targets_0": label_list_0,
                        "targets_1": label_list_1
                    }
                    current_batch_loss = train_vector_binary_classification_model_with_cross_entropy(
                        vector_model,
                        model,
                        tokenizer,
                        optimizer,
                        text_batch)
                    print(
                        "|epoch {:2d}|batch {:4d}"
                        "|loss {:5.5f}|".format(
                            i + 1,
                            batch_id,
                            current_batch_loss
                        )
                    )
                    count = 0
                    text_list = []
                    label_list_0 = []
                    label_list_1 = []
                    batch_id = batch_id + 1

        # Eval per epoch
        model_checkpoint = model
        torch.save(model_checkpoint, output_model_dir+"_"+str(i)+"epoch")
        # eval_loss = eval_cross_encoder_on_the_fly(model=model_checkpoint,
        #                                             tokenizer=tokenizer,
        #                                             data_type=data_type,
        #                                             eval_batch_size=eval_batch_size,
        #                                             eval_dataset_dir=eval_dataset_dir)

    # Timer
    duration = (time.time() - start) / 60
    print('### Finetune {} Finished in {:d} min! ###'.format(output_model_dir, int(duration)))


def eval_cross_encoder_on_the_fly_in_train(model, tokenizer, data_type, eval_batch_size=512, eval_dataset_dir="./data/eval_shuffle.tsv"):
    # Initialize Variables
    text_list = []
    label_list = []
    count = 0
    batch_id = 0
    total_loss = 0.0
    label2tensor = {"0.0": torch.tensor(0), "1.0": torch.tensor(1),"0": torch.tensor(0), "1": torch.tensor(1)}

    # Evaluate on-the-fly
    with open(eval_dataset_dir, "r", encoding="utf-8") as eval_dataset_file:
        for line in eval_dataset_file:
            # Load Data
            line_list = line.replace("\n", "").split("\t")

            # check label
            human_label = line_list[2]
            if human_label in ["label"]:
                continue
            # human_label = "1" if human_label == "yes" else "0"
            human_label = str(human_label).strip()  # 保持原样，只是确保是字符串并去除空格
            # if human_label not in ["0", "1", "label"]:
            #     continue 

            if data_type == "pair":
                text_list.append("[SEP]".join([line_list[0], line_list[1]]))
                label_list.append(label2tensor[human_label])
            elif data_type == "reference":
                text_list.append("[SEP]".join([line_list[0], line_list[1], line_list[3]]))
                label_list.append(label2tensor[human_label])
            else:
                raise ()

            # Evaluate
            count = count + 1
            if count <= eval_batch_size - 1:
                continue
            else:
                text_batch = {
                    "texts": text_list,
                    "target": label_list
                }
                current_batch_loss = eval_binary_regression_model(model, tokenizer, text_batch)
                print(
                    "|batch {:4d}"
                    "|loss {:5.5f}|".format(
                        batch_id,
                        current_batch_loss
                    )
                )
                count = 0
                text_list = []
                label_list = []
                batch_id = batch_id + 1
                total_loss = total_loss + current_batch_loss

    avg_loss = total_loss / batch_id
    return avg_loss


def eval_binary_classification_model_with_cross_entropy(model, tokenizer, text_batch):
    model.eval()
    with torch.no_grad():

        # Load Data
        criterion = nn.CrossEntropyLoss()
        train_text_encodings = tokenizer(text_batch["texts"], padding=True,
                                        truncation=True, max_length=128, return_tensors="pt")
        targets = torch.LongTensor(text_batch["target"])
        train_text_encodings = train_text_encodings.to(device)
        targets = targets.to(device)

        # Forward
        logits = model(**train_text_encodings)
        loss = criterion(logits, targets)

        softmax = nn.Softmax(dim=-1)
        prob = softmax(logits)
        similarity_tensor = torch.narrow(prob, 1, 1, 1)
        similarity_tensor = torch.squeeze(similarity_tensor, 1)
        return loss.item(), similarity_tensor.to("cpu").detach().numpy()
        # return loss.item()


def train_text_embedding_model_with_cosine_embedding(model, tokenizer, optimizer, text_batch):
    """对输入的模型进行余弦相似度训练。

    Args:

        text_batch: 
            {
                texts_a:      ["", "", ...], 

                texts_b:      ["", "", ...], 

                targets:  ["", "", ...],

                ...
            }

    Returns:
        loss: 当前batch的平均loss
    """

    # Start Training
    model.train()
    optimizer.zero_grad()
    criterion = nn.CosineEmbeddingLoss(margin=0.2)

    # Load Data
    text_encodings_a = tokenizer(text_batch["texts_a"], padding=True,
                                 truncation=True, max_length=128, return_tensors="pt").to(device)
    text_encodings_b = tokenizer(text_batch["texts_b"], padding=True,
                                 truncation=True, max_length=128, return_tensors="pt").to(device)
    targets = torch.LongTensor(text_batch["targets"]).to(device)

    # Forward
    text_embeddings_a = model(**text_encodings_a)
    text_embeddings_b = model(**text_encodings_b)
    loss = criterion(text_embeddings_a, text_embeddings_b, targets)

    # Backward
    loss.backward()
    optimizer.step()

    return loss


def finetune_bi_encoder_on_the_fly(tokenizer_dir="./mengzi-bert-base",
                                   input_model_dir="./mengzi-bert-base",
                                   output_model_dir="./output/mengzi_pretrain_model.bin",
                                   train_dataset_dir="./data/train_shuffle.tsv",
                                   eval_dataset_dir="./data/eval_shuffle.tsv",
                                   lr=5e-5,
                                   epochs=2,
                                   train_batch_size=512,
                                   eval_batch_size=512,
                                   checkpoint_step=10000,
                                   model_type="bert",
                                   has_pretrained=False,
                                   is_contrastive_learning=False):
    """通过流式加载数据方式 & bi-encoder架构微调相似度计算模型。

    Args:
        model_type:

            `"bert"`: 表示输入模型为bert类

            `"t5_encoder"`: 表示输入模型为t5_encoder类

        is_contrastive_learning: 表示是否为对比学习
    """
    # Timer
    start = time.time()
    print('### Finetune {} Started! ###'.format(output_model_dir))

    # Load Model Parameters
    if has_pretrained:
        model = torch.load(input_model_dir).to(device)
    else:
        if model_type == "bert":
            pretrained_model = BertModel.from_pretrained(input_model_dir).to(device)
            model = BertForClassification(pretrained_model).to(device)
            # model = pretrained_model.to(device)
            # model = BertForTextEmbedding(pretrained_model).to(device)
        else:
            raise ()

    # if model_type == "bert":
    #     pretrained_model = BertModel.from_pretrained(input_model_dir).to(device)
    #     model = BertForTextEmbedding(pretrained_model).to(device)
    # elif model_type == "t5_encoder":
    #     pretrained_model = T5EncoderModel.from_pretrained(input_model_dir, map_location=device)
    # else:
    #     raise()

    # Initialize Tokenizer & Optimizer
    tokenizer = BertTokenizerFast.from_pretrained(tokenizer_dir, do_lower_case=True)
    optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
    label2tensor = {"0": torch.tensor(-1), "1": torch.tensor(1), "0.0": torch.tensor(-1),
                    "0.1": torch.tensor(-1), "1.0": torch.tensor(1), "0.6": torch.tensor(-1), "0.95": torch.tensor(1)}

    # Initialize Variables
    text_list_a = []
    text_list_b = []
    label_list = []
    count = 0
    batch_id = 0

    # Fine-tune on-the-fly
    for i in range(epochs):
        with open(train_dataset_dir, "r", encoding="utf-8") as train_dataset_file:
            for line in train_dataset_file:
                # Load Data
                line_list = line.replace("\n", "").split("\t")
                if len(line_list) < 3:
                    continue

                # check label
                human_label = line_list[2]
                if human_label in ["label"]:
                    continue
                human_label = "1" if human_label == "yes" else "0"

                if human_label in label2tensor:
                    pass
                else:
                    continue

                text_list_a.append(line_list[0])
                text_list_b.append(line_list[1])
                label_list.append(label2tensor[human_label])

                # Train
                count = count + 1
                if count <= train_batch_size - 1:
                    continue
                else:
                    text_batch = {
                        "texts_a": text_list_a,
                        "texts_b": text_list_b,
                        "targets": label_list
                    }
                    current_batch_loss = train_text_embedding_model_with_cosine_embedding(
                        model, tokenizer, optimizer, text_batch)
                    print(
                        "|epoch {:2d}|batch {:4d}"
                        "|loss {:5.5f}|".format(
                            i + 1,
                            batch_id,
                            current_batch_loss
                        )
                    )
                    count = 0
                    text_list_a = []
                    text_list_b = []
                    label_list = []
                    batch_id = batch_id + 1
        torch.save(model, output_model_dir+"_epoch_"+str(i))

    # Timer
    duration = (time.time() - start) / 60
    print('### Finetune {} Finished in {:d} min! ###'.format(output_model_dir, int(duration)))


def pt2onnx(pt_dir, onnx_dir, batch_size=50, text_length=96):
    model = torch.load(pt_dir, map_location=device)
    data = torch.zeros(batch_size, text_length, device=device).long()
    input_ids = attention_mask = token_type_ids = data
    pseudo_input = (input_ids, attention_mask, token_type_ids)
    torch.onnx.export(model,
                      pseudo_input,
                      onnx_dir,
                      opset_version=12,
                      do_constant_folding=True,
                      input_names=['input_ids', 'attention_mask', 'token_type_ids'],
                      output_names=['output'],
                      dynamic_axes={
                          'input_ids': {0: 'N', 1: 'L'},
                          'attention_mask': {0: 'N', 1: 'L'},
                          'token_type_ids': {0: 'N', 1: 'L'},
                          'output': {0: 'N'}
                      }
                      )


if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument("--train_stage", type=int, help="Use --train_stage 1 or 2.")

    parser.add_argument("--tokenizer_dir", help="embedding model path", type=str)
    parser.add_argument("--model_dir", help="embedding model path", type=str)
    parser.add_argument("--data_dir", help="input dataset path", type=str)
    parser.add_argument("--outmodel_dir", help="output embedding path", type=str)
    parser.add_argument("--has_pretrained", help="whether the model has been pretrained", type=str)
    parser.add_argument("--epochs", help="number of training epochs", type=int)
    parser.add_argument("--eval_dataset_dir", help="evaluation dataset path", type=str)
    parser.add_argument("--lr", help="learning rate", type=float)
    parser.add_argument("--train_batch_size", help="training batch size", type=int)
    parser.add_argument("--eval_batch_size", help="evaluation batch size", type=int)

    if parser.parse_args().train_stage == 1:
        parser.add_argument("--two_model_dir", type=str, default=None, help="stage 2 model path")
        parser.add_argument("--two_data_dir", type=str, default=None, help="stage 2 training data path")
        parser.add_argument("--two_outmodel_dir", type=str, default=None, help="stage 2 output model path")
        parser.add_argument("--two_epochs", type=int, default=None, help="stage 2 training epochs")
        parser.add_argument("--two_eval_dataset_dir", type=str, default=None, help="stage 2 eval dataset path")
        parser.add_argument("--two_lr", type=float, default=None, help="stage 2 learning rate")
        parser.add_argument("--two_train_batch_size", help="training batch size", type=int)
        parser.add_argument("--two_eval_batch_size", help="evaluation batch size", type=int)
    args = parser.parse_args()

    finetune_cross_encoder_on_the_fly(
        tokenizer_dir=args.tokenizer_dir,
        input_model_dir=args.model_dir,  # 使用命令行参数
        output_model_dir=args.outmodel_dir,  # 使用命令行参数
        train_dataset_dir=args.data_dir,  # 使用命令行参数
        eval_dataset_dir=args.eval_dataset_dir,  # 使用命令行参数
        lr=args.lr,  # 使用命令行参数
        epochs=args.epochs,  # 使用命令行参数
        train_batch_size=args.train_batch_size,  # 使用命令行参数
        eval_batch_size=args.eval_batch_size,  # 使用命令行参数
        data_type="pair",
        model_type="bert",
        is_multi_task=False,
        has_pretrained=args.has_pretrained.lower() == "true"  # 将字符串转换为布尔值
    )

    if args.train_stage == 2:
        finetune_cross_encoder_on_the_fly(
            tokenizer_dir=args.tokenizer_dir,
            input_model_dir=args.two_model_dir,  # 使用命令行参数
            output_model_dir=args.two_outmodel_dir,  # 使用命令行参数
            train_dataset_dir=args.two_data_dir,  # 使用命令行参数
            eval_dataset_dir=args.two_eval_dataset_dir,  # 使用命令行参数
            lr=args.two_lr,  # 使用命令行参数
            epochs=args.two_epochs,  # 使用命令行参数
            train_batch_size=args.two_train_batch_size,  # 使用命令行参数
            eval_batch_size=args.two_eval_batch_size,  # 使用命令行参数
            data_type="pair",
            model_type="bert",
            is_multi_task=False,
            has_pretrained=True
        )
