from utils.file_utils import read_jsonl_file
import pdb
import csv
if __name__ == "__main__":

    path = "data/cloud_share/qabot_relevance_data/trainset/train_pair.json"
    output_tsv_file = "data/cloud_share/qabot_relevance_data/trainset/train_pair.tsv"
    data = read_jsonl_file(path)
    # pdb.set_trace()
    with open(output_tsv_file, 'w', newline='', encoding='utf-8') as tsv_file:
        writer = csv.writer(tsv_file, delimiter='\t')
        for sample in data:
            # 提取字段
            query = sample.get('sentence1', '')
            question = sample.get('sentence2', '')
            label = sample.get('label', '')

            # 写入 TSV 文件
            writer.writerow([query, question, label])
