from asyncio import Semaphore
from utils.llm_utils.serverless_function import request_llm_async, RateLimiter
from utils.file_utils import read_jsonl_file
import json
from tqdm import tqdm
import pandas as pd
import numpy as np
from search.qa_bot.service_bot_relevance.example.set_train.prompt import *
import asyncio
import aiohttp
import os
from tqdm.asyncio import tqdm_asyncio
from utils.search_utils.semantic_deduplicate import compute_similarity


class GeneralSpecial:
    """
    """

    def __init__(self):
        # --- 配置参数 ---
        # 模型配置
        self.model_name = "gpt-4o"  # 可选模型: gpt-4o | claude-3_5-sonnet | deepseek-v3 | deepseek-r1 | deepseek-r1-distill-qwen-32b
        # 并发控制
        self.max_concurrent = 10  # 最大并发数（控制资源消耗）
        self.qps = 3              # 请求频率限制（建议≤4）

    def load_data(self):
        df = pd.DataFrame()
        logs_path = "data/cloud/search/qa_bot/qa_bot_test_by_week/"
        for dir in tqdm(os.listdir(logs_path)):
            path = os.path.join(logs_path, dir, "step3_real_and_relevance_ica.xlsx")
            if os.path.exists(path):
                tmp_df = pd.read_excel(path)
                df = pd.concat([df, tmp_df], ignore_index=True)

        logs_path = "data/cloud/search/qa_bot/qa_bot_test/"
        for dir in tqdm(os.listdir(logs_path)):
            path = os.path.join(logs_path, dir, "step3_real_and_relevance_ica.jsonl")
            if os.path.exists(path):
                tmp_df = pd.DataFrame(read_jsonl_file(path))
                df = pd.concat([df, tmp_df], ignore_index=True)
        df = df.dropna(subset=["query", "hitQuestion"])
        return df

    def re_filter(self, df, pattern_general, pattern_special):
        """
        给df添加semantic label，为1代表query和hitQuestion为相同类型的问法，为0则不同
        res_df:存在一般疑问的case
        unfiltered_df:都为特殊疑问的case（不使用）
        """
        # 默认为特殊疑问
        df.loc[:, 'query_semantic_label'] = 0
        df.loc[:, 'question_semantic_label'] = 0
        # 一般疑问
        df.loc[~df["query"].str.contains(pattern_special, regex=True) &
               df["query"].str.contains(pattern_general, regex=True),
               'query_semantic_label'] = 1
        df.loc[~df["hitQuestion"].str.contains(pattern_special, regex=True) &
               df["hitQuestion"].str.contains(pattern_general, regex=True),
               'question_semantic_label'] = 1
        df.loc[:, "semantic_label"] = [1 if item["query_semantic_label"] == item["question_semantic_label"]
                                       else 0 for item in df.iloc]
        # 去重
        df = df.drop_duplicates(subset=['query', 'hitQuestion'])
        # 去除都为特殊疑问的case
        res_df = df[(df["query_semantic_label"] > 0) | (df["question_semantic_label"] > 0)]
        unfiltered_df = df[(df["query_semantic_label"] == 0) & (df["question_semantic_label"] == 0)]
        # # 后处理
        # res_df = res_df[["query", "hitQuestion", "label", "semantic_label"]].reset_index(drop=True)
        # unfiltered_df = unfiltered_df[["query", "hitQuestion", "label", "semantic_label"]].reset_index(drop=True)
        return res_df, unfiltered_df

    def process(self, input_list, batch_size=16):
        # 分batch进行输入
        batches = np.array_split(input_list, len(input_list) // batch_size)
        loop = asyncio.get_event_loop()
        res = loop.run_until_complete(self.process_async(batches, max_retries=3))
        return pd.concat(res)

    async def process_async(self, input_list, max_retries):
        rate_limiter = RateLimiter(self.qps)
        semaphore = Semaphore(self.max_concurrent)  # 限制最大并发数为 max_concurrent
        async with aiohttp.ClientSession() as session:
            tasks = [self.process_item_async(rate_limiter, semaphore, session, item, max_retries) for
                     item in input_list]
            results = [None] * len(tasks)
            task_objects = [asyncio.create_task(task) for task in tasks]
            for idx, task in tqdm_asyncio(zip(range(len(tasks)), task_objects), total=len(tasks)):
                response = await task
                # 根据任务的索引存储结果
                results[idx] = response
        return results

    async def process_item_async(self, rate_limiter, semaphore, session, item, max_retries):
        input_list = []
        for input in item.iloc:
            if input["query_semantic_label"] * input["question_semantic_label"] == 0:
                input_list.append({
                    "query": input["query"],
                    "question": input["hitQuestion"],
                    "label": input["semantic_label"]
                })
        if input_list == []:
            return item
        history = [
            GENERAL_SPECIAL_PROMPT,
            GENERAL_SPECIAL_USER_PROMPT.format(query=input_list)
        ]

        # 4. 调用LLM进行判断
        try:
            payload, response_data = await request_llm_async(
                rate_limiter,
                semaphore,
                session,
                max_retries,
                history,
                model=self.model_name,
                n=1,
                temperature=0
            )
            question_new_str = response_data["choices"][0]["message"]["content"]
            question_new_list = json.loads(question_new_str)
        except Exception as e:
            question_new_list = []
            try:
                # 尝试修复格式错误
                question_new_list = json.loads(question_new_str.strip().strip(
                    '`').replace("json", '').replace("\n", ""))
            except Exception as e:
                print("llm-api调用失败")
                return item

        # 5. 回写判断结果
        for res in question_new_list:
            try:
                item.loc[
                    (item['query'] == res['query']) & (item['hitQuestion'] == res['question']),
                    ['query_semantic_label', 'question_semantic_label']] = res['query_semantic_label'], res['question_semantic_label']
                orig_label = item.loc[
                    (item['query'] == res['query']) & (item['hitQuestion'] == res['question']),
                    'semantic_label']
                gpt_label = 1 if res['query_semantic_label'] == res['question_semantic_label'] else 0
                if orig_label.values[0] != gpt_label:
                    item.loc[
                        (item['query'] == res['query']) & (item['hitQuestion'] == res['question']),
                        'semantic_label'] = gpt_label
                    print(f"<{res['query']},{res['question']}> semantic_label修改为{gpt_label}")
            except Exception as e:
                print(f"!!Warning!!: <{res['query']},{res['question']}> semantic_label修改失败")
        return item


if __name__ == "__main__":
    obj = GeneralSpecial()
    # 加载日志数据，构造训练集
    df = obj.load_data()
    # # 加载train_shuffled，构造测试集
    # df = pd.read_csv("data/cloud_share/qabot_relevance_data/trainset/train_shuffled.tsv",
    #                  sep='\t', on_bad_lines='skip', header=None, nrows=10000)
    # df.rename(columns={df.columns[0]: 'query', df.columns[1]: 'hitQuestion', df.columns[2]: 'label'}, inplace=True)
    # df["label"] = [1 if i > 0.5 else 0 for i in df["label"].to_list()]
    # 正则过滤
    pattern_general = r'(?:是否|能否|有没有|能不能|是不是|用不用|会不会|该不该|可不可以|要不要|行不行|对不对|好不好|了吗|了没有|' \
        r'(?:.*(?:在|可以|支持|有|是|会|能|需要).*(?:吗|么|嘛)[。？！?.!]?$)|' \
        r'(?:.*是.*还是.*)|' \
        r'(?:着|了)(?:吗|么)[。？！?.!]?$)'
    pattern_special = r'(?:有多少|在哪里|在哪儿|怎么|是多少|什么|是干嘛)'

    res_df, unfiltered_df = obj.re_filter(df, pattern_general, pattern_special)
    # 后处理
    res_df['label'] = res_df['label'].astype(float)
    # 拼接未被过滤的数据
    unfiltered_df = pd.concat([unfiltered_df,
                               res_df[(res_df["semantic_label"] == 1) | (res_df["label"] < 0.5)]],  # 保留semantic_label为1，或本身label就为0的case；剩下semantic_label为0且label为1的被过滤
                              ignore_index=True)
    # 保留原有正例作为测试集
    res_df = res_df[res_df["label"] == 1]
    # # semantic label校验
    res_df = obj.process(res_df)
    # label合并
    res_df["label"] = [int(min(item["label"], item["semantic_label"])) for item in res_df.iloc]
    res_df = res_df[["query", "hitQuestion", "label"]]

    # 补充模型打分-作为分析
    # score = compute_similarity(question_list=res_df["hitQuestion"].to_list(), query_list=res_df["query"].to_list())
    # score = score[:, :, 1][0]
    # res_df["score"] = score
    # 保存
    # unfiltered_df.to_csv(save_path, index=False, sep='\t', header=False)
    save_path = "data/cloud_share/qabot_relevance_data/trainset/general_special_question.tsv"
    res_df.to_csv(save_path, index=False, sep='\t', header=False)
