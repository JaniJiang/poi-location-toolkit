python step1_data_process.py
python step2_entity_positive.py

# 建议先人工分类，即把很相似的不同的词组放在一起，再做step3（step3逻辑较为简单和笼统）
python step3_entity_negative.py

nohup python -u ../eval/eval.py \
    --model_dir "../data/cloud_share/data_share/qabot_relevance_model/finish_model" \
    --eval_dataset_dir "../data/cloud_share/data_share/qabot_relevance_data/testset/v1_test_badcase.tsv" \
    --output_json "../data/cloud_share/data_share/qabot_relevance_data/onxx_model_score/v1_score.json" \
    --eval_onnx "true" > score.log 2>&1 &
# 会生成中间文件，人工选择打分超过0.5的作为负样本集（打分边界可以自选，根据数据量的大小来决定，如果0.5以上的太少了，可以逐渐降低）

'''
python step4_action_data_process.py

nohup python -u ../eval/eval.py \
    --model_dir "../data/cloud_share/data_share/qabot_relevance_model/finish_model" \
    --eval_dataset_dir "../data/cloud_share/data_share/qabot_relevance_data/testset/v1_test_badcase.tsv" \
    --output_json "../data/cloud_share/data_share/qabot_relevance_data/onxx_model_score/v1_score.json" \
    --eval_onnx "true" > score.log 2>&1 &
# 会生成中间文件，人工选择打分超过0.6的作为候选样本集（打分边界可以自选，根据数据量的大小来决定，如果0.6以上的太少了，可以逐渐降低）

# GPT标注
'''