import pandas as pd
import random

# 读取Excel文件
df = pd.read_excel("entities_matched_query.xlsx")

# 清洗数据
df = df.dropna(subset=["同义词"])  # 没有同义词的行跳过
df["同义词列表"] = df["同义词"].apply(lambda x: [s.strip() for s in str(x).split(",") if s.strip()])

# 按类型分组
type_groups = df.groupby("类型")

# 最终输出的负样本对
negative_pairs = []

# 遍历每种类型
for entity_type, group_df in type_groups:
    # 构建一个归一词 -> 同义词列表的映射
    canon2synonyms = {
        row["归一词"]: row["同义词列表"]
        for _, row in group_df.iterrows()
    }

    # 遍历同一类型下每一组归一词及其 query
    for _, row in group_df.iterrows():
        this_canon = row["归一词"]
        this_synonyms = row["同义词列表"]

        # 获取其他归一词组（不能是自己）
        other_canon_synonym_pairs = [
            (canon, syns)
            for canon, syns in canon2synonyms.items()
            if canon != this_canon
        ]

        # 遍历 query1~query10
        for i in range(1, 11):
            query_col = f"匹配到的 query{i}"
            if query_col not in row or pd.isna(row[query_col]):
                continue
            orig_query = row[query_col]

            # 找出原 query 中出现的实体
            used_entity = None
            for syn in this_synonyms:
                if syn in orig_query:
                    used_entity = syn
                    break
            if not used_entity:
                continue

            # 随机替换为其他归一词组中的一个实体，构造负样本
            for other_canon, other_syns in other_canon_synonym_pairs:
                if not other_syns:
                    continue
                replacement = random.choice(other_syns)
                neg_query = orig_query.replace(used_entity, replacement)
                if neg_query != orig_query:
                    negative_pairs.append((orig_query, neg_query))

# 输出结果
neg_df = pd.DataFrame(negative_pairs, columns=["original_query", "negative_query"])
neg_df.to_excel("generated_negative_query_pairs.xlsx", index=False)

print(f"共生成负样本数：{len(negative_pairs)} 对")
