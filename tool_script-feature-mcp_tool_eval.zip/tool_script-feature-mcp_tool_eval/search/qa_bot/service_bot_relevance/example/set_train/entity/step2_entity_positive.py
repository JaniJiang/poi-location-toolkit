import pandas as pd
import random
import re

# 加载 Excel 文件
df = pd.read_excel("entities_matched_query.xlsx")

# 存储最终结果
output_pairs = []

# 遍历每一行实体信息
for idx, row in df.iterrows():
    synonyms_str = row["同义词"]
    if pd.isna(synonyms_str):
        continue

    # 处理同义词列表
    synonyms = [s.strip() for s in synonyms_str.split(",") if s.strip()]
    if len(synonyms) < 2:
        continue  # 没有替换空间

    # 遍历匹配到的 query 列（query1 ~ query10）
    for i in range(1, 11):
        query_col = f"匹配到的 query{i}"
        if query_col not in row or pd.isna(row[query_col]):
            continue
        orig_query = row[query_col]

        # 在 query 中找出使用的实体
        used_entity = None
        for syn in synonyms:
            if syn in orig_query:
                used_entity = syn
                break
        if not used_entity:
            continue  # 没发现实体，跳过

        # 构造替换候选列表
        candidates = [s for s in synonyms if s != used_entity]
        if not candidates:
            continue

        # 随机选择最多 5 个替换实体
        selected = random.sample(candidates, min(5, len(candidates)))

        # 构造新 query 对
        for new_entity in selected:
            new_query = orig_query.replace(used_entity, new_entity)
            output_pairs.append((orig_query, new_query))

# 保存到新文件
output_df = pd.DataFrame(output_pairs, columns=["original_query", "new_query"])
output_df.to_excel("generated_query_pairs.xlsx", index=False)

print(f"共生成 {len(output_pairs)} 对 query")
