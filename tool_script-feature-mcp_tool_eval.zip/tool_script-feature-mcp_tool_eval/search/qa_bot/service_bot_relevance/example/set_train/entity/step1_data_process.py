import pandas as pd
import random
import os

# 读取实体表 Excel 文件
entity_df = pd.read_excel('entities.xlsx')

# 读取线上日志数据（TSV 文件，假设第一列是 query）
tsv_file_path = os.path.join('..', 'data', 'agg_train_set', 'train_shuffled.tsv')
log_queries = []
with open(tsv_file_path, 'r', encoding='utf-8') as f:
    for line in f:
        parts = line.strip().split('\t')
        if len(parts) >= 1:
            log_queries.append(parts[0])  # 只提取第一列的 query

# 将实体表中的同义词按组分组存储
entity_groups = []
for index, row in entity_df.iterrows():
    synonyms = str(row['同义词']).split('、')  # 根据实体表中同义词的分隔符进行分割
    entity_groups.append(synonyms)

# 准备存储匹配结果
results = []

# 遍历每组同义词进行匹配
for group_index, synonyms in enumerate(entity_groups):
    matched_queries = []
    # 随机选择 100 次同义词进行匹配
    for _ in range(100):
        if not synonyms:  # 跳过空的同义词组
            continue
        selected_entity = random.choice(synonyms)
        # 在日志数据中查找包含该实体的 query
        for query in log_queries:
            if selected_entity in query:
                matched_queries.append(query)
                break  # 找到一个匹配就跳出循环，进行下一次随机选择和匹配
        if len(matched_queries) == 10:
            break
    # 为当前组添加匹配的 query 列
    result_entry = {'组号': group_index}
    for i in range(10):
        result_entry[f'匹配到的 query{i+1}'] = matched_queries[i] if i < len(matched_queries) else ''
    results.append(result_entry)

# 将结果转换为 DataFrame
result_df = pd.DataFrame(results)

# 将结果保存到新的 Excel 文件中
output_excel_path = 'entities_matched_results.csv'
result_df.to_csv(output_excel_path, index=False)

print(f"匹配完成，结果已保存到 {output_excel_path} 文件中")