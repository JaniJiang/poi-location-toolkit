"""
"""
import os
import pandas as pd
from utils.search_utils.semantic_deduplicate import compute_similarity
from tqdm import tqdm
# 日志路径
logs_path = "data/cloud/search/qa_bot/qa_bot_test_by_week/"
# W17/real_and_relevance_ica.xlsx

# 保存路径
save_path = "data/cloud_share/qabot_relevance_data/trainset"
save_path = os.path.join(save_path, "simple_postive.tsv")


def run(logs_path):
    df = pd.read_excel(logs_path).dropna()
    query_list = df['query'].to_list()
    hitQuestion_list = df['hitQuestion'].to_list()
    # 模型打分
    score = compute_similarity(question_list=hitQuestion_list, query_list=query_list)
    score = score[:, :, 1][0]
    # 筛选并保存数据
    res = pd.DataFrame({
        "query": query_list,
        "question": hitQuestion_list,
        "score": score
    })
    res = res[res['score'] > 0.9]
    res["label"] = [1]*len(res)
    res = res[["query", "question", "label"]]
    return res


def save(res, save_path):
    res.to_csv(save_path, index=False, sep='\t', header=None)


if __name__ == "__main__":
    df = pd.DataFrame()
    for dir in tqdm(os.listdir(logs_path)):
        path = os.path.join(logs_path, dir, "real_and_relevance_ica.xlsx")
        if os.path.exists(path):
            tmp_df = run(path)
            df = pd.concat([df, tmp_df])
    save(df, save_path)
