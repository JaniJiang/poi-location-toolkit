from asyncio import Semaphore
from utils.llm_utils.serverless_function import request_llm_async, RateLimiter
from utils.file_utils import read_jsonl_file
import json
from tqdm import tqdm
import pandas as pd
from search.qa_bot.service_bot_relevance.example.set_train.prompt import *
import asyncio
import aiohttp
import os
from tqdm.asyncio import tqdm_asyncio

logs_path = "data/cloud/search/qa_bot/qa_bot_test_by_week/"


class StateConstruct:
    """
    """

    def __init__(self):
        # --- 配置参数 ---
        # 模型配置
        self.model_name = "claude-3_5-sonnet"  # 可选模型: gpt-4o | claude-3_5-sonnet | deepseek-v3 | deepseek-r1 | deepseek-r1-distill-qwen-32b
        # 并发控制
        self.max_concurrent = 10  # 最大并发数（控制资源消耗）
        self.qps = 3              # 请求频率限制（建议≤4）

    def process(self, input_list):
        loop = asyncio.get_event_loop()
        res = loop.run_until_complete(self.process_async(input_list, max_retries=3))

        return res

    async def process_async(self, input_list, max_retries):
        rate_limiter = RateLimiter(self.qps)
        semaphore = Semaphore(self.max_concurrent)  # 限制最大并发数为 max_concurrent
        async with aiohttp.ClientSession() as session:
            tasks = [self.process_item_async(rate_limiter, semaphore, session, query, max_retries) for
                     item in input_list]
            results = [None] * len(tasks)
            task_objects = [asyncio.create_task(task) for task in tasks]
            for idx, task in tqdm_asyncio(zip(range(len(tasks)), task_objects), total=len(tasks)):
                response = await task
                # 根据任务的索引存储结果
                results[idx] = response
        return results

    async def process_item_async(self, rate_limiter, semaphore, session, item, max_retries):
        """单条数据处理流程：规则过滤→LLM判断→结果回写"""

        history = [
            PROMPT_STATE,
            USER_PROMPT_STATE.format(query=item['query']
                                     )
        ]

        # 4. 调用LLM进行判断
        try:
            payload, response_data = await request_llm_async(
                rate_limiter,
                semaphore,
                session,
                max_retries,
                history,
                model=self.model_name,
                n=1,
                temperature=0
            )
            question_new_str = response_data["choices"][0]["message"]["content"]
            question_new_list = json.loads(question_new_str)
        except Exception as e:
            question_new_list = []
            print(e)
            try:
                # 尝试修复格式错误
                question_new_list = json.loads(question_new_str.strip().strip(
                    '`').replace("json", '').replace("\n", ""))
            except Exception as e:
                print("llm-api调用失败")
                return item

        # 5. 回写判断结果
        item["res"] = question_new_list["res"]
        return item


if __name__ == "__main__":
    df = pd.DataFrame()
    obj = StateConstruct()
    for dir in tqdm(os.listdir(logs_path)):
        path = os.path.join(logs_path, dir, "real_and_relevance_ica.xlsx")
        if os.path.exists(path):
            tmp_df = pd.read_excel(path).dropna()
            df = pd.concat([df, tmp_df])
    df = df[df["query"].str.contains("状态")]
    res = obj.process(df["query"])
