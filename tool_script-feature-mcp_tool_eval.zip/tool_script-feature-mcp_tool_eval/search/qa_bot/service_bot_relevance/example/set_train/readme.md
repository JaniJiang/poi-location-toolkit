**simple_postive: 补充简单正例**
**entity: 补充实体正负样本**
**state: 补充状态正负样本（暂时废弃）**
**general_special_question: 补充语义正负样本（一般疑问对特殊疑问）**