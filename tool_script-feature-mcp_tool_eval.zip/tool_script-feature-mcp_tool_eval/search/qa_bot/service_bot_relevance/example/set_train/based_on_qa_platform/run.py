from utils.search_utils.semantic_deduplicate import compute_similarity
from utils.file_utils import read_jsonl_file
import pandas as pd
import numpy as np
import re
import random
import requests
import json
import csv

from tqdm import tqdm
from utils.nlp_utils.embedding import get_batch_embedding
from search.qa_bot.service_bot_analyse.steps.step6_knowledge_coverage import KnowledgeCoverage
PATTERN_GENERAL = r'(?:是否|能否|有没有|能不能|是不是|用不用|会不会|该不该|可不可以|要不要|行不行|对不对|好不好|了吗|了没有|' \
    r'(?:.*(?:在|可以|支持|有|是|会|能|需要).*(?:吗|么|嘛)[。？！?.!]?$)|' \
    r'(?:.*是.*还是.*)|' \
    r'(?:着|了)(?:吗|么)[。？！?.!]?$)'
PATTERN_SPECIAL = r'(?:有多少|在哪里|在哪儿|怎么|是多少|什么|是干嘛)'
DIM = 128  # 768 | 128
BATCH_SIZE = 8


class QaPlatformGenerator():
    def __init__(self, input_path="data/cloud_share/qabot_miner/qa_index/step4_knowledge_extract.qa.jsonl",
                 output_path="data/cloud_share/qabot_relevance_data/trainset/qa_platform.tsv"):
        self.input_path = input_path
        self.output_path = output_path
        pass

    def construct_postive(self, qList):
        postive_list = []

        regex_general = re.compile(PATTERN_GENERAL)
        regex_special = re.compile(PATTERN_SPECIAL)
        general_questions = []
        special_questions = []

        for query in qList:
            query = query.strip()
            if regex_general.search(query) is not None and regex_special.search(query):
                general_questions.append(query)
            else:
                special_questions.append(query)

        def sample_n(list, n):
            res = []
            random.shuffle(list)
            for i in range(n):
                start = i * 2
                end = start + 2
                if end > len(list):
                    # print("剩余元素不足，无法完成抽取")
                    break
                sampled = list[start:end]
                sampled.append(1)
                res.append(sampled)       # 添加label为1
            return res

        if len(general_questions) > 1:
            postive_list += sample_n(general_questions, 3)
        if len(special_questions) > 1:
            postive_list += sample_n(special_questions, 3)

        return postive_list

    def construct_negative(self, query_emb, query, qid, index):
        # find negative
        negative_list = []

        # USE vector recall
        item_list = index.search(query_emb, top_k=100, deduplicate=True)
        for item in item_list:
            if len(negative_list) >= 10:
                break
            try:
                item_qid = item["payload"]['question_id']
                score = item['score']
                if qid == item_qid or score > 0.8:
                    continue
                else:
                    negative_list += [[query, question, 0]
                                      for question in random.sample(item['payload']['question'], 2)]
            except Exception as e:
                continue
        # USE onnx model
        # stdQuestionList = [d['question'][0] for d in dataList]
        # scores = compute_similarity(query, stdQuestionList)[:, :, 1][0]
        # for score in sorted(scores)[-5:]:
        #     if score > 0.8:
        #         continue
        #     index = list(scores).index(score)
        #     negative_list += dataList[index]["question"][:2]
        return negative_list

    def process(self):
        obj = KnowledgeCoverage()
        index = obj.build_index("data/cloud_share/qabot_miner/qa_index/step5_knowledge_index.qa.jsonl")
        dataList = read_jsonl_file(self.input_path)
        query_list = [data['question'][0] for data in dataList]
        query_emb = get_batch_embedding(query_list, DIM, BATCH_SIZE)
        all_sample_list = []
        for i in tqdm(range(len(dataList))):
            questionList = dataList[i]['question']
            # 正例构造
            postive = self.construct_postive(questionList)
            # 负例构造
            try:
                qid = dataList[i]['feature_dict']['question_id']
            except Exception as e:
                continue
            negative = self.construct_negative(query_emb[i], query_list[i], qid, index)
            all_sample_list += postive + negative

        header = ["query", "question", "label"]
        with open(self.output_path, mode='w', newline='', encoding='utf-8') as file:
            writer = csv.writer(file, delimiter='\t')
            writer.writerow(header)  # 写入表头
            writer.writerows(all_sample_list)


if __name__ == "__main__":
    obj = QaPlatformGenerator()
    obj.process()
