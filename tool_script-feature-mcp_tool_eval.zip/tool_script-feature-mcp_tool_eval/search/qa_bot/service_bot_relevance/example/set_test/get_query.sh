# 圈选服务专家和汽车RAG的Query
export DATA_DATE="2025-04-01"
export DATA_DATE_END="2025-4-30"
export DATA_DATE_PATH="202504"
export NUM="100000"
SQL_STRING_IC="select msg_id, query from dwd_vechile_merge_prod_di where (dt between '$DATA_DATE' and '$DATA_DATE_END') AND domain='in_car_assistant' and vehicle_category = '1' order by RAND() limit $NUM"
CSV_FILE_IC="incarassistant_log.csv"
../tool/adt --token 731a63a43618b0b444a2b86f36cf3e14 ark2csv --sql-string "$SQL_STRING_IC" --csv-file "$CSV_FILE_IC"

# 初始化一个空数组
msg_ids=()
# 使用 awk 提取第二列
while IFS=, read -r msg_id query; do
    msg_ids+=("$msg_id")
done < $CSV_FILE_IC

# 分批处理 msg_ids，每批处理 1000 个 msg_id
BATCH_SIZE=1000
TOTAL=${#msg_ids[@]}
echo "Total msg_ids: $TOTAL"

# 初始化最终的合并 CSV 文件
CSV_FILE_VERIFIED="incarassistant_log_verified.csv"
> "$CSV_FILE_VERIFIED"  # 创建一个空文件

for ((i=0; i<TOTAL; i+=BATCH_SIZE)); do
    # 获取当前批次的 msg_ids
    BATCH_msg_ids=("${msg_ids[@]:i:BATCH_SIZE}")
    # 将数组转换为 SQL 兼容的格式
    sql_msg_ids=$(printf "'%s'," "${BATCH_msg_ids[@]}")
    sql_msg_ids=${sql_msg_ids%,}  # 去掉最后一个多余的逗号
    
    # 构建 SQL 查询
    SQL_STRING_VERIFIED="select msg_id, message from ods_service_expert_log_v1_prod_rt where (dt between '$DATA_DATE' and '$DATA_DATE_END') and msg_id IN ($sql_msg_ids) AND logger_name='com.lixiang.voice.cockpit.faqse.utils.filter.AccessLogFilter'"
    
    # 生成临时 CSV 文件
    TEMP_CSV="temp_incarassistant_log_verified_${i}.csv"
    ../tool/adt --token 731a63a43618b0b444a2b86f36cf3e14 ark2csv --sql-string "$SQL_STRING_VERIFIED" --csv-file "$TEMP_CSV"
    
    # 将临时文件追加到最终文件
    if [ -f "$TEMP_CSV" ]; then
        # 如果是第一个批次，保留表头；否则跳过表头
        if [ $i -eq 0 ]; then
            cat "$TEMP_CSV" >> "$CSV_FILE_VERIFIED"
        else
            tail -n +2 "$TEMP_CSV" >> "$CSV_FILE_VERIFIED"  # 跳过第一行表头
        fi
        rm "$TEMP_CSV"  # 删除临时文件
    fi
    
    echo "Processed batch: $i to $((i+BATCH_SIZE))"
done

echo "All batches processed. Final CSV saved to: $CSV_FILE_VERIFIED"

# 运行 Python 脚本处理日志
python process_logs.py
python query_matching.py
