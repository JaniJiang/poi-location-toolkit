import json
import pandas as pd
import torch
import torch.nn as nn
import onnxruntime as ort
from transformers import AutoTokenizer  # 替换成你自己的 tokenizer 导入方式
from tqdm import tqdm
from collections import defaultdict

# === 设置 ===
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
ONNX_PATH = "../model_best/model.onnx"
EXCEL_PATH = "incarassistant_log_mock.xlsx"
# EXCEL_PATH = "incarassistant_log_verified_processed.xlsx"
JSON_PATH = "data.json"
OUTPUT_PATH = "query_question_prompt.xlsx"
TOKENIZER_PATH = "../sentenceembed/mengzi-bert-base"  # 替换成你模型路径

# === 加载 tokenizer ===
tokenizer = AutoTokenizer.from_pretrained(TOKENIZER_PATH)

# === 打分函数 ===
def get_similarity_scores(tokenizer, texts, onnx_path=None):
    softmax = nn.Softmax(dim=-1)

    encodings = tokenizer(
        texts,
        padding=True,
        truncation=True,
        max_length=128,
        return_tensors="pt"
    )

    input_ids = encodings['input_ids'].to(DEVICE)
    attention_mask = encodings['attention_mask'].to(DEVICE)
    token_type_ids = encodings.get('token_type_ids')
    if token_type_ids is not None:
        token_type_ids = token_type_ids.to(DEVICE)

    if onnx_path:
        sess = ort.InferenceSession(onnx_path, None)
        ort_inputs = {
            'input_ids': input_ids.cpu().numpy(),
            'attention_mask': attention_mask.cpu().numpy()
        }
        if token_type_ids is not None:
            ort_inputs['token_type_ids'] = token_type_ids.cpu().numpy()

        onnx_output = sess.run(['output'], ort_inputs)
        logits = torch.tensor(onnx_output)[0].to(DEVICE)
    else:
        raise ValueError("This script requires ONNX model inference.")

    probs = softmax(logits)
    similarity_scores = probs[:, 1]  # 第二类的概率
    return similarity_scores.cpu().numpy()


# === 加载 JSON ===
with open(JSON_PATH, "r", encoding="utf-8") as f:
    qa_data = json.load(f)

qid2questions = {}
for item in qa_data:
    # 检查 answerGroup 是否存在并非空
    if "answerGroup" not in item or not item["answerGroup"]:
        print("没有answerGroup")
        continue
    if "question" not in item or not item["question"]:
        print("question")
        continue
    try:
        qid = item["answerGroup"][0]["questionId"]
        qid2questions[qid] = item["question"]
    except KeyError:
        continue

# === 加载 Excel ===
df = pd.read_excel(EXCEL_PATH)
queries = df["query"].tolist()
qids = df["qid"].tolist()

# === 构造句对 ===
sentence_pairs = []
index_map = []

for idx, (query, qid) in enumerate(zip(queries, qids)):
    try:
        qid = int(qid)
        candidates = qid2questions.get(qid, [])
        for cand in candidates:
            sentence_pairs.append(f"{query}[SEP]{cand}")
            index_map.append((idx, cand))
    except BaseException:
        continue

# === 批量打分 ===
BATCH_SIZE = 32
scores = []

for i in tqdm(range(0, len(sentence_pairs), BATCH_SIZE)):
    batch_texts = sentence_pairs[i:i + BATCH_SIZE]
    batch_scores = get_similarity_scores(tokenizer, batch_texts, ONNX_PATH)
    scores.extend(batch_scores)

# === 聚合打分结果 ===
best_match = defaultdict(lambda: ("", -1.0))  # index -> (question, score)

for (idx, cand), score in zip(index_map, scores):
    if score > best_match[idx][1]:
        best_match[idx] = (cand, score)

# === 写入结果 ===
best_questions = []
best_scores = []

for i in range(len(df)):
    question, score = best_match.get(i, ("", -1.0))
    best_questions.append(question)
    best_scores.append(score)

df["best_question"] = best_questions
df["best_score"] = best_scores

# 检查是否包含必要的列
required_columns = ['query', 'best_question', 'answer']
if not all(col in df.columns for col in required_columns):
    raise ValueError(f"数据必须包含以下列：{required_columns}")
# 新增 prompt_list 列
df['prompt_list'] = df.apply(
    lambda row: f"'[用户指令]':{row['query']}\n\n'[匹配问题]':{row['best_question']},\n'[系统回复]':{row['answer']}",
    axis=1)

df.to_excel(OUTPUT_PATH, index=False)
print(f"✅ 成功完成！结果已保存到：{OUTPUT_PATH}")
