import csv
import json
import pandas as pd
import os
import re
import random


def process_item(message):
    try:
        request = json.loads(message.split(",request=")
                             [1].split(",response=")[0])
        response = json.loads(message.split(",request=")
                              [1].split(",response=")[1])

        if "uri=/assistant/query/release_prod" in message:
            try:
                return {
                    "type": "in_car_assistant",
                    "query": request["nlu"][0]["dass"][0]["slots"]["query"],
                    "qid": response["data"]["qaPayload"]["questionId"],
                    "answer": response["data"]["qaPayload"]["speak"],
                }
            except Exception as e:
                print(f"Error processing in_car_assistant: {e}")
                return None
        elif "uri=/expert/query" in message:
            try:
                return {
                    "type": "autoqa",
                    "query": request["nlu"][0]["dass"][0]["slots"]["query"],
                    "qid": None,
                    "answer": response["data"][0]["answer"],
                }
            except Exception as e:
                print(f"Error processing autoqa: {e}")
                return None
        else:
            return None
    except Exception as e:
        print(f"Error processing message: {e}")
        return None


def process_queries(df):
    # 如果没有数据，直接返回空 DataFrame
    if df.empty:
        return df

    # 为方便引用，给前3列命名为 query, question, label，其余列命名为 col4, col5, ...
    # num_cols = df.shape[1]
    # col_names = ["query", "question", "label"] + [f"col{i}" for i in range(4, num_cols+1)]
    # df.columns = col_names[:num_cols]

    # 统计每个 query 的出现次数并降序排序
    query_counts = df['query'].value_counts()

    # 高频：取出现频率排前 500 的 query 列表
    high_queries = query_counts.index[:500].tolist()

    # 中低频候选：前500名之后的所有 query
    rest_queries = query_counts.index[500:].tolist()

    # 从中低频候选中随机选 1000 个不同的 query（如不足则取全部）
    num_mid = min(1000, len(rest_queries))
    selected_mid_queries = random.sample(rest_queries, num_mid)

    # 剩余用于低频选取的候选：排除已经选为中频的 query
    remaining_for_low = [
        q for q in rest_queries if q not in selected_mid_queries]
    # 低频：pv<3 的 query 候选列表
    low_candidates = [q for q in remaining_for_low if query_counts[q] < 3]
    # 随机选 500 个低频 query（如不足则取全部）
    num_low = min(1000, len(low_candidates))
    selected_low_queries = random.sample(low_candidates, num_low)

    # 对于每个选择的 query，从原数据中随机采样一条记录
    df_high = df[df['query'].isin(high_queries)].groupby('query').sample(n=1)
    df_mid = df[df['query'].isin(selected_mid_queries)].groupby(
        'query').sample(n=1)
    df_low = df[df['query'].isin(selected_low_queries)].groupby(
        'query').sample(n=1)

    selected_df = pd.concat([df_high, df_mid, df_low])

    # 从剩余数据中随机抽取以凑满 5000 行
    remaining_df = df.drop(index=selected_df.index)
    num_to_sample = max(0, 5000 - selected_df.shape[0])
    if num_to_sample > 0 and num_to_sample <= len(remaining_df):
        sampled_df = remaining_df.sample(n=num_to_sample)
    else:
        sampled_df = remaining_df

    # 合并已选记录与随机抽取记录，并打乱顺序
    final_df = pd.concat([selected_df, sampled_df]).sample(
        frac=1).reset_index(drop=True)
    return final_df


def main():
    input_file = "incarassistant_log_verified.csv"  # 输入CSV文件路径

    # 在内存中处理数据，避免生成中间文件
    data = []

    with open(input_file, 'r', encoding='utf-8') as infile:
        reader = csv.DictReader(infile)

        for row in reader:
            msg_id = row["msg_id"]
            message = row["message"]

            result = process_item(message)
            if result:
                data.append({
                    "query": result["query"],
                    "qid": result["qid"],
                    "answer": result["answer"]
                })
                print(f"Processed msg_id: {msg_id}")
            else:
                print(f"Skipped msg_id: {msg_id}")

    if not data:
        print("No data to process.")
        return

    # 将内存中的数据转换为DataFrame
    df = pd.DataFrame(data)

    '''
    # 检查是否包含必要的列
    required_columns = ['query', 'hit_question', 'answer', 'qid']
    if not all(col in df.columns for col in required_columns):
        raise ValueError(f"数据必须包含以下列：{required_columns}")

    # 新增 prompt_list 列
    df['prompt_list'] = final_df.apply(lambda row: f"'[用户指令]':{row['query']}\n\n'[匹配问题]':{row['question']},\n'[系统回复]':{row['answer']}", axis=1)

    '''

    # 数据清洗：清理 qid 列，只保留主 id 部分
    df['qid'] = df['qid'].apply(
        lambda x: re.sub(
            r'_\d+$',
            '',
            str(x)) if pd.notnull(x) else x)

    # 数据清洗：删除可能导致 Excel 保存问题的特殊字符
    def clean_text(text):
        if not isinstance(text, str):
            return text
        # 替换退格符、换页符、垂直制表符等
        text = text.replace('\b', '').replace('\f', '').replace('\v', '')
        # 删除所有控制字符（ASCII码0-31）
        text = re.sub(r'[\x00-\x1F\x7F]', '', text)
        # 替换换行符和回车符为空格
        text = re.sub(r'[\n\r]', ' ', text)
        return text

    # 对所有文本列进行清洗
    for col in df.columns:
        if df[col].dtype == 'object':  # 只处理文本列
            df[col] = df[col].apply(clean_text)

    final_df = process_queries(df)

    # 保存为 Excel 文件
    excel_file = os.path.splitext(input_file)[0] + '_processed.xlsx'
    final_df.to_excel(excel_file, index=False, engine='openpyxl')

    print(f"数据已转换为 Excel 文件，保存路径为：{excel_file}")


if __name__ == "__main__":
    main()
