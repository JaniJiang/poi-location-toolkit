# -*- coding:utf-8 -*-
import asyncio
import collections

import aiohttp
import json
from tqdm import tqdm
import pandas as pd
from datetime import datetime
from asyncio import Semaphore
import os
# import util

pd.set_option('display.max_columns', None)  # 显示所有列
pd.set_option('display.max_rows', None)  # 显示所有行
pd.set_option('display.width', None)  # 自动调整列宽
pd.set_option('display.max_colwidth', None)  # 显示所有单元格的内容


class RateLimiter:
    def __init__(self, rate):
        self.rate = rate
        self.current = 0
        self.last_check = datetime.now()

    async def wait(self):
        while True:
            now = datetime.now()
            passed_seconds = (now - self.last_check).seconds
            if passed_seconds > 1:
                self.last_check = now
                self.current = 0
            if self.current < self.rate:
                self.current += 1
                return
            await asyncio.sleep(1)


def make_chat_request_entry(messages, message_type):
    """
    messages: ['',''] .messages[0] = system/user prompt,  message[1] = user/assistant prompt
    示例：
    单轮 system prompt
    # messages = [
    #    {"role": "system", "content": "你是理想同学"}
    #    {"role": "user", "content": "你是谁"},
    # ]
    单轮/多轮 user/assistant prompt
    # messages = [
    #    {"role": "user", "content": "周杰伦的代表作是什么"},
    #    {"role": "assistant", "content": "周杰伦是华语乐坛的重要人物，他的音乐作品多种多样，风格独特，深受广大听众的喜爱。以下是他的一些代表作：\n\n1.《青花瓷》：这首歌是周杰伦的代表作之一，歌曲以中国传统文化为背景，歌词优美，旋律悠扬。\n\n2.《简单爱》：这首歌是周杰伦早期的作品，歌词直接表达了对爱情的向往和追求，深受年轻人的喜爱。\n\n3.《不能说的秘密》：这首歌是周杰伦自编自导的电影《不能说的秘密》的主题曲，歌曲旋律优美，歌词深情。\n\n4.《七里香》：这首歌是周杰伦的经典作品之一，歌曲旋律悠扬，歌词描绘了一段深情的爱情故事。\n\n5.《稻香》：这首歌歌词深入人心，歌曲旋律优美，是周杰伦的代表作之一。\n\n6.《双截棍》：这首歌是周杰伦的代表作之一，歌曲以中国传统武术为主题，展现了周杰伦的音乐创新和实验精神。\n\n7.《夜曲》：这首歌是周杰伦的经典作品之一，歌曲旋律优美，歌词深情，展现了周杰伦的音乐才华。\n\n以上只是周杰伦的部分代表作，他的音乐作品还有很多，每一首都有其独特的魅力。"},
    #    {"role": "user", "content": "他哪一年出道的"}
    # ]
    """
    if message_type == "prompt":
        # 单轮 system prompt
        data_entry = {"messages": [{"role": ["system",
                                             "user"][i % 2],
                                    "content": messages[i]} for i in range(len(messages))],
                      "temperature": 0}
    else:
        # 单轮/多轮 user/assistant prompt
        data_entry = {
            "messages": [{"role": ["user", "assistant"][i % 2], "content": messages[i]} for i in
                         range(len(messages))],
            "temperature": 0}
    if message_type == "GPT-4-TURBO":
        data_entry = {"messages": [{"role": ["user",
                                             "assistant"][i % 2],
                                    "content": [{"type": "text",
                                                 "text": messages[i]}]} for i in range(len(messages))],
                      "temperature": 0,
                      "model": "GPT-4-TURBO"}
    # gpt4o格式
    data_entry = {"messages": [{"role": ["user",
                                         "assistant"][i % 2],
                                "content": [{"type": "text",
                                             "text": messages[i]}]} for i in range(len(messages))],
                  "temperature": 0,
                  "model": "GPT-4O"}
    return data_entry


async def request_chat_async(
        rate_limiter,
        semaphore,
        session,
        messages,
        message_type,
        max_retries=10):
    """
    Async version of the request_chat function
    message_type 表示单轮/多轮/prompt请求
    """
    url = "https://yzx-agent-data.fc.chj.cloud/gpt4_turbo"  # For example
    url = "https://wzy-gpt4-memorytest.fc.chj.cloud/gpt4_turbo"
    url = "https://wzy-gpt4-memorytest.fc.chj.cloud/chat"
    headers = {'Content-Type': 'application/json'}
    data_entry = make_chat_request_entry(messages, message_type)

    retries = 0
    while retries < max_retries:
        await rate_limiter.wait()  # 控制请求的发出速率
        async with semaphore:  # 限制同时处理的请求数量
            try:
                async with session.post(url, json=data_entry, headers=headers) as response:
                    return await response.json()
            except Exception as e:
                print(f'chatgpt api exception: {e}')
                retries += 1
                await asyncio.sleep(1)

    print('Maximum retry attempts reached, returning error')
    return {"error": "Maximum retry attempts reached, returning error"}


async def process_prompts_chunk_async(
        rate_limiter,
        semaphore,
        session,
        prompts,
        message_type,
        max_retries=10):
    """
    Async version of the process_prompts_chunk function
    """
    response = await request_chat_async(rate_limiter, semaphore, session, prompts, message_type, max_retries)
    return [prompts, response]


async def gen_assistant_async(
        df,
        message_type,
        max_retries=10,
        qps=1,
        max_concurrent=20,
        output_assistant_path=""):
    """
    qps 最大为2，建议设置小于2
    max_concurrent 为并发数限制，文档没有要求，但是RateLimiter在异步时有时无法控制好qps，因此加此限制，具体数值可根据自身需要调整
    """
    prompts_ls = df  # df['prompts'].to_list()
    rate_limiter = RateLimiter(qps)
    # 限制最大并发数为 max_concurrent，暂时无限制，可以根据自身需求调整大小
    semaphore = Semaphore(max_concurrent)

    async with aiohttp.ClientSession() as session:
        tasks = [
            process_prompts_chunk_async(
                rate_limiter,
                semaphore,
                session,
                prompts,
                message_type,
                max_retries) for prompts in prompts_ls]
        responses = []

        with open(output_assistant_path, 'a', encoding='utf-8') as f:
            for prompt, future in tqdm(
                    zip(prompts_ls, asyncio.as_completed(tasks)), total=len(tasks)):
                response = await future
                f.write(json.dumps([prompt, response],
                        ensure_ascii=False) + "\n")
                f.flush()  # ensure the data is written to disk after each iteration
                responses.append(response)

    return responses


def parser_gpt_response(response_list, ordered_query):
    """
    解析response_list，assistant_dataframe[query, response]
    """
    query_pair = dict()
    user_list = []
    assistant_list = []
    for response in response_list:
        user = response[0][-1]
        user_list.append(user)
        try:
            assistant = response[1]['data']['choices'][0]['content']
            assistant_list.append(assistant)
        except Exception as e:
            print(e)
            assistant_list.append("<|wrong data|>")
        query_pair[user] = assistant_list[-1]

    res_list = []
    for query in ordered_query:
        res_list.append(query_pair[query])

    assistant_dataframe = pd.DataFrame()
    assistant_dataframe['prompt_list'] = ordered_query
    assistant_dataframe['response'] = res_list

    return user_list, assistant_list, res_list, assistant_dataframe
