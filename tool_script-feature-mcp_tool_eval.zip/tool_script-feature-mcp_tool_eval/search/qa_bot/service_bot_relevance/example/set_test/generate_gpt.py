import asyncio
import pandas as pd
import os
import re
import json

from utils import gen_assistant_async, parser_gpt_response
from constants import PROMPT_TEMPLATE, GENERATE_SYN_TASK, GET_CAR_ENTITY_TASK, LABEL_TASK_QABOT, LABEL_TASK_RAG, NEW_QABOT_TASK, NEW_AUTO_TASK_TITLEONLY, NEW_AUTO_TASK_TITLEONLY_MULTISTAGE


def generate(df, input, prompt):

    prompt_list = [[prompt, '用户语音输入如下：' + "文本：" + f"{i}"] for i in input]
    ordered_query = ['用户语音输入如下：' + "文本：" + f"{i}" for i in input]
    # prompt_list = [input]
    # ordered_query = input

    data = {
        "prompts": prompt_list,
        "single": [['你好呀']],
        "context": [
            ["刘德华的代表作是什么", "周杰伦的代表作有很多，其中最为人所知的可能是《青花瓷》、《七里香》、《不能说的秘密》等。",
             "我问的是刘德华"],
            ["周杰伦的代表作是什么", "周杰伦的代表作有很多，其中最为人所知的可能是《青花瓷》、《七里香》、《不能说的秘密》等。",
             "他是哪一年出道的"], ]
    }

    # prompt 调用方法
    prompt_df = data['prompts']
    message_type = "GPT-4-TURBO"

    loop = asyncio.get_event_loop()
    response_ls = loop.run_until_complete(
        gen_assistant_async(
            prompt_df,
            message_type,
            max_retries=3,
            qps=4,
            max_concurrent=20,
            output_assistant_path="../asyncio_out.json"))

    a, r, res_list, res_df = parser_gpt_response(response_ls, ordered_query)
    df.loc[:, 'gpt_label'] = res_df['response'].to_list()
    res_df = df

    return res_df


def extract_label(df, category, step="1"):
    n = len(df)
    if category == 'RAG':
        label_list = [0] * n
    elif category == 'QABOT':
        label_list = [1] * n
    else:
        print('Not in targeted category')
        raise ()
    reject_list = [0] * n

    for i in range(len(df['gpt_label'])):
        label = df['gpt_label'].to_list()[i]
        try:
            # 移除单行注释
            label = re.sub(r'//.*', '', label)
            # 移除多行注释
            label = re.sub(r'/\*.*?\*/', '', label, flags=re.DOTALL)
            # load
            label = json.loads(label.replace('`', '').replace('json', ''))

            # step2反思
            if category == 'RAG' and step == "2":
                if label['result'] == '不相关':
                    label = 0
                else:
                    label = 1
                label_list[i] = label
                continue

            # step1标注
            reject_list[i] = label['results'][0]['是否兜底']
            # 若兜底则忽略内容可解的打分（最后一项）
            if reject_list[i] == 1:
                list_score = list(label['results'][0]['指令遵循'].values())[:-1]
            else:
                list_score = list(label['results'][0]['指令遵循'].values())[:]
            if category == 'RAG':
                # rag链路 存在不为满分的项 --> 属于rag链路，若无则应为qa链路
                if bool([x for x in list_score if x < 2]):
                    label = 0
                else:
                    label = 1
            elif category == 'QABOT':
                # 存在不相关的标注项==不相关 --> 落域错误，属于rag链路
                if bool([x for x in list_score if x == 0]):
                    if reject_list[i] == 0 and list_score[-2] != 0 and list_score[-1] == 0:
                        # 若不为兜底，且问题遵循情况下，忽略内容可解
                        label = 1
                    else:
                        label = 0
                else:
                    label = 1
            label_list[i] = label
        except Exception as e:
            continue
            # print(e)
            # print(label)

    df.loc[:, 'label'] = label_list
    df.loc[:, 'reject'] = reject_list
    return df


if __name__ == "__main__":
    import sys

    path = "output.xlsx"
    resource = "QABOT"
    date = "03_31"
    step = "1"
    print("No argument provided.")
    print("Start QABOT Step1 Labeling")
    prompt = NEW_QABOT_TASK

    # 读取数据
    df = pd.read_excel(path)
    input_df = df
    input = input_df['prompt_list'].to_list()

    # 标注
    print(f"Start Labeling {len(input)} data")
    res_df = generate(input_df, input, prompt)
    print(f"Start Parsing {len(input)} result")
    res_df = extract_label(res_df, resource, step=step)

    df.loc[:, "label"] = res_df['label'].to_list()

    # 保存结果
    target_path = f"/mnt/pfs-guan-ssai/nlu/qingshuo/badcase_process/gpt_labeled_{resource}_{date}.xlsx"
    df.to_excel(target_path)
