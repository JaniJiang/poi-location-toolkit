import json
import argparse
import pandas as pd
from collections import Counter
from utils.file_utils import check_output_path
from ark_script.utils.common_utils import get_dates_of_last_week


class CalculateMetrics:
    """TODO:需要再优化一下"""

    def __init__(self, end_date):
        # 校验本地文件路径
        date_list = get_dates_of_last_week(end_date)
        start_date = date_list[0]
        end_date = date_list[-1]
        self.input_path = f"data/cloud/search/rag/log_analyse/v2/{start_date}_to_{end_date}/step2_label_search_result.jsonl"
        self.output_path = f"data/cloud/search/rag/log_analyse/v2/{start_date}_to_{end_date}/step3_calculate_metrics.tsv"
        check_output_path(self.output_path)

    def process(self):
        # 读取输入数据
        input_df = pd.read_json(self.input_path, lines=True)
        input_df["P准确问题"] = ""
        input_df["P不确定问题"] = ""
        label_msg_list = []
        recall_all_count, recall_real_count, unrecall_count = 0, 0, 0
        p_reason_type_list = []
        p2_reason_type_list = []
        acc_reason_type_list = []
        p_all_count = 0
        acc_all_count = 0
        for idx, row in input_df.iterrows():
            # 分析召回
            recall_all_count += 1
            if row["is_recall"] == 0:
                unrecall_count += 1
                label_msg_list.append(row["label_msg"])
                continue
            else:
                recall_real_count += 1
            # 分析准确
            bad_reason_type_list = []
            uncertain_reason_type_list = []
            try:
                label_llm = json.loads(row["label_llm"])
            except:
                label_msg_list.append(row["label_llm"])
                continue
            label_p = 0
            label_acc = 0
            label_num = len(label_llm)
            for item in label_llm:
                if item.get("label", "") == "不满足":
                    reason_type = item.get("reason_type", "")
                    if reason_type != "":
                        bad_reason_type_list.append(reason_type)
                elif item.get("label", "") == "不确定":
                    reason_type = item.get("reason_type", "")
                    if reason_type != "":
                        uncertain_reason_type_list.append(reason_type)
                elif item.get("label", "") == "满足":
                    label_p = 1
                    label_acc += 1
            p_all_count += 1
            if label_p == 0:
                bad_reason_type_uniq = ";".join(sorted(list(set(bad_reason_type_list))))
                if bad_reason_type_uniq != "":
                    p_reason_type_list.append(bad_reason_type_uniq)
                uncertain_reason_type_uniq = ";".join(sorted(list(set(uncertain_reason_type_list))))
                if uncertain_reason_type_uniq != "":
                    p2_reason_type_list.append(uncertain_reason_type_uniq)
            else:
                bad_reason_type_uniq = ""
                uncertain_reason_type_uniq = ""
            acc_all_count += label_num
            acc_reason_type_list.extend(bad_reason_type_list)
            input_df.loc[idx, "P准确问题"] = bad_reason_type_uniq
            input_df.loc[idx, "P不确定问题"] = uncertain_reason_type_uniq
        # 保存处理结果数据
        input_df.to_csv(self.output_path, sep="\t", index=False)
        # 计算&保存指标
        with open(self.output_path + ".metrics.tsv", "w") as f_write:
            # 召回指标
            self.write_metrics(f_write, "召回指标", "recall", recall_real_count, recall_all_count)
            self.write_metrics(f_write, "召回指标", "unrecall", unrecall_count, recall_all_count)
            # 召回问题占比
            label_msg_counts = Counter(label_msg_list)
            for key, value in label_msg_counts.items():
                self.write_metrics(f_write, "召回问题占比", key, value, recall_all_count)
            # 准确问题占比
            p_reason_type_counts = Counter(p_reason_type_list)
            for key, value in p_reason_type_counts.items():
                self.write_metrics(f_write, "准确问题占比", key, value, recall_all_count)
            # 不确定问题占比
            p2_reason_type_counts = Counter(p2_reason_type_list)
            for key, value in p2_reason_type_counts.items():
                self.write_metrics(f_write, "不确定问题占比", key, value, recall_all_count)
            # P指标
            for key, value in p_reason_type_counts.items():
                self.write_metrics(f_write, "P指标", key, value, p_all_count)
            # ACC指标
            acc_reason_type_counts = Counter(acc_reason_type_list)
            for key, value in acc_reason_type_counts.items():
                self.write_metrics(f_write, "ACC指标", key, value, acc_all_count)
            print("recall_all_count:", recall_all_count)
            print("p_all_count:", p_all_count)
            print("acc_all_count:", acc_all_count)

    def write_metrics(self, f_write, metrics_type, metrics_key, metrics_value_a, metrics_value_b):
        metrics_rate = "{:.2%}".format(round(metrics_value_a / metrics_value_b, 4))
        metrics_one = [metrics_type, metrics_key, metrics_rate, metrics_value_a, metrics_value_b]
        f_write.write("\t".join([str(x) for x in metrics_one]) + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--end_date", type=str, help="End date in YYYY-MM-DD format. Defaults to yesterday")
    args = parser.parse_args()
    obj = CalculateMetrics(args.end_date)
    obj.process()

# python -m search.rag.log_analyse.v2.step3_calculate_metrics --end_date=2025-03-23
