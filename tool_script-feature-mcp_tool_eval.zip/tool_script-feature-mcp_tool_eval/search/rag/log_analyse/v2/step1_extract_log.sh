#!/bin/bash
# bash search/rag/log_analyse/v2/step1_extract_log.sh

end_date="2025-03-23"
cd ark_script && /opt/spark/bin/spark-submit car_log_for_rag_weekly.py --end_date=${end_date}
