import argparse
import pandas as pd
from utils.file_utils import check_output_path
from ark_script.utils.common_utils import get_dates_of_last_week
from search.rag.log_analyse.rag_utils import parse_label


class GetBadCase:

    def __init__(self, end_date):
        # 校验本地文件路径
        date_list = get_dates_of_last_week(end_date)
        start_date = date_list[0]
        end_date = date_list[-1]
        self.input_path = f"data/cloud/search/rag/log_analyse/v2/{start_date}_to_{end_date}/step2_label_search_result.jsonl"
        self.output_path = f"data/cloud/search/rag/log_analyse/v2/{start_date}_to_{end_date}/step4_get_badcase.tsv"
        check_output_path(self.output_path)
        self.need_api_name_list = ["MEDIASearch", "QASearch"]
        self.del_field_name_list = ["knowledge_search_result", "media_search_result", "time_space_modify_response"]

    def process(self):
        # 读取输入数据
        input_df = pd.read_json(self.input_path, lines=True)
        for field_name in ["bad_reason_type", "uncertain_reason_type"]:
            input_df[field_name] = ""
        # 处理每条样本
        badcase_df = pd.DataFrame(columns=input_df.columns)
        for idx, row in input_df.iterrows():
            if row["api_name"] not in self.need_api_name_list:
                continue
            label_status, label_num, label_p, label_acc, bad_reason_type, uncertain_reason_type = parse_label(
                row["label_llm"])
            if label_status is False or label_p == 1:
                continue
            row["bad_reason_type"] = bad_reason_type
            row["uncertain_reason_type"] = uncertain_reason_type
            badcase_df = pd.concat([badcase_df, row.to_frame().T], ignore_index=True)
        # 保存处理结果数据
        badcase_df.drop(self.del_field_name_list, axis=1, inplace=True)
        badcase_df.to_csv(self.output_path, sep="\t", index=False)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--end_date", type=str, help="End date in YYYY-MM-DD format. Defaults to yesterday")
    args = parser.parse_args()
    obj = GetBadCase(args.end_date)
    obj.process()

# python -m search.rag.log_analyse.v2.step4_get_badcase --end_date=2025-03-23
