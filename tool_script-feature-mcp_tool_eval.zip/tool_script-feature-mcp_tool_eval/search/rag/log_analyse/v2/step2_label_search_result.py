import random
import argparse
import threading
from tqdm import tqdm
from collections import Counter
from joblib import Parallel, delayed
from utils.search_utils.es_client import ElasticSearchClient
from utils.file_utils import read_fuzzy_jsonl_file, check_output_path, write_json_file
from ark_script.utils.common_utils import get_dates_of_last_week
from search.rag.log_analyse.rag_utils import *


class LabelSearchResult:

    def __init__(self, end_date):
        # 校验本地文件路径
        date_list = get_dates_of_last_week(end_date)
        start_date = date_list[0]
        end_date = date_list[-1]
        self.input_path = f"data/cloud/ark_log/result/car_log_for_rag_weekly_sampled/{start_date}_to_{end_date}/part-00000-*.json"
        self.output_path = f"data/cloud/search/rag/log_analyse/v2/{start_date}_to_{end_date}/step2_label_search_result.jsonl"
        check_output_path(self.output_path)
        # 简化输出长度
        self.need_simple_data = True
        self.cutoff_len = 200
        # 初始化ES客户端
        self.es_client = ElasticSearchClient("meta_prod")
        # 随机样本数量
        self.sample_num = 500
        # 并发控制参数
        self.n_jobs = 5  # 并发度
        self.file_lock = threading.Lock()  # 文件锁

    def process(self):
        # 读取输入数据
        input_list = read_fuzzy_jsonl_file(self.input_path)
        # 随机采样数据
        proportions, sample_list = self.sample_strategy(input_list)
        write_json_file(proportions, self.output_path + ".proportions.json")
        # 并发处理数据
        Parallel(n_jobs=self.n_jobs, prefer="threads")(
            delayed(self.process_and_save_sample_one)(sample_one)
            for sample_one in tqdm(sample_list, total=len(sample_list))
        )

    def sample_strategy(self, input_list):
        # 计算每种类型的占比
        total = len(input_list)
        counter = Counter([item.get("api_name", "") for item in input_list])
        proportions = {k: v/total for k, v in counter.items()}
        # 设置随机种子以保证结果可复现
        random.seed(42)
        # 按api_name分组
        auto_items = [item for item in input_list if item.get("api_name") == "AUTOSearch"]
        media_items = [item for item in input_list if item.get("api_name") == "MEDIASearch"]
        qa_items = [item for item in input_list if item.get("api_name") == "QASearch"]
        # 为每种类型随机采样数据（如果有足够的数据）
        sampled_auto = random.sample(auto_items, min(self.sample_num, len(auto_items)))
        sampled_media = random.sample(media_items, min(self.sample_num, len(media_items)))
        sampled_qa = random.sample(qa_items, min(self.sample_num, len(qa_items)))
        # 合并结果
        final_sample = sampled_auto + sampled_media + sampled_qa
        return proportions, final_sample

    def process_and_save_sample_one(self, sample_one):
        sample_one_processed = self.process_sample_one(sample_one)
        # 写入单条数据的处理结果
        if sample_one_processed is not None:
            with self.file_lock:
                with open(self.output_path, "a") as f:
                    f.write(json.dumps(sample_one_processed, ensure_ascii=False) + "\n")

    def process_sample_one(self, sample_one):
        request_time = sample_one.get("request_time", "")
        api_query = sample_one.get("api_query", "")
        api_name = sample_one.get("api_name", "")
        category = sample_one.get("category", "")
        media_type = sample_one.get("media_type", "")

        # 调试逻辑
        # print(request_time, api_query, api_name, category, media_type)
        # if api_name != "AUTOSearch" or category != "汽车":
        #     return None
        # if api_name != "QASearch" or category != "公司":
        #     return None
        # if api_name != "MEDIASearch" or media_type != "视频":
        #     return None

        # 解析时效特征
        time_feature = parse_time_feature(sample_one)
        sample_one.update(time_feature)

        # 解析搜索结果
        bot_data = parse_bot_data(sample_one)
        if len(bot_data) == 0:
            sample_one["label_msg"] = "bot_data empty"
            sample_one["label_llm"] = ""
            return sample_one

        # 分别处理不同的api_name
        if api_name == "AUTOSearch":
            status, msg, item_list, label_llm = label_vehicle_result(
                api_query, request_time, time_feature, bot_data)
        elif api_name == "MEDIASearch":
            if media_type == "新闻":
                status, msg, item_list, label_llm = label_news_result(
                    api_query, request_time, time_feature, bot_data)
            elif media_type == "视频":
                status, msg, item_list, label_llm = label_vedio_result(
                    api_query, request_time, time_feature, bot_data, self.es_client)
            elif media_type == "音乐":
                status, msg, item_list, label_llm = label_default_result(
                    api_query, request_time, time_feature, bot_data)
            elif media_type == "体育":
                status, msg, item_list, label_llm = label_default_result(
                    api_query, request_time, time_feature, bot_data)
            else:
                status, msg, item_list, label_llm = label_default_result(
                    api_query, request_time, time_feature, bot_data)
        elif api_name == "QASearch":
            status, msg, item_list, label_llm = label_default_result(
                api_query, request_time, time_feature, bot_data)
        else:
            status, msg, item_list, label_llm = False, "api_name exception", [], ""
        # 标注搜索结果失败
        if status is False:
            sample_one["label_msg"] = msg
            sample_one["label_llm"] = ""
            return sample_one
        # 简化数据，用于飞书表格展示
        if self.need_simple_data is True:
            item_list = self.simple_data(item_list)
        sample_one["is_recall"] = 1
        sample_one["item_list"] = json.dumps(item_list, ensure_ascii=False, indent=4)
        sample_one["label_msg"] = msg
        sample_one["label_llm"] = label_llm
        return sample_one

    def simple_data(self, item_list):
        for item in item_list:
            content = item["content"]
            if type(content) is str:
                item["content"] = content[:self.cutoff_len]
            elif type(content) is dict:
                for k, v in content.items():
                    if type(v) is str:
                        item["content"][k] = v[:self.cutoff_len]
        return item_list


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--end_date", type=str, help="End date in YYYY-MM-DD format. Defaults to yesterday")
    args = parser.parse_args()
    obj = LabelSearchResult(args.end_date)
    obj.process()

# python -m search.rag.log_analyse.v2.step2_label_search_result --end_date=2025-03-23
# nohup python -m search.rag.log_analyse.v2.step2_label_search_result --end_date=2025-03-23 > log/search/rag/log_analyse/v2/step2_label_search_result.log.2025-03-23 2>&1 &
# nohup python -m search.rag.log_analyse.v2.step2_label_search_result --end_date=2025-03-30 > log/search/rag/log_analyse/v2/step2_label_search_result.log.2025-03-30 2>&1 &
# python utils/data_utils/data_trans.py
