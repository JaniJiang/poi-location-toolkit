#!/bin/bash
# bash search/rag/log_analyse/v1/step1_extract_log.sh

log_date="2025-03-25"
cd ark_script && /opt/spark/bin/spark-submit car_log_for_rag_daily.py --log_date=${log_date}
