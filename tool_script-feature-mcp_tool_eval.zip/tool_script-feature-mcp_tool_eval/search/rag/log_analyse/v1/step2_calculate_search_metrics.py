import csv
import copy
import json
import random
from tqdm import tqdm
from utils.file_utils import read_fuzzy_jsonl_file
from utils.llm_utils.serverless_function import request_llm
from search.rag.log_analyse.v1.prompt import SYSTEM_PROMPT, USER_PROMPT
from search.rag.log_analyse.rag_utils import *

random.seed(42)


class CalculateSearchMetrics:

    def __init__(self):
        date = "2025-03-25"  # "2025-03-18"
        self.input_path = f"data/cloud/ark_log/result/car_log_for_rag_daily_sampled/{date}/part-00000-*.json"
        self.output_path = f"data/cloud/search/rag/log_analyse/v1/{date}/step2_calculate_search_metrics"
        self.sample_num = 1000
        self.model_name = "gpt-4o"
        self.add_field_dict = {
            "is_time": 0, "time_type": "", "time_granularity": "",
            "label_msg": "", "is_recall": 0, "item_list": "",
            "label_llm": "", "label_num": 0, "label_p": 0, "label_acc": 0,
        }
        self.del_field_list = ["knowledge_search_result", "media_search_result", "time_space_modify_response"]

    def process(self):
        # 读取输入数据
        input_list = read_fuzzy_jsonl_file(self.input_path)
        # 随机采样数据
        sample_list = random.sample(input_list, self.sample_num)
        # 逐条处理数据
        query_counter_dict = {}
        for sample_one in tqdm(sample_list, total=len(sample_list)):
            sample_one.update(copy.deepcopy(self.add_field_dict))
            request_time = sample_one.get("request_time", "")
            # 校验api_query
            api_query = sample_one.get("api_query", "")
            if api_query not in query_counter_dict:
                query_counter_dict[api_query] = 1
            else:  # TODO: 这部分不应该留在sample_list
                query_counter_dict[api_query] += 1
                print(f"api_query[{api_query}] exist")
                continue
            # 解析时效特征
            time_feature = parse_time_feature(sample_one)
            sample_one.update(time_feature)
            # 解析搜索结果
            parse_status, parse_msg, item_list = self.parse_search_result(sample_one)
            if parse_status is False:
                sample_one["label_msg"] = parse_msg
                continue
            # 判断准确性
            try:
                item_json = json.dumps(item_list, ensure_ascii=False, indent=4)
                history = [
                    SYSTEM_PROMPT,
                    USER_PROMPT.format(
                        query=api_query,
                        request_time=request_time,
                        time_feature=json.dumps(time_feature, ensure_ascii=False, indent=4),
                        item_list=item_json
                    )
                ]
                payload, response_data = request_llm(history, model=self.model_name, n=1, temperature=0)
                # print(json.dumps({"payload": payload, "response": response_data}, ensure_ascii=False))
                label_str = response_data["choices"][0]["message"]["content"]
                label_status, label_num, label_p, label_acc = self.parse_label(label_str)
                if label_status is False:
                    print(f"api_query[{api_query}] parse_label failed: {label_str}")
                    sample_one["label_msg"] = "parse_label failed"
                    continue
                sample_one["is_recall"] = 1
                sample_one["item_list"] = item_json
                sample_one["label_llm"] = label_str
                sample_one["label_num"] = label_num
                sample_one["label_p"] = label_p
                sample_one["label_acc"] = label_acc
            except Exception as e:
                print(f"api_query[{api_query}] exception: {str(e)}")
                sample_one["label_msg"] = "exception"
        # 计算指标
        self.calculate_metrics(sample_list, query_counter_dict)
        # 保存挖掘结果到jsonl文件
        with open(self.output_path + ".jsonl", "w", encoding="utf-8") as f:
            for sample_one in sample_list:
                f.write(json.dumps(sample_one, ensure_ascii=False) + "\n")
        # 保存挖掘结果到tsv文件
        fieldnames = sample_list[0].keys()
        with open(self.output_path + ".tsv", "w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter="\t")
            writer.writeheader()
            writer.writerows(sample_list)

    def parse_search_result(self, sample_one):
        api_name = sample_one.get("api_name", "")
        try:
            if api_name == "MEDIASearch":
                search_result_str = sample_one.get("media_search_result", "")
                search_result_list = json.loads(search_result_str)
                bot_data = search_result_list[0].get("data", [])
            else:
                search_result_str = sample_one.get("knowledge_search_result", "")
                search_result_list = json.loads(search_result_str)
                bot_data = search_result_list[0].get("data", [])[0].get("bot_data", [])
        except:
            bot_data = []
        if len(bot_data) == 0:
            return False, "bot_data empty", []
        item_list = []
        hit_default_reply = False
        for idx, item in enumerate(bot_data):
            title = item.get("title", "")
            content = item.get("content", "")
            if check_default_reply(content) is True:
                hit_default_reply = True
                break
            date_published = item.get("date_published", "")
            item_list.append({
                "idx": idx + 1,
                "title": title,
                "content": content,
                "date_published": date_published,
            })
        if hit_default_reply is True:
            return False, "default reply", []
        if len(item_list) == 0:
            return False, "item_list empty", []
        return True, "", item_list

    def parse_label(self, label_str):
        try:
            label_list = json.loads(label_str)
            label_num = len(label_list)
            label_p = 0
            label_acc = 0
            for label_one in label_list:
                if label_one.get("label", "") == "满足":
                    label_p = 1
                    label_acc += 1
            return True, label_num, label_p, label_acc
        except Exception as e:
            print(f"parse_label failed: {str(e)}")
            return False, 0, 0, 0

    def calculate_metrics(self, sample_list, query_counter_dict):
        try:
            p_all = 0
            p_real = 0
            acc_all = 0
            acc_real = 0
            for sample_one in sample_list:
                for del_field in self.del_field_list:
                    if del_field in sample_one:
                        del sample_one[del_field]
                api_query = sample_one.get("api_query", "")
                pv = query_counter_dict.get(api_query, 0)
                sample_one["pv"] = pv
                if sample_one.get("is_recall", 0) == 0:
                    continue
                # 计算准确性指标
                p_all += 1 * pv
                p_real += sample_one["label_p"] * pv
                acc_all += sample_one["label_num"] * pv
                acc_real += sample_one["label_acc"] * pv
            p_result = p_real / p_all if p_all > 0 else 0.0
            acc_result = acc_real / acc_all if acc_all > 0 else 0.0
            with open(self.output_path + ".metrics.tsv", "w") as f:
                f.write("\n".join([
                    f"P\t{p_result}",
                    f"ACC\t{acc_result}",
                ]) + "\n")
        except Exception as e:
            print(f"calculate_metrics failed: {str(e)}")


if __name__ == "__main__":
    obj = CalculateSearchMetrics()
    obj.process()

# python -m search.rag.log_analyse.v1.step2_calculate_search_metrics
# nohup python -m search.rag.log_analyse.v1.step2_calculate_search_metrics > log/search/rag/log_analyse/v1/step2_calculate_search_metrics.log 2>&1 &
