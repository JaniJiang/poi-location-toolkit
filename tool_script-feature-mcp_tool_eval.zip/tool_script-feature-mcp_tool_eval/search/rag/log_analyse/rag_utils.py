import re
import json
from datetime import datetime, timedelta
from utils.nlp_utils.freshness_api import request_freshness, time_intent_granularity
from utils.search_utils.es_client import search_item_by_id
from utils.llm_utils.serverless_function import request_llm
from search.rag.log_analyse.v2.prompt_default import *
from search.rag.log_analyse.v2.prompt_news import *
from search.rag.log_analyse.v2.prompt_vedio import *
from search.rag.log_analyse.v2.prompt_vehicle import *

DEFAULT_REPLY_LIST = [
    "关于这个问题，我目前无法提供准确的答案。",
    "关于这个问题，我暂时没有查询到相关信息。",
]


def parse_time_feature(sample_one):
    """解析时效特征"""
    try:
        time_space_modify_response = json.loads(sample_one.get("time_space_modify_response", "{}"))
        time_intent = time_space_modify_response.get("time_intent", {})
        is_time = time_intent.get("is_time", 0)
        time_type = time_intent.get("time_type", "一般")
        time_granularity = time_intent.get("time_granularity", "无")
        if time_type == "突发":
            api_query = sample_one.get("api_query", "")
            freshness_result = request_freshness(api_query)
            pred_score = freshness_result.get("general_timeliness_probability_score", -1)
            is_time, time_granularity = time_intent_granularity(pred_score)
        time_feature = {
            "is_time": is_time,
            "time_granularity": time_granularity,
        }
    except:
        time_feature = {
            "is_time": 0,
            "time_granularity": "无"
        }
    return time_feature


def parse_bot_data(sample_one):
    """解析搜索结果"""
    api_name = sample_one.get("api_name", "")
    try:
        if api_name == "MEDIASearch":
            search_result_str = sample_one.get("media_search_result", "")
            search_result_list = json.loads(search_result_str)
            bot_data = search_result_list[0].get("data", [])
        else:
            search_result_str = sample_one.get("knowledge_search_result", "")
            search_result_list = json.loads(search_result_str)
            bot_data = search_result_list[0].get("data", [])[0].get("bot_data", [])
    except Exception as e:
        print("parse_bot_data failed:", e)
        bot_data = []
    return bot_data


def check_default_reply(content):
    """校验是否默认回复(汽车搜索独有)"""
    for default_reply_one in DEFAULT_REPLY_LIST:
        if default_reply_one in content:
            return True
    return False


def label_vehicle_result(api_query, request_time, time_feature, bot_data):
    """标注汽车搜索结果"""
    # 格式化搜索结果
    item_list = []
    hit_default_reply = False
    for idx, item in enumerate(bot_data):
        content = item.get("content", "")
        if check_default_reply(content) is True:
            hit_default_reply = True
            break
        title = item.get("title", "")
        date_published = item.get("date_published", "")
        content, date_published = clean_fields(content, title, date_published)
        item_list.append({
            "idx": idx + 1,
            "title": title,
            "content": content,
            "date_published": date_published,
            "doc_source": item.get("doc_source", ""),
            "source_name": item.get("source_name", ""),
            "source_domain": item.get("source_domain", ""),
        })
    if hit_default_reply is True:
        return False, "default reply", [], ""
    if len(item_list) == 0:
        return False, "item_list empty", [], ""
    # 构造Prompt，标注搜索结果
    label_llm = llm_label(VEHICLE_SYSTEM_PROMPT, VEHICLE_USER_PROMPT, api_query, request_time, time_feature, item_list)
    return True, "", item_list, label_llm


def label_news_result(api_query, request_time, time_feature, bot_data):
    """标注新闻搜索结果"""
    # 格式化搜索结果
    item_list = []
    for idx, item in enumerate(bot_data):
        title = item.get("title", "")
        content = item.get("content", "")
        date_published = item.get("date_published", "")
        try:
            news_dict = json.loads(content)
            news_title = news_dict.get("新闻标题", "")
            if news_title != "":
                title = news_title
            news_content = news_dict.get("新闻内容", "")
            if news_content != "":
                content = news_content
            date_published = news_dict.get("新闻发布时间", "")
        except Exception as e:
            print("label_news_result failed:", e)
            pass
        content, date_published = clean_fields(content, title, date_published)
        pattern = r"\b\d{4}-\d{2}-\d{2} \d{2}:\d{2}\b"
        content = re.sub(pattern, "", content).strip()
        item_list.append({
            "idx": idx + 1,
            "title": title,
            "content": content,
            "date_published": date_published,
        })
    if len(item_list) == 0:
        return False, "item_list empty", [], ""
    # 构造Prompt，标注搜索结果
    label_llm = llm_label(NEWS_SYSTEM_PROMPT, NEWS_USER_PROMPT, api_query, request_time, time_feature, item_list)
    return True, "", item_list, label_llm


def label_vedio_result(api_query, request_time, time_feature, bot_data, es_client):
    """标注视频搜索结果"""
    item_list = format_default_result(bot_data, need_id=True)
    if len(item_list) == 0:
        return False, "item_list empty", [], ""
    # 视频走的是media-bot，不能拿到发布时间，通过媒资库补充视频时间
    for item in item_list:
        # 通过媒资库补充视频时间
        date_published = item.get("date_published", "")
        item_id = item.get("id", "")
        if date_published == "" and item_id != "":
            publish_time = search_vedio_by_id(request_time, es_client, item_id)
            if publish_time != "":
                date_published = publish_time
            del item["id"]
        date_published = convert_to_date_format(date_published)
        item["date_published"] = date_published
        # 格式化内容
        try:
            content_dict = json.loads(item["content"])
            item["content"] = content_dict
        except Exception as e:
            print("label_vedio_result failed:", e)
    # 构造Prompt，标注搜索结果
    label_llm = llm_label(VEDIO_SYSTEM_PROMPT, VEDIO_USER_PROMPT, api_query, request_time, time_feature, item_list)
    return True, "", item_list, label_llm


def label_default_result(api_query, request_time, time_feature, bot_data):
    """标注通用搜索结果(默认)"""
    # 格式化搜索结果
    item_list = format_default_result(bot_data)
    if len(item_list) == 0:
        return False, "item_list empty", [], ""
    # 构造Prompt，标注搜索结果
    label_llm = llm_label(DEFAULT_SYSTEM_PROMPT, DEFAULT_USER_PROMPT, api_query, request_time, time_feature, item_list)
    return True, "", item_list, label_llm


def llm_label(system_prompt, user_prompt, api_query, request_time, time_feature, item_list, model_name="gpt-4o"):
    if system_prompt == "" or user_prompt == "":
        return "prompt empty"
    try:
        history = [
            system_prompt,
            user_prompt.format(
                query=api_query,
                request_time=request_time,
                time_feature=json.dumps(time_feature, ensure_ascii=False, indent=4),
                item_list=json.dumps(item_list, ensure_ascii=False, indent=4)
            )
        ]
        payload, response_data = request_llm(history, model=model_name, n=1, temperature=0)
        # print(json.dumps({"payload": payload, "response": response_data}, ensure_ascii=False))
        label_str = response_data["choices"][0]["message"]["content"]
        return label_str
    except Exception as e:
        print(f"api_query[{api_query}] llm_label exception: {str(e)}")
        return ""


def parse_label(label_str):
    try:
        label_list = json.loads(label_str)
        label_num = len(label_list)
        label_p = 0
        label_acc = 0
        bad_reason_type_list = []
        uncertain_reason_type_list = []
        for label_one in label_list:
            if label_one.get("label", "") == "满足":
                label_p = 1
                label_acc += 1
            elif label_one.get("label", "") == "不满足":
                reason_type = label_one["reason_type"] if "reason_type" in label_one else label_one.get("reason", "")
                if reason_type != "":
                    bad_reason_type_list.append(reason_type)
            elif label_one.get("label", "") == "不确定":
                reason_type = label_one["reason_type"] if "reason_type" in label_one else label_one.get("reason", "")
                if reason_type != "":
                    uncertain_reason_type_list.append(reason_type)
        bad_reason_type = ";".join(sorted(list(set(bad_reason_type_list))))
        uncertain_reason_type = ";".join(sorted(list(set(uncertain_reason_type_list))))
        return True, label_num, label_p, label_acc, bad_reason_type, uncertain_reason_type
    except Exception as e:
        print(f"parse_label failed: {str(e)}")
        return False, 0, 0, 0, "", ""


def format_default_result(bot_data, need_id=False):
    item_list = []
    for idx, item in enumerate(bot_data):
        title = item.get("title", "")
        content = item.get("content", "")
        date_published = item.get("date_published", "")
        doc_timestamp = item.get("extend_data", {}).get("doc_timestamp", "")
        if date_published == "" and doc_timestamp != "":  # 体育搜索兼容逻辑：体育发布时间放在doc_timestamp
            date_published = doc_timestamp
        content, date_published = clean_fields(content, title, date_published)
        item_new = {
            "idx": idx + 1,
            "title": title,
            "content": content,
            "date_published": date_published,
        }
        if need_id is True:  # 视频搜索兼容逻辑：保留视频id
            item_id = item.get("id", "")
            if item_id != "":
                item_new["id"] = item_id
        item_list.append(item_new)
    return item_list


def clean_fields(content, title, date_published):
    # 删除title
    if title != "" and content.startswith(title) is True:
        content = content[len(title):].lstrip()
    # 提取并删除发布时间
    extract_date, content = extract_date_and_clean_content(content)
    content = content.lstrip("；").lstrip(";").lstrip()
    # 格式化发布时间
    date_published = convert_to_date_format(date_published)
    if date_published == "" and extract_date != "":
        date_published = extract_date
    return content, date_published


def extract_date_and_clean_content(content):
    """
    Extract date from the beginning of content string and remove that part.
    Args:
        content (str): The content string that may start with a date
    Returns:
        tuple: (extracted_date, cleaned_content)
            - extracted_date (str): Date in the format 'YYYY-MM-DD' or None if no date found
            - cleaned_content (str): Content with the date part removed
    """
    # Pattern to match various date formats at the beginning of the string
    # Handles formats like:
    # - 发布时间：2025-01-12
    # - 发布时间：2025-01-12 00:00:00
    # - 发布时间：2025-02-20T08:00:00
    # - 发布时间：2018-07-06T08:00:00.0000000
    pattern = r"^发布时间：(\d{4}-\d{2}-\d{2})(?:[ T]\d{2}:\d{2}:\d{2}(?:\.\d+)?)?"
    match = re.search(pattern, content)
    if match:
        date_str = match.group(1)  # Extract just the YYYY-MM-DD part
        full_match = match.group(0)  # The entire matched string
        # Remove the matched part from the content
        cleaned_content = content[len(full_match):].lstrip()
        return date_str, cleaned_content
    else:
        # No date found at the beginning
        return "", content


def convert_to_date_format(date_string):
    """
    Convert various date time string formats to YYYY-MM-DD format.
    Args:
        date_string (str): Date string in various formats
            - YYYY-MM-DD
            - YYYY-MM-DD HH:MM:SS
            - YYYY-MM-DDThh:mm:ss
            - YYYY-MM-DDThh:mm:ss.fffffff
    Returns:
        str: Date string in YYYY-MM-DD format
    """
    # Try different formats
    formats = [
        '%Y-%m-%d',                  # 2025-01-12
        '%Y-%m-%d %H:%M:%S',         # 2025-01-12 00:00:00
        '%Y-%m-%dT%H:%M:%S',         # 2025-02-20T08:00:00
        '%Y-%m-%dT%H:%M:%S.%f'       # 2018-07-06T08:00:00.0000000
    ]
    for fmt in formats:
        try:
            date_obj = datetime.strptime(date_string, fmt)
            return date_obj.strftime('%Y-%m-%d')
        except ValueError:
            continue
    # If no format matched
    return date_string


def search_vedio_by_id(request_time, es_client, item_id, source=["id", "publish_time"]):
    current_date, nearby_date_list = get_nearby_dates(request_time)
    nearby_index_list = [f"ssai_tv_meta_{nearby_date}" for nearby_date in nearby_date_list]
    index_name_list = [f"ssai_tv_meta_{current_date}", "ssai_tv_meta"]
    index_name_list.extend(nearby_index_list)
    for index_name in index_name_list:
        search_item = search_item_by_id(es_client, index_name, item_id, source)
        if search_item is not None:
            publish_time = search_item.get("publish_time", "")
            if publish_time != "":
                return publish_time
    return ""


def get_nearby_dates(request_time):
    """获取当前日期及前后三天的日期"""
    # 解析输入时间
    dt = datetime.strptime(request_time, "%Y-%m-%d %H:%M:%S")
    current_date = dt.strftime("%Y%m%d")
    # 生成前后三天的日期
    nearby_date_list = []
    for delta in [-3, -2, -1, 1, 2, 3]:  # 前后三天（不包括当天）
        nearby_date = dt + timedelta(days=delta)
        nearby_date_list.append(nearby_date.strftime("%Y%m%d"))
    return current_date, nearby_date_list
