import json
import pandas as pd
from tqdm import tqdm


class SearchTruncation:

    def __init__(self):
        self.input_path = "data/cloud_share/search/rag/search_truncation/merge_log_data.tsv"
        self.output_path = "data/cloud_share/search/rag/search_truncation/output.tsv"

    def process(self):
        result_list = []
        input_df = pd.read_csv(self.input_path, sep="\t").fillna("")
        for _, row in tqdm(input_df.iterrows(), total=len(input_df)):
            content = json.loads(row["content"])
            api_name = content["APINAME"]
            # 解析搜索结果
            bot_data = []
            try:
                if api_name == "MEDIASearch":
                    media_search_result_list = json.loads(row["media_search_result"])
                    if len(media_search_result_list) > 0:
                        for data_i in media_search_result_list:
                            bot_data.extend(data_i.get("data", []))
                else:
                    knowledge_search_result_list = json.loads(row["knowledge_search_result"])
                    if len(knowledge_search_result_list) > 0:
                        for data_j in knowledge_search_result_list:
                            bot_data.extend(data_j.get("data", [])[0].get("bot_data", []))
            except Exception as e:
                print("process search_result failed: ", e)
                continue
            # 解析模型输入
            obs_list = []
            try:
                model_13b_input = json.loads(row["model_13b_input"])
                messages = model_13b_input["messages"]
                for idx in range(len(messages)-1, -1, -1):
                    message = messages[idx]
                    if message["role"] == "":
                        continue
                    if message["role"] != "tool":
                        break
                    if api_name == "MEDIASearch":
                        obs_list.extend(message["content"])
                    else:
                        obs_list.extend(message["content"][0].get("search_result", []))
            except Exception as e:
                print("process obs failed: ", e)
                continue
            # 拼装输出结果
            result_list.append({
                "record_id": row["record_id"],
                "raw_query": row["raw_query"],
                "query": row["query"],
                "api_name": api_name,
                "api_query": content["QUERY"],
                "search_num": len(bot_data),
                "obs_num": len(obs_list),
                "diff_num": len(bot_data) - len(obs_list),
            })
        # 保存结果
        result_df = pd.DataFrame(result_list)
        result_df.to_csv(self.output_path, header=True, index=False, sep="\t")


if __name__ == "__main__":
    obj = SearchTruncation()
    obj.process()

# python -m search.rag.search_truncation
