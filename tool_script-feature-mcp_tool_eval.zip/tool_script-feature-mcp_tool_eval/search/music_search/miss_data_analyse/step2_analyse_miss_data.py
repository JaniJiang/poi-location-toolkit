import pandas as pd
from datetime import datetime, timedelta
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from search.music_search.miss_data_analyse.step1_get_miss_data import MissMusicData


class MusicDataAnalyse:
    HOODIE_META_COLS = [
        "_hoodie_commit_time", "_hoodie_commit_seqno", "_hoodie_record_key",
        "_hoodie_partition_path", "_hoodie_file_name"
    ]

    @staticmethod
    def load_df_from_hudi(spark: SparkSession, table_path: str):
        df = spark.read.format("hudi").load(table_path)
        # 去除hudi元数据字段
        cols_to_drop = [
            c for c in MusicDataAnalyse.HOODIE_META_COLS if c in df.columns]
        if cols_to_drop:
            df = df.drop(*cols_to_drop)
        return df

    @staticmethod
    def get_last_dt(df, dt_col: str):
        """
        筛选出最大日期的数据
        """
        dt_values = [row[dt_col] for row in df.select(
            dt_col).distinct().collect() if row[dt_col]]
        if not dt_values:
            raise ValueError(f"No valid values found in column {dt_col}")
        last_dt = max(dt_values)
        return df.filter(col(dt_col) == last_dt)

    @classmethod
    def load_bos_data(cls, spark: SparkSession, bos_path: str, dt_col="dt"):
        """
        加载BOS数据，并过滤最后分区的数据
        """
        df = cls.load_df_from_hudi(spark, bos_path)
        df = cls.get_last_dt(df, dt_col)
        return df

    @classmethod
    def find_problem(
        cls, miss_music_list, bos_path, output_csv_path, dt_col="dt", spark=None
    ):
        """
        核查缺失歌曲原因，并将结果输出到CSV
        """
        if spark is None:
            spark = SparkSession.builder.getOrCreate()
        spark.sparkContext.setLogLevel("ERROR")
        # 只保留最后分区的数据
        df = cls.load_bos_data(spark, bos_path, dt_col)
        all_songs = set(row['song_name'] for row in df.select(
            'song_name').distinct().collect() if row['song_name'])

        result = []
        for song_name in miss_music_list:
            miss_reason = "中间流程问题" if song_name in all_songs else "无资源"
            result.append({
                "song_name": song_name,
                "miss_reason": miss_reason
            })
        pd.DataFrame(result).to_csv(
            output_csv_path,
            index=False,
            encoding="utf-8-sig"
        )
        print(f"[INFO] Result saved to: {output_csv_path}")

        return result


if __name__ == '__main__':
    env = "prod"
    yesterday = (datetime.now() - timedelta(days=1)).strftime('%Y%m%d')
    index_name = f"kgs_music_recommend_v3_newrelease_{yesterday}"
    miss_music_data = MissMusicData(env, index_name)
    miss_music_list = miss_music_data.process()
    table_path = 'bos://spaceai-internal/dmp/eps_idc_dwd/dwd_idc_life_ent_music_qq_df/'
    output_csv = "/mnt/volumes/ss-spaceai-lx-my/zhaojiufeng/tool_script/search/music_search/miss_data_analyse/analyse_result.csv"
    MusicDataAnalyse.find_problem(
        miss_music_list,
        table_path,
        output_csv
    )
