import pandas as pd
from datetime import datetime, timedelta
from typing import List, Optional
from utils.search_utils.es_client import ElasticSearchClient


class MissMusicData:
    def __init__(self, env: str, index_name: str, refresh_index: bool = False):
        self.index_name = index_name
        self.refresh_index = refresh_index
        self.input_path = (
            "/mnt/volumes/ss-spaceai-lx-my/zhaojiufeng/data/data_cloud/search/"
            "media_search/music/miss_music_analyse/miss_data.tsv"
        )
        cluster_name = "music_prod" if env == "prod" else "music_testtwo"
        self.es_client = ElasticSearchClient(cluster_name)

    def process(self) -> Optional[List[str]]:
        try:
            df = pd.read_csv(self.input_path, sep='\t')
            miss_titles = df['title'].dropna().unique()
        except Exception as e:
            print(f"[ERROR] Error reading data file: {e}")
            return None

        missed = []
        no_missed = []
        for title in miss_titles:
            search_query = {
                "query": {
                    "term": {
                        "song_name": title   # 精确匹配
                    }
                }
            }
            try:
                res = self.es_client.search(
                    search_query, self.index_name, need_parse=True
                )
                # 如果没有返回结果，则说明未命中
                if not res:
                    missed.append(title)
                else:
                    no_missed.append({
                        "song_name": title,
                        "miss_reason": "媒资库有资源"
                    })
            except Exception as e:
                print(f"[ERROR] ES search failed for title '{title}': {e}")
        # print(no_missed)
        return missed


if __name__ == '__main__':
    env = "prod"
    yesterday = (datetime.now() - timedelta(days=1)).strftime('%Y%m%d')
    index_name = f"kgs_music_recommend_v3_newrelease_{yesterday}"
    miss_music_data = MissMusicData(env, index_name)
    miss_music_list = miss_music_data.process()
    print(miss_music_list)
    output_csv_path = (
        "/mnt/volumes/ss-spaceai-lx-my/zhaojiufeng/data/data_cloud/search/"
        "media_search/music/miss_music_analyse/es_miss_data.tsv"
    )
    if miss_music_list is not None:
        df_out = pd.DataFrame(miss_music_list, columns=["miss_title"])
        df_out.to_csv(
            output_csv_path,
            index=False,
            encoding="utf-8-sig",
            sep="\t")
        print(f"[INFO] Missed data saved to {output_csv_path}")
    # python -m search.music_search.miss_data_analyse.step1_get_miss_data
