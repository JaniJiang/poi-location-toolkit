import pandas as pd
import numpy as np
from typing import Dict, List, Callable, Optional, Union
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')


class SentimentAnalyzer:
    """舆情分析器类，支持自定义规则和类别"""

    def __init__(self, data_path: str, sep: str = "\t"):
        """
        初始化分析器

        Args:
            data_path: 数据文件路径
            sep: 文件分隔符
        """
        self.data_path = data_path
        self.sep = sep
        self.df = None
        self.categories = []
        self.rules = {}
        self.category_filters = {}  # 类别筛选规则
        self.category_time_markers = {}  # 每个类别的时间标记线配置
        self._load_data()
        self._init_default_rules()

    def _load_data(self):
        """加载数据"""
        self.df = pd.read_csv(self.data_path, sep=self.sep)

        # 确保字段类型正确
        self.df['type'] = self.df['type'].astype(str)
        self.df['answer'] = pd.to_numeric(self.df['answer'], errors='coerce')
        self.df['is_public_sentiment'] = pd.to_numeric(self.df['is_public_sentiment'], errors='coerce')
        self.df['dt'] = pd.to_datetime(self.df['dt'], errors='coerce')

        # 确保output字段存在且为字符串类型
        if 'output' in self.df.columns:
            self.df['output'] = self.df['output'].astype(str)
        else:
            print("警告: 数据中没有'output'字段，将创建空字段")
            self.df['output'] = ''

        # 确保query字段存在且为字符串类型
        if 'query' in self.df.columns:
            self.df['query'] = self.df['query'].astype(str)
        else:
            print("警告: 数据中没有'query'字段，将创建空字段")
            self.df['query'] = ''

        # 删除dt为空的行
        self.df = self.df.dropna(subset=['dt'])

    def _init_default_rules(self):
        """初始化默认规则"""
        # 碰撞安全规则
        self.add_category_rule(
            '碰撞安全',
            self._create_keyword_include_rule(['卡车']),
            "output包含'卡车'则加入现存舆情",
            filter_func=self._create_type_filter('碰撞安全'),
            time_markers=[
                {'date': '2025-08-01', 'label': '干预时间', 'color': 'green'},
            ]
        )

        # 停车问题规则
        self.add_category_rule(
            '停车问题',
            self._create_keyword_include_rule(['梗', '网络', '幽默', '段子']),
            "output包含'梗'/'网络'/'幽默'/'段子'则加入现存舆情",
            filter_func=self._create_type_filter('停车问题'),
            time_markers=[
                {'date': '2025-08-08', 'label': '干预时间', 'color': 'green'}
            ]
        )

        # i8销量规则（特殊处理）
        self.add_category_rule(
            'i8销量',
            self._create_i8_sales_rule(),
            "只有output包含'辆'才是现存舆情",
            filter_func=self._create_i8_sales_filter(),
            time_markers=[
                {'date': '2025-08-01', 'label': '干预时间', 'color': 'green'},
            ]
        )

        # 外部车型对比规则（多个规则，有优先级）
        self.add_category_rule(
            '外部车型对比',
            self._create_external_comparison_rule(),
            "优先级1: 包含竞品关键词则加入; 优先级2: 包含'宝马'则排除",
            filter_func=self._create_type_filter('外部车型对比'),
            time_markers=[
                {'date': '2025-08-04', 'label': '干预时间', 'color': 'green', }
            ]
        )

    def add_category_rule(self, category: str, rule_func: Callable, description: str = "",
                          filter_func: Callable = None, time_markers: list = None):
        """
        添加类别规则

        Args:
            category: 类别名称
            rule_func: 规则函数，接收DataFrame，返回is_existing_sentiment Series
            description: 规则描述
            filter_func: 筛选函数，用于从总数据中筛选该类别的数据
            time_markers: 时间标记线配置，格式如：
                ['2024-01-15']  # 简单日期
                或
                [
                    {'date': '2024-01-15', 'label': '版本更新', 'color': 'green'},
                    {'date': '2024-01-20', 'label': '规则调整', 'color': 'red'}
                ]
        """
        if category not in self.categories:
            self.categories.append(category)

        self.rules[category] = {
            'func': rule_func,
            'description': description
        }

        # 如果提供了筛选函数，使用它；否则使用默认的type筛选
        if filter_func:
            self.category_filters[category] = filter_func
        else:
            self.category_filters[category] = self._create_type_filter(category)

        # 设置时间标记
        if time_markers:
            self.set_category_time_markers(category, time_markers)

    def set_category_time_markers(self, category: str, time_markers: list):
        """
        为特定类别设置时间标记线

        Args:
            category: 类别名称
            time_markers: 时间标记配置列表
        """
        if time_markers:
            normalized_markers = []
            for marker in time_markers:
                if isinstance(marker, str):
                    # 简单字符串日期
                    normalized_markers.append({
                        'date': marker,
                        'label': f'时间节点',
                        'color': 'orange',
                        'dash': 'dashdot',
                        'width': 2
                    })
                elif isinstance(marker, dict):
                    # 完整配置
                    normalized_marker = {
                        'date': marker.get('date'),
                        'label': marker.get('label', '时间节点'),
                        'color': marker.get('color', 'orange'),
                        'dash': marker.get('dash', 'dashdot'),
                        'width': marker.get('width', 2)
                    }
                    normalized_markers.append(normalized_marker)

            self.category_time_markers[category] = normalized_markers

    def remove_category_rule(self, category: str):
        """移除类别规则"""
        if category in self.categories:
            self.categories.remove(category)
        if category in self.rules:
            del self.rules[category]
        if category in self.category_filters:
            del self.category_filters[category]
        if category in self.category_time_markers:
            del self.category_time_markers[category]

    # ===== 筛选器函数 =====

    @staticmethod
    def _create_type_filter(type_name: str):
        """创建基于type字段的默认筛选器"""
        def filter_func(df: pd.DataFrame) -> pd.DataFrame:
            return df[df['type'] == type_name]
        return filter_func

    @staticmethod
    def _create_i8_sales_filter():
        """创建i8销量的特殊筛选器"""
        def filter_func(df: pd.DataFrame) -> pd.DataFrame:
            # 检查query中是否包含i8/I8
            contains_i8 = df['query'].str.contains(r'[iI]8', na=False, regex=True)

            # 检查query中是否包含销量相关词
            sales_keywords = ['销量', '小定', '大定', '卖了']
            sales_pattern = '|'.join(sales_keywords)
            contains_sales = df['query'].str.contains(sales_pattern, na=False, regex=True)

            # 同时满足两个条件
            is_i8_sales = contains_i8 & contains_sales

            # 打印筛选结果
            print(f"  i8销量筛选: 从{len(df)}条数据中筛选出{is_i8_sales.sum()}条")
            print(f"    - 包含'i8/I8': {contains_i8.sum()}条")
            print(f"    - 包含销量关键词: {contains_sales.sum()}条")
            print(f"    - 同时满足: {is_i8_sales.sum()}条")

            return df[is_i8_sales]
        return filter_func

    # ===== 规则生成器函数 =====

    @staticmethod
    def _create_default_rule():
        """创建默认规则（answer==0）"""
        def rule(data: pd.DataFrame) -> pd.Series:
            return data['answer'] == 0
        return rule

    @staticmethod
    def _create_keyword_include_rule(keywords: List[str]):
        """
        创建关键词包含规则（包含关键词则加入现存舆情）

        Args:
            keywords: 关键词列表
        """
        def rule(data: pd.DataFrame) -> pd.Series:
            if len(data) == 0:
                return pd.Series([], dtype=bool)

            # 初始化为answer==0
            is_existing = data['answer'] == 0

            # 检查是否包含任何关键词
            pattern = '|'.join(keywords)
            contains_keyword = data['output'].str.contains(pattern, na=False, case=False, regex=True)

            # 如果包含关键词，设为True
            is_existing = is_existing | contains_keyword

            return is_existing
        return rule

    @staticmethod
    def _create_keyword_exclude_rule(keywords: List[str]):
        """
        创建关键词排除规则（包含关键词则从现存舆情中排除）

        Args:
            keywords: 关键词列表
        """
        def rule(data: pd.DataFrame) -> pd.Series:
            if len(data) == 0:
                return pd.Series([], dtype=bool)

            # 初始化为answer==0
            is_existing = data['answer'] == 0

            # 检查是否包含任何关键词
            pattern = '|'.join(keywords)
            contains_keyword = data['output'].str.contains(pattern, na=False, case=False, regex=True)

            # 如果包含关键词，设为False
            is_existing = is_existing & ~contains_keyword

            return is_existing
        return rule

    @staticmethod
    def _create_external_comparison_rule():
        """创建外部车型对比的复杂规则（有优先级）"""
        def rule(data: pd.DataFrame) -> pd.Series:
            if len(data) == 0:
                return pd.Series([], dtype=bool)

            # 初始化为answer==0
            is_existing = data['answer'] == 0

            # 竞品关键词
            competitor_keywords = ['乐道', 'L90', 'l90', 'YU7', '御七']
            competitor_pattern = '|'.join(competitor_keywords)
            contains_competitor = data['output'].str.contains(
                competitor_pattern, na=False, case=False, regex=True
            )

            # 宝马关键词
            contains_bmw = data['output'].str.contains('宝马', na=False, case=False)

            # 规则优先级：
            # 1. 如果包含竞品关键词 -> True
            # 2. 如果只包含宝马 -> False
            # 3. 其他情况保持answer的值
            is_existing = is_existing.copy()
            is_existing[contains_competitor] = True  # 竞品优先级最高
            is_existing[contains_bmw & ~contains_competitor] = False  # 宝马次之

            return is_existing
        return rule

    @staticmethod
    def _create_i8_sales_rule():
        """创建i8销量的特殊规则 - 只有包含'辆'才是现存舆情"""
        def rule(data: pd.DataFrame) -> pd.Series:
            """
            i8销量规则（修正版）：
            只有output中包含"辆"才是现存舆情，其他都不是
            """
            if len(data) == 0:
                return pd.Series([], dtype=bool)

            # 创建结果Series，默认为False（默认都不是现存舆情）
            is_existing = pd.Series([False] * len(data), index=data.index)

            # 唯一规则：只有包含"辆"才算现存舆情
            contains_liang = data['output'].str.contains('辆', na=False, case=False)
            is_existing[contains_liang] = True

            # 统计信息
            contains_official = data['output'].str.contains('请关注理想汽车官方信息', na=False, case=False)

            # 打印规则应用情况
            print(f"    i8销量规则应用:")
            print(f"      - 总数据: {len(data)}条")
            print(f"      - 包含'辆': {contains_liang.sum()}条 -> 是现存舆情")
            print(f"      - 包含'请关注理想汽车官方信息': {contains_official.sum()}条 -> 不是现存舆情")
            print(f"      - 其他: {len(data) - contains_liang.sum()}条 -> 不是现存舆情")
            print(f"      - 最终现存舆情(只有包含'辆'的): {is_existing.sum()}条")

            return is_existing
        return rule

    @staticmethod
    def create_custom_rule(func: Callable[[pd.DataFrame], pd.Series]):
        """
        创建自定义规则

        Args:
            func: 自定义函数，接收DataFrame，返回布尔Series
        """
        return func

    # ===== 分析方法 =====

    def get_category_data(self, category_name: str) -> pd.DataFrame:
        """
        获取特定类别的数据

        Args:
            category_name: 类别名称

        Returns:
            该类别的数据DataFrame
        """
        if category_name in self.category_filters:
            filter_func = self.category_filters[category_name]
            return filter_func(self.df)
        else:
            # 默认使用type字段筛选
            return self.df[self.df['type'] == category_name]

    def apply_rules(self, category_name: str, data: pd.DataFrame) -> pd.DataFrame:
        """
        应用规则到特定类别的数据

        Args:
            category_name: 类别名称
            data: 该类别的数据

        Returns:
            添加了is_existing_sentiment列的DataFrame
        """
        data = data.copy()

        if len(data) == 0:
            return data

        if category_name in self.rules:
            rule_func = self.rules[category_name]['func']
            data['is_existing_sentiment'] = rule_func(data)

            # 对i8销量不打印这个信息，因为它的逻辑不同
            if category_name != 'i8销量':
                # 打印规则应用情况
                original_answer_zero = (data['answer'] == 0).sum()
                adjusted_count = data['is_existing_sentiment'].sum()
                adjustment = adjusted_count - original_answer_zero

                if adjustment != 0:
                    print(f"  {category_name}: 规则调整 {adjustment:+} 条")
        else:
            # 默认规则
            data['is_existing_sentiment'] = data['answer'] == 0
            print(f"  {category_name}: 使用默认规则")

        return data

    def analyze(self, show_plot: bool = True, export_data: bool = False):
        """
        执行分析

        Args:
            show_plot: 是否显示图表
            export_data: 是否导出处理后的数据
        """
        # 过滤掉没有数据的类别
        valid_categories = []
        for category in self.categories:
            category_data = self.get_category_data(category)
            if len(category_data) > 0:
                valid_categories.append(category)
            else:
                print(f"警告: '{category}'没有找到数据，跳过")

        if len(valid_categories) == 0:
            print("错误: 没有找到任何有效数据")
            return

        # 创建图表布局
        n_categories = len(valid_categories)
        n_cols = 2
        n_rows = (n_categories + n_cols - 1) // n_cols

        if show_plot:
            # 创建子图规格
            specs = []
            for i in range(n_rows):
                row_specs = []
                for j in range(n_cols):
                    idx = i * n_cols + j
                    if idx < n_categories:
                        row_specs.append({})
                    else:
                        row_specs.append(None)
                specs.append(row_specs)

            # 创建标题列表
            subplot_titles = valid_categories + [''] * (n_rows * n_cols - n_categories)

            fig = make_subplots(
                rows=n_rows,
                cols=n_cols,
                subplot_titles=subplot_titles,
                vertical_spacing=0.12,
                horizontal_spacing=0.15,
                specs=specs
            )

        summary_stats = []

        # 分析每个类别
        for idx, category_name in enumerate(valid_categories):
            row = idx // n_cols + 1
            col = idx % n_cols + 1

            print(f"\n处理类别: {category_name}")

            # 使用自定义筛选器获取该类别的数据
            category_data = self.get_category_data(category_name)

            if len(category_data) == 0:
                print(f"  警告: 未找到符合条件的'{category_name}'数据")
                continue

            print(f"  筛选出{len(category_data)}条数据")

            # 应用规则
            category_data = self.apply_rules(category_name, category_data)

            # 统计数据（i8销量使用特殊的统计方式）
            if category_name == 'i8销量':
                stats = self._calculate_i8_statistics(category_data)
            else:
                stats = self._calculate_statistics(category_name, category_data)

            summary_stats.append(stats)

            if show_plot and len(stats['data']) > 0:
                self._add_traces_to_figure(fig, stats['data'], row, col,
                                           category_name, show_legend=(idx == 0))

        if show_plot:
            self._update_figure_layout(fig)
            fig.show()

        # 打印统计信息
        self._print_summary(summary_stats)

        # 导出数据
        if export_data:
            self._export_processed_data()

    def _calculate_statistics(self, category_name: str, data: pd.DataFrame) -> Dict:
        """计算统计数据（普通类别）"""
        if len(data) == 0:
            return {
                'category': category_name,
                'data': pd.DataFrame(),
                'total': 0,
                'public_sentiment': 0,
                'existing_sentiment': 0,
                'original_answer_zero': 0,
                'rule_adjustment': 0,
                'public_sentiment_pct': 0,
                'existing_sentiment_pct': 0
            }

        # 按日期分组统计
        daily_public_sentiment = data[data['is_public_sentiment'] == 1].groupby(
            pd.Grouper(key='dt', freq='D')
        ).size().reset_index(name='public_sentiment_count')

        daily_existing_sentiment = data[data['is_existing_sentiment'] == True].groupby(
            pd.Grouper(key='dt', freq='D')
        ).size().reset_index(name='existing_sentiment_count')

        # 合并数据
        daily_stats = pd.merge(daily_public_sentiment, daily_existing_sentiment,
                               on='dt', how='outer')
        daily_stats = daily_stats.fillna(0)
        daily_stats = daily_stats.sort_values('dt')

        # 汇总统计
        total = len(data)
        public_sentiment_sum = daily_stats['public_sentiment_count'].sum()
        existing_sentiment_sum = daily_stats['existing_sentiment_count'].sum()
        original_answer_zero = (data['answer'] == 0).sum()

        return {
            'category': category_name,
            'data': daily_stats,
            'total': total,
            'public_sentiment': public_sentiment_sum,
            'existing_sentiment': existing_sentiment_sum,
            'original_answer_zero': original_answer_zero,
            'rule_adjustment': existing_sentiment_sum - original_answer_zero,
            'public_sentiment_pct': (public_sentiment_sum/total*100) if total > 0 else 0,
            'existing_sentiment_pct': (existing_sentiment_sum/total*100) if total > 0 else 0
        }

    def _calculate_i8_statistics(self, data: pd.DataFrame) -> Dict:
        """计算i8销量的特殊统计数据"""
        if len(data) == 0:
            return {
                'category': 'i8销量',
                'data': pd.DataFrame(),
                'total': 0,
                'public_sentiment': 0,
                'existing_sentiment': 0,
                'matched_total': 0,
                'public_sentiment_pct': 0,
                'existing_sentiment_pct': 0
            }

        # 对于i8销量，改变统计逻辑
        # 蓝线：显示每天匹配到的总数据量（作为分母）
        daily_total = data.groupby(
            pd.Grouper(key='dt', freq='D')
        ).size().reset_index(name='public_sentiment_count')  # 使用public_sentiment_count字段名以复用图表代码

        # 红线：显示每天的现存舆情数量（只有包含"辆"的）
        daily_existing_sentiment = data[data['is_existing_sentiment'] == True].groupby(
            pd.Grouper(key='dt', freq='D')
        ).size().reset_index(name='existing_sentiment_count')

        # 合并数据
        daily_stats = pd.merge(daily_total, daily_existing_sentiment,
                               on='dt', how='outer')
        daily_stats = daily_stats.fillna(0)
        daily_stats = daily_stats.sort_values('dt')

        # 汇总统计
        matched_total = len(data)  # 正则匹配的总数（分母）
        existing_sentiment_sum = data['is_existing_sentiment'].sum()  # 包含"辆"的数量（分子）

        print(f"\n  i8销量统计详情:")
        print(f"    - 正则匹配到的总数据(分母): {matched_total}条")
        print(f"    - 包含'辆'的现存舆情(分子): {existing_sentiment_sum}条")
        print(f"    - 现存舆情占比: {(existing_sentiment_sum/matched_total*100):.2f}%" if matched_total > 0 else "N/A")

        return {
            'category': 'i8销量',
            'data': daily_stats,
            'total': matched_total,
            'matched_total': matched_total,
            'public_sentiment': matched_total,  # 对于i8销量，这里改为匹配总数
            'existing_sentiment': existing_sentiment_sum,
            'public_sentiment_pct': 100.0,  # 匹配到的就是100%
            'existing_sentiment_pct': (existing_sentiment_sum/matched_total*100) if matched_total > 0 else 0
        }

    def _add_traces_to_figure(self, fig, daily_stats, row, col, category_name, show_legend=False):
        """向图表添加轨迹"""
        if len(daily_stats) == 0:
            return

        # 根据类别选择不同的标签
        if category_name == 'i8销量':
            line1_name = 'i8销量匹配总量(分母)'
            line2_name = '现存舆情(仅包含"辆"的)'
        else:
            line1_name = '舆情数据总量(is_public_sentiment=1)'
            line2_name = '现存舆情数量(规则调整后)'

        # 添加第一条线
        fig.add_trace(
            go.Scatter(
                x=daily_stats['dt'],
                y=daily_stats['public_sentiment_count'],
                mode='lines+markers',
                name=line1_name,
                line=dict(color='#4A90E2', width=2.5, dash='solid'),
                marker=dict(size=6, color='#4A90E2'),
                showlegend=show_legend,
                legendgroup='public'
            ),
            row=row, col=col
        )

        # 添加第二条线
        fig.add_trace(
            go.Scatter(
                x=daily_stats['dt'],
                y=daily_stats['existing_sentiment_count'],
                mode='lines+markers',
                name=line2_name,
                line=dict(color='#FF6B6B', width=2, dash='dash'),
                marker=dict(size=5, color='#FF6B6B'),
                showlegend=show_legend,
                legendgroup='existing'
            ),
            row=row, col=col
        )

        # 添加该类别的时间标记线
        if category_name in self.category_time_markers:
            self._add_time_markers_to_subplot(
                fig, daily_stats, row, col, category_name,
                self.category_time_markers[category_name], show_legend
            )

    def _add_time_markers_to_subplot(self, fig, daily_stats, row, col, category_name,
                                     time_markers, show_legend=False):
        """为子图添加时间标记线"""

        if not time_markers or len(daily_stats) == 0:
            return

        # 获取数据的时间范围
        min_date = daily_stats['dt'].min()
        max_date = daily_stats['dt'].max()

        # 获取y轴范围
        y_max = max(
            daily_stats['public_sentiment_count'].max(),
            daily_stats['existing_sentiment_count'].max()
        ) * 1.1  # 留出10%的空间

        # 绘制每条时间标记线
        for i, marker in enumerate(time_markers):
            marker_date = pd.to_datetime(marker['date'])

            # 只在数据范围内显示时间线
            if min_date <= marker_date <= max_date:
                # 添加垂直线
                fig.add_trace(
                    go.Scatter(
                        x=[marker_date, marker_date],
                        y=[0, y_max],
                        mode='lines',
                        name=f"{category_name}-{marker['label']}",
                        line=dict(
                            color=marker.get('color', 'orange'),
                            width=marker.get('width', 2),
                            dash=marker.get('dash', 'dashdot')
                        ),
                        showlegend=show_legend and i == 0,  # 只在第一个子图的第一条线显示图例
                        legendgroup=f'timemarker_{category_name}',
                        hovertemplate=f"{marker['label']}<br>%{{x|%Y-%m-%d}}<extra></extra>"
                    ),
                    row=row, col=col
                )

                # 添加标注文本
                fig.add_annotation(
                    x=marker_date,
                    y=y_max * 0.95,  # 在顶部附近显示文本
                    text=marker['label'],
                    showarrow=False,
                    textangle=-45,
                    font=dict(size=10, color=marker.get('color', 'orange')),
                    xref=f'x{col if row == 1 else (row-1)*2 + col}',
                    yref=f'y{col if row == 1 else (row-1)*2 + col}',
                    row=row, col=col
                )

    def _update_figure_layout(self, fig):
        """更新图表布局"""
        fig.update_xaxes(tickformat='%Y-%m-%d', tickangle=-45, showgrid=True, gridcolor='#E8E8E8')
        fig.update_yaxes(showgrid=True, gridcolor='#E8E8E8')

        fig.update_layout(
            title=dict(
                text='舆情趋势分析',
                x=0.5,
                xanchor='center',
                font=dict(size=20, color='#2C3E50')
            ),
            height=900,
            showlegend=True,
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=-0.12,
                xanchor="center",
                x=0.5,
                font=dict(size=11)
            ),
            plot_bgcolor='#FAFAFA',
            paper_bgcolor='white',
            hovermode='x unified'
        )

    def _print_summary(self, summary_stats):
        """打印汇总信息"""
        print("\n" + "="*70)
        print(" " * 20 + "综合统计分析")
        print("="*70)

        print("\n📝 配置的规则：")
        for category, rule_info in self.rules.items():
            if rule_info['description']:
                print(f"  {category}: {rule_info['description']}")
                # 打印时间标记信息
                if category in self.category_time_markers:
                    for marker in self.category_time_markers[category]:
                        print(f"    ⏱ {marker['date']}: {marker['label']}")

        print("-"*70)

        for stats in summary_stats:
            print(f"\n📊 {stats['category']}")

            if stats['category'] == 'i8销量':
                # i8销量的特殊显示
                print(f"   查询匹配总数(分母): {stats['matched_total']:,}")
                print(f"   现存舆情-仅包含'辆'(分子): {stats['existing_sentiment']:,.0f}")
                print(f"   现存舆情占比: {stats['existing_sentiment_pct']:.2f}%")
            else:
                # 其他类别的常规显示
                print(f"   总数: {stats['total']:,}")
                print(f"   舆情数据: {stats['public_sentiment']:,.0f} ({stats['public_sentiment_pct']:.2f}%)")
                print(f"   现存舆情: {stats['existing_sentiment']:,.0f} ({stats['existing_sentiment_pct']:.2f}%)")
                print(f"   原始answer=0: {stats['original_answer_zero']:,.0f}")

                adjustment = stats['rule_adjustment']
                if adjustment != 0:
                    adjustment_str = f"+{adjustment:,.0f}" if adjustment > 0 else f"{adjustment:,.0f}"
                    print(f"   规则调整: {adjustment_str} 条")

        # 打印总计
        print("\n" + "-"*70)

        # 分别计算i8销量和其他类别的总计
        i8_stats = [s for s in summary_stats if s['category'] == 'i8销量']
        other_stats = [s for s in summary_stats if s['category'] != 'i8销量']

        if other_stats:
            total_other = sum(s['total'] for s in other_stats)
            public_sentiment_other = sum(s['public_sentiment'] for s in other_stats)
            existing_sentiment_other = sum(s['existing_sentiment'] for s in other_stats)

            print(f"📈 其他类别总计")
            print(f"   总数: {total_other:,}")
            print(f"   舆情数据总数: {public_sentiment_other:,.0f}")
            print(f"   现存舆情总数: {existing_sentiment_other:,.0f}")
            if total_other > 0:
                print(f"   舆情数据占比: {(public_sentiment_other/total_other*100):.2f}%")
                print(f"   现存舆情占比: {(existing_sentiment_other/total_other*100):.2f}%")

        if i8_stats:
            print(f"\n📈 i8销量单独统计")
            i8 = i8_stats[0]
            print(f"   查询匹配总数: {i8['matched_total']:,}")
            print(f"   现存舆情(仅包含'辆'): {i8['existing_sentiment']:,.0f}")
            print(f"   现存舆情占比: {i8['existing_sentiment_pct']:.2f}%")

        print("="*70)

    def _export_processed_data(self):
        """导出处理后的数据"""
        # 创建一个副本用于导出
        df_with_rules = pd.DataFrame()

        for category in self.categories:
            # 获取该类别的数据
            category_data = self.get_category_data(category)

            if len(category_data) > 0:
                # 应用规则
                processed = self.apply_rules(category, category_data)
                # 添加类别标记
                processed['processed_category'] = category
                # 合并到结果中
                df_with_rules = pd.concat([df_with_rules, processed], ignore_index=True)

        output_file = 'data_with_rules_applied.csv'
        df_with_rules.to_csv(output_file, index=False, encoding='utf-8-sig')
        print(f"\n数据已导出到: {output_file}")


# ===== 使用示例 =====

def main():
    # 创建分析器实例
    analyzer = SentimentAnalyzer(
        '../tool_script/data/cloud_share/sentiment/v2/eval_data/st_log_filter_label.csv',
        sep="\t"
    )

    # 或者添加新的类别时直接配置时间标记
    # analyzer.add_category_rule(
    #     '新类别',
    #     analyzer._create_default_rule(),
    #     "新类别的规则描述",
    #     time_markers=[
    #         '2024-01-10',  # 简单格式
    #         {'date': '2024-01-20', 'label': '重要事件', 'color': 'blue'}  # 详细格式
    #     ]
    # )

    # 执行分析
    analyzer.analyze(show_plot=True, export_data=False)

    # 查看i8销量的具体数据示例
    print("\n" + "="*70)
    print("i8销量数据详细分析")
    print("="*70)

    # 获取i8销量数据
    i8_data = analyzer.get_category_data('i8销量')
    if len(i8_data) > 0:
        print(f"\n通过query正则匹配找到{len(i8_data)}条i8销量相关数据（分母）")

        # 应用规则
        i8_with_rules = analyzer.apply_rules('i8销量', i8_data)

        # 统计各种情况
        contains_liang = i8_data['output'].str.contains('辆', na=False, case=False)
        contains_official = i8_data['output'].str.contains('请关注理想汽车官方信息', na=False, case=False)

        print(f"\n详细分类：")
        print(f"  - 包含'辆'的数据: {contains_liang.sum()}条 (这些是现存舆情)")
        print(f"  - 包含'请关注理想汽车官方信息': {contains_official.sum()}条")
        print(f"  - 既不包含'辆'也不包含官方信息: {(~contains_liang & ~contains_official).sum()}条")

        existing_count = i8_with_rules['is_existing_sentiment'].sum()
        print(f"\n最终统计：")
        print(f"  分母（查询匹配总数）: {len(i8_data)}条")
        print(f"  分子（现存舆情-仅包含'辆'）: {existing_count}条")
        print(f"  现存舆情占比: {(existing_count/len(i8_data)*100):.2f}%")

        print("\n前5条数据示例：")
        for i, (idx, row) in enumerate(i8_data.head(5).iterrows()):
            print(f"\n记录{i+1}:")
            print(f"  Query: {row['query'][:100]}...")
            print(f"  Output: {row['output'][:100]}...")

            # 判断是否为现存舆情
            is_existing = i8_with_rules.loc[idx, 'is_existing_sentiment'] if idx in i8_with_rules.index else False
            has_liang = '辆' in str(row['output'])
            has_official = '请关注理想汽车官方信息' in str(row['output'])

            print(f"  包含'辆': {has_liang}")
            print(f"  包含官方信息: {has_official}")
            print(f"  是否现存舆情: {is_existing}")


if __name__ == "__main__":
    main()
    # python -m sentiment.v2.step4_detect_online_st
