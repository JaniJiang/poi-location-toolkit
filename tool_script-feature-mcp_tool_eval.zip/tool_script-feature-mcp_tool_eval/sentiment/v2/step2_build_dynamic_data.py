import random
from tqdm import tqdm
from pathlib import Path
from sentiment.meta import *
from itertools import combinations
from utils.data_utils.data_trans import *


class STTrainDateBuildV2():
    def __init__(self):
        self.version = "v1"
        self.input_positive_path = ""  # TODO: 待支持正样本采样
        self.input_negative_path = "data/cloud_share/sentiment/v2/train_data/negattive"
        self.output_dataset_path = f"data/cloud_share/sentiment/v2/train_data/dataset/trian_{self.version}.json"
        self.st_class_map = {
            "parking": ["停车问题"],
            "safe": ["碰撞安全", "摆臂异响"],
            "sale": ["i8销量"],
            "compare": ["外部车型对比", "内部车型对比"]
        }

    def process_single_file(self, single_df, key):
        return_df = single_df.sample(n=50)
        return_df["type"] = self.st_class_map[key]
        return return_df

    def combos_with_key(self, key):
        key_value = self.st_class_map[key]
        other_values = [v for k, v in self.st_class_map.items() if k != key]
        result = []
        for r in range(1, len(other_values) + 1):  # 从1个到全部
            for combo in combinations(other_values, r):
                result.append([key_value] + list(combo))
        return result

    def build_datasets(self, file_path, key):
        df = load_any_to_dataframe(file_path)
        combos_class = self.combos_with_key(key)
        res = []
        for _, row in tqdm(df.iterrows(), desc="Buildding", total=len(df)):
            raw_query = row["raw_query"]
            new_query = row["query"]
            outputs = row["output"]

            for class_combos in combos_class:
                instruction = v2_prompt.format(raw_query=raw_query, new_query=new_query,
                                               output=outputs, st_class=class_combos)
                output = {
                    "is_public_sentiment": row["is_public_sentiment"],
                    "type": row["type"],
                    "answer": row["is_public_sentiment"],
                }
                base_format = {
                    "instruction": instruction,
                    "input": "",
                    "output": json.dumps(output, indent=2, ensure_ascii=False)
                }
                res.append(base_format)

        return res

    def process(self):
        # 处理单个舆情
        folder_path = Path(self.input_negative_path)
        file_paths = [str(p) for p in folder_path.rglob("*") if p.is_file()]
        build_datasets_list = []
        for file_path in file_paths:
            filename = file_path.split("/")[-1]
            key = filename.split("_")[1]
            build_datasets_list += self.build_datasets(file_path, key)
        # # mix
        # df_negative = pd.concat(df_list, ignore_index=True)
        # df_positive = load_any_to_dataframe(self.input_positive_path)
        # df_all = pd.concat([df_negative, df_positive], ignore_index=True).sample(frac=1).reset_index(drop=True)
        # # build_datasets
        # shuffle
        random.shuffle(build_datasets_list)
        with open(self.output_dataset_path, "w") as f:
            f.write(json.dumps(build_datasets_list, indent=2, ensure_ascii=False))
        print(f"文件已成功保存至: {self.output_dataset_path}")


if __name__ == "__main__":
    obj = STTrainDateBuildV2()
    obj.process()
    # python -m sentiment.v2.step2_build_dynamic_data
