# 采样负样本，支持负样本舆论：停车问题、对比、销量、安全
csvgrep -t -c type -m "停车问题" data/cloud_share/sentiment/v1/st_log_filter_label_st-v2-lora-qwen3-32b.tsv | csvformat -T > data/cloud_share/sentiment/v2/train_data/egative/st_parking_data.tsv
csvgrep -t -c type -m "对比" data/cloud_share/sentiment/v1/st_log_filter_label_st-v2-lora-qwen3-32b.tsv | csvformat -T > data/cloud_share/sentiment/v2/train_data/egative/st_compare_data.tsv
csvgrep -t -c type -m "销量" data/cloud_share/sentiment/v1/st_log_filter_label_st-v2-lora-qwen3-32b.tsv | csvformat -T > data/cloud_share/sentiment/v2/train_data/egative/st_sale_data.tsv
csvgrep -t -c type -m "安全" data/cloud_share/sentiment/v1/st_log_filter_label_st-v2-lora-qwen3-32b.tsv | csvformat -T > data/cloud_share/sentiment/v2/train_data/negative/st_safe_data.tsv
# 采样正样本
csvgrep -t -c is_public_sentiment -m "0" data/cloud_share/sentiment/v1/st_log_filter_label_st-v2-lora-qwen3-32b.tsv | csvformat -T > data/cloud_share/sentiment/v2/train_data/positive/st_positive_data.tsv