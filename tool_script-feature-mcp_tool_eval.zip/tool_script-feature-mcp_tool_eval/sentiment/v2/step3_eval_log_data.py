import json
from tqdm import tqdm
from sentiment.meta import *
from utils.llm_utils.chat_with_lapi_LLM import *
from utils.data_utils.data_trans import *
from concurrent.futures import ThreadPoolExecutor, as_completed


class EvalV2():
    def __init__(self):
        self.input_path = f"{DATA_ROOT}/v2/eval_data/st_log_filter.tsv"
        self.output_path = f"{DATA_ROOT}/v2/eval_data/st_log_filter_label_1.csv"
        self.st_class = [['碰撞安全', '摆臂异响'], ['停车问题'], ['i8销量'], ['外部车型对比', '内部车型对比']]
        self.max_workers = 96
        self.model = "st-v2-lora-qwen3-32b-1"

    def process_row(self, idx, data):
        try:
            raw_query = data["raw_query"]
            new_query = data["query"]
            output = data["output"]
            instruction = v2_prompt.format(raw_query=raw_query, new_query=new_query,
                                           output=output, st_class=self.st_class)
            res = chat_with_lpai_LLM_signal(instruction=instruction, model=self.model,
                                            url=llm_config[self.model], temperature=0.1, max_tokens=4096)
            if 'qwen3' in self.model:
                res, _ = parse_json_from_think_res(res, "answer", -1)
            else:
                res = json.loads(res)

            return idx, {
                "is_public_sentiment": res["is_public_sentiment"],
                "type": res["type"],
                "answer": res["answer"]
            }
        except Exception as e:
            print(e)
            return idx, {
                "is_public_sentiment": 2,
                "type": "",
                "answer": 2,
            }

    def process(self):

        dataset = load_any_to_dataframe(self.input_path)
        dataset_len = len(dataset)

        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = [
                executor.submit(self.process_row, idx, dataset.iloc[idx])
                for idx in range(dataset_len)
            ]
            for future in tqdm(as_completed(futures), total=dataset_len, desc="Processing"):
                idx, res = future.result()
                dataset.at[idx, "is_public_sentiment"] = res["is_public_sentiment"]
                dataset.at[idx, "answer"] = res["answer"]
                dataset.at[idx, "type"] = res["type"]

        dataset.to_csv(self.output_path, sep="\t", index=False)
        print(f"文件已成功保存至: {self.output_path}")


if __name__ == "__main__":
    obj = EvalV2()
    obj.process()
    # python -m sentiment.v2.step3_eval_log_data
