import json
from pathlib import Path
import pandas as pd
from tqdm import tqdm
from sentiment.meta import *
from utils.llm_utils.chat_with_lapi_LLM import *
from utils.data_utils.data_trans import load_any_to_dataframe
from concurrent.futures import ThreadPoolExecutor, as_completed


class Sentiment():
    def __init__(self, train_data_path: str, eval_data_path: str, model: str):
        self.train_data_path = train_data_path
        self.eval_data_path = eval_data_path
        self.train_data = load_any_to_dataframe(train_data_path)
        self.train_len = len(self.train_data)
        self.eval_data = load_any_to_dataframe(eval_data_path)
        self.eval_len = len(self.eval_data)
        self.model = model

    def get_metric(self, dataset):
        truth = dataset["是否舆情问题"].astype(str).str.strip()
        pred = pd.to_numeric(dataset["is_public_sentiment"], errors="coerce")

        correct_mask = ((truth == "是") & (pred == 1)) | ((truth == "否") & (pred == 0))

        correct_count = int(correct_mask.sum())
        total_count = int(len(dataset))
        sentiment_acc = correct_count / total_count if total_count else 0.0

        reply = dataset["回复是否正确"].astype(str).str.strip()
        ans = pd.to_numeric(dataset["answer"], errors="coerce")
        eligible_mask = reply.isin(["正确", "错误"])
        correct_answer_mask = eligible_mask & (
            ((reply == "正确") & (ans == 1)) |
            ((reply == "错误") & (ans == 0))
        )
        correct_answer_count = int(correct_answer_mask.sum())
        total_answer_count = int(eligible_mask.sum())
        answer_acc = correct_answer_count / total_answer_count if total_answer_count else 0.0

        return sentiment_acc, answer_acc

    def process_row(self, idx, data, env):
        try:
            if env == "online":
                raw_query = data["raw_query"]
                new_query = data["query"]
                output = data["output"]
            elif env == "local":
                raw_query = data["taskformer-raw-query"]
                new_query = data["taskformer-new-query"]
                output = data["taskformer-output"]
            instruction = v1_prompt.format(raw_query=raw_query, new_query=new_query,
                                           output=output)
            res = chat_with_lpai_LLM_signal(instruction=instruction, model=self.model,
                                            url=llm_config[self.model], temperature=0.1, max_tokens=4096)
            if 'qwen3' in self.model:
                res, _ = parse_json_from_think_res(res, "answer", -1)
            else:
                res = json.loads(res)

            return idx, {
                "is_public_sentiment": res["is_public_sentiment"],
                "answer": res["answer"],
                "type": res["type"]
            }
        except Exception as e:
            print(e)
            return idx, {
                "is_public_sentiment": 2,
                "answer": 2,
                "type": ""
            }

    def process(self, model: str, env="local",  max_workers=96):
        if model not in ("train", "eval"):
            raise ValueError("model 必须是 'train' 或 'eval'")

        if model == "train":
            dataset, dataset_len, dataset_path = self.train_data.copy(), self.train_len, self.train_data_path
        else:
            dataset, dataset_len, dataset_path = self.eval_data.copy(), self.eval_len, self.eval_data_path

        dataset_path = Path(dataset_path)
        save_dataset_path = dataset_path.with_stem(dataset_path.stem + "_label" + f"_{self.model}")
        dataset["type"] = pd.Series(pd.NA, index=dataset.index, dtype="string")

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = [
                executor.submit(self.process_row, idx, dataset.iloc[idx], env)
                for idx in range(dataset_len)
            ]
            for future in tqdm(as_completed(futures), total=dataset_len, desc="Processing"):
                idx, res = future.result()
                dataset.at[idx, "is_public_sentiment"] = res["is_public_sentiment"]
                dataset.at[idx, "answer"] = res["answer"]
                dataset.at[idx, "type"] = res["type"]

        # 计算指标
        if env == "local":
            sentiment_acc, answer_acc = self.get_metric(dataset=dataset)
            print(f"Sentimemt ACC: {sentiment_acc:.2%}")
            print(f"Answer ACC: {answer_acc:.2%}")

        dataset.to_csv(save_dataset_path, sep="\t", index=False)
        print(f"文件已成功保存至: {save_dataset_path}")


if __name__ == "__main__":
    train_data_path = f"{DATA_ROOT}/v1/sentiment_train.tsv"
    eval_data_path = f"{DATA_ROOT}/v1/sentiment_eval.tsv"
    model = "st-v2-lora-qwen3-32b"
    st = Sentiment(train_data_path, eval_data_path, model)
    st.process("eval", "local")
    # python -m sentiment.v1.step2_eval_model
