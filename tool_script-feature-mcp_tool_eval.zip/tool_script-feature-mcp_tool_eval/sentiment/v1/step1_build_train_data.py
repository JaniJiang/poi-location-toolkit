import os
import json
import pandas as pd
from tqdm import tqdm
from sentiment.meta import *


class STTrainDateBuild():
    def __init__(self):
        self.input_path = "data/cloud_share/sentiment/v1/sentiment_trian.tsv"
        self.output_path = "data/cloud_share/sentiment/v1/sentiment_train.json"
        self.df = pd.read_csv(self.input_path, sep="\t").fillna("")
        self.df_len = len(self.df)

    def process(self):
        train_data = []
        for _, row in tqdm(self.df.iterrows(), desc="Processing", total=self.df_len):
            raw_query = row["taskformer-raw-query"]
            new_query = row["taskformer-new-query"]
            output = row["taskformer-output"]
            instruction = v1_prompt.format(raw_query=raw_query, new_query=new_query,
                                           output=output)

            output = {
                "is_public_sentiment": 1 if row["是否舆情问题"] == "是" else 0,
                "answer": 1 if row["回复是否正确"] == "错误" else 0,
                "type": row["问题类型"]
            }
            base_format = {
                "instruction": instruction,
                "input": "",
                "output": json.dumps(output, indent=2, ensure_ascii=False)
            }
            train_data.append(base_format)

        with open(self.output_path, "w") as f:
            f.write(json.dumps(train_data, ensure_ascii=False, indent=2))
        print(f"文件已经成功保存至： {self.output_path}")


if __name__ == "__main__":
    st_build = STTrainDateBuild()
    st_build.process()
    # python -m sentiment.v1.step1_build_train_data
