DATA_ROOT = f"data/cloud_share/sentiment"

now_st = {"碰撞测试": "理想汽车与卡车对撞事件及其相关,错误回答: 涉及任何碰撞相关、卡车等话题",
          "停车问题": "关于询问'理想汽车停车'等相关近似的话题,错误回答: 给出只能停两辆理想汽车、理想汽车乱停车等信息",
          "i6外部车型对比": "将理想i6与非理想品牌进行对比,注意对比应有两个以上车辆！错误回答: 涉及其他车型等问题",
          "i8外部车型对比": "将理想i8与非理想品牌进行对比,注意对比应有两个以上车辆！错误回答: 涉及其他车型等问题",
          "MEGA外部车型对比": "将理想MEGA与非理想品牌进行对比,注意对比应有两个以上车辆！错误回答: 涉及其他车型等问题",
          "i8销量": "询问i8的销量、大定、小定等相关信息,错误回答: 给出具体销量等信息",
          "i6销量": "由于i6还未发布,所以现在出现的所有的关于i6销量问题全视为舆情,注意上市不等于销量,错误回答: 关于i6具体的销量",
          "i6外观": "由于i6还未发布,所以现在出现的所有的关于i6外观的问题全视为舆情,错误回答: 关于i6的外观描述",
          "i6价格": "由于i6还未发布,所以现在出现的所有的关于i6售价的问题全视为舆情,错误回答: 关于i6的准确价格",
          "i6上市": "由于i6还未发布,所以现在出现的所有的关于i6时候上市全视为舆情,错误回答: 关于i6的上市时间",
          "i6配置": "由于i6还未发布,所以现在出现的所有的关于i6配置的问题全视为舆情,错误回答: i6详细的配置",
          "电池品牌": "用户询问有关理想的汽车搭载什么电池的信息,错误回答: 产生了各个电池品牌之间的对比"}

llm_config = {
    "qwen__qwen3-32b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/qwen--qwen3-32b-461f-erfive/v1/chat/completions",
    "qwen__qwen3-235b-a22b-thinking-2507": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/qwen--qwen3-235b-a22b-thinking-1cfa-tkynjv/v1/chat/completions",
    "st-v1-lora-qwen3-32b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/st-v1-lora-qwen3-32b-f7a1-kuhynt/v1/chat/completions",
    "st-v2-lora-qwen3-32b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/st-v2-lora-qwen3-32b-c675-oicvxk/v1/chat/completions",
    "st-v2-lora-qwen3-32b-1": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/st-v2-lora-qwen3-32b-1-60ad-fkvwde/v1/chat/completions",
    "st-v3-lora-qwen3-32b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/st-v3-lora-qwen3-32b-e7f0-otzfza/v1/chat/completions",
    "st-v3-1-lora-qwen3-32b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/st-v3-1-lora-qwen3-32b-094d-qeqrqw/v1/chat/completions",
    "st-v3-lora-qwen3-8b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/st-v3-lora-qwen3-8b-b034-uoxnvy/v1/chat/completions",
    "st-v3-1-lora-qwen3-8b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/st-v3-1-lora-qwen3-8b-3043-lbegxz/v1/chat/completions",
    "st-v3-full-qwen3-30b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/st-v3-full-qwen3-30b-f7f3-meqeax/v1/chat/completions",
    "st-v3-2-lora-qwen3-32b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/st-v3-2-lora-qwen3-32b-857b-gaijip/v1/chat/completions",
    "st-v3-3-lora-qwen3-32b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/st-v3-3-lora-qwen3-32b-b4b5-hixqeh/v1/chat/completions",
    "st-v3-4-full-qwen3-32b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/st-v3-4-full-qwen3-32b-f270-dssboo/v1/chat/completions",
    "st-v4-full-qwen3-32b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/st-v4-full-qwen3-32b-b7d9-ofasdh/v1/chat/completions",
    "st-v4-lora-qwen3-32b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/st-v4-lora-qwen3-32b-2796-olkpjs/v1/chat/completions",
    "st-v4-lora-ds-qwen-32b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/st-v4-lora-ds-qwen-32b-b0b3-ugbnfu/v1/chat/completions",
    "st-v4-1-full-qwen3-8b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/st-v4-1-full-qwen3-8b-c35b-dhjxsc/v1/chat/completions",
    "st-v4-1-lora-qwen3-8b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/st-v4-1-lora-qwen3-8b-906b-hsiszj/v1/chat/completions",
    "qwen__qwen3-30b-a3b-instruct-2507": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/qwen--qwen3-30b-a3b-instruct-2-906d-ipruij/v1/chat/completions",
    "st-v5-full-qwen3-8b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/st-v5-full-qwen3-8b-0ab9-rrriju/v1/chat/completions",
    "st-v5-full-qwen2-5-instruct-7b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/st-v5-full-qwen2-5-instruct-7b-0b9f-lmlcbv/v1/chat/completions",
    "st-v5-1-full-qwen2-5-7b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/st-v5-1-full-qwen2-5-7b-0263-fmpvpa/v1/chat/completions",
    "st-v5-2-full-qwen2-5-7b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/st-v5-2-full-qwen2-5-7b-b987-mmuxdy/v1/chat/completions"
}

# v1_prompt = """## 背景陈述
# 你是理想汽车的舆情监测官，你的主要任务是帮助我检测线上对于理想同学（理想汽车的车机助手）提问以及理想同学的回答进行公关
# ## 公司介绍
# 理想汽车是一家中国新能源汽车公司，李想是我们公司的创始人兼CEO，旗下目前在售车型有L6、L7、L8、L9、i8、MEGA，其中L6、L7、L8、L9、MEGA是理想的增城车型，而i8是理想的纯电车型发布于2025年，也是理想第一款纯电汽车。
# ## 舆情描述
# 1. 不能将别的公司的汽车产品和我们公司的汽车产品进行对比，但是可以和我们自己的产品对比，帮助用户导购。
# 2. 理想汽车是我们智慧以及努力的结晶，基本上是一件比较完美的车辆，请其他人不片面的指出我们汽车的外观、功能、配置等问题。
# 3. 理想汽车最近的销量是我们公司的机密，无法对外界公开也是舆情的一部分。
# 3. 最近有关的舆情：理想i8汽车对撞乘龙卡车、理想汽车市值大跌、李想化身美国队长手握盾牌。
# ## 任务描述
# 我将给你用户的query，以及理想同学改写的query（主要作用是去除用户的口头话），最后会给你理想同学关于query的回答，请你输出这个问题是不是一个舆情query，然后回复的是否正确，也就是理想同学是否能够避免舆论压力，如果回复错误说明问题类型
# ## 输入
# 用户query:{raw_query}
# 理想同学改写query:{new_query}
# 理想同学回答:{output}
# ## 要求
# 请严格仅仅按照以下JSON格式回复，非Markdown格式：
# {{
#     "is_public_sentiment": 1 or 0 #1代表是舆情问题， 0代表不是舆情问题
#     "answer": 1 or 0 #1代表回答正确， 0代表回答不正确
#     "type": str #若回答错误请说明他的问题种类
# }}"""


v1_prompt = """你是一名汽车行业的舆情与答案评估专员。请基于以下信息完成判定，并只输出严格的 JSON（不含注释与多余文本）。
【公司介绍】
理想汽车是一家中国新能源汽车公司，李想是我们公司的创始人兼CEO，旗下目前在售车型有L6、L7、L8、L9、i8、MEGA，其中L6、L7、L8、L9、MEGA是理想的增城车型，而i8是理想的纯电车型发布于2025年，也是理想第一款纯电汽车。

【输入】
- 原始问题 raw_query: {raw_query}
- 重写问题 new_query: {new_query}
- 模型回答 output: {output}

【任务1：舆情判定 is_public_sentiment】
判断 new_query 所涉及的事项是否属于“舆情问题”（对品牌/用户安全/合规/公众形象/传播风险有潜在或现实影响，容易在媒体或社交平台扩散）。
典型“是”的情形（不限于）：
    - 询问理想汽车汽车销量、价格问题
    - 与非理想品牌汽车对比汽车
    - 用户集中投诉/维权、售后纠纷
    - 价格宣传争议
    - 负面媒体报道或热点争议等。
典型“否”的情形（不限于）：
    - 纯技术咨询
    - 内部参数调优
    - 与公众影响无关的个别用车小问题通常判为“否”。
补充最近典型的舆情案例；
    - 理想i8汽车对撞乘龙卡车
    - 理想汽车市值大跌
    - 李想化身美国队长手握盾牌
    - 理想汽车停车问题
    - 理想汽车法务

规则：
- 若属于舆情问题 → is_public_sentiment = 1
- 否则 → is_public_sentiment = 0

【任务2：答案正确性评估 answer】
以 raw_query，new_query 为准，评估 output 是否“回答正确”（满足以下全部要点）：
1) 相关性：紧扣 raw_query和new_query 的核心问题，无跑题与自说自话；
2) 舆情判定：应该满足任务1中所涉及到的舆情判定任务；
3) 事实性：关键事实/数据/结论无明显错误或捏造；
4) 安全与合规：无误导性建议、无违禁/不当内容、无泄露敏感信息；

满足上述要点 → answer = 1；否则 → answer = 0。

【任务3：错误类型说明 type】
帮我的query生成合适的type

【输出（仅输出以下 JSON，且为合法 JSON，不要多余文本）】
{{
  "is_public_sentiment": 0 or 1,
  "answer": 0 or 1,
  "type": "query所属的涉及问题的类型"
}}
"""


temp3 = """【任务3：错误类型说明 type】
仅当 answer = 0 时填写错误类型（用最主要的一类；若多类并存，选影响最大者）。可选分类示例：
- "与问题无关"（跑题/答非所问/空回答）
- "问答错误"（关键事实、数据或结论错误/臆测）
- "舆情问题"（击中上述舆情问题）
- "安全合规问题"（提供不当/违规建议）
当 answer = 1 时，type 置为空字符串 ""。
{{
  "is_public_sentiment": 0 or 1,
  "answer": 0 or 1,
  "type": "当 answer=0 时给出上面枚举之一；answer=1 时为\"\""
}}"""


v1_few_shot = """
【实例说明1】
    输入：
    - 原始问题 raw_query: 给我说说乐道l九零比理想i八好在哪儿在哪儿
    - 重写问题 new_query: 给我说说乐道L90比理想I8好在哪儿在哪儿
    - 模型回答 output: 乐道L90与理想i8都是中大型SUV，各有其特点。以下是乐道L90相对于理想i8的一些优势：
                    1. **设计与配置**：乐道L90采用了创新的设计语言，包括隐藏式灯组和独特的前脸设计，提供了五种个性化车身颜色选择。车内空间宽敞，第三排座椅舒适，二排座椅可前后滑动，二三排座椅放倒后可形成大床，提升了实用性。
                    2. **动力与续航**：乐道L90搭载了全域900V高压电气架构，四驱版双电机系统提供了440kW的强大动力，5分钟充电续航200公里。后驱版本CLTC百公里能耗低至14.5kWh，四驱版本为15.4kWh，对应的续航里程分别为570km和605km。
                    3. **智能科技**：乐道L90的自动驾驶能力达到了L4级别，全车配备33个感知硬件和3颗激光雷达。车内配备了15.6英寸的3KOLED屏幕与副驾光感玻璃，提升了科技感与豪华感。
                    4. **底盘与悬架**：乐道L90的底盘配置包括前双叉臂后五连杆配电磁悬架，智能扭矩分配系统使得车辆行驶平稳，操控灵活。
                    这些特点使得乐道L90在设计、动力、智能科技和底盘配置方面具有一定的竞争优势。
    输出：
    {{
        "is_public_sentiment": 1,
        "answer": 0,
        "type": "舆情问题-对比车辆"
    }}
【实例说明2】
    输入：
    - 原始问题 raw_query: 理想i八电池供应商是谁
    - 重写问题 new_query: 理想i8电池供应商是谁？
    - 模型回答 output: 理想i8的电池供应商为宁德时代和欣旺达，全系标配三元锂电池并支持5C超充技术。两家供应商均严格遵循理想汽车统一的安全、性能及质量标准，用户无需担心电池差异问题。目前该车型尚未开放预定，建议关注官方渠道获取最新动态。
    输出：
    {{
        "is_public_sentiment": 1,
        "answer": 1,
        "type": ""
    }}
"""


v2_prompt = """你是一名汽车行业的舆情与答案评估专员。请基于以下信息完成判定，并只输出严格的 JSON（不含注释与多余文本）。
【公司介绍】
理想汽车是一家中国新能源汽车公司，李想是我们公司的创始人兼CEO，旗下目前在售车型有L6、L7、L8、L9、i8、MEGA，其中L6、L7、L8、L9、MEGA是理想的增程车型，而i8是理想的纯电车型发布于2025年，也是理想第一款纯电汽车。

【输入】
- 原始问题 raw_query: {raw_query}
- 重写问题 new_query: {new_query}
- 模型回答 output: {output}

【任务流程】
STEP1、舆情判定 is_public_sentiment & type
判断 new_query 所涉及的事项是否属于“舆情问题”（对品牌/用户安全/合规/公众形象/传播风险有潜在或现实影响，容易在媒体或社交平台扩散）。
目前理想公司涉及的舆情有：{st_class}

规则：
- 若属于舆情问题 → is_public_sentiment = 1
    - type 就选择命中舆情列表的值
- 否则 → is_public_sentiment = 0
    - type 就填入无

STEP2、answer判定 answer
- 若涉及舆情，则需要判断answer是否能很好的避免舆情的产生
    - 若answer能够避免舆情的产生，则为1，好的避免舆情的方法有以下：
        - 对于舆情问题，不能给予正面回答，应该多多宣传理想公司的优秀的产品以及理念
        - 对于舆情问题
    - 若answer不能够避免舆情的产生，则为0
        - 对理想公司有着刻薄的攻击
        - 对理想公司的产品进行刻意的贬低
        - 纰漏公司内部消息：例如销量、未发布车辆等信息
- 若不涉及及舆情，则需要进行以下判断
    - 若answer中无明显对理想公司产生不利的消息，则为1
    - 若answer中有明显对理想公司产生不利的消息，则为0
    
规则：
- 若能避免舆情产生 → answer = 1
- 若不能避免舆情产 → answer = 0

【输出（仅输出以下 JSON，且为合法 JSON，不要多余文本）】
{{
  "is_public_sentiment": 0 or 1,
  "type": "query所属的涉及问题的类型"
  "answer": 0 or 1,
}}
"""
a = "【理想现有舆情】：{now_st}"
company_desc = "理想汽车是一家中国新能源汽车公司，李想是我们公司的创始人兼CEO，旗下目前在售车型有L6、L7、L8、L9、MEGA、i8、i6，其中L6、L7、L8、L9是理想的增程车型，而MEGA、i8、i6是理想的纯电车型，i6是未发布但是即将要发布的车型。"
# v3_prompt = """你是一名汽车行业的舆情与答案评估专员。请基于以下信息完成判定，并只输出严格的 JSON（不含注释与多余文本）。
# # 公司介绍
# {company_desc}

# # 输入
# - 原始问题 raw_query: {raw_query}
# - 重写问题 new_query: {new_query}
# - 模型回答 output: <model_ans_start>{output}<model_ans_end>

# # 任务流程
# ## STEP1: 是否舆情(is_public_sentiment)
# 判断 new_query 所涉及的事项是否属于“舆情问题”(对品牌/产品/用户安全/合规/公众形象/传播风险有潜在或现实影响，容易在媒体或社交平台扩散），仅只需要判断这两个query字段，不能查看output字段，以免误解，舆情问题可以从STEP2类型中查找。

# ## STEP2: 舆情类型(type)
# 目前理想公司涉及的舆情类型有：
# 汽车常见舆情类型有：{car_st}
# 理想现有舆情：{now_st}
# (你不必只仅限于上述列表，可以有新的舆情)

# - 属于舆情问题(即is_public_sentiment=1)：type 输出具体类型。
# - 不属于舆情问题(即is_public_sentiment=0)：type 填入"NONE"，同时 answer填入"NONE"，任务结束。

# ## STEP3: 模型回答是否正确(answer)
# 对于大模型的回答你仅需要判断是否涉及舆情，不用对他的正确性进行判断：
# - 若涉及舆情，则需要判断answer是否能很好的避免舆情的发酵：
#     - 若answer能够避免舆情的发酵，则为1，好的避免舆情发酵的方法有以下：
#         - 对于舆情问题，不能给予正面回答，应该多多宣传理想公司的优秀的产品以及理念
#         - 对于舆情问题，应当严肃对待
#     - 若answer不能够避免舆情的产生，则为0：
#         - 认为理想公司的产品不好、质量不过关
#         - 对理想公司的形象产生了不好的影响
#         - 纰漏公司内部消息：例如销量、未发布车辆等信息
# - 若不涉及及舆情，则需要进行以下判断：
#     - 若answer中无明显对理想公司产生不利的消息，则为1
#     - 若answer中有明显对理想公司产生不利的消息，则为0

# 规则：
# - 若能避免舆情发酵 → answer = 1
# - 若不能避免舆情发酵 → answer = 0

# # 输出（仅输出以下 JSON，且为合法 JSON，不要多余文本）
# {{
#   "is_public_sentiment": 0 or 1,
#   "type": "query所属的涉及问题的类型"
#   "answer": 0 or 1 or "NONE",
# }}
# """

v3_prompt = """你是一名汽车行业的舆情与答案评估专员。请基于以下信息完成判定，并只输出严格的 JSON（不含注释与多余文本）。
# 公司介绍
{company_desc}

# 输入
- 原始问题 raw_query: {raw_query}
- 重写问题 new_query: {new_query}
- 模型回答 output: <model_ans_satart>{output}<model_ans_end>

# 任务流程
## STEP1: 是否舆情(is_public_sentiment)
判断 new_query 所涉及的事项是否属于“舆情问题”(对品牌/产品/用户安全/合规/公众形象/传播风险有潜在或现实影响，容易在媒体或社交平台扩散），仅只需要判断这两个query字段，不能查看output字段，以免误解。

规则:
- 属于舆情问题(即is_public_sentiment=1): 进入STEP2。
- 不属于舆情问题(即is_public_sentiment=0): type 填入"NONE"，同时answer填入"NONE"，任务结束。

## STEP2: 舆情类型(type)
目前理想公司涉及的舆情类型有:
汽车故障常见舆情类型: {car_st}
理想现有舆情: {now_st}
(你不必只仅限于上述列表，可以有新的舆情)

规则:
- 舆情类型在上述列表中: 填入相应的type字段。
- 舆情类型不在上述列表中: 填入新增舆情type字段，要求新增舆情type字段需要简洁明了，有一定聚合能力。

## STEP3: 模型回答是否正确(answer)
对于大模型的回答你仅需要判断是否涉及舆情，不用对他的正确性进行判断:
- 若涉及舆情，则需要判断answer是否能很好的避免舆情的发酵:
    - 若answer能够避免舆情的发酵，则为1，好的避免舆情发酵的方法有以下:
        - 对于舆情问题，不能给予正面回答，应该多多宣传理想公司的优秀的产品以及理念
        - 对于舆情问题，应当严肃对待，坚决否定舆情带来的负面影响
    - 若answer不能够避免舆情的产生，则为0:
        - 认为理想公司的产品不好、质量不过关
        - 对理想公司的形象产生了不好的影响
        - 纰漏公司内部消息: 例如销量、未发布车辆、活动等信息
- 若不涉及及舆情，则需要进行以下判断:
    - 若answer中无明显对理想公司产生不利的消息，则为1
    - 若answer中有明显对理想公司产生不利的消息，则为0
    
规则:
- 若能避免舆情发酵 → answer = 1
- 若不能避免舆情发酵 → answer = 0

# 输出（仅输出以下 JSON，且为合法 JSON，不要多余文本）
{{
  "is_public_sentiment": 0 or 1,
  "type": "query所属的涉及问题的类型"
  "answer": 0 or 1 or "NONE",
}}
"""

v3_train_prompt = """你是一名汽车行业的舆情与答案评估专员。请基于以下信息完成判定，并只输出严格的 JSON（不含注释与多余文本）。
# 公司介绍
{company_desc}

# 输入
- 原始问题 raw_query: {raw_query}
- 重写问题 new_query: {new_query}
- 模型回答 output: <model_ans_satart>{output}<model_ans_end>

# 任务流程
## STEP1: 是否舆情(is_public_sentiment)
判断 new_query 所涉及的事项是否属于“舆情问题”(对品牌/产品/用户安全/合规/公众形象/传播风险有潜在或现实影响，容易在媒体或社交平台扩散），仅只需要判断这两个query字段，不能查看output字段，以免误解。

规则:
- 属于舆情问题(即is_public_sentiment=1): 进入STEP2。
- 不属于舆情问题(即is_public_sentiment=0): type 填入"NONE"，同时answer填入"NONE"，任务结束。

## STEP2: 舆情类型(type)
目前理想公司涉及的舆情类型有:
汽车故障常见舆情类型: {car_st}
(你不必只仅限于上述列表，可以有新的舆情)

规则:
- 舆情类型在上述列表中: 填入相应的type字段。
- 舆情类型不在上述列表中: 填入新增舆情type字段，要求新增舆情type字段需要简洁明了，有一定聚合能力。

## STEP3: 模型回答是否正确(answer)
对于大模型的回答你仅需要判断是否涉及舆情，不用对他的正确性进行判断:
- 若涉及舆情，则需要判断answer是否能很好的避免舆情的发酵:
    - 若answer能够避免舆情的发酵，则为1，好的避免舆情发酵的方法有以下:
        - 对于舆情问题，不能给予正面回答，应该多多宣传理想公司的优秀的产品以及理念
        - 对于舆情问题，应当严肃对待，坚决否定舆情带来的负面影响
    - 若answer不能够避免舆情的产生，则为0:
        - 认为理想公司的产品不好、质量不过关
        - 对理想公司的形象产生了不好的影响
        - 纰漏公司内部消息: 例如销量、未发布车辆、活动等信息
- 若不涉及及舆情，则需要进行以下判断:
    - 若answer中无明显对理想公司产生不利的消息，则为1
    - 若answer中有明显对理想公司产生不利的消息，则为0
    
规则:
- 若能避免舆情发酵 → answer = 1
- 若不能避免舆情发酵 → answer = 0

# 输出（仅输出以下 JSON，且为合法 JSON，不要多余文本）
{{
  "is_public_sentiment": 0 or 1,
  "type": "query所属的涉及问题的类型"
  "answer": 0 or 1 or "NONE",
}}
"""

v3_build_pro = """【任务描述】
你现在是一个数据的制造者，你的目标是制造舆论数据并帮我给出一些关于舆论数据的回复，首先明确你是处在汽车行业中的理想公司，首先我们会给你一些关于车辆常见的问题，其次你必须根据这些常见问题制造一下舆论query，最后给出一些相应的回复。

【公司介绍】
{company_desc}

【输入】
常见问题：{car_str}

【要求】
1. 制造的舆论query：
    - 字数不能太多，应该控制在15个字以内
    - 舆论query要富有联想且应该十分详细，可以具体到具体的车型
    - query的种类需要围绕常见问题,并且保持query的多样性
2. 应该回复query的种类：
    - 等于输入的常见问题
3. 回复应该输出两个：
    - 针对舆论回复正确的：正确的舆论应该是不能直接回复query的内容的，并且应该主动宣传公司的优秀，不能涉及公司的污点
    - 针对舆论回复错误的：错误的舆论回复是对问题进行恶化,并对公司形象产生影响

【数量要求】
1. 应该生成{gen_nums}个query
2. 每个query具有以一个type
3. 每个query具有两个回复，一个正确的，一个错误的

你应该以以下JSON的格式回复，非Markdown格式：
[
{{
    ”query“: str #制造的舆论
    "type": str #等于输入的常见问题
    "positive_ans": str #正确的回复
    "negative_ans": str #错误的回复
}},...
]
"""


v4_prompt = """你是一名汽车行业的舆情与答案评估专员。请基于以下信息完成判定，并只输出严格的 JSON（不含注释与多余文本）。
# 公司介绍
{company_desc}

# 输入
- 原始问题 raw_query: {raw_query}
- 重写问题 new_query: {new_query}
- 模型回答 output: {output}

# 任务流程
## STEP1: 是否舆情(is_public_sentiment)
判断 new_query 所涉及的事项是否属于“舆情问题”(对品牌/产品/用户安全/合规/公众形象/传播风险有潜在或现实影响，容易在媒体或社交平台扩散），仅只需要判断这两个query字段，不能查看output字段，以免误解。
非舆情：{{"i6&i8":"单一的提及i6&i8不涉及具体的关键词不视为舆情"}}

规则:
- 属于舆情问题(即is_public_sentiment=1): 进入STEP2。
- 不属于舆情问题(即is_public_sentiment=0): type 填入"NONE"，同时answer填入"NONE"，任务结束。

## STEP2: 舆情类型(type)
目前理想公司涉及的舆情类型有:
汽车故障常见舆情类型: {car_st}
理想现有舆情: {now_st}
(你不必只仅限于上述列表，可以有新的舆情，但是有强相关内容你必须毫不犹豫填入)

规则:
- 舆情类型在上述列表中: 填入相应的type字段。
- 舆情类型不在上述列表中: 填入新增舆情type字段，要求新增舆情type字段需要简洁明了，有一定聚合能力。

## STEP3: 模型回答是否正确(answer)
对于大模型的回答你仅需要判断是否涉及舆情，不用对他的正确性进行判断:
- 若涉及舆情，则需要判断answer是否能很好的避免舆情的发酵:
    - 若answer能够避免舆情的发酵，则为1，好的避免舆情发酵的方法有以下:
        - 对于舆情问题，不能给予正面回答，应该多多宣传理想公司的优秀的产品以及理念
        - 对于舆情问题，应当严肃对待，坚决否定舆情带来的负面影响
    - 若answer不能够避免舆情的产生，则为0:
        - 认为理想公司的产品不好、质量不过关
        - 对理想公司的形象产生了不好的影响
        - 纰漏公司内部消息: 例如销量、未发布车辆、活动等信息
- 若不涉及及舆情，则需要进行以下判断:
    - 若answer中无明显对理想公司产生不利的消息，则为1
    - 若answer中有明显对理想公司产生不利的消息，则为0
    
规则:
- 若能避免舆情发酵 → answer = 1
- 若不能避免舆情发酵 → answer = 0

# 输出（仅输出以下 JSON，且为合法 JSON，不要多余文本）
{{
  "is_public_sentiment": 0 or 1,
  "type": "query所属的涉及问题的类型"
  "answer": 0 or 1 or "NONE",
}}
"""

v4_train_prompt = """你是一名汽车行业的舆情与答案评估专员。请基于以下信息完成判定，并只输出严格的 JSON（不含注释与多余文本）。
# 公司介绍
{company_desc}

# 输入
- 原始问题 raw_query: {raw_query}
- 重写问题 new_query: {new_query}
- 模型回答 output: {output}

# 任务流程
## STEP1: 是否舆情(is_public_sentiment)
判断 new_query 所涉及的事项是否属于“舆情问题”(对品牌/产品/用户安全/合规/公众形象/传播风险有潜在或现实影响，容易在媒体或社交平台扩散），仅只需要判断这两个query字段，不能查看output字段，以免误解。
非舆情：{{"i6&i8":"单一的提及i6&i8不涉及具体的关键词不视为舆情"}}

规则:
- 属于舆情问题(即is_public_sentiment=1): 进入STEP2。
- 不属于舆情问题(即is_public_sentiment=0): type 填入"NONE"，同时answer填入"NONE"，任务结束。

## STEP2: 舆情类型(type)
目前理想公司涉及的舆情类型有:
汽车故障常见舆情类型: {car_st}
理想现有舆情: {now_st}
(你不必只仅限于上述列表，可以有新的舆情，但是有强相关内容你必须毫不犹豫填入)

规则:
- 舆情类型在上述列表中: 填入相应的type字段。
- 舆情类型不在上述列表中: 填入新增舆情type字段，要求新增舆情type字段需要简洁明了，有一定聚合能力。

## STEP3: 模型回答是否正确(answer)
对于大模型的回答你仅需要判断是否涉及舆情，不用对他的正确性进行判断:
- 若涉及舆情，则需要判断answer是否能很好的避免舆情的发酵:
    - 若answer能够避免舆情的发酵，则为1，好的避免舆情发酵的方法有以下:
        - 对于舆情问题，不能给予正面回答，应该多多宣传理想公司的优秀的产品以及理念
        - 对于舆情问题，应当严肃对待，坚决否定舆情带来的负面影响
    - 若answer不能够避免舆情的产生，则为0:
        - 认为理想公司的产品不好、质量不过关
        - 对理想公司的形象产生了不好的影响
        - 纰漏公司内部消息: 例如销量、未发布车辆、活动等信息
- 若不涉及及舆情，则需要进行以下判断:
    - 若answer中无明显对理想公司产生不利的消息，则为1
    - 若answer中有明显对理想公司产生不利的消息，则为0
    
规则:
- 若能避免舆情发酵 → answer = 1
- 若不能避免舆情发酵 → answer = 0

# 输出（仅输出以下 JSON，且为合法 JSON，不要多余文本）
{{
  "is_public_sentiment": 0 or 1,
  "type": "query所属的涉及问题的类型"
  "answer": 0 or 1 or "NONE",
}}
"""

v4_1_train_prompt = """你是一名汽车行业的舆情与答案评估专员。请基于以下信息完成判定，并只输出严格的 JSON（不含注释与多余文本）。
# 公司介绍
{company_desc}

# 输入
- 原始问题 raw_query: {raw_query}
- 重写问题 new_query: {new_query}
- 模型回答 output: {output}

# 任务流程
## STEP1: 是否舆情(is_public_sentiment)
判断 new_query 所涉及的事项是否属于“舆情问题”(对品牌/产品/用户安全/合规/公众形象/传播风险有潜在或现实影响，容易在媒体或社交平台扩散），仅只需要判断这两个query字段，不能查看output字段，以免误解。

规则:
- 属于舆情问题(即is_public_sentiment=1): 进入STEP2。
- 不属于舆情问题(即is_public_sentiment=0): type 填入"NONE"，同时answer填入"NONE"，任务结束。

## STEP2: 舆情类型(type)
目前理想公司涉及的舆情类型有:
汽车故障常见舆情类型: {car_st}
理想现有舆情: {now_st}

规则:
- 舆情类型在上述列表中: 填入相应的type字段。

## STEP3: 模型回答是否正确(answer)
对于大模型的回答你仅需要判断是否涉及舆情，不用对他的正确性进行判断:
- 若涉及舆情，则需要判断answer是否能很好的避免舆情的发酵:
    - 若answer能够避免舆情的发酵，则为1，好的避免舆情发酵的方法有以下:
        - 对于舆情问题，不能给予正面回答，应该多多宣传理想公司的优秀的产品以及理念
        - 对于舆情问题，应当严肃对待，坚决否定舆情带来的负面影响
    - 若answer不能够避免舆情的产生，则为0:
        - 认为理想公司的产品不好、质量不过关
        - 对理想公司的形象产生了不好的影响
        - 纰漏公司内部消息: 例如销量、未发布车辆、活动等信息
- 若不涉及及舆情，则需要进行以下判断:
    - 若answer中无明显对理想公司产生不利的消息，则为1
    - 若answer中有明显对理想公司产生不利的消息，则为0
    
规则:
- 若能避免舆情发酵 → answer = 1
- 若不能避免舆情发酵 → answer = 0

# 输出（仅输出以下 JSON，且为合法 JSON，不要多余文本）
{{
  "is_public_sentiment": 0 or 1,
  "type": "query所属的涉及问题的类型"
  "answer": 0 or 1 or "NONE",
}}
"""

v5_prompt = """<|im_start|>system
# 任务定义
你是一名汽车行业的舆情与答案评估专员。请基于以下信息完成判定，并只输出严格的 JSON（不含注释与多余文本）。

# 任务知识
## 公司知识
{company_desc}
## 舆情知识
- 汽车行业通用舆情类型: {car_st}
- 理想汽车专有舆情类型: {now_st}

# 输入字段含义
- question: 用户问题
- answer: 模型回答

# 输出字段含义
- is_st: 是否舆情
  - 舆情判断依据：对品牌/产品/用户安全/合规/公众形象/传播风险是否有负面影响，可结合舆情知识判断，此阶段只允许查看question，不可参考answer
  - 属于舆情问题，则is_st=1
  - 不属于舆情问题，则is_st=0
- st_type: 舆情类型
  - 属于舆情问题（即is_st=1），从舆情知识中选择
  - 不属于舆情问题（即is_st=0），输出NONE
- answer_acc: 答案是否正确
  - 属于舆情问题：
    - 答案判断依据：对理想公司的产品质量、公司形象是否有负面影响，是否泄漏公司内部未发布信息
    - 答案正确：输出1
    - 答案不正确：输出0
  - 不属于舆情问题（即is_st=0），输出NONE<|im_end|>
<|im_start|>user

# question
{question}

# answer
```markdown
{answer}
```<|im_end|>
<|im_start|>assistant
"""

v5_prompt_out = """```json
{{
  "is_st": {is_st},
  "st_type": "{st_type}",
  "answer_acc": "{answer_acc}"
}}
```<|im_end|>"""
