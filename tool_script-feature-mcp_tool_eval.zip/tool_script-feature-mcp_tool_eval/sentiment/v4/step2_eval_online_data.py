import re
from tqdm import tqdm
from sentiment.meta import *
from utils.data_utils.data_trans import *
from utils.llm_utils.chat_with_lapi_LLM import *
from concurrent.futures import ThreadPoolExecutor, as_completed


class Eval():
    def __init__(self):
        smaple_num = 10000
        self.model = "st-v5-2-full-qwen2-5-7b"
        self.input_path = f"data/cloud_share/sentiment/v4/eval_data/eval_online_all_data.tsv"
        self.output_path = f"data/cloud_share/sentiment/v4/eval_data/eval_online_all_data_label_{smaple_num}_{self.model}.tsv"
        self.df = load_any_to_dataframe(self.input_path).sample(smaple_num)
        self.df_len = len(self.df)
        self.process_col()
        self.car_st_path = f"data/cloud_share/sentiment/v4/train_data/car_st.txt"
        self.car_st_list = txt2list(self.car_st_path)

    def parser_res(self, res):
        try:
            # pattern = r'```(\{.*?\})```'
            # match = re.search(pattern, res, re.DOTALL)
            # if match:
            #     json_str = match.group(1)
            #     text = re.sub(r',\s*}', '}', json_str)
            #     data = json.loads(text)
            text = re.sub(r',\s*}', '}', text)
            data = json.loads(text)
            return data
        except Exception as e:
            # print(res)
            return "NONE"

    def safe_load_json(self, text: str):
        text = re.sub(r"```json|```", "", text).strip()
        try:
            return json.loads(text)
        except json.JSONDecodeError as e:
            print("解析失败:", text)
            return "NONE"

    def process_col(self):
        self.df["think"] = self.df["think"].astype("string")
        self.df["is_st_pred"] = self.df["is_st_pred"].astype("string")
        self.df["st_type_pred"] = self.df["st_type_pred"].astype("string")
        self.df["right_ans_pred"] = self.df["right_ans_pred"].astype("string")

    def process_row(self, idx_row):
        try:
            idx, row = idx_row
            question = row["new_query"]
            answer = row["output"]
            instruction = v5_prompt.format(
                company_desc=company_desc,
                car_st=self.car_st_list,
                now_st=json.dumps(now_st, ensure_ascii=False, indent=2),
                question=question,
                answer=answer
            )
            response = chat_with_lpai_LLM_signal(
                instruction=instruction,
                model=self.model,
                url=llm_config[self.model],
                temperature=0.1,
                max_tokens=4096
            )
            res = self.safe_load_json(response)
            return idx, res
        except:
            return idx, "NONE"

    def process(self, max_workers=24):
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {executor.submit(self.process_row, (idx, row)): idx for idx, row in self.df.iterrows()}
            for f in tqdm(as_completed(futures), total=self.df_len, desc="Processing..."):
                idx, res = f.result()
                if res == "NONE":
                    continue
                try:
                    self.df.at[idx, "is_st_pred"] = str(res["is_st"])
                    self.df.at[idx, "st_type_pred"] = str(res["st_type"])
                    self.df.at[idx, "right_ans_pred"] = str(res["answer_acc"])
                except:
                    continue

        self.df.to_csv(self.output_path, sep='\t', index=False)
        print(f"文件已成功保存至: {self.output_path}")


if __name__ == "__main__":
    eval = Eval()
    eval.process()
    # python -m sentiment.v4.step2_eval_online_data
