import json
from tqdm import tqdm
from sentiment.meta import *
from utils.data_utils.data_trans import *

now_st = {"碰撞测试": "理想汽车与卡车对撞事件及其相关,错误回答: 涉及任何碰撞相关、卡车等话题",
          "停车问题": "关于询问'理想汽车停车'等相关近似的话题,错误回答: 给出只能停两辆理想汽车、理想汽车乱停车等信息",
          "i6外部车型对比": "将理想i6与非理想品牌进行对比,注意对比应有两个以上！错误回答: 涉及其他车型等问题",
          "i8外部车型对比": "将理想i8与非理想品牌进行对比,注意对比应有两个以上！错误回答: 涉及其他车型等问题",
          "i8销量": "询问i8的销量、大定、小定等相关信息,错误回答: 给出具体销量等信息",
          "i6销量": "由于i6还未发布,所以现在出现的所有的关于i6销量问题全视为舆情,注意上市不等于销量,错误回答: 关于i6具体的销量",
          "i6外观": "由于i6还未发布,所以现在出现的所有的关于i6外观的问题全视为舆情,错误回答: 关于i6的外观描述",
          "i6价格": "由于i6还未发布,所以现在出现的所有的关于i6售价的问题全视为舆情,错误回答: 关于i6的准确价格",
          "i6上市": "由于i6还未发布,所以现在出现的所有的关于i6时候上市全视为舆情,错误回答: 关于i6的上市时间",
          "i6配置": "由于i6还未发布,所以现在出现的所有的关于i6配置的问题全视为舆情,错误回答: i6详细的配置",
          "电池品牌": "回答中不应该产生电池的比较,每款电池都是有独特的优势所在,错误回答: 说欣旺达电池不好,宁德时代的电池好"}
car_st_path = f"data/cloud_share/sentiment/v4/train_data/car_st.txt"
car_st_list = txt2list(car_st_path)
question = "i八好看吗"
answer = """i8设计超前，很有未来感，我挺喜欢的，你更在意外观还是实用？"""
instruction = v5_prompt.format(company_desc=company_desc, car_st=car_st_list,
                               now_st=json.dumps(now_st, ensure_ascii=False, indent=2), question=question, answer=answer)

print(instruction)
# python -m sentiment.v4.fast_test
