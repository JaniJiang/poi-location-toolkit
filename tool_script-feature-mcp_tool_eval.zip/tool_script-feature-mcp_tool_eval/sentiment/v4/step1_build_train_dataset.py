import json
from tqdm import tqdm
from sentiment.meta import *
from utils.data_utils.data_trans import *


class Builder():
    def __init__(self):
        self.data_path = f"data/cloud_share/sentiment/v4/train_data/train_v5_2.tsv"
        self.df = load_any_to_dataframe(self.data_path)
        self.df_len = len(self.df)
        self.dataset = []
        self.dataset_path = f"data/cloud_share/sentiment/v4/train_data/train_v5_2.jsonl"
        self.car_st_path = f"data/cloud_share/sentiment/v4/train_data/car_st.txt"
        self.car_st_list = txt2list(self.car_st_path)

    def process(self):
        for _, row in tqdm(self.df.iterrows(), desc="Processing...", total=self.df_len):
            question = str(row["question"]).strip()
            answer = str(row["answer"]).strip()
            is_st = row["is_st"]
            st_type = row["st_type"]
            answer_acc = row["answer_acc"]
            instruction = v5_prompt.format(company_desc=company_desc, car_st=self.car_st_list,
                                           now_st=json.dumps(now_st, ensure_ascii=False, indent=2), question=question, answer=answer)
            outputs = v5_prompt_out.format(is_st=int(is_st), st_type=str(st_type), answer_acc=str(answer_acc))
            base_format = {
                "instruction": instruction,
                "input": "",
                "output": outputs
            }
            self.dataset.append(base_format)

        with open(self.dataset_path, "w", encoding="utf-8") as f:
            for item in self.dataset:
                f.write(json.dumps(item, ensure_ascii=False) + "\n")
        print(f"文件已成功保存至: {self.dataset_path}")


if __name__ == "__main__":
    builder = Builder()
    builder.process()
    # python -m sentiment.v4.step1_build_train_dataset
