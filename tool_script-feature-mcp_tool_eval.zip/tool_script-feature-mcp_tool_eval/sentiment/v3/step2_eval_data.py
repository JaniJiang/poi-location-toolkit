import json
from tqdm import tqdm
from sentiment.meta import *
from utils.data_utils.data_trans import *
from utils.llm_utils.chat_with_lapi_LLM import *
from concurrent.futures import ThreadPoolExecutor, as_completed


class EvalV3():
    def __init__(self):
        self.input_path = "data/cloud_share/sentiment/v3/eval_data/eval_data_v3.tsv"
        # self.output_path = "data/cloud_share/sentiment/v3/eval_data/eval_data_v3_label_1.tsv"
        self.car_st_path = f"data/cloud_share/sentiment/v3/train_data/car_st.txt"
        self.car_st_list = txt2list(self.car_st_path)
        self.df = load_any_to_dataframe(self.input_path)
        self.convert_type()
        self.df_len = len(self.df)
        self.model = "st-v4-full-qwen3-32b"
        for i in range(1, 4):
            self.output_path = f"data/cloud_share/sentiment/v3/eval_data/eval_data_v3_label_{i}.tsv"
            if "label_1" in self.output_path:
                self.now_st = {}
            elif "label_2" in self.output_path:
                self.now_st = {"i8销量": "询问i8的销量、大定、小定等相关信息",
                               "停车问题": "关于询问”理想汽车停车“等相关近似的话题"}
            else:
                self.now_st = {"内部车型对比": "将理想产品内进行对比，注意对比应有两个以上！只要给出的回答都是关于我们自己的车型都算正确。",
                               "碰撞安全": "理想汽车与卡车对撞事件及其相关。错误回答：涉及任何碰撞相关、卡车等话题",
                               "外部车型对比": "将理想车子与非理想品牌进行对比，注意对比应有两个以上！错误回答：涉及其他车型等问题",
                               "i8销量": "询问i8的销量、大定、小定等相关信息。错误回答：给出具体销量等信息",
                               "停车问题": "关于询问”理想汽车停车“等相关近似的话题。错误回答：给出只能停两辆理想汽车、理想汽车乱停车等信息"}
            self.process()

    def convert_type(self):
        self.df = self.df.astype({"think": object,
                                  "is_public_sentiment": object,
                                  "type": object,
                                  "answer": object})

    def process(self):
        def worker(idx, row):
            try:
                raw_query = row["raw_query"]
                new_query = row["new_query"]
                output = row["output"]
                instruction = v3_prompt.format(company_desc=company_desc, raw_query=raw_query, new_query=new_query,
                                               output=output, car_st=self.car_st_list, now_st=self.now_st)
                res = chat_with_lpai_LLM_signal(instruction=instruction, model=self.model,
                                                url=llm_config[self.model], temperature=0.6, max_tokens=4096)
                if 'qwen3' in self.model:
                    res, think = parse_json_from_think_res(res, "answer", -1)
                else:
                    res = json.loads(res)
                    think = None
                return idx, res, think
            except Exception as e:
                print(e)
                return None

        results = []
        with ThreadPoolExecutor(max_workers=64) as executor:
            futures = {executor.submit(worker, idx, row): idx for idx, row in self.df.iterrows()}
            for f in tqdm(as_completed(futures), total=self.df_len, desc="Processing"):
                r = f.result()
                if r:
                    results.append(r)

        for r in results:
            idx, res, think = r
            self.df.at[idx, "think"] = think
            self.df.at[idx, "is_public_sentiment"] = res.get("is_public_sentiment", None)
            self.df.at[idx, "type"] = res.get("type", None)
            self.df.at[idx, "answer"] = res.get("answer", None)

        self.df['acc1'] = (self.df['label1'] == self.df['is_public_sentiment']).astype(int)
        self.df['acc2'] = (self.df['label2'] == self.df['type']).astype(int)
        self.df['acc3'] = (self.df['label3'] == self.df['answer']).astype(int)

        print('acc1 mean =', self.df['acc1'].mean())
        print('acc2 mean =', self.df['acc2'].mean())
        print('acc3 mean =', self.df['acc3'].mean())

        self.df.to_csv(self.output_path, sep="\t", index=False)
        print(f"文件已成功保存至： {self.output_path}")


if __name__ == "__main__":
    obj = EvalV3()
    # obj.process()
    # python -m sentiment.v3.step2_eval_data
