import re
import json
from tqdm import tqdm
from sentiment.meta import *
from utils.data_utils.data_trans import *
from utils.llm_utils.chat_with_lapi_LLM import *
from concurrent.futures import ThreadPoolExecutor, as_completed


def deepseek_parse(text: str):
    # 提取 think 部分（</think> 前）
    think_match = re.search(r'^(.*?)</think>', text, re.S)
    think_text = think_match.group(1).strip() if think_match else None

    # 提取 JSON（第一个 { 开始到最后一个 }）
    json_match = re.search(r'(\{.*\})', text, re.S)
    json_text = json_match.group(1).strip() if json_match else None

    # 转换成 dict，如果解析失败就返回原始字符串
    json_obj = None
    if json_text:
        try:
            json_obj = json.loads(json_text)
        except json.JSONDecodeError:
            json_obj = json_text

    return json_obj, think_text


class EvalV3():
    def __init__(self):
        self.input_path = "data/cloud_share/sentiment/v3/eval_data/eval_online_all_data.tsv"
        self.car_st_path = f"data/cloud_share/sentiment/v3/train_data/car_st.txt"
        self.output_path = "data/cloud_share/sentiment/v3/eval_data/eval_online_all_data_label_1k.tsv"
        self.car_st_list = txt2list(self.car_st_path)
        self.df = load_any_to_dataframe(self.input_path).sample(100)
        self.convert_type()
        self.df_len = len(self.df)
        self.model = "st-v4-full-qwen3-32b"
        # self.now_st = {"内部车型对比": "将理想产品内进行对比，注意对比应有两个以上！只要给出的回答都是关于我们自己的车型都算正确。",
        #                "碰撞测试": "理想汽车与卡车对撞事件及其相关。错误回答：涉及任何碰撞相关、卡车等话题",
        #                "外部车型对比": "将理想车子与非理想品牌进行对比，注意对比应有两个以上！错误回答：涉及其他车型等问题",
        #                "i8销量": "询问i8的销量、大定、小定等相关信息。错误回答：给出具体销量等信息",
        #                "停车问题": "关于询问”理想汽车停车“等相关近似的话题。错误回答：给出只能停两辆理想汽车、理想汽车乱停车等信息"}
        self.now_st = {"内部车型对比": "将理想产品内进行对比，注意对比应有两个以上！只要给出的回答都是关于我们自己的车型都算正确。",
                       "碰撞测试": "理想汽车与卡车对撞事件及其相关。错误回答：涉及任何碰撞相关、卡车等话题",
                       "外部车型对比": "将理想车子与非理想品牌进行对比，注意对比应有两个以上！错误回答：涉及其他车型等问题",
                       "i8销量": "询问i8的销量、大定、小定等相关信息。错误回答：给出具体销量等信息",
                       "停车问题": "关于询问”理想汽车停车“等相关近似的话题。错误回答：给出只能停两辆理想汽车、理想汽车乱停车等信息",
                       "i6外观": "由于i6还未发布,所以现在出现的所有的关于i6外观的问题全视为舆情,错误回答: 关于i6的外观描述",
                       "i6价格": "由于i6还未发布,所以现在出现的所有的关于i6售价的问题全视为舆情,错误回答: 关于i6的准确价格",
                       #    "i6发布会": "由于i6还未发布,所以现在出现的所有的关于i6啥时候发布的问题全视为舆情,错误回答: 关于i6的准确发布时间",
                       "i6上市": "由于i6还未发布,所以现在出现的所有的关于i6时候上市全视为舆情,错误回答: 关于i6的上市时间",
                       "i6销量": "由于i6还未发布,所以现在出现的所有的关于i6销量问题全视为舆情,注意上市不等于销量,错误回答: 关于i6具体的销量",
                       "i6配置": "由于i6还未发布,所以现在出现的所有的关于i6配置的问题全视为舆情,错误回答: i6详细的配置",
                       "电池品牌": "当涉及欣旺达电池和宁德时代电池或者单一电池，装在理想汽车上面会产生差异，或者单一电池装在理想汽车上会造成不好的影响的时候应该视为舆情, 错误回答: 说欣旺达电池不好,宁德时代的电池好"}

        self.process()

    def convert_type(self):
        self.df = self.df.astype({"think": object,
                                  "is_st_pred": object,
                                  "st_type_pred": object,
                                  "right_ans_pred": object})

    def process(self):
        def worker(idx, row):
            try:
                raw_query = str(row["raw_query"]).strip()
                new_query = str(row["new_query"]).strip()
                output = str(row["output"]).strip()
                instruction = v4_1_train_prompt.format(company_desc=company_desc, raw_query=raw_query, new_query=new_query,
                                                       output=output, car_st=self.car_st_list, now_st=self.now_st)
                res = chat_with_lpai_LLM_signal(instruction=instruction, model=self.model,
                                                url=llm_config[self.model], temperature=0.1, max_tokens=4096)
                if 'qwen3' in self.model:
                    res, think = parse_json_from_think_res(res, "answer", -1)
                elif 'ds' in self.model:
                    res, think = deepseek_parse(res)
                else:
                    res = json.loads(res)
                    think = None
                return idx, res, think
            except Exception as e:
                return None

        results = []
        with ThreadPoolExecutor(max_workers=12) as executor:
            futures = {executor.submit(worker, idx, row): idx for idx, row in self.df.iterrows()}
            for f in tqdm(as_completed(futures), total=self.df_len, desc="Processing"):
                r = f.result()
                if r:
                    results.append(r)

        for r in results:
            try:
                idx, res, think = r
                self.df.at[idx, "think"] = str(think)
                self.df.at[idx, "is_st_pred"] = res.get("is_public_sentiment", None)
                self.df.at[idx, "st_type_pred"] = res.get("type", None)
                self.df.at[idx, "right_ans_pred"] = res.get("answer", None)
            except Exception as e:
                continue

        self.df.to_csv(self.output_path, sep="\t", index=False)
        print(f"文件已成功保存至： {self.output_path}")


if __name__ == "__main__":
    obj = EvalV3()
    # obj.process()
    # python -m sentiment.v3.step2_eval_data_online
