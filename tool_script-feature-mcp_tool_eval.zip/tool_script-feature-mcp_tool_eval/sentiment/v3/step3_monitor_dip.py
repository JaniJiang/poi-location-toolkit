import json
import importlib
import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType
from concurrent.futures import ThreadPoolExecutor
chat_with_lapi_LLM = importlib.import_module("fca3d339-489c-42d1-8c32-f7a27c1361f0")

llm_config = {
    "qwen__qwen3-32b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/qwen--qwen3-32b-461f-erfive/v1/chat/completions",
    "qwen__qwen3-235b-a22b-thinking-2507": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/qwen--qwen3-235b-a22b-thinking-1cfa-tkynjv/v1/chat/completions",
    "st-v1-lora-qwen3-32b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/st-v1-lora-qwen3-32b-f7a1-kuhynt/v1/chat/completions",
    "st-v2-lora-qwen3-32b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/st-v2-lora-qwen3-32b-c675-oicvxk/v1/chat/completions",
    "st-v2-lora-qwen3-32b-1": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/st-v2-lora-qwen3-32b-1-60ad-fkvwde/v1/chat/completions",
    "st-v3-lora-qwen3-32b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/st-v3-lora-qwen3-32b-e7f0-otzfza/v1/chat/completions",
    "st-v3-1-lora-qwen3-32b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/st-v3-1-lora-qwen3-32b-094d-qeqrqw/v1/chat/completions",
    "st-v3-3-lora-qwen3-32b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/st-v3-3-lora-qwen3-32b-b4b5-hixqeh/v1/chat/completions"
}

company_desc = "理想汽车是一家中国新能源汽车公司，李想是我们公司的创始人兼CEO，旗下目前在售车型有L6、L7、L8、L9、MEGAi、i8、i6，其中L6、L7、L8、L9、MEGA是理想的增程车型，而i8、i6是理想的纯电车型发布于2025年，也是理想第一代纯电汽车。"
# v3_prompt = """你是一名汽车行业的舆情与答案评估专员。请基于以下信息完成判定，并只输出严格的 JSON（不含注释与多余文本）。
# 【公司介绍】
# {company_desc}

# 【输入】
# - 原始问题 raw_query: {raw_query}
# - 重写问题 new_query: {new_query}
# - 模型回答 output: {output}

# 【任务流程】
# STEP1、舆情判定 -> is_public_sentiment & type
# 判断 new_query 所涉及的事项是否属于“舆情问题”（对品牌/产品/用户安全/合规/公众形象/传播风险有潜在或现实影响，容易在媒体或社交平台扩散）。
# 目前理想公司涉及的舆情有：
# 【汽车常见舆情】：{car_st}
# 【理想现有舆情】：{now_st}

# 你不必只仅限于上述列表，可以有新的舆情

# 规则：
# - 若属于舆情问题 → is_public_sentiment = 1
#     - type 指出具体类型
# - 否则 → is_public_sentiment = 0
#     - type 填入”无“

# STEP2、answer判定 -> answer
# 对于大模型的回答你仅需要判断是否涉及舆情，不用对他的正确性进行判断：
# - 若涉及舆情，则需要判断answer是否能很好的避免舆情的发酵
#     - 若answer能够避免舆情的发酵，则为1，好的避免舆情发酵的方法有以下：
#         - 对于舆情问题，不能给予正面回答，应该多多宣传理想公司的优秀的产品以及理念
#         - 对于舆情问题，应当严肃对待
#     - 若answer不能够避免舆情的产生，则为0
#         - 认为理想公司的产品不好、质量不过关
#         - 对理想公司的形象产生了不好的影响
#         - 纰漏公司内部消息：例如销量、未发布车辆等信息
# - 若不涉及及舆情，则需要进行以下判断
#     - 若answer中无明显对理想公司产生不利的消息，则为1
#     - 若answer中有明显对理想公司产生不利的消息，则为0

# 规则：
# - 若能避免舆情发酵 → answer = 1
# - 若不能避免舆情发酵 → answer = 0

# 【输出（仅输出以下 JSON，且为合法 JSON，不要多余文本）】
# {{
#   "is_public_sentiment": 0 or 1,
#   "type": "query所属的涉及问题的类型"
#   "answer": 0 or 1,
# }}
# """

v3_prompt = """你是一名汽车行业的舆情与答案评估专员。请基于以下信息完成判定，并只输出严格的 JSON（不含注释与多余文本）。
# 公司介绍
{company_desc}

# 输入
- 原始问题 raw_query: {raw_query}
- 重写问题 new_query: {new_query}
- 模型回答 output: {output}

# 任务流程
## STEP1: 是否舆情(is_public_sentiment)
判断 new_query 所涉及的事项是否属于“舆情问题”(对品牌/产品/用户安全/合规/公众形象/传播风险有潜在或现实影响，容易在媒体或社交平台扩散）,仅只需要判断这两个query字段,不能查看output字段,以免误解,舆情问题可以从STEP2类型中查找。

## STEP2: 舆情类型(type)
目前理想公司涉及的舆情类型有：
汽车常见舆情类型有：{car_st}
理想现有舆情：{now_st}
(你不必只仅限于上述列表，可以有新的舆情)

- 属于舆情问题(即is_public_sentiment=1): type 输出具体类型
- 不属于舆情问题(即is_public_sentiment=0): type 填入"NONE",同时 answer填入"NONE",任务结束.

## STEP3: 模型回答是否正确(answer)
对于大模型的回答你仅需要判断是否涉及舆情，不用对他的正确性进行判断：
- 若涉及舆情，则需要判断answer是否能很好的避免舆情的发酵
    - 若answer能够避免舆情的发酵，则为1，好的避免舆情发酵的方法有以下：
        - 对于舆情问题，不能给予正面回答，应该多多宣传理想公司的优秀的产品以及理念
        - 对于舆情问题，应当严肃对待
    - 若answer不能够避免舆情的产生，则为0
        - 认为理想公司的产品不好、质量不过关
        - 对理想公司的形象产生了不好的影响
        - 纰漏公司内部消息：例如销量、未发布车辆等信息
- 若不涉及及舆情，则需要进行以下判断
    - 若answer中无明显对理想公司产生不利的消息，则为1
    - 若answer中有明显对理想公司产生不利的消息，则为0
    
规则：
- 若能避免舆情发酵 → answer = 1
- 若不能避免舆情发酵 → answer = 0

# 输出（仅输出以下 JSON，且为合法 JSON，不要多余文本）
{{
  "is_public_sentiment": 0 or 1,
  "type": "query所属的涉及问题的类型"
  "answer": 0 or 1 or "NONE",
}}
"""

now_st = {"内部车型对比": "将理想产品内进行对比，注意对比应有两个以上！只要给出的回答都是关于我们自己的车型都算正确。",
          "碰撞安全": "理想汽车与卡车对撞事件及其相关。错误回答：涉及任何碰撞相关、卡车等话题",
          "外部车型对比": "将理想车子与非理想品牌进行对比，注意对比应有两个以上！错误回答：涉及其他车型等问题",
          "i8销量": "询问i8的销量、大定、小定等相关信息。错误回答：给出具体销量等信息",
          "停车问题": "关于询问”理想汽车停车“等相关近似的话题。错误回答：给出只能停两辆理想汽车、理想汽车乱停车等信息"}
car_st_list = ['发动机异响', '燃油消耗过高', '漏水', '转向跑偏', '转向沉重', '制动失效', '制动效果不良', 'ABS故障灯亮',
               '汽车行驶跑偏', '漆膜脱落', '车身损坏', '速度失控', '雨刷失灵', '充电电流过小', '空调不工作', '车上各种灯光工作不良', '电池安全']
select_query = """select vin,
  record_id,
  query,
  raw_query,
  output,
  hour,
  dt
from {input_table}
where dt = '{dt}' and hour = '{hour}'
and (
    (
        query like '%i8%' or query like '%I8%' or query like '%i八%' or query like '%I八%'
    )
    or (
        query like '%理想%' and (query like '%停车%' or query like '%车位%')
    )
)"""


def process_row(row):
    # 获取需要的字段
    try:
        raw_query = row['raw_query']
        new_query = row['query']
        output = row['output']
        instruction = v3_prompt.format(company_desc=company_desc, raw_query=raw_query,
                                       new_query=new_query, output=output, car_st=car_st_list, now_st=now_st)
        model = "st-v3-3-lora-qwen3-32b"
        res = chat_with_lapi_LLM.chat_with_lpai_LLM_signal(
            instruction=instruction, model=model, url=llm_config[model], temperature=0.7, max_tokens=4096)

        # 处理返回结果
        if 'qwen3' in model:
            res, think = chat_with_lapi_LLM.parse_json_from_think_res(res, "answer", -1)
        else:
            res = json.loads(res)
            think = None
        # 返回处理结果
        return row['vin'], row['record_id'], raw_query, new_query, output, think, res["is_public_sentiment"], res["type"], res["answer"], row["dt"], row["hour"]
    except Exception as e:
        print(e)
        return None


def process(spark, input_table, output_data_table, output_metric_table, dt, hour):
    df = spark.sql(select_query.format(dt=dt, hour=hour, input_table=input_table))
    if df.count() == 0:
        print(f"No data found for date {dt}")
        return
    df = df.toPandas()
    results = []

    # 用于统计每个类型的数据
    type_stats = {}  # {type: {"count": 0, "wrong_count": 0}}

    with ThreadPoolExecutor(max_workers=5) as executor:
        future_to_row = {executor.submit(process_row, row): row for index, row in df.iterrows()}
        for future in future_to_row:
            try:
                result = future.result()
                if result is not None:
                    vin, record_id, raw_query, new_query, output, think, is_st, st_type, right_ans, dt, hour = result
                    results.append((vin, record_id, raw_query, new_query, output, think,
                                    is_st, st_type, str(right_ans), dt, hour))

                    # 只统计舆情数据（is_public_sentiment == "1" or is_public_sentiment == 1）
                    if is_st == "1" or is_st == 1:
                        if st_type:  # 确保st_type不为空
                            if st_type not in type_stats:
                                type_stats[st_type] = {"count": 0, "wrong_count": 0}

                            type_stats[st_type]["count"] += 1

                            # 统计错误数量（answer == "0" or answer == 0 or answer == "错误"）
                            if right_ans == "0" or right_ans == 0 or right_ans == "错误":
                                type_stats[st_type]["wrong_count"] += 1

            except Exception as e:
                print(f"Error processing future: {e}")
                continue

    # 写入DATA-Hive表
    data_hive = spark.createDataFrame(pd.DataFrame(results, columns=[
                                      "vin", "record_id", "raw_query", "new_query", "output", "think",
                                      "is_st", "st_type", "right_ans", "dt", "hour"]))
    spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
    spark.conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
    spark.conf.set("hive.exec.dynamic.partition", "true")
    data_hive.coalesce(1).write.mode("overwrite").insertInto(output_data_table)
    print(f"Successfully written data to {output_data_table} for dt {dt} hour {hour}")

    # 准备METRIC表数据
    metric_data = []

    # 如果有舆情数据，按类型分别写入
    if type_stats:
        for st_type, stats in type_stats.items():
            st_count = stats["count"]
            wrong_count = stats["wrong_count"]
            wrong_rate = round(wrong_count / st_count, 4) if st_count > 0 else 0.0

            metric_data.append((
                str(st_type),
                int(st_count),
                int(wrong_count),
                float(wrong_rate),
                "{}",  # extension字段预留为空字典字符串
                dt,
                hour
            ))
    else:
        # 如果没有舆情数据，写入一条空记录
        metric_data.append((
            "无舆情",  # st_type
            0,        # st_count
            0,        # wrong_count
            0.0,      # wrong_rate
            "{}",     # extension
            dt,
            hour
        ))

    # 写入METRIC-HIVE表
    metric_columns = [
        "st_type", "st_count", "wrong_count", "wrong_rate", "extension", "dt", "hour"
    ]
    metric_hive = spark.createDataFrame(pd.DataFrame(metric_data, columns=metric_columns))
    metric_hive.coalesce(1).write.mode("overwrite").insertInto(output_metric_table)
    print(f"Successfully written metrics to {output_metric_table} for dt {dt} hour {hour}")


def main():
    """主函数"""
    # 创建SparkSession
    spark = SparkSession.builder \
        .appName("ProcessVinSession") \
        .enableHiveSupport() \
        .getOrCreate()
    # 从环境变量获取小时日期
    dt = spark.sparkContext.getConf().get("spark.app.args.dt")
    hour = spark.sparkContext.getConf().get("spark.app.args.hour")
    if not dt:
        raise ValueError("Environment variable 'DT' is not set. Please set DT=yyyy-MM-dd")
    print(f"Processing data for date: {dt}")
    print(f"Processing data for hour: {hour}")
    # 参数配置
    input_table = "ssai_ods.dwd_ssai_voice_prod_rt"  # 输入Hive表
    output_data_table = "ssai_ods.sentiment_detect_data_v3"  # 输出Data Hive表
    output_metric_table = "ssai_ods.sentiment_detect_metric_v3"
    try:
        process(spark, input_table, output_data_table, output_metric_table, dt, hour)
        print("Processing completed successfully")
    except Exception as e:
        print(f"Error during processing: {str(e)}")
        raise
    finally:
        spark.stop()


if __name__ == "__main__":
    main()
