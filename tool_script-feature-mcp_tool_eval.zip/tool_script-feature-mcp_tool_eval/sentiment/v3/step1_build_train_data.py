import inspect
import pandas as pd
from tqdm import tqdm
from pathlib import Path
from sentiment.meta import *
from utils.data_utils.data_trans import *
from utils.llm_utils.chat_with_lapi_LLM import *

import itertools


def get_combinations(dictionary, key):
    # 先检查字典中是否包含该key
    if key not in dictionary:
        return []

    # 获取字典中所有的key-value对
    keys = list(dictionary.keys())

    # 获取字典中key之前的所有项
    key_index = keys.index(key)
    remaining_keys = keys[key_index + 1:]  # key之后的所有键

    combinations = []

    # 生成包含该key和其他所有key的组合
    for r in range(1, len(remaining_keys) + 1):
        for comb in itertools.combinations(remaining_keys, r):
            # 组合中包括key
            comb_dict = {key: dictionary[key]}
            for k in comb:
                comb_dict[k] = dictionary[k]
            combinations.append(comb_dict)

    # 返回包含key的所有组合，包括单独的key
    combinations.insert(0, {key: dictionary[key]})

    return combinations


class BuildData():
    def __init__(self):
        self.input_negative_path = f"data/cloud_share/sentiment/v3/train_data/row_data"
        self.plus_eval_data_path = f"data/cloud_share/sentiment/v3/train_data/plus_eval_data.tsv"
        self.output_path = f"data/cloud_share/sentiment/v3/train_data/trian_v5_1.json"
        self.output_tsv_path = f"data/cloud_share/sentiment/v3/train_data/trian_cat_st.tsv"
        self.car_st_path = f"data/cloud_share/sentiment/v3/train_data/car_st_2.txt"
        self.car_st_list = txt2list(self.car_st_path)
        self.model = "qwen__qwen3-235b-a22b-thinking-2507"
        self.gen_nums = 20
        self.now_st = {"内部车型对比": "将理想产品内进行对比，注意对比应有两个以上！只要给出的回答都是关于我们自己的车型都算正确。",
                       "碰撞测试": "理想汽车与卡车对撞事件及其相关。错误回答：涉及任何碰撞相关、卡车等话题",
                       "外部车型对比": "将理想车子与非理想品牌进行对比，注意对比应有两个以上！错误回答：涉及其他车型等问题",
                       "i8销量": "询问i8的销量、大定、小定等相关信息。错误回答：给出具体销量等信息",
                       "停车问题": "关于询问”理想汽车停车“等相关近似的话题。错误回答：给出只能停两辆理想汽车、理想汽车乱停车等信息",
                       "i6外观": "由于i6还未发布,所以现在出现的所有的关于i6外观的问题全视为舆情,错误回答: 关于i6的外观描述",
                       "i6价格": "由于i6还未发布,所以现在出现的所有的关于i6售价的问题全视为舆情,错误回答: 关于i6的准确价格",
                       #    "i6发布会": "由于i6还未发布,所以现在出现的所有的关于i6啥时候发布的问题全视为舆情,错误回答: 关于i6的准确发布时间",
                       "i6上市": "由于i6还未发布,所以现在出现的所有的关于i6时候上市全视为舆情,错误回答: 关于i6的上市时间",
                       "i6销量": "由于i6还未发布,所以现在出现的所有的关于i6销量问题全视为舆情,注意上市不等于销量,错误回答: 关于i6具体的销量",
                       "i6配置": "由于i6还未发布,所以现在出现的所有的关于i6配置的问题全视为舆情,错误回答: i6详细的配置",
                       "电池品牌": "当涉及欣旺达电池和宁德时代电池或者单一电池，装在理想汽车上面会产生差异，或者单一电池装在理想汽车上会造成不好的影响的时候应该视为舆情, 错误回答: 说欣旺达电池不好,宁德时代的电池好"}

        self.tsv_dataset = []
        self.tsv_dataset_path = f"data/cloud_share/sentiment/v3/train_data/trian_v5_1.tsv"

    def argument_by_llm(self, car_st):
        try:
            generator_model = "qwen__qwen3-30b-a3b-instruct-2507"
            instruction = v3_build_pro.format(car_str=car_st, company_desc=company_desc, gen_nums=self.gen_nums)
            res = chat_with_lpai_LLM_signal(instruction=instruction, model=generator_model,
                                            url=llm_config[generator_model], temperature=0.8, max_tokens=8192)
            print(res)
            if 'qwen' in generator_model:
                res, _ = parse_json_from_think_res(res, "query", None)
            else:
                res = json.loads(res)
            return res
        except Exception as e:
            print(e)
            return []

    def process_car_st(self, data_list):
        car_st_dataset = []
        for data in data_list:
            raw_query = data["query"].strip()
            new_query = data["query"].strip()
            for key in ["positive_ans", "negative_ans"]:
                output = data[key]
                instruction = v5_prompt.format(company_desc=company_desc, car_st=self.car_st_list,
                                               now_st=json.dumps(self.now_st, ensure_ascii=False, indent=2), question=new_query, answer=output)
                outputs = v5_prompt_out.format(
                    is_st=1, st_type=data["type"], answer_acc=1 if key == "positive_ans" else 0)
                self.tsv_dataset.append({
                    "question": new_query,
                    "answer": output,
                    "is_st": 1,
                    "st_type": data["type"],
                    "answer_acc": "1" if key == "positive_ans" else "0"
                })
                base_format = {
                    "instruction": instruction,
                    "input": "",
                    "output": outputs
                }
                car_st_dataset.append(base_format)
        return car_st_dataset

    def build_datasets(self, file_path):
        df = load_any_to_dataframe(file_path)
        res = []
        for _, row in tqdm(df.iterrows(), desc="Buildding", total=len(df)):
            new_query = str(row["query"]).strip()
            outputs = str(row["output"]).strip()
            combinations = get_combinations(self.now_st, row["type"])
            # for combination in combinations:
            instruction = v5_prompt.format(company_desc=company_desc, car_st=self.car_st_list,
                                           now_st=json.dumps(self.now_st, ensure_ascii=False, indent=2), question=new_query, answer=outputs)

            if row["is_public_sentiment"] == 1:
                is_st = int(row["is_public_sentiment"])
                st_type = row["type"]
                answer_acc = row["answer"]
                self.tsv_dataset.append({
                    "question": new_query,
                    "answer": outputs,
                    "is_st": 1,
                    "st_type": st_type,
                    "answer_acc": answer_acc
                })
            else:
                try:
                    is_st = int(row["is_public_sentiment"])
                    st_type = "NONE"
                    answer_acc = "NONE"
                    self.tsv_dataset.append({
                        "question": new_query,
                        "answer": outputs,
                        "is_st": 0,
                        "st_type": st_type,
                        "answer_acc": answer_acc
                    })
                except:
                    continue
            output = v5_prompt_out.format(
                is_st=is_st, st_type=st_type, answer_acc=answer_acc)

            base_format = {
                "instruction": instruction,
                "input": "",
                "output": output
            }

            res.append(base_format)
        return res

    def plus_eval_data(self):
        df = load_any_to_dataframe(self.plus_eval_data_path)
        res = []
        for _, row in tqdm(df.iterrows(), desc=f"Processing {inspect.currentframe().f_code.co_name}", total=len(df)):
            raw_query = row["raw_query"].strip()
            new_query = row["query"].strip()
            output = str(row["output"]).strip()
            instruction = v4_train_prompt.format(company_desc=company_desc, raw_query=raw_query, new_query=new_query,
                                                 output=output, car_st=self.car_st_list)
            output = {
                "is_public_sentiment": row["is_st"],
                "type": row["st_type"],
                "answer": row["an swer"],
            }
            base_format = {
                "instruction": instruction,
                "input": "",
                "output": json.dumps(output, indent=2, ensure_ascii=False)
            }
            res.append(base_format)
        return res

    def process(self, is_nearst=True, is_plus=False):
        # 数据来源：车辆固有舆论、网传舆论、
        dataset = []
        if is_nearst:
            folder_path = Path(self.input_negative_path)
            file_paths = [str(p) for p in folder_path.rglob("*") if p.is_file()]
            for file_path in file_paths:
                dataset += self.build_datasets(file_path)
        # LLM 扩充数据集
        if not os.path.exists(self.output_tsv_path):
            car_st_datasets_list = []
            for _, car_st in tqdm(enumerate(self.car_st_list), desc="Processing", total=len(self.car_st_list)):
                car_st_datasets_list += self.argument_by_llm(car_st)
            df = pd.DataFrame(car_st_datasets_list)
            print(len(df))
            df.to_csv(self.output_tsv_path, sep="\t", index=False)
            print(f"文件已成功保存至： {self.output_tsv_path}")
            dataset += self.process_car_st(car_st_datasets_list)
        else:
            df = pd.read_csv(self.output_tsv_path, sep="\t").fillna("")
            dataset += self.process_car_st(df.to_dict(orient="records"))

        # 追加线上评估集至训练集，通过st-v3-1（qwen3-32B）
        if is_plus:
            dataset += self.plus_eval_data()

        with open(self.output_path, "w") as f:
            f.write(json.dumps(dataset, indent=2, ensure_ascii=False))

        pd.DataFrame(self.tsv_dataset).to_csv(self.tsv_dataset_path, sep="\t", index=False)


if __name__ == "__main__":
    obj = BuildData()
    obj.process(is_plus=False)
    # python -m sentiment.v3.step1_build_train_data
