import os
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
from typing import List, Optional

plt.rcParams["font.sans-serif"] = ["Noto Sans CJK SC"]  # 或者 "SimHei"
plt.rcParams["axes.unicode_minus"] = False  # 正常显示负号


class SentimentTrend:
    def __init__(self, csv_path: str, encoding: str = "utf-8"):
        if not os.path.exists(csv_path):
            raise FileNotFoundError(f"文件不存在: {csv_path}")
        self.df = pd.read_csv(csv_path, encoding=encoding)
        self.df["dt"] = pd.to_datetime(self.df["dt"]).dt.date
        self.df["hour"] = pd.to_numeric(self.df["hour"], errors="coerce").fillna(0).astype(int)
        self.df["timestamp"] = self.df.apply(
            lambda r: datetime.combine(r["dt"], datetime.min.time()).replace(hour=r["hour"]), axis=1
        )

    def _clip_range(self, start_dt: Optional[str], end_dt: Optional[str]) -> pd.DataFrame:
        data = self.df
        if start_dt:
            data = data[data["timestamp"] >= pd.to_datetime(start_dt)]
        if end_dt:
            data = data[data["timestamp"] <= pd.to_datetime(end_dt)]
        return data

    def plot_trend(self, st_list: List[str], start_dt: Optional[str] = None, end_dt: Optional[str] = None,
                   freq: str = "H", save_dir: str = "data/cloud_share/sentiment/v3/online_log_data", show: bool = True):
        data = self._clip_range(start_dt, end_dt)
        os.makedirs(save_dir, exist_ok=True)  # 保证保存目录存在
        for st in st_list:
            sub = data[data["st_type"] == st]
            if sub.empty:
                continue
            agg = (sub.set_index("timestamp")
                      .groupby(pd.Grouper(freq=freq))[["st_count", "wrong_count"]]
                      .sum()
                      .reset_index())
            plt.figure(figsize=(8, 4))
            plt.plot(agg["timestamp"], agg["st_count"], label="st_count")
            plt.plot(agg["timestamp"], agg["wrong_count"], label="wrong_count")
            plt.title(f"{st} 趋势")
            plt.xlabel("时间")
            plt.ylabel("数量")
            plt.legend()
            plt.tight_layout()

            save_path = os.path.join(save_dir, f"{st}_trend.png")
            if show:
                plt.show()
            plt.savefig(save_path, dpi=150, bbox_inches="tight")  # ✅ 保存时加上 bbox_inches
            plt.close()
            print(f"已保存图片: {save_path}")

    def query_today(self, date_str: Optional[str] = None) -> dict:
        if date_str is None:
            date_str = datetime.now().strftime("%Y-%m-%d")
        d = pd.to_datetime(date_str).date()
        sub = self.df[self.df["dt"] == d]
        total_count = sub["st_count"].sum()
        wrong_count = sub["wrong_count"].sum()
        wrong_rate = (wrong_count / total_count) if total_count > 0 else 0
        by_type = sub.groupby("st_type")[["st_count", "wrong_count"]].sum().reset_index()
        by_type["wrong_rate"] = by_type.apply(
            lambda r: r["wrong_count"]/r["st_count"] if r["st_count"] > 0 else 0, axis=1
        )
        return {"date": str(d),
                "total": {"st_count": int(total_count), "wrong_count": int(wrong_count), "wrong_rate": float(wrong_rate)},
                "by_type": by_type}

    def stats_in_range(self, start_dt: Optional[str], end_dt: Optional[str]) -> pd.DataFrame:
        sub = self._clip_range(start_dt, end_dt)
        res = sub.groupby("st_type")[["st_count", "wrong_count"]].sum().reset_index()
        res["wrong_rate"] = res.apply(
            lambda r: r["wrong_count"]/r["st_count"] if r["st_count"] > 0 else 0, axis=1
        )
        return res


if __name__ == "__main__":
    sr = SentimentTrend("data/cloud_share/sentiment/v3/online_log_data/st_metric_3.csv")

    # 画图（每个 st_type 单独保存一张图，含 st_count 和 wrong_count 两条线）
    sr.plot_trend(st_list=["i8销量"], start_dt="2025-07-20", end_dt="2025-09-08", freq="H")

    # 查询当天情况
    today = sr.query_today()
    print(today["total"])
    print(today["by_type"])

    # 统计区间情况
    stats = sr.stats_in_range("2025-08-01", "2025-09-01")
    print(stats)
    # python -m sentiment.v3.step4_draw_detect_log
