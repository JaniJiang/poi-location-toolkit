# 版本
VERSION = "v8"
# 路径
DATA_DIR = f"data/cloud_share/cua/asr/poi_search/eval/{VERSION}"
