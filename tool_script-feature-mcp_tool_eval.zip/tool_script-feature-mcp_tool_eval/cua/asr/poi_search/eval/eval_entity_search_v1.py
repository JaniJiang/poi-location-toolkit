import json
import pandas as pd
from tqdm import tqdm
from utils.search_utils.entity_search import EntitySearch
from cua.asr.poi_search.eval.meta import *


class EvalEntitySearchV1:

    def __init__(self):
        self.input_path = f"{DATA_DIR}/eval_data.tsv"
        self.output_path = f"{DATA_DIR}/eval_entity_search_v1.tsv"
        self.new_cols = ["item_list", "hit_pos", "hit_score", "top_score"]
        # init search client
        url = "http://ssai-data-center-lids-testtwo.ssai-apis-staging.chj.cloud:80/search"
        self.entity_search = EntitySearch(url)

    def process(self):
        # 读取评估数据
        eval_df = pd.read_csv(self.input_path, sep="\t").fillna("")
        for col in self.new_cols:
            eval_df[col] = None
        # 发起检索
        for idx, row in tqdm(eval_df.iterrows(), total=len(eval_df)):
            request_json = {
                "scene": row["scene"],
                "type": row["type"],
                "city": row["city"],
                "origin_query": row["slot_query"],
                "search_query": row["slot_query"],
                "size": 10,
                "debug": True,
            }
            response_json = self.entity_search.search(request_json)
            if response_json is not None:
                item_list = []
                if response_json.get("status", "") == "success":
                    item_list = response_json.get("items", [])
                eval_df.loc[idx, "item_list"] = json.dumps(item_list, ensure_ascii=False, indent=4)
                if len(item_list) > 0:
                    # 校验hit位置
                    hit_pos_list, hit_score_list = self.check_hit_item(row["entity_name"], item_list)
                    eval_df.loc[idx, "hit_pos"] = ",".join([str(x) for x in hit_pos_list])
                    eval_df.loc[idx, "hit_score"] = ",".join([str(x) for x in hit_score_list])
                    # item最高分
                    eval_df.loc[idx, "top_score"] = item_list[0].get("similarityFeature", {}).get("RankScore", -1)
            else:
                eval_df.loc[idx, "item_list"] = "EMPTY"
        # 保存检索结果
        eval_df.to_csv(self.output_path, sep="\t", index=False, header=True)

    def check_hit_item(self, label, item_list):
        label_list = label.split("\n")  # 兼容多个label（单元格内换行表示）
        hit_pos_list = []
        hit_score_list = []
        for idx, item in enumerate(item_list, start=1):
            if item.get("text", "") in label_list:
                hit_pos_list.append(idx)
                hit_score_list.append(item.get("similarityFeature", {}).get("RankScore", -1))
        return hit_pos_list, hit_score_list


if __name__ == "__main__":
    obj = EvalEntitySearchV1()
    obj.process()

# python -m cua.asr.poi_search.eval.eval_entity_search_v1
