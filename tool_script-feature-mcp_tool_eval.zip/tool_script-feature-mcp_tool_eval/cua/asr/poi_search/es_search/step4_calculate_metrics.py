import os
import json
import pandas as pd
from utils.metrics_utils.common_metrics_utils import cal_metrics
from cua.asr.poi_search.es_search.meta import *
from cua.asr.poi_search.es_search.strategy.preprocess import *


class CalculateRecallMetrics:

    def __init__(self):
        self.input_path_dict = {
            "recall_v1_rank_v0": f"{DATA_DIR}/step3_search_entity.recall_v1.rank_v0.tsv",
            "recall_v2_rank_v0": f"{DATA_DIR}/step3_search_entity.recall_v2.rank_v0.tsv",
            "recall_v3_rank_v0": f"{DATA_DIR}/step3_search_entity.recall_v3.rank_v0.tsv",
        }
        self.output_path = f"{DATA_DIR}/step4_calculate_recall_metrics.tsv"

    def process(self):
        result_list = []
        # 计算指标
        for version, input_path in self.input_path_dict.items():
            if os.path.exists(input_path) is False:
                continue
            df = pd.read_csv(input_path, sep="\t").fillna("")
            df = df[(df["black_query"] == 0) & (df["entity_name"] != "")]  # 去除query黑名单和无标签数据
            result_item = {"策略版本": version}
            for n in range(1, RECALL_NUM + 1):
                col_name = f"p@{n}"
                df[col_name] = df.apply(lambda row: self.calculate_hit(row, n), axis=1)
                p_count = df[col_name].sum()
                p_rate = round(p_count / len(df), 4)
                result_item[col_name] = p_rate
            result_list.append(result_item)
        # 保存结果
        result_df = pd.DataFrame(result_list)
        result_df.to_csv(self.output_path, sep="\t", index=False, header=True)

    def calculate_hit(self, row, n) -> bool:
        """计算是否命中"""
        try:
            item_list = json.loads(row["item_list"])
            entity_name_list = row["entity_name"].split("\n")
            item_text_list = []
            for item in item_list[:n]:
                if item["text"] in entity_name_list:
                    item_text_list.append(item["text"])
            if set(entity_name_list) == set(item_text_list):
                return True
        except Exception as e:
            print(f"[CalculateMetricsV1] calculate_hit failed: {e}")
        return False


class CalculateRankMetrics:

    def __init__(self):
        self.input_path = f"{DATA_DIR}/step3_search_entity.recall_v2.rank_v1.tsv"
        self.output_path = f"{DATA_DIR}/step4_calculate_rank_metrics"

    def process(self):
        # 整体
        df = pd.read_csv(self.input_path, sep="\t").fillna("")
        cal_metrics(df, f"{self.output_path}.1_all", "final_score", "final_label", 0.01, 0.9, 1.01)
        # 检索可解
        filtered_a_df = df[df["问题类型"] != "非语义-其他错别字"]
        cal_metrics(filtered_a_df, f"{self.output_path}.2_need", "final_score", "final_label", 0.01, 0.9, 1.01)
        # ASR识别错误
        filtered_b_df = df[(df["是否识别正确"] == "否")]
        cal_metrics(filtered_b_df, f"{self.output_path}.3_asr", "final_score", "final_label", 0.01, 0.9, 1.01)
        # ASR识别错误&检索可解
        filtered_c_df = df[(df["是否识别正确"] == "否") & (df["问题类型"] != "非语义-其他错别字")]
        cal_metrics(filtered_c_df, f"{self.output_path}.4_asr_need", "final_score", "final_label", 0.01, 0.9, 1.01)
        # 真实解决率
        filtered_d_df = df[(df["能否搜到门店"] == "否") & (df["entity_name"] != "") &
                           (df["是否识别正确"] == "否") & (df["问题类型"] != "非语义-其他错别字")]
        cal_metrics(filtered_d_df, f"{self.output_path}.5_real", "final_score", "final_label", 0.01, 0.9, 1.01)


if __name__ == "__main__":
    # 计算recall指标
    recall_metrics_obj = CalculateRecallMetrics()
    recall_metrics_obj.process()
    # 计算rank指标
    rank_metrics_obj = CalculateRankMetrics()
    rank_metrics_obj.process()

# python -m cua.asr.poi_search.es_search.step4_calculate_metrics
