from cua.asr.poi_search.es_search.meta import *


def recall_strategy_v1(scene, type, country, province, city, query_normalized):
    """文本召回"""
    query_dsl_dict = {
        "query": {
            "bool": {
                "must": [
                    {"term": {"scene": scene}},
                    {"term": {"type": type}}
                ],
                "should": [
                    {"match": {"text_alias": {"query": query_normalized, "boost": 1.0}}}
                ],
                "minimum_should_match": 1
            }
        },
        "highlight": {"fields": {"text_pinyin": {}, "text_alias": {}}},
        "_source": RECALL_FIELDS,
        "size": RECALL_NUM
    }
    # 可选字段
    if country != "":
        query_dsl_dict["query"]["bool"]["must"].append({"term": {"country": country}})
    if province != "":
        query_dsl_dict["query"]["bool"]["must"].append({"term": {"province": province}})
    if city != "":
        query_dsl_dict["query"]["bool"]["must"].append({"term": {"city": city}})
    return query_dsl_dict


def recall_strategy_v2(scene, type, country, province, city, query_pinyin):
    """拼音召回"""
    query_dsl_dict = {
        "query": {
            "bool": {
                "must": [
                    {"term": {"scene": scene}},
                    {"term": {"type": type}}
                ],
                "should": [
                    {"match": {"text_pinyin": {"query": query_pinyin, "boost": 1.0}}}
                ],
                "minimum_should_match": 1
            }
        },
        "highlight": {"fields": {"text_pinyin": {}, "text_alias": {}}},
        "_source": RECALL_FIELDS,
        "size": RECALL_NUM
    }
    # 可选字段
    if country != "":
        query_dsl_dict["query"]["bool"]["must"].append({"term": {"country": country}})
    if province != "":
        query_dsl_dict["query"]["bool"]["must"].append({"term": {"province": province}})
    if city != "":
        query_dsl_dict["query"]["bool"]["must"].append({"term": {"city": city}})
    return query_dsl_dict


def recall_strategy_v3(scene, type, country, province, city, query_normalized, query_pinyin):
    """拼音&文本召回"""
    query_dsl_dict = {
        "query": {
            "bool": {
                "must": [
                    {"term": {"scene": scene}},
                    {"term": {"type": type}}
                ],
                "should": [
                    {"match": {"text_pinyin": {"query": query_pinyin, "boost": 1.0}}},
                    {"match": {"text_alias": {"query": query_normalized, "boost": 1.0}}}
                ],
                "minimum_should_match": 1
            }
        },
        "highlight": {"fields": {"text_pinyin": {}, "text_alias": {}}},
        "_source": RECALL_FIELDS,
        "size": RECALL_NUM
    }
    # 可选字段
    if country != "":
        query_dsl_dict["query"]["bool"]["must"].append({"term": {"country": country}})
    if province != "":
        query_dsl_dict["query"]["bool"]["must"].append({"term": {"province": province}})
    if city != "":
        query_dsl_dict["query"]["bool"]["must"].append({"term": {"city": city}})
    return query_dsl_dict


def recall_strategy_v4(scene, type, query_normalized, query_pinyin, query_pinyin_list):
    """召回调权"""
    query_dsl_dict = {
        "query": {
            "function_score": {
                "query": {
                    "bool": {
                        "must": [
                            {"term": {"scene": scene}},
                            {"term": {"type": type}}
                        ],
                        "should": [
                            {"match": {"text_pinyin": {"query": query_pinyin, "boost": 1.0}}},
                            # {"match": {"text_alias": {"query": query_normalized, "boost": 0.5}}}
                        ],
                        "minimum_should_match": 1
                    }
                },
                "script_score": {
                    "script": {  # 计算query长度与文档字段长度的差异（绝对值越小越相关）
                        "source": """
                            int queryLen = params.query_pinyin_len;
                            int docLen = (int)doc['text_pinyin_len'].value;
                            double lenDiff = Math.abs(queryLen - docLen);
                            int a = 5;
                            return a / (lenDiff + a);
                        """,
                        "params": {
                            "query_pinyin_len": len(query_pinyin_list)
                        }
                    }
                },
                "boost_mode": "multiply"  # 将脚本评分与原始评分相乘(multiply|sum|min|max|avg|replace)
            }
        },
        "_source": RECALL_FIELDS,
        "size": RECALL_NUM
    }
    return query_dsl_dict
