import re
import copy
from typing import List
from utils.nlp_utils.embedding_client import EmbeddingClient
from utils.search_utils.rule_match import generate_pinyin


def remove_suffix_text(text: str) -> str:
    text_copy = copy.deepcopy(text)
    for suffix in ["门店", "店"]:
        if text_copy.endswith(suffix) is True:
            return text_copy.removesuffix(suffix)
    return ""


def remove_suffix_pinyin(text: str) -> str:
    text_copy = copy.deepcopy(text)
    for suffix in ["men dian", "dian"]:
        if text_copy.endswith(suffix) is True:
            return text_copy.removesuffix(suffix)
    return ""


def get_highlighted_span_content(highlight_text, join_sep):
    """找到第一个<em>和最后一个</em>之间的所有内容，然后去掉标签"""
    if not highlight_text or "<em>" not in highlight_text or "</em>" not in highlight_text:
        return ""
    first_em = highlight_text.find("<em>")
    last_em_end = highlight_text.rfind("</em>") + 5
    if first_em == -1 or last_em_end < 5:
        return ""
    span_content = highlight_text[first_em:last_em_end]
    clean_content = re.sub(r"<[^>]*>", "", span_content)
    return join_sep.join(clean_content.split())


def exact_match(text_a: str, text_b: str) -> bool:
    if text_a == text_b:
        return True
    return False


def normalize_exact_match(text_a: str, text_b: str) -> bool:
    text_a_normalized = copy.deepcopy(text_a)
    text_b_normalized = copy.deepcopy(text_b)
    for del_char in [" ", "-"]:
        text_a_normalized = text_a_normalized.replace(del_char, "")
        text_b_normalized = text_b_normalized.replace(del_char, "")
    if text_a_normalized == text_b_normalized:
        return True
    return False


def pinyin_fuzzy_match(list1, list2):
    """
    比较两个拼音拆分列表是否匹配
    规则：
    1. 长度必须相同
    2. 逐个位置比较：
        - 完全相等：匹配
        - 声母位置：平翘舌不一致视为匹配（z/zh, c/ch, s/sh等），l/n互换（南方方言常见混淆）
        - 韵母位置：前后鼻音不一致视为匹配（an/ang, en/eng, in/ing等）
    """
    # 1. 检查长度是否一致
    if len(list1) != len(list2):
        return False
    # 定义声母互换对
    shengmu_pairs = {
        # 平翘舌
        ("z", "zh"), ("zh", "z"), ("c", "ch"), ("ch", "c"), ("s", "sh"), ("sh", "s"),
        # l/n 互换（南方方言常见混淆）
        ("l", "n"), ("n", "l")
    }
    for i in range(len(list1)):
        # 2. 检查完全相等的情况
        if list1[i] == list2[i]:
            continue
        # 3. 处理平翘舌不一致（仅限声母位置 - 偶数索引）
        elif i % 2 == 0:  # 声母位置
            # 检查是否为平翘舌对
            if (list1[i], list2[i]) in shengmu_pairs:
                continue
            # 非平翘舌对，且不相等
            return False
        # 4. 处理前后鼻音不一致（韵母位置 - 奇数索引）
        else:  # 韵母位置
            # 处理前鼻音变后鼻音的情况（如 an -> ang）
            if (list1[i].endswith("n") and list2[i].endswith("ng") and list1[i][:-1] + "ng" == list2[i]):
                continue
            # 处理后鼻音变前鼻音的情况（如 ang -> an）
            elif (list1[i].endswith("ng") and list2[i].endswith("n") and list1[i][:-2] + "n" == list2[i]):
                continue
            # 5. 其他不匹配情况
            return False
    # 所有位置都通过检查
    return True


def text_contain(text_a: str, text_b: str) -> bool:
    """
    判断text_a是否是text_b的子序列（不要求连续）
    Args:
        text_a: 子序列
        text_b: 主字符串
    Returns:
        bool: text_a是text_b的子序列返回True，否则返回False
    """
    if text_a is None or text_b is None or len(text_a) == 0 or len(text_b) == 0:
        return False
    if len(text_a) > len(text_b):
        return False
    i = 0  # text_a的指针
    j = 0  # text_b的指针
    while i < len(text_a) and j < len(text_b):
        if text_a[i] == text_b[j]:
            i += 1
        j += 1
    return i == len(text_a)


def pinyin_exact_contain(text_a: str, text_b: str) -> bool:
    """
    判断text_a是否是text_b的子序列（按单词匹配，不要求连续）
    Args:
        text_a: 子序列（按空格分隔的单词）
        text_b: 主字符串（按空格分隔的单词）
    Returns:
        bool: text_a的单词序列是text_b的单词子序列返回True，否则返回False
    """
    if text_a is None or text_b is None or len(text_a) == 0 or len(text_b) == 0:
        return False
    # 按空格分割成单词列表，过滤空字符串
    pinyin_words_a = [word for word in text_a.split() if word]
    pinyin_words_b = [word for word in text_b.split() if word]
    # 边界情况检查
    if len(pinyin_words_a) == 0 or len(pinyin_words_b) == 0 or len(pinyin_words_a) > len(pinyin_words_b):
        return False
    # 双指针算法
    i = 0  # pinyin_words_b的指针
    j = 0  # pinyin_words_b的指针
    while i < len(pinyin_words_a) and j < len(pinyin_words_b):
        if pinyin_words_a[i] == pinyin_words_b[j]:
            i += 1
        j += 1
    return i == len(pinyin_words_a)


def pinyin_fuzzy_contain(text_a: str, text_b: str) -> bool:
    """
    判断text_a是否是text_b的拼音子序列（按单词匹配，支持声母韵母模糊匹配，不要求连续）
    Args:
        text_a: 子序列（按空格分隔的拼音单词）
        text_b: 主字符串（按空格分隔的拼音单词）
    Returns:
        bool: text_a的拼音序列是text_b的拼音子序列返回True，否则返回False
    """
    if text_a is None or text_b is None or len(text_a) == 0 or len(text_b) == 0:
        return False
    # 按空格分割成拼音单词列表，过滤空字符串
    pinyin_words_a = [word for word in text_a.split() if word]
    pinyin_words_b = [word for word in text_b.split() if word]
    # 边界情况检查
    if len(pinyin_words_a) == 0 or len(pinyin_words_b) == 0 or len(pinyin_words_a) > len(pinyin_words_b):
        return False

    def pinyin_word_fuzzy_match(pinyin1, pinyin2):
        """使用声母韵母模糊匹配判断两个拼音单词是否相等"""
        try:
            # 将拼音字符串转换为声母韵母列表
            _, _, list1, _ = generate_pinyin(pinyin1)
            _, _, list2, _ = generate_pinyin(pinyin2)
            # 使用已有的模糊匹配函数
            return pinyin_fuzzy_match(list1, list2)
        except:  # 如果转换失败，回退到精确匹配
            return pinyin1 == pinyin2
    # 双指针算法
    i = 0  # pinyin_words_a的指针
    j = 0  # pinyin_words_b的指针
    while i < len(pinyin_words_a) and j < len(pinyin_words_b):
        if pinyin_word_fuzzy_match(pinyin_words_a[i], pinyin_words_b[j]):
            i += 1
        j += 1
    return i == len(pinyin_words_a)


def semantic_similarity(text_a: str, item_text_list: List[str]) -> List[float]:
    request_info = {
        "sentences": [text_a] + item_text_list,
        "need_normalize": True,
        "need_score": True,
        "need_sort": False,
        "model_type": "bge-m3"
    }
    obj = EmbeddingClient()
    result_list = obj.process(request_info)
    sim_score_list = [round(result_one["cosine_score"], 2) for result_one in result_list]
    return sim_score_list
