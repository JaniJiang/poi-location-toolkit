import copy
from cua.asr.poi_search.es_search.strategy.preprocess import *
from cua.asr.poi_search.es_search.strategy.rank_utils import *


def rank_strategy_v1(query_normalized, query_pinyin_str, query_pinyin_split_list, item_list):
    query_alias = remove_suffix_text(query_normalized)
    query_pinyin_alias = remove_suffix_pinyin(query_pinyin_str)
    item_copy_list = copy.deepcopy(item_list)
    item_text_list = [item["text"] for item in item_copy_list]  # text已经在离线BuildData做过归一化了
    sim_score_list = semantic_similarity(query_normalized, item_text_list)  # TODO: 计算text_alias
    for idx, item in enumerate(item_copy_list):
        sim_score = sim_score_list[idx]  # 语义相似度
        rank_score, rank_feature = rank_item_strategy_v1(
            query_normalized, query_alias, query_pinyin_str, query_pinyin_alias, query_pinyin_split_list, item, sim_score)
        item["feature"]["rank_score"] = rank_score
        item["feature"]["rank_hit"] = rank_feature.get("rank_hit", "")
    return True, item_copy_list


def rank_item_strategy_v1(query_normalized, query_alias, query_pinyin_str, query_pinyin_alias, query_pinyin_split_list, item, sim_score):
    rank_score = 0.0
    rank_feature = {}
    text_list = item["text_alias"]
    text_pinyin_str_list = item["text_pinyin"]
    text_pinyin_split_all_list = [i.split(" ") for i in item["text_pinyin_split"]]
    # 匹配策略1: 字符串精确匹配
    for text in text_list:
        if exact_match(query_normalized, text) is True:  # 文本精确匹配
            rank_score = 2.0
            rank_feature["rank_hit"] = "text_exact_match"
            return rank_score, rank_feature
    for text in text_list:
        if normalize_exact_match(query_normalized, text) is True:  # 归一化文本精确匹配
            rank_score = 1.9
            rank_feature["rank_hit"] = "text_normalize_exact_match"
            return rank_score, rank_feature
    for text_pinyin_str in text_pinyin_str_list:
        if exact_match(query_pinyin_str, text_pinyin_str) is True:  # 拼音精确匹配
            rank_score = 1.8
            rank_feature["rank_hit"] = "pinyin_exact_match"
            return rank_score, rank_feature
    for text_pinyin_split_list in text_pinyin_split_all_list:
        if pinyin_fuzzy_match(query_pinyin_split_list, text_pinyin_split_list) is True:  # 拼音模糊匹配
            rank_score = 1.7
            rank_feature["rank_hit"] = "pinyin_fuzzy_match"
            return rank_score, rank_feature
    # 匹配策略2: 高亮字符串模糊匹配
    highlight_dict = item.get("highlight", {})
    highlight_text_alias_list = highlight_dict.get("text_alias", [])
    for highlight_text_alias in highlight_text_alias_list:
        em_content_str = get_highlighted_span_content(highlight_text_alias, "")
        if text_contain(query_normalized, em_content_str) is True:
            rank_score = 1.6
            rank_feature["rank_hit"] = "text_contain"
            return rank_score, rank_feature
        elif text_contain(query_alias, em_content_str) is True:
            rank_score = 1.5
            rank_feature["rank_hit"] = "text_alias_contain"
            return rank_score, rank_feature
    highlight_text_pinyin_list = highlight_dict.get("text_pinyin", [])
    for highlight_text_pinyin in highlight_text_pinyin_list:
        em_content_str = get_highlighted_span_content(highlight_text_pinyin, " ")
        # 拼音精确包含
        if pinyin_exact_contain(query_pinyin_str, em_content_str) is True:
            rank_score = 1.4
            rank_feature["rank_hit"] = "pinyin_exact_contain"
            return rank_score, rank_feature
        elif pinyin_exact_contain(query_pinyin_alias, em_content_str) is True:
            rank_score = 1.3
            rank_feature["rank_hit"] = "pinyina_alias_exact_contain"
            return rank_score, rank_feature
        # 拼音模糊包含
        if pinyin_fuzzy_contain(query_pinyin_str, em_content_str) is True:
            rank_score = 1.2
            rank_feature["rank_hit"] = "pinyin_fuzzy_contain"
            return rank_score, rank_feature
        elif pinyin_fuzzy_contain(query_pinyin_alias, em_content_str) is True:
            rank_score = 1.1
            rank_feature["rank_hit"] = "pinyin_alias_fuzzy_contain"
            return rank_score, rank_feature
    # 匹配策略3: 语义相似度匹配
    rank_score = sim_score
    rank_feature["rank_hit"] = "semantic_similarity"
    return rank_score, rank_feature
