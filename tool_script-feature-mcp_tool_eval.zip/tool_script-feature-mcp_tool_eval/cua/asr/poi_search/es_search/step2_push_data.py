from loguru import logger
from utils.file_utils import read_jsonl_file
from utils.search_utils.es_client import ElasticSearchClient
from cua.asr.poi_search.es_search.meta import *


class PushData:

    def __init__(self, env, index_name, refresh_index=False):
        self.index_name = index_name
        self.refresh_index = refresh_index
        self.input_path = f"{DATA_DIR}/step1_build_data.jsonl"
        # init es client
        cluster_name = "recommend_prod" if env in ["prod"] else "recommend_testtwo"
        self.es_client = ElasticSearchClient(cluster_name)
        self.mapping = {
            "properties": {
                "id": {"type": "keyword"},
                "scene": {"type": "keyword"},
                "type": {"type": "keyword"},
                "text_full": {"type": "text"},
                "text": {"type": "text"},
                "text_alias": {"type": "text"},
                "text_pinyin": {"type": "text"},
                "text_pinyin_split": {"type": "text"},
                "country": {"type": "keyword"},
                "province": {"type": "keyword"},
                "city": {"type": "keyword"},
                "county": {"type": "keyword"},
            }
        }

    def process(self):
        # create index
        code = self.es_client.check_and_create_index(self.index_name, self.refresh_index, self.mapping)
        if code is False:
            logger.error(f"[PushData] check_and_create_index {self.index_name} failed")
            return False
        logger.info(f"[PushData] check_and_create_index {self.index_name} success")
        # read data
        data_list = read_jsonl_file(self.input_path)
        # load data
        success, failed = self.es_client.load_data(self.index_name, data_list)
        logger.info(f"[PushData] {success} documents loaded successfully, {failed} documents failed to load.")
        return True


if __name__ == "__main__":
    env = "testtwo"
    index_name = INDEX_NAME
    refresh_index = True
    obj = PushData(env, index_name, refresh_index)
    obj.process()

# python -m cua.asr.poi_search.es_search.step2_push_data
