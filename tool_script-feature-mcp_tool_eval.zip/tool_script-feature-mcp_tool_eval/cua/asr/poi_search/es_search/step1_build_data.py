import copy
import json
import hashlib
import pandas as pd
from tqdm import tqdm
from typing import List, Tuple
from utils.search_utils.rule_match import generate_pinyin
from cua.asr.poi_search.es_search.meta import *
from cua.asr.poi_search.es_search.strategy.preprocess import *


class BuildData:

    def __init__(self):
        self.input_path = f"{DATA_DIR}/entity_list.tsv"
        self.output_path = f"{DATA_DIR}/step1_build_data.jsonl"

    def process(self):
        # 读取输入数据
        input_df = pd.read_csv(self.input_path, sep="\t").fillna("")
        # 逐条处理生成索引数据
        with open(self.output_path, "w", encoding="utf-8") as f:
            for _, row in tqdm(input_df.iterrows(), total=len(input_df), desc="BuildData"):
                entity_full_name = normalize_text(row["entity_full_name"])
                # 生成entity的ID和别名
                entity_id = self.generate_index_id(entity_full_name, row)
                entity_alias_list = self.generate_entity_alias(entity_full_name, row)
                # 文本转拼音
                text_pinyin = []
                text_pinyin_split = []
                for entity_alias in entity_alias_list:
                    _, entity_pinyin_str, _, entity_pinyin_split_str = generate_pinyin(entity_alias)
                    text_pinyin.append(entity_pinyin_str)
                    text_pinyin_split.append(entity_pinyin_split_str)
                # 拼装建库数据
                item = {
                    "id": entity_id,
                    "scene": row["scene"],
                    "type": row["type"],
                    "text_full": row["entity_full_name"],
                    "text": row["entity_name"],
                    "text_alias": entity_alias_list,
                    "text_pinyin": text_pinyin,
                    "text_pinyin_split": text_pinyin_split,
                    "country": row["country"],
                    "province": row["province"],
                    "city": row["city"],
                    "county": row["county"],
                }
                f.write(json.dumps(item, ensure_ascii=False) + "\n")

    def generate_entity_alias(self, entity: str, row: pd.Series) -> List[str]:
        entity_alias_list = []
        # entity_alias_list = [entity]
        # 从头部开始去掉scene
        entity, entity_alias_list = self.remove_prefix_text(entity, row["scene"], entity_alias_list)
        # 从头部开始去掉loc
        if row["city"] != "" or row["county"] != "":
            for field_name in ["country", "province", "city", "county"]:
                entity, entity_alias_list = self.remove_prefix_text(entity, row[field_name], entity_alias_list)
        # 去掉后缀
        _, entity_alias_list = self.remove_suffix_text(entity, entity_alias_list)
        return entity_alias_list

    def remove_prefix_text(self, text: str, prefix: str, text_alias_list: List[str]) -> Tuple[str, List[str]]:
        text_copy = copy.deepcopy(text)
        text_copy_removed = text_copy.removeprefix(prefix)
        if text_copy_removed not in text_alias_list:
            text_alias_list.append(text_copy_removed)
        return text_copy_removed, text_alias_list

    def remove_suffix_text(self, text: str, text_alias_list: List[str]) -> Tuple[str, List[str]]:
        text_copy = copy.deepcopy(text)
        for suffix in ["店", "门店"]:
            text_copy_removed = text_copy.removesuffix(suffix)
            if text_copy_removed not in text_alias_list:
                text_alias_list.append(text_copy_removed)
        return text_copy_removed, text_alias_list

    def generate_index_id(self, entity: str, row: pd.Series) -> str:
        text_list = []
        for field_name in ["scene", "type", "country", "province", "city", "county"]:
            text_list.append(row[field_name])
        text_list.append(entity)
        text_join_str = "|".join(text_list)
        index_id = hashlib.md5(text_join_str.encode("utf-8")).hexdigest()
        return index_id


if __name__ == "__main__":
    obj = BuildData()
    obj.process()

# python -m cua.asr.poi_search.es_search.step1_build_data
