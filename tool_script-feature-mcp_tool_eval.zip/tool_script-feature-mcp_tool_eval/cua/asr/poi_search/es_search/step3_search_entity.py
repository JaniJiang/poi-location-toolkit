import json
import pandas as pd
from tqdm import tqdm
from utils.search_utils.rule_match import generate_pinyin
from utils.search_utils.es_client import ElasticSearchClient
from cua.asr.poi_search.es_search.meta import *
from cua.asr.poi_search.es_search.strategy.preprocess import *
from cua.asr.poi_search.es_search.strategy.recall import *
from cua.asr.poi_search.es_search.strategy.rank import *


class SearchEntity:

    def __init__(self, env, index_name, recall_version, rank_version):
        self.index_name = index_name
        self.recall_version = recall_version
        self.rank_version = rank_version
        self.input_path = f"{DATA_DIR}/eval_data.tsv"
        self.output_path = f"{DATA_DIR}/step3_search_entity"
        self.new_cols = ["slot_query_pinyin", "black_query", "recall_pos", "rank_pos",
                         "final_score", "final_label", "item_list", "item_filtered_list"]
        # init es client
        cluster_name = "recommend_prod" if env in ["prod"] else "recommend_testtwo"
        self.es_client = ElasticSearchClient(cluster_name)
        # query黑名单
        self.black_fuzzy_query_list = ["附近", "最近", "当前"]
        self.black_exact_query_list = ["旗舰店", "门店"]

    def process(self):
        # 读取评估数据
        eval_df = pd.read_csv(self.input_path, sep="\t").fillna("")
        for col in self.new_cols:
            eval_df[col] = None
        # 发起检索
        for idx, row in tqdm(eval_df.iterrows(), total=len(eval_df),
                             desc=f"recall_{self.recall_version}_rank_{self.rank_version}"):
            # if row["slot_query"] != "紫金城店":  # DEBUG逻辑
            #     continue
            # 预处理query
            query_normalized = normalize_text(row["slot_query"])
            # query黑名单过滤
            hit_black_query = 0
            if query_normalized in self.black_exact_query_list:
                hit_black_query = 1
            else:
                for black_fuzzy_query in self.black_fuzzy_query_list:
                    if black_fuzzy_query in query_normalized:
                        hit_black_query = 1
                        break
            eval_df.loc[idx, "black_query"] = hit_black_query
            if hit_black_query == 1:
                eval_df.loc[idx, "final_score"] = 1.0
                eval_df.loc[idx, "final_label"] = 1
                eval_df.loc[idx, "item_list"] = json.dumps([], ensure_ascii=False)
                eval_df.loc[idx, "item_filtered_list"] = json.dumps([], ensure_ascii=False)
                continue
            # query转拼音
            _, query_pinyin_str, query_pinyin_split_list, _ = generate_pinyin(query_normalized)
            eval_df.loc[idx, "slot_query_pinyin"] = query_pinyin_str
            # 处理recall策略
            if self.recall_version == "v1":
                query_dsl_dict = recall_strategy_v1(row["scene"], row["type"], row["country"], row["province"], row["city"],
                                                    query_normalized)
            elif self.recall_version == "v2":
                query_dsl_dict = recall_strategy_v2(row["scene"], row["type"], row["country"], row["province"], row["city"],
                                                    query_pinyin_str)
            elif self.recall_version == "v3":
                query_dsl_dict = recall_strategy_v3(row["scene"], row["type"], row["country"], row["province"], row["city"],
                                                    query_normalized, query_pinyin_str)
            else:
                continue
            # 发起ES检索
            item_list = self.es_client.search(query_dsl_dict, index_name, need_parse=True)
            # 处理检索结果
            if len(item_list) > 0:
                # recall命中位置
                eval_df.loc[idx, "recall_pos"] = self.hit_pos(row, item_list)
                eval_df.loc[idx, "final_score"] = item_list[0]["feature"]["recall_score"]
                # 处理rank策略
                is_rank = False
                if self.rank_version == "v1":
                    is_rank, item_list = rank_strategy_v1(
                        query_normalized, query_pinyin_str, query_pinyin_split_list, item_list)
                # 排序策略&过滤策略
                if is_rank is True:
                    item_list = sorted(item_list, key=lambda x: x["feature"]["rank_score"], reverse=True)
                    eval_df.loc[idx, "final_score"] = item_list[0]["feature"]["rank_score"]
                    item_filtered_list = [item for item in item_list if item["feature"]["rank_score"] >= 0.93]
                else:
                    item_filtered_list = item_list[:1]
                # rank命中位置
                rank_pos = self.hit_pos(row, item_list)
                eval_df.loc[idx, "rank_pos"] = rank_pos
                if rank_pos >= 1:
                    eval_df.loc[idx, "final_label"] = 1 if rank_pos == 1 else 0
                    eval_df.loc[idx, "item_list"] = json.dumps(item_list, ensure_ascii=False, indent=4)
                    eval_df.loc[idx, "item_filtered_list"] = json.dumps(
                        item_filtered_list, ensure_ascii=False, indent=4)
                else:  # rank_pos=-1
                    eval_df.loc[idx, "final_label"] = self.hit_empty(row)
                    eval_df.loc[idx, "item_list"] = json.dumps(item_list, ensure_ascii=False, indent=4)
                    eval_df.loc[idx, "item_filtered_list"] = json.dumps(
                        item_filtered_list, ensure_ascii=False, indent=4)
            else:
                eval_df.loc[idx, "final_score"] = 0.0
                eval_df.loc[idx, "final_label"] = self.hit_empty(row)
                eval_df.loc[idx, "item_list"] = json.dumps([], ensure_ascii=False)
                eval_df.loc[idx, "item_filtered_list"] = json.dumps([], ensure_ascii=False)
        # 保存检索结果
        eval_df.to_csv(f"{self.output_path}.recall_{self.recall_version}.rank_{self.rank_version}.tsv",
                       sep="\t", index=False, header=True)

    def hit_pos(self, row, item_list):
        if row["entity_name"] == "":
            return -1
        entity_name_list = row["entity_name"].split("\n")
        item_text_list = []
        pos_list = []
        for pos, item in enumerate(item_list, start=1):
            if item["text"] in entity_name_list:
                item_text_list.append(item["text"])
                pos_list.append(pos)
        if set(entity_name_list) == set(item_text_list) and len(pos_list) > 0:
            return pos_list[0]
        return -1

    def hit_empty(self, row):
        final_label = 1 if row["entity_name"] == "" else 0
        return final_label


if __name__ == "__main__":
    env = "testtwo"
    index_name = INDEX_NAME
    for recall_version in RECALL_VERSION_LIST:
        for rank_version in RANK_VERSION_LIST:
            obj = SearchEntity(env, index_name, recall_version, rank_version)
            obj.process()

# python -m cua.asr.poi_search.es_search.step3_search_entity
