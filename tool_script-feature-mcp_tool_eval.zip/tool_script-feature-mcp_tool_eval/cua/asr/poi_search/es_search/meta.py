# 版本
VERSION = "v3"
# 路径
DATA_DIR = f"data/cloud_share/cua/asr/poi_search/es_search/{VERSION}"
# ES参数
INDEX_NAME = f"entity_20250612_test_{VERSION}"
# 召回策略
RECALL_NUM = 10
RECALL_FIELDS = ["text_full", "text", "text_alias", "text_pinyin", "text_pinyin_split"]
# RECALL_VERSION_LIST = ["v1", "v2", "v3"]
RECALL_VERSION_LIST = ["v2"]
# 排序策略
# RANK_VERSION_LIST = ["v0", "v1"]
RANK_VERSION_LIST = ["v1"]
