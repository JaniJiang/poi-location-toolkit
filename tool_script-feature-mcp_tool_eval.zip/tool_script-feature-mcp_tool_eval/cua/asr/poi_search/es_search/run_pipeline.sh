#!/bin/bash
# bash cua/asr/poi_search/es_search/run_pipeline.sh

# 生成建库数据
python -m cua.asr.poi_search.es_search.step1_build_data
# 推送ES建库
python -m cua.asr.poi_search.es_search.step2_push_data
sleep 5
# ES检索
python -m cua.asr.poi_search.es_search.step3_search_entity
# 指标计算
python -m cua.asr.poi_search.es_search.step4_calculate_metrics
