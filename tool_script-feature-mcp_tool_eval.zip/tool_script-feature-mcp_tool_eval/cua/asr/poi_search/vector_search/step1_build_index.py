import json
import hashlib
from tqdm import tqdm
from loguru import logger
from utils.file_utils import read_text_file
from utils.nlp_utils.embedding import get_one_batch_embedding
from cua.asr.poi_search.vector_search.meta import *


class BuildIndex:

    def __init__(self):
        self.input_path = f"{DATA_DIR}/kfc_poi_list.txt"
        self.output_path = f"{DATA_DIR}/step1_build_index.jsonl"

    def process(self):
        # 读取输入数据
        input_list = read_text_file(self.input_path)
        # 逐条处理生成索引数据
        with open(self.output_path, "w", encoding="utf-8") as f:
            for i in tqdm(range(0, len(input_list), BATCH_SIZE), desc="index"):
                batch_question_list = []
                for question in input_list[i: (i + BATCH_SIZE)]:
                    batch_question_list.append(question)
                # 获取索引文本对应的向量
                try:
                    batch_embedding_list = get_one_batch_embedding(batch_question_list, DIM)
                except Exception as e:
                    logger.warning("get_batch_embedding:" + str(e))
                    continue
                if len(batch_question_list) != len(batch_embedding_list):
                    logger.warning("get_batch_embedding: result num not equal")
                    continue
                # 逐条生成qdrant索引数据
                for i, batch_question in enumerate(batch_question_list):
                    index_id = self.generate_index_id(batch_question)
                    batch_embedding = batch_embedding_list[i]
                    qdrant_item = {
                        "id": index_id,
                        "vector": batch_embedding,
                        "query": batch_question,
                        "payload": {}
                    }
                    f.write(json.dumps(qdrant_item, ensure_ascii=False) + "\n")

    def generate_index_id(self, question):
        index_id = hashlib.md5(question.encode("utf-8")).hexdigest()
        return index_id


if __name__ == "__main__":
    obj = BuildIndex()
    obj.process()

# python -m cua.asr.poi_search.step1_build_index
