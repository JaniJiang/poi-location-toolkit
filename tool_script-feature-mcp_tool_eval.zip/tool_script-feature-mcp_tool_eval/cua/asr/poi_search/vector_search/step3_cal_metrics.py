import pandas as pd
from utils.metrics_utils.common_metrics_utils import cal_metrics
from cua.asr.poi_search.vector_search.meta import *


class CalMetrics:

    def __init__(self):
        self.input_path = f"{DATA_DIR}/step2_eval_case_compare.tsv"
        self.output_path = f"{DATA_DIR}/step3_cal_metrics"

    def process(self):
        df = pd.read_csv(self.input_path, sep="\t")
        cal_metrics(df, f"{self.output_path}", "slot_score", "slot_label", 0.01, 0.82, 0.99)
        cal_metrics(df, f"{self.output_path}", "origin_score", "origin_label", 0.01, 0.73, 0.9)


if __name__ == "__main__":
    obj = CalMetrics()
    obj.process()

# python -m cua.asr.poi_search.step3_cal_metrics
