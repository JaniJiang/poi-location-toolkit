import json
import pandas as pd
from tqdm import tqdm
from utils.search_utils.rule_match import calculate_pinyin_match
from cua.asr.poi_search.vector_search.meta import *


class AnalysePinyinMatch:

    def __init__(self):
        self.input_path = f"{DATA_DIR}/analyse/pinyin_match.input.tsv"
        self.output_path = f"{DATA_DIR}/analyse/pinyin_match.output.tsv"
        self.query_field = "slot_query"
        self.retriever_result_field = "slot_retriever_result"

    def process(self):
        df = pd.read_csv(self.input_path, sep="\t")
        for idx, row in tqdm(df.iterrows(), total=len(df)):
            query = row[self.query_field]
            score, title = row[self.retriever_result_field].split("\n")[0].split(" | ")
            is_match, overlap_ratio, overlap_count, query_pinyin, title_pinyin, diff_query_pinyin, diff_title_pinyin = calculate_pinyin_match(
                query, title)
            df.at[idx, "is_match"] = is_match
            df.at[idx, "overlap_ratio"] = round(overlap_ratio, 6)
            df.at[idx, "overlap_count"] = overlap_count
            df.at[idx, "pinyin_all"] = json.dumps({"query": str(query_pinyin), "title": str(title_pinyin)},
                                                  ensure_ascii=False, indent=4)
            df.at[idx, "pinyin_diff"] = json.dumps({"query": str(diff_query_pinyin), "title": str(diff_title_pinyin)},
                                                   ensure_ascii=False, indent=4)
        df.to_csv(self.output_path, sep="\t", header=True, index=False)


if __name__ == "__main__":
    obj = AnalysePinyinMatch()
    obj.process()

# python -m cua.asr.poi_search.analyse.analyse_pinyin_match
