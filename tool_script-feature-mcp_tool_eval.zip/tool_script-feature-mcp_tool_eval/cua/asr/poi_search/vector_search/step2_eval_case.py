import json
import pandas as pd
from tqdm import tqdm
from typing import List
from loguru import logger
from utils.file_utils import read_text_file, read_jsonl_file
from utils.nlp_utils.embedding import get_batch_embedding
from utils.search_utils.memory_qdrant import MemoryQdrant
from cua.asr.poi_search.vector_search.meta import *


class EvalCase:

    def __init__(self):
        self.candidate_query_path = f"{DATA_DIR}/candidate_query.txt"
        self.index_path = f"{DATA_DIR}/step1_build_index.jsonl"
        self.output_path = f"{DATA_DIR}/step2_eval_case.tsv"
        self.recall_num = 5

    def process(self):
        # 构建索引
        text_index = self.build_index(self.index_path)
        # 读取query & 发起搜索
        query_text_list = read_text_file(self.candidate_query_path)
        retriever_result_list = self.do_retriever(text_index, query_text_list)
        # 保存搜索结果
        retriever_result_df = pd.DataFrame(retriever_result_list)
        retriever_result_df.to_csv(self.output_path, sep="\t", index=False, header=True)

    def build_index(self, index_path):
        logger.info("构建索引")
        text_index = MemoryQdrant()
        index_list = read_jsonl_file(index_path)
        for point in index_list:
            text_index.add_points([point])
        return text_index

    def do_retriever(self, text_index: MemoryQdrant, query_text_list: List[str], prefix: str = "", real_query_list: List[str] = None):
        logger.info("发起搜索")
        retriever_result_list = []
        query_embedding_list = get_batch_embedding(query_text_list, DIM, BATCH_SIZE)
        for query_idx, query in tqdm(enumerate(query_text_list), total=len(query_text_list), desc="do_retriever"):
            query_embedding = query_embedding_list[query_idx]
            item_list = text_index.search(query_embedding, top_k=self.recall_num)
            retriever_result_item = {
                f"{prefix}_query": query,
                f"{prefix}_retriever_result": self.format_item_list(item_list, "lines")
            }
            # 标注acc@1
            if real_query_list is not None:
                real_query = real_query_list[query_idx]
                # retriever_result_item[f"{prefix}_real_query"] = real_query
                retriever_result_item[f"{prefix}_score"] = round(item_list[0]["score"], 6)
                retriever_result_item[f"{prefix}_label"] = 1 if item_list[0]["payload"]["query"] == real_query else 0
            retriever_result_list.append(retriever_result_item)
        return retriever_result_list

    def format_item_list(self, item_list, data_type="json"):
        if data_type == "lines":
            formated_item_list = []
            for item in item_list:
                formated_item_list.append(" | ".join([str(round(item["score"], 6)), item["payload"]["query"]]))
            return "\n".join(formated_item_list)
        else:
            formated_item_list = []
            for item in item_list:
                formated_item_list.append([round(item["score"], 6), item["payload"]["query"]])
            return json.dumps(formated_item_list, ensure_ascii=False, indent=4)


if __name__ == "__main__":
    obj = EvalCase()
    obj.process()

# python -m cua.asr.poi_search.step2_eval_case
