# 版本
VERSION = "v2"
# 路径
DATA_DIR = f"data/cloud_share/cua/asr/poi_search/vector_search/{VERSION}"
# 向量模型参数
DIM = 128  # 768 | 128
BATCH_SIZE = 1
