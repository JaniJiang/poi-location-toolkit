import pandas as pd
from utils.file_utils import read_text_split_file
from cua.asr.poi_search.vector_search.meta import *
from cua.asr.poi_search.vector_search.step2_eval_case import EvalCase


class EvalCaseCompare(EvalCase):
    """https://li.feishu.cn/sheets/X0lusYnldhEpsYtIQImcSchGnGj"""

    def __init__(self):
        self.candidate_query_path = f"{DATA_DIR}/candidate_query_compare.txt"
        self.index_path = f"{DATA_DIR}/step1_build_index.jsonl"
        self.output_path = f"{DATA_DIR}/step2_eval_case_compare.tsv"
        self.recall_num = 5

    def process(self):
        # 构建索引
        text_index = self.build_index(self.index_path)
        # 读取query
        query_segs_list = read_text_split_file(self.candidate_query_path)
        real_query_list = [segs[0] for segs in query_segs_list]
        slot_query_list = [segs[1] for segs in query_segs_list]
        origin_query_list = [segs[2] for segs in query_segs_list]
        # 发起搜索
        slot_retriever_result_list = self.do_retriever(text_index, slot_query_list, "slot", real_query_list)
        origin_retriever_result_list = self.do_retriever(text_index, origin_query_list, "origin", real_query_list)
        # 按行合并搜索结果
        merge_result_list = []
        for idx, real_query in enumerate(real_query_list):
            merge_result_one = {"real_query": real_query}
            merge_result_one.update(slot_retriever_result_list[idx])
            merge_result_one.update(origin_retriever_result_list[idx])
            merge_result_list.append(merge_result_one)
        # 保存搜索结果
        merge_result_df = pd.DataFrame(merge_result_list)
        merge_result_df.to_csv(self.output_path, sep="\t", index=False, header=True)


if __name__ == "__main__":
    obj = EvalCaseCompare()
    obj.process()

# python -m cua.asr.poi_search.step2_eval_case_compare
