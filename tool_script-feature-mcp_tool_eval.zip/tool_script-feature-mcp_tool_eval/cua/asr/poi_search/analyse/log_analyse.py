import json
import pandas as pd


def main():
    input_path = "data/cloud_share/cua/asr/poi_search/analyse/log_analyse/20250918.tsv"
    input_df = pd.read_csv(input_path, sep="\t").fillna("")
    for _, row in input_df.iterrows():
        try:
            cua_output_str = row["cua_output"]
            cua_output_dict = json.loads(cua_output_str)
            shopAddressOrigin = cua_output_dict["dialog_acts"][0]["dass"][0]["slots"]["shopAddress"]
            shopAddressNew = json.loads(cua_output_dict["extras"]["nluSlots"])["门店地址"]["value"]
            if shopAddressNew != shopAddressOrigin:
                print(shopAddressOrigin, shopAddressNew)
        except Exception as e:
            print(e)
            continue


if __name__ == "__main__":
    main()
