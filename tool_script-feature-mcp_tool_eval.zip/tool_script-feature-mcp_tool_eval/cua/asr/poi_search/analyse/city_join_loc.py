import pandas as pd
from tqdm import tqdm
from utils.file_utils import read_jsonl_file


def main():
    candidate_loc_path = "data/dict/candidate_loc.jsonl"
    candidate_loc_list = read_jsonl_file(candidate_loc_path)
    city_dict = {item["city"]: item for item in candidate_loc_list if item["city"] != ""}

    data_dir = "data/cloud_share/cua/asr/poi_search/analyse/city_join_loc"
    input_path = f"{data_dir}/input.tsv"
    output_path = f"{data_dir}/output.tsv"

    input_df = pd.read_csv(input_path, sep="\t").fillna("")
    for idx, row in tqdm(input_df.iterrows(), total=len(input_df)):
        loc_item = city_dict.get(row["城市"], {})
        country = loc_item.get("country", "")
        province = loc_item.get("province", "")
        input_df.loc[idx, "国家"] = country
        input_df.loc[idx, "省份"] = province
    input_df.to_csv(output_path, sep="\t", header=True, index=False)


if __name__ == "__main__":
    main()

# python -m cua.asr.poi_search.analyse.city_join_loc
