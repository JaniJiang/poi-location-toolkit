import pandas as pd
from tqdm import tqdm
from utils.file_utils import write_json_file
from cua.asr.poi_search.es_search.meta import *


def main():
    input_path = f"{DATA_DIR}/eval_data.tsv"
    output_path = "data/cloud_share/cua/asr/poi_search/analyse/label_loc_by_rule/white_dict.json"
    eval_df = pd.read_csv(input_path, sep="\t").fillna("")
    result_dict = {}
    for _, row in tqdm(eval_df.iterrows(), total=len(eval_df)):
        entity_name_str = row["entity_name"].strip()
        if entity_name_str == "":
            continue
        entity_name_list = entity_name_str.split("\n")
        for entity_name in entity_name_list:
            entity_name = entity_name.strip()
            if entity_name == "":
                continue
            result_dict[entity_name] = {"country": row["country"], "province": row["province"], "city": row["city"]}
    write_json_file(result_dict, output_path)


if __name__ == "__main__":
    main()

# python -m cua.asr.poi_search.analyse.gen_white_dict
