import pandas as pd
from tqdm import tqdm
from cua.asr.poi_search.es_search.meta import *
from utils.file_utils import read_jsonl_file, read_json_file


class LabelLocByRule:

    def __init__(self):
        data_dir = "data/cloud_share/cua/asr/poi_search/analyse/label_loc_by_rule"
        self.input_path = f"{data_dir}/input.tsv"
        self.output_path = f"{data_dir}/output.tsv"
        # 获取地域词表
        self.candidate_loc_path = "data/dict/candidate_loc.jsonl"
        self.country_dict, self.province_dict, self.city_dict, self.county_dict = self.get_loc_dict()
        # 获取白名单词表
        white_human_dict = {
            "琼海东风路店": {"country": "中国", "province": "海南", "city": "", "county": "琼海"},
        }
        white_dict_path = f"{data_dir}/white_dict.json"
        self.white_dict = read_json_file(white_dict_path)
        self.white_dict.update(white_human_dict)

    def process(self):
        input_df = pd.read_csv(self.input_path, sep="\t").fillna("")
        for idx, row in tqdm(input_df.iterrows(), total=len(input_df)):
            # 标注国家、省份、城市
            entity_name = row["entity_name"]
            if entity_name in self.white_dict:
                white_item_dict = self.white_dict[entity_name]
                country = white_item_dict.get("country", "")
                province = white_item_dict.get("province", "")
                city = white_item_dict.get("city", "")
                county = white_item_dict.get("county", "")
            else:
                country, province, city, county = self.rule_label(entity_name)
            # 回写结果
            input_df.loc[idx, "country"] = country
            input_df.loc[idx, "province"] = province
            input_df.loc[idx, "city"] = city
            input_df.loc[idx, "county"] = county
            input_df.loc[idx, "has_loc"] = str(any([country, province, city, county]))
        input_df.to_csv(self.output_path, sep="\t", header=True, index=False)

    def rule_label(self, text):
        country, province, city, county = "", "", "", ""
        # 匹配城市
        for city_value, city_parent_value in self.city_dict.items():
            if city_value in text:
                city = city_value
                if country == "":
                    country = city_parent_value["country"]
                if province == "":
                    province = city_parent_value["province"]
                break
        # 匹配区县
        for county_value, county_parent_value in self.county_dict.items():
            if city != "":
                if county_parent_value["city"] != city or county_value == city:
                    continue
            if county_value in text and f"{county_value}路" not in text:
                county = county_value
                if country == "":
                    country = county_parent_value["country"]
                if province == "":
                    province = county_parent_value["province"]
                if city == "":
                    city = county_parent_value["city"]
                break
        if city == "" and county == "":
            # 匹配省份
            for province_value, province_parent_value in self.province_dict.items():
                if province_value in text:
                    province = province_value
                    if country == "":
                        country = province_parent_value
                    break
        return country, province, city, county

    def get_loc_dict(self):
        candidate_loc_list = read_jsonl_file(self.candidate_loc_path)
        country_dict = {item["country"]: "" for item in candidate_loc_list if item["country"] != ""}
        province_dict = {item["province"]: item["country"] for item in candidate_loc_list if item["province"] != ""}
        city_dict = {item["city"]: item for item in candidate_loc_list if item["city"] != ""}
        county_dict = {item["county"]: item for item in candidate_loc_list
                       if item["county"] not in ["", "东方", "东风"]}
        return country_dict, province_dict, city_dict, county_dict


if __name__ == "__main__":
    obj = LabelLocByRule()
    obj.process()

# python -m cua.asr.poi_search.analyse.label_loc_by_rule
