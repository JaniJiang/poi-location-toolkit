from cua.plan.sample.merge_sample.extend_data import assistant_query
# 由LLM或手动构造的一些测试样本
start_sample = {
    "Electric_bill": {
        "Check bill": [
            "帮我查一下电费",
            "我想查查现在的电费余额",
            "查下电费还剩多少",
            "查一下家里的电费",
            "电费还有多少钱，帮我看下",
            "我想看看电费用了多少",
            "帮忙查查电费情况",
            "帮我看看国网电费",
            "查询一下当前的电费余额",
            "查电费",
            "我想查下网上国网里的电费",
            "帮我登录一下国网查电费",
            "请查一下家里电费余额",
            "看一下账户里的电费还有多少",
            "现在电费是多少，帮我查下",
            "电费用到多少了，帮我看看",
            "能不能查一下电费余额",
            "帮我查下这个月的电费",
            "我想知道现在电费还剩多少",
            "查一下电费明细"
        ],
        "Pay bill": [
            "我想交电费",
            "帮我缴一下电费",
            "帮我支付一下电费",
            "把电费交了吧",
            "缴一下这个月的电费",
            "帮我在网上国网缴电费",
            "我要缴电费",
            "电费帮我交一下",
            "请代我缴纳电费",
            "交一下家里的电费",
            "我想交50块电费",
            "帮我交70元的电费",
            "帮我充100块电费",
            "把电费缴一下",
            "请帮我交一下电费账单",
            "帮我在线交下电费",
            "缴纳本月的电费",
            "交200元电费给国网",
            "请帮我交下电费费用",
            "我要充值电费"
        ],
    },
    "Phone_bill": {
        "Check bill": [
            "帮我查一下话费还有多少",
            "查查手机话费余额",
            "我想查下话费",
            "帮我查下这个月用了多少钱话费",
            "查一下13898765432这个号码的话费",
            "看看我手机号话费还剩多少",
            "请查询一下当前手机号的话费余额",
            "我爸的手机号还有多少话费，帮我查下",
            "帮我看看18688889999这个号话费还有多少",
            "看看幺三八九八七六五四三二还有话费吗",
            "查查幺八六七七七八八八八八的话费",
            "我想知道手机话费还有多少",
            "帮我看一下话费用了多少",
            "请查一下默认手机号话费",
            "帮我查话费",
            "查话费余额",
            "查当前号码的话费",
            "话费查询一下",
            "帮忙查下手机话费",
            "这个月话费用了多少，帮我看看"
        ],
        "Pay bill": [
            "给我充一下话费",
            "帮我充50块钱话费",
            "给我爸的手机充200元话费",
            "我想充点话费",
            "帮我充话费到18612345678",
            "给当前手机号充100元话费",
            "给13876543210充20块话费",
            "充一百块话费",
            "充个话费，50块",
            "帮我充200元话费到我的号上",
            "给我妈充话费，号码是幺三八六五四三二一零",
            "给幺八六一二三四五六七八充100块话费",
            "充壹佰元话费到默认手机号",
            "帮我在线充话费",
            "我要给手机充点话费",
            "充50元话费到这个号码",
            "帮我充一百块钱到话费里",
            "我要充话费，金额是200",
            "充点话费，差不多100元",
            "给13811112222充个话费，10块也行"
        ],
    },
    "Di Di": {
        "Quick Dial": [
            "一键叫个代驾",
            "我想一键叫代驾",
            "一键下单一个代驾",
            "一键代驾服务",
            "一键帮我叫个代驾",
            "点一下一键代驾",
            "一键呼叫代驾司机",
            "帮我一键下个代驾订单",
            "一键下单请个代驾",
            "我想要一键呼叫代驾",
            "一键发起代驾请求",
            "马上一键叫个代驾",
            "一键帮我安排代驾",
            "一键叫人来开车",
            "我需要一键代驾",
            "帮我一键打个代驾",
            "一键下单叫司机",
            "一键派单叫代驾",
            "呼叫代驾，走一键下单",
            "一键代驾下单请求"
        ],
        "Instant Call": [
            "帮我叫个代驾司机",
            "从这儿给我叫个代驾回家",
            "叫个滴滴代驾送我回公司",
            "帮我找一个代驾",
            "叫个特惠代驾，从现在的位置回家",
            "帮我安排一个代驾回去",
            "叫个代驾从大悦城到机场",
            "请帮我叫一个代驾司机",
            "找个滴滴代驾从公司出发",
            "我要叫个代驾从当前定位到家",
            "叫个代驾从星巴克回住处",
            "帮我从原麦山丘叫个代驾去望京SOHO",
            "找人给我开车回家，叫个代驾",
            "叫个代驾，现在出发去理想汽车总部",
            "我想用滴滴叫个代驾",
            "给我叫个代驾司机，越快越好",
            "帮我叫个特惠代驾，从现在出发到公司",
            "叫一个代驾从这里回家",
            "叫个代驾从这里去地铁站",
            "从当前位置叫个代驾，送我去机场"
        ],
    },
}

user_response = {
    "Confirm login": ["同意", "可以", "好", "没问题", "行", "登录吧", "不同意", "暂时不用", "先不用了", "不需要登录"],
    "Recharge check": ["需要", "充吧", "要的", "继续充", "是的", "不用", "先不用", "暂时不充", "不需要", "先这样吧"],
    "Amount": ["充50", "充五十", "充100", "一百", "先充20", "充二十块", "来个30", "三十元", "充个200", "两百"],
    "Confirm payment": ["确认", "支付", "好的", "可以", "付吧", "没问题", "不确认", "先不付", "等等", "暂时不需要"],
    "Confirm check": ["要查", "查", "好的", "可以", "查余额", "不用查", "先不用", "不查", "暂时不用"],
    "Confirm pay": ["要", "充值", "好的", "可以", "充", "不用", "不充", "先不用", "暂时不充"],
    "phontNumber": [
        "13800138000",
        "一三八零零一三八零零零",
        "13912345678",
        "一三九一二三四五六七八",
        "15012345678",
        "一五零一二三四五六七八",
        "18888888888",
        "一八八八八八八八八八八",
        "13100001111",
        "一三一零零零零一一一一"
    ],
    "captcha": [
        "1234",
        "一二三四",
        "5678",
        "五六七八",
        "4321",
        "四三二一",
        "8765",
        "八七六五",
        "0000",
        "零零零零"
    ],
    "Confirm account/location": ["同意", "可以", "好", "没问题", "行", "授权", "不同意", "不授权", "暂时不", "先不"],
    "Confirm start": [
        "起点是家里",
        "起点地址是学校",
        "从地铁站出发",
        "我在商场附近",
        "起点就是我现在的位置",
        "起点是朋友家",
        "现在的起点是机场",
        "起点是医院附近",
        "帮我设置起点为咖啡店"
    ],
    "Start location": [
        "起点是家里",
        "起点地址是学校",
        "从地铁站出发",
        "我在商场附近",
        "起点就是我现在的位置",
        "起点是朋友家",
        "现在的起点是机场",
        "起点是医院附近",
        "帮我设置起点为咖啡店"
    ],
    "Final location": [
        "终点是家里",
        "我要去公司",
        "终点地址是学校",
        "送我到机场吧",
        "终点是商场",
        "目的地是朋友家",
        "终点改成医院",
        "帮我设置终点为咖啡店",
        "终点是公园"
    ],
    "servertype": ["立即呼叫", "当前勾选", "特惠代驾", "滴滴代驾", "青桔代驾", "星享代驾", "默认", "全部", "全选", "最便宜"],
}

continue_workflow = {
    "Electric_bill": {
        "Check bill": [
            {"assis": assistant_query["Electric_bill"]["Check bill"]
             ["Confirm login"], "user": "Confirm login"},
            {"assis": assistant_query["Electric_bill"]["Share query"]
             ["Link account"], "user": "继续执行小程序"},
            {"assis": assistant_query["Electric_bill"]["Check bill"]
             ["Recharge check"], "user": "Recharge check"},
            {"assis": assistant_query["Electric_bill"]["Share query"]
             ["Amount query"], "user": "Amount"},
            {"assis": assistant_query["Electric_bill"]["Share query"]
             ["Confirm payment"], "user": "Confirm payment"},
        ],
        "Pay bill": [
            {"assis": assistant_query["Electric_bill"]["Share query"]
                    ["Amount query"], "user": "Amount"},
            {"assis": assistant_query["Electric_bill"]["Share query"]
             ["Confirm payment"], "user": "Confirm payment"},
        ],
    },
    "Phone_bill": {
        "Check bill": [
            {"assis": assistant_query["Phone_bill"]["Check bill"]
             ["Confirm check"], "user": "Confirm check"},
            {"assis": assistant_query["Phone_bill"]["Check bill"]
             ["Number query"], "user": "phontNumber"},
            {"assis": assistant_query["Phone_bill"]["Check bill"]
             ["Captcha query"], "user": "captcha"},
        ],
        "Pay bill": [
            {"assis": assistant_query["Phone_bill"]["Pay bill"]
                    ["Confirm pay"], "user": "Confirm pay"},
            {"assis": assistant_query["Phone_bill"]["Pay bill"]
             ["Number query"], "user": "phontNumber"},
            {"assis": assistant_query["Phone_bill"]["Pay bill"]
             ["Amount query"], "user": "Amount"},
            {"assis": assistant_query["Phone_bill"]["Pay bill"]
             ["Confirm payment"], "user": "Confirm payment"},
        ],
    },
    "Di Di": {
        "Quick Dial": [
            {"assis": assistant_query["designated_driver"]["Share query"]
             ["Confirm payment"], "user": "Confirm payment"},
        ],
        "Instant Call": [
            {"assis": assistant_query["designated_driver"]["Share query"]
             ["Account aggrement"], "user": "Confirm account/location"},
            {"assis": assistant_query["designated_driver"]["Share query"]
             ["Location aggrement"], "user": "Confirm account/location"},
            {"assis": assistant_query["designated_driver"]["Instant Call"]
             ["Destination check"], "user": "Confirm start"},
            {"assis": assistant_query["designated_driver"]["Instant Call"]
             ["Start location"], "user": "Start location"},
            {"assis": assistant_query["designated_driver"]["Instant Call"]
             ["Final location"], "user": "Final location"},
            {"assis": assistant_query["designated_driver"]["Instant Call"]
             ["Final location_2"], "user": "Final location"},
            {"assis": assistant_query["designated_driver"]["Instant Call"]
             ["Designated type"], "user": "servertype"},
            {"assis": assistant_query["designated_driver"]["Share query"]
             ["Confirm payment"], "user": "Confirm payment"},
        ],
    }
}
