import os
import re
import csv
import threading
import pandas as pd
from tqdm import tqdm
from loguru import logger
from joblib import Parallel, delayed
from utils.file_utils import check_output_path
from utils.llm_utils.openai_style_api import OpenAIStyleAPI
from cua.plan.sample.meta import *
from cua.plan.sample.prompt import *
from cua.plan.eval.calculate_metrics import CalculateMetrics
from cua.plan.sample.merge_sample.reduce_sample import ReduceSample

API_DICT = {
    "lpai_qwen2": {
        "model": "cua-plan",
        # "url": "https://lpai-inference-miyun.inner.chj.cloud/inference/ss-sai/cua-plan-a1ff-apypor/v1/completions",
        "url": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/cua-plan-a1ff-apypor/v1/completions",
    },
    "lpai_qwen3": {
        "model": "cua-scene-plan",
        # "url": "https://lpai-inference-miyun.inner.chj.cloud/inference/ss-sai/cua-scene-plan-9c42-czpgnu/v1/completions",
        "url": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/cua-scene-plan-9c42-czpgnu/v1/completions",
    },
    "testtwo": {
        "model": "cua-scene-plan-qwen2.5-1.5b-vehicle",
        "url": "http://cua-scene-plan-qwen2d5-1d5b-vllm-vehicle-ssai-http.ssai-apis-staging.chj.cloud:80/v1/completions",
    },
    "my_model": {
        "model": "cua-plan-qwen2",
        "url": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/cua-plan-qwen2-fd46-rjkmyo/v1/completions",
    },
    "my_model_qwen3": {
        "model": "cua-plan-qwen3",
        "url": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/cua-plan-qwen3-5053-eclkce/v1/chat/completions",
}


class EvalSample(ReduceSample):

    def __init__(self, env, stop):
        # 评估数据集放在data/cloud_share/cua/plan/sample/eval目录下，并处理成统一格式
        self.human_dataset_name_list = ["dev_easy", "dev_middle", "dev_hard", "dev_ota7", "test_must", "test_log"]
        self.log_dataset_name_list = ["test_log_0512", "test_log_0513", "test_log_0514"]
        self.dataset_name_list = self.human_dataset_name_list + self.log_dataset_name_list
        self.dataset_version = "V3"
        # 支持的槽位列表
        self.slot_name_list = ["appName", "taskType"]
        # 推理接口参数
        self.env = env
        self.model, self.url = API_DICT[env]["model"], API_DICT[env]["url"]
        self.api_obj = OpenAIStyleAPI(self.url)
        self.stop = stop
        # 设置并发控制参数
        self.n_jobs = 20  # 并发度
        self.file_lock = threading.Lock()  # 文件锁
        # 是否简化对话
        self.need_reduce_dialog = False

    def process(self, env=None):
        if env == "my_model_qwen3":
            eval_version = QWEN3_EVAL_VERSION
        else:
            eval_version = EVAL_VERSION
        for dataset_name in tqdm(self.dataset_name_list, total=(len(self.dataset_name_list))):
            if "log_" in dataset_name:
                input_path = f"{SAMPLE_DIR}/eval/log_processed/{dataset_name}.tsv"
            else:
                input_path = f"{SAMPLE_DIR}/eval/{self.dataset_version}/{dataset_name}.tsv"
            output_path = f"{EVAL_DIR}/{eval_version}/{dataset_name}.{self.env}.tsv"
            check_output_path(output_path)  # 校验输出路径
            # 读取输入数据
            sample_df = pd.read_csv(input_path, sep="\t")
            # 并发处理
            Parallel(n_jobs=self.n_jobs, prefer="threads")(
                delayed(self.process_sample_one)(output_path, sample_row)
                for _, sample_row in tqdm(sample_df.iterrows(), total=len(sample_df))
            )

    def process_sample_one(self, output_path, sample_row):
        dialog, tool_real, arguments_real, scene_name, app_name = sample_row[
            "对话"], sample_row["工具"], sample_row["参数"], sample_row["场景"], sample_row["小程序"]
        if self.need_reduce_dialog is True:
            dialog = self.process_reduce_dialog(dialog)
        instruction = dialog2prompt(dialog)
        if instruction == "" or tool_real == "":
            return
        try:
            arguments_real_dict = json.loads(arguments_real)
        except Exception as e:
            logger.warning("[arguments_real]" + str(e))
            logger.warning("[arguments_real]" + arguments_real)
            return
        # 请求推理接口
        pred_str = self.api_obj.v1_completions(self.model, instruction.rstrip("\n") + "\n", stop=self.stop)
        parse_flag, pred_dict = self.parse_pred_str(pred_str)
        # 计算是否工具、槽位和改写Query正确
        tool_pred, tool_acc, slot_acc, query_acc = "", "", "", ""
        if parse_flag is True:
            tool_pred, tool_acc, slot_acc, query_acc = self.calculate_acc(tool_real, arguments_real_dict, pred_dict)
        # 格式化结果
        result_list = [{
            "对话": dialog,
            "工具": tool_real,
            "参数": arguments_real,
            "场景": scene_name,
            "小程序": app_name,
            "工具-预测": tool_pred,
            "工具是否正确": tool_acc,
            "槽位是否正确": slot_acc,
            "改写是否正确": query_acc,
            "预测结果": json.dumps(pred_dict, ensure_ascii=False, indent=4),
            "原始预测结果": pred_str,
        }]
        # 保存处理结果
        self.save_result(output_path, result_list)

    def process_reduce_dialog(self, dialog):
        conversations = dialog2conversations(dialog)
        reduced_conversations = self.process_reduce_conversations(conversations)
        reduced_dialog = conversations2dialog(reduced_conversations)
        return reduced_dialog

    def parse_pred_str(self, pred_str):
        match = re.search(r'```function_call\s*\n(.*?)```', pred_str, flags=re.DOTALL)
        if not match:
            return False, {}
        json_part = match.group(1)
        try:
            data = json.loads(json_part)
            if isinstance(data, list) and len(data) == 1:
                return True, data[0]
            else:
                return False, {}
        except Exception as e:
            logger.warning("[EvalSample]" + str(e))
            logger.warning("[EvalSample]" + pred_str)
            return False, {}

    def calculate_acc(self, tool_real, arguments_real, pred_dict):
        # 判断工具是否正确
        tool_pred = pred_dict.get("name", "")
        tool_acc = "1" if tool_real == tool_pred else "0"
        # 判断槽位是否正确
        arguments_pred = pred_dict.get("arguments", {})
        slots_real = {k: arguments_real[k] for k in sorted(arguments_real.keys())
                      if k in self.slot_name_list}
        slots_pred = {k: arguments_pred[k] for k in sorted(arguments_pred.keys())
                      if k in self.slot_name_list}
        slot_acc = "1" if slots_real == slots_pred else "0"
        # 判断改写Query是否正确
        query_acc = "1" if arguments_real.get("query", "") == arguments_pred.get("query", "") else "0"
        return tool_pred, tool_acc, slot_acc, query_acc

    def save_result(self, output_path, result_list):
        with self.file_lock:
            fieldnames = result_list[0].keys()
            file_exists = os.path.isfile(output_path) and os.path.getsize(output_path) > 0
            with open(output_path, "a", encoding="utf-8", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter="\t")
                if not file_exists:
                    writer.writeheader()
                writer.writerows(result_list)


if __name__ == "__main__":
    env = "testtwo"  # testtwo | lpai_qwen3 | my_model
    stop = "[unused1]"  # [unused1] | <|im_end|>
    # 模型推理
    eval_sample_obj = EvalSample(env, stop)
    eval_sample_obj.process()
    # 指标计算
    calculate_metrics_obj = CalculateMetrics()
    calculate_metrics_obj.process(env)

# python -m cua.plan.eval.eval_sample
