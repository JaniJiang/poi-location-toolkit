import os
import pandas as pd
from cua.plan.sample.meta import *


class CalculateMetrics:

    def __init__(self):
        self.env_list = ["lpai_qwen2", "lpai_qwen3", "testtwo", "my_model",
                         "my_model_qwen3", "my_model_lora", "my_model_local"]
        self.dataset_name_list = ["dev_easy", "dev_middle", "dev_hard", "dev_ota7", "test_must", "test_log_merged", "test_new_app",
                                  "test_log", "test_log_0622", "test_log_0623", "test_log_0624", "test_living_Di"]

    def process(self, env=None):
        if env not in ["testtwo", "my_model"]:
            eval_version = QWEN3_EVAL_VERSION
        else:
            eval_version = EVAL_VERSION
        output_path = f"{EVAL_DIR}/{eval_version}/calculate_metrics.tsv"
        with open(output_path, "w") as f:
            if env in ["testtwo", "my_model"]:
                f.write("\t".join([
                    "env", "dataset_name", "total_count",
                    "tool_correct_count", "tool_acc",
                    "slot_correct_count", "slot_acc",
                    "query_correct_count", "query_acc",
                ]) + "\n")
            else:
                f.write("\t".join([
                    "env", "dataset_name", "total_count",
                    "tool_correct_count", "tool_acc",
                ]) + "\n")
            for env in self.env_list:
                for dataset_name in self.dataset_name_list:
                    input_path = f"{EVAL_DIR}/{eval_version}/{dataset_name}.{env}.tsv"
                    if os.path.exists(input_path) is False:
                        continue
                    input_df = pd.read_csv(input_path, sep="\t")
                    total_count = len(input_df)
                    # 计算工具ACC
                    tool_correct_count = (input_df["工具是否正确"] == 1).sum()
                    tool_acc = "{:.2%}".format(tool_correct_count / total_count)
                    if env in ["testtwo", "my_model"]:
                        # 计算槽位ACC
                        slot_correct_count = (input_df["槽位是否正确"] == 1).sum()
                        slot_acc = "{:.2%}".format(slot_correct_count / total_count)
                        # 计算Query改写ACC
                        query_correct_count = (input_df["改写是否正确"] == 1).sum()
                        query_acc = "{:.2%}".format(query_correct_count / total_count)
                        # 输出指标
                        output_line = "\t".join([
                            env, dataset_name, str(total_count),
                            str(tool_correct_count), tool_acc,
                            str(slot_correct_count), slot_acc,
                            str(query_correct_count), query_acc,
                        ])
                    else:
                        # 输出指标
                        output_line = "\t".join([
                            env, dataset_name, str(total_count),
                            str(tool_correct_count), tool_acc,
                        ])
                    f.write(output_line + "\n")
                    # TODO: 评估不同场景的效果
                    # TODO: 评估不同小程序的效果


if __name__ == "__main__":
    obj = CalculateMetrics()
    obj.process(env="my_model")

# python -m cua.plan.eval.calculate_metrics
