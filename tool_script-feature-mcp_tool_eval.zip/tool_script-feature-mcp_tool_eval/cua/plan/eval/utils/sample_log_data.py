import pandas as pd
import random
import os
from loguru import logger
from utils.file_utils import check_output_path
from cua.plan.sample.meta import *


class LogDataSampler:
    """
    对于日志自测集去重并随机抽样。
    """

    def __init__(self, filenames, sample_num):
        self.sample_num = sample_num
        self.merged_samples_file_path = f"{SAMPLE_DIR}/qwen3_processed/{QWEN3_SAMPLE_VERSION}/merged_samples.tsv"
        self.tsv_file_paths = [f"{SAMPLE_DIR}/eval/log_processed/{filename}.tsv" for filename in filenames]
        self.output_path = f"{SAMPLE_DIR}/eval/log_processed/test_log_deduped_{sample_num}.tsv"
        check_output_path(self.output_path)
        self.dialog_data_for_dedup = set()  # 用于存储去重依据的“对话样本”数据
        self._load_merged_samples_data()

    def _load_merged_samples_data(self):
        """
        加载并保存merged_samples.tsv文件中“对话样本”列的数据。
        """
        try:
            df_merge = pd.read_csv(self.merged_samples_file_path, sep='\t')
            self.dialog_data_for_dedup = set(df_merge["对话样本"].dropna().astype(str))
        except Exception as e:
            logger.info(f"读取 merged_samples.tsv 文件时发生错误: {e}")

    def process(self, dedup_column: str = "对话"):
        """
        从给定的TSV文件列表中读取数据，进行去重，并随机抽取n条数据。

        Args:
            dedup_column (str): 用于去重的列名，默认为"对话"。
        """
        all_data = []
        processed_dialogs = set(self.dialog_data_for_dedup)

        for file_path in self.tsv_file_paths:
            if not os.path.exists(file_path):
                logger.info(f"警告: 文件未找到，已跳过: {file_path}")
                continue
            try:
                df = pd.read_csv(file_path, sep='\t')
                initial_rows = len(df)
                logger.info(f"成功读取文件: {file_path}, 原始行数: {initial_rows}")
                # 对当前文件进行去重处理
                unique_rows_from_current_file = []
                for _, row in df.iterrows():
                    dialog = str(row[dedup_column])
                    if dialog not in processed_dialogs:
                        unique_rows_from_current_file.append(row)
                        processed_dialogs.add(dialog)

                df_deduplicated_current = pd.DataFrame(unique_rows_from_current_file, columns=df.columns)
                all_data.append(df_deduplicated_current)
                logger.info(f"文件 {file_path} 去重后新增 {len(df_deduplicated_current)} 条数据。")
            except Exception as e:
                logger.info(f"读取或处理文件 {file_path} 时发生错误: {e}")

        # 合并所有文件的去重数据
        if not all_data:
            logger.info("没有可处理的数据。")
        final_df = pd.concat(all_data, ignore_index=True)
        logger.info(f"\n所有文件合并去重后总数据量: {len(final_df)} 条。")
        # 随机抽取n条数据
        if len(final_df) > self.sample_num:
            sampled_df = final_df.sample(n=self.sample_num, random_state=42)
            logger.info(f"已随机抽取 {self.sample_num} 条数据。")
        else:
            sampled_df = final_df
            logger.info(f"数据总量 ({len(final_df)}) 小于或等于请求的样本数 ({self.sample_num})，返回所有去重后的数据。")
        sampled_df.to_csv(self.output_path, sep="\t", index=False)

if __name__ == "__main__":
    # "test_log_0513", "test_log_0514", "test_log_0525-28", "test_log_0529", "test_log_0605-09"
    input_list = ["test_log_0513", "test_log_0514", "test_log_0525-28", "test_log_0529", "test_log_0605-09"]
    sample_num = 1000
    obj = LogDataSampler(input_list, sample_num)
    obj.process()

# python -m cua.plan.eval.utils.sample_log_data