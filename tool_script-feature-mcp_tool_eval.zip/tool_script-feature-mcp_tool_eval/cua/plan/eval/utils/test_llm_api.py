import json
from utils.llm_utils.openai_style_api import OpenAIStyleAPI
from cua.plan.eval.eval_sample import API_DICT
from cua.plan.sample.prompt import build_prompt


def transform_dialog_to_session(dialog):
    dialog_list = dialog.strip().split("\n")
    formatted_dialog = []
    for line in dialog_list:
        line = line.strip()
        if line.startswith("user: "):
            role = "user"
            content = line[len("user: "):].strip()
        elif line.startswith("assistant: "):
            role = "assistant"
            content = line[len("assistant: "):].strip()
        formatted_dialog.append({"role": role, "content": content})
    return formatted_dialog


def test_cua_plan_model(env, stop):
    model, url = API_DICT[env]["model"], API_DICT[env]["url"]
    api_obj = OpenAIStyleAPI(url)

    prompt, _ = build_prompt([
        {"role": "user", "content": "帮我点杯咖啡"},
        {"role": "assistant", "content": "选择哪家门店"},
        {"role": "user", "content": "理想汽车总部门店"},
        {"role": "assistant", "content": "已为你选择好理想汽车总部门店，你要大杯中杯还是超大杯？什么温度？"},
        {"role": "user", "content": "大杯，冰的"}
    ])
    print("\n", prompt, api_obj.v1_completions(model, prompt, stop=stop))

    prompt, _ = build_prompt([
        {"role": "user", "content": "帮我点杯咖啡"},
        {"role": "assistant", "content": "选择哪家门店"},
        {"role": "user", "content": "我的星巴克订单到哪儿了"},
    ])
    print("\n", prompt, api_obj.v1_completions(model, prompt, stop=stop))

    prompt, _ = build_prompt([
        {"role": "user", "content": "帮我点杯咖啡"},
        {"role": "assistant", "content": "选择哪家门店"},
        {"role": "user", "content": "南京大学是所怎样的学校"}
    ])
    print("\n", prompt, api_obj.v1_completions(model, prompt, stop=stop))

    prompt, _ = build_prompt([
        {"role": "user", "content": "帮我点杯咖啡"},
        {"role": "assistant", "content": "自取还是外送"},
        {"role": "user", "content": "自取有什么优惠"}
    ])
    print("\n", prompt, api_obj.v1_completions(model, prompt, stop=stop))

    prompt, _ = build_prompt([
        {"role": "user", "content": "帮我点杯热拿铁，自取，送到家里"},
        {"role": "assistant", "content": "我已经帮你点好啦，想让我帮你下单的话，请说立即支付哦"},
        {"role": "user", "content": "立即支付、支付"},
    ])
    print("\n", prompt, api_obj.v1_completions(model, prompt, stop=stop))

    dialog = """user：帮我用捷停车，叫一下停车费。
user：帮我用捷停车，叫一下停车费。"""
    formatted_dialog = transform_dialog_to_session(dialog)
    prompt, _ = build_prompt(formatted_dialog)
    print("\n", prompt, api_obj.v1_completions(model, prompt, stop=stop))


if __name__ == "__main__":
    env = "lpai_qwen2"  # lpai_qwen2 | lpai_qwen3 | testtwo
    stop = "[unused1]"  # [unused1] | <|im_end|>
    test_cua_plan_model(env, stop)

# python -m cua.plan.eval.utils.test_llm_api
