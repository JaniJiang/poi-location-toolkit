import json
import csv
from cua.plan.sample.meta import *


class TestProcess:
    def __init__(self, input_file_path: str, output_file_path: str):
        self.input = input_file_path
        self.output = output_file_path

    def process(self):
        output_data = []
        with open(self.input, 'r', encoding='utf-8') as infile:
            reader = csv.DictReader(infile, delimiter='\t')
            for row in reader:
                # 1. 处理对话列
                dialogue_text = ""
                if row.get('上文'):
                    context_list = json.loads(row['上文'])
                    for item in context_list:
                        dialogue_text += f"user: {item.get('user', '')}\nassistant: {item.get('assistant', '')}\n"
                query_text = row.get('Query', '')
                if query_text:
                    dialogue_text += f"user: {query_text}"
                # 2. 处理工具列
                action_text = f"cu_agent_{row.get('LiAction', '')}"
                # 3. 处理参数列
                params = {}
                if row.get('LiAction') == 'start' and row.get('LiSlot'):
                    try:
                        slot_data = json.loads(row['LiSlot'])
                        appname = slot_data.get('appName', '')
                        tasktype = slot_data.get('taskType', '')
                        query = query_text
                        if appname and tasktype:
                            params = {
                                'appName': appname,
                                'taskType': tasktype,
                                'query': query
                            }
                        elif appname:
                            params = {
                                'appName': appname,
                                'query': query
                            }
                        else:
                            params = {
                                'taskType': tasktype,
                                'query': query
                            }
                    except json.JSONDecodeError:
                        print(f"Warning: Failed to parse 'LiSlot' data in row: {row}. Skipping params part.")

                output_data.append({
                    '对话': dialogue_text,
                    '工具': action_text,
                    '参数': json.dumps(params, ensure_ascii=False),
                    '场景': "NONE",
                    '小程序': "NONE",
                })

        # 写入新的 TSV 文件
        if output_data:
            with open(self.output, 'w', encoding='utf-8', newline='') as outfile:
                fieldnames = ['对话', '工具', '参数', '场景', '小程序']
                writer = csv.DictWriter(outfile, fieldnames=fieldnames, delimiter='\t')
                writer.writeheader()
                writer.writerows(output_data)

        print(f"转换完成！文件已保存到：{self.output}")


# 示例调用
if __name__ == "__main__":
    share_dir = f"{SAMPLE_DIR}/eval"
    input_path = f"{share_dir}/8.0/test_data.tsv"
    output_path = f"{share_dir}/V3/test_ota8.tsv"
    obj = TestProcess(input_path, output_path)
    obj.process()

# python -m cua.plan.eval.utils.process_8_0_test
