import pandas as pd
from tqdm import tqdm
from cua.plan.sample.meta import *
from cua.plan.sample.prompt import *


class TestMustDataProcessV2:

    def __init__(self, input_path, output_path):
        self.input_path = input_path
        self.output_path = output_path

    def process(self):
        input_df = pd.read_csv(self.input_path, sep="\t")
        output_list = []
        for _, row in tqdm(input_df.iterrows(), total=len(input_df)):
            context = row["上文"]
            if pd.isna(context):
                continue
            conversation_list = []
            context_list = json.loads(context)
            for context_one in context_list:
                if "user" in context_one:
                    content = context_one["user"].replace("\n", "，")
                    conversation_list.append({"role": "user", "content": content})
                if "assistant" in context_one:
                    content = context_one["assistant"].replace("\n", "，")
                    conversation_list.append({"role": "assistant", "content": content})
            conversation_list.append({"role": "user", "content": row["Query"]})
            if len(conversation_list) > 0:
                prompt, _ = build_prompt(conversation_list)
                dialog = prompt2dialog(prompt)
                output_list.append({"对话": dialog, "工具": TOOL_NAME_CU_AGENT_CONTINUE,
                                    "参数": "{}", "场景": "NONE", "小程序": row["业务类型"]})
        # 保存结果到文件
        output_df = pd.DataFrame(output_list)
        output_df.to_csv(self.output_path, sep="\t", index=False, header=True)


if __name__ == "__main__":
    input_path = f"{SAMPLE_DIR}/eval/source/test_must.v2.tsv"
    dataset_version = "V3"
    output_path = f"{SAMPLE_DIR}/eval/{dataset_version}/test_must.tsv"
    obj = TestMustDataProcessV2(input_path, output_path)
    obj.process()

# python -m cua.plan.eval.utils.test_must_data_process_v2
