import csv
import json
import os
import re
from tqdm import tqdm
from loguru import logger
import random
import threading
from cua.plan.sample.meta import *
from cua.plan.sample.prompt import *
from cua.plan.sample.scene import SCENE_LIST
from joblib import Parallel, delayed
import pandas as pd
from utils.llm_utils.openai_style_api import OpenAIStyleAPI
from utils.file_utils import check_output_path

API_DICT = {
    "gpt-4o": {
        "model": "gpt-4o",
        "url": "https://xuzhou1-tool-llm.ontest.fc.chj.cloud/gpt-4o",
    },
    'qwen-32b': {
        "model": "deepseek-r1-distill-qwen-32b",
        "url": "https://xuzhou1-tool-llm.ontest.fc.chj.cloud/deepseek-r1-distill-qwen-32b"
    },
    'deepseek-v3': {
        "model": "deepseek-v3",
        "url": "https://xuzhou1-tool-llm.ontest.fc.chj.cloud/deepseek-v3"
    },
    "qwen-1.8b": {
        "model": "qwen__qwen1_5-1_8b",
        "url": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/qwen--qwen1-5-1-8b-a411-cvvieg/v1/completions"
    }
}


class CUALogProcess:
    def __init__(self, model_name):
        self.n_jobs = 3
        self.file_lock = threading.Lock()
        self.model, self.url = API_DICT[model_name]["model"], API_DICT[model_name]["url"]
        self.api_obj = OpenAIStyleAPI(self.url)
        self.system_prompt = """你是一个专业的文本分类模型，需要根据用户在车载小程序环境下的对话历史和最新话语，准确判断用户意图，并将其归类到以下八个类别之一。请严格遵守分类定义和分类优先级，输出标准化的 JSON 结果。
        <任务输入>
        你将接收到以下两个字段的输入：
        "对话历史": 过去对话历史(字符串形式,从旧到新)
        "最新话语": 用户的最新话语(字符串)
        <输出要求>
        请仅输出如下格式的 JSON：
        {"tool_label": "分类标签","analyse":分类理由}
        [任务描述占位符]
        <补充说明>
        - “啡快”、“专星送” 是星巴克配送方式
        - 霸王茶姬是一家以传统文化为特色的奶茶店，其奶茶名称通常非常独特，很多名字取自古诗词、成语或文学作品，如“伯牙绝弦”、“木兰辞”等。这些名字虽然听起来像文学用语，但在对话中它们常常是对奶茶选择的直接回答。
        """
        self.system_prompt = fill_template_with_label_defnition(
            self.system_prompt, Label_definition, task="log_process")
        self.user_prompt = Qwen3_Prompt["input"]

    def process(self, input_path, output_path, date_need_process=None):
        """
        转化日志为自测集格式

        """
        data_need_process = []
        with open(input_path, 'r', encoding='utf-8') as infile:
            csv_reader = csv.DictReader(infile, delimiter='\t')
            # 初始化已处理的对话集合
            seen_dialogues = set()
            for row in csv_reader:
                if "时间" in row:
                    date = row.get("时间", "")
                    if date not in date_need_process:
                        continue
                # 0512/log数据有slots字段,0513至往后无slots字段
                if "上文" in row:
                    shangwen = row.get("上文", "")
                elif "上文session" in row:
                    shangwen = row.get("上文session", "")
                # 去除异常值
                if shangwen == "":
                    continue
                current_query = row.get("当前query", "")
                # 去重检查
                current_session = shangwen + "|||" + current_query
                if current_session in seen_dialogues:
                    continue
                seen_dialogues.add(current_session)
                # 获取上文列表
                context_list = json.loads(shangwen)
                # 跳过首轮项(上文为空列表)
                if context_list == []:
                    continue
                data_need_process.append(row)
        current_data_num = len(data_need_process)
        sample_num = int(input(f"请输入想要抽样的数据量,原始数据量为{current_data_num}:"))
        data_need_process = random.sample(data_need_process, sample_num)
        # 并发处理
        check_output_path(output_path)
        Parallel(n_jobs=self.n_jobs, prefer="threads")(
            delayed(self.process_sample_one)(output_path, sample_row)
            for sample_row in tqdm(data_need_process, total=len(data_need_process))
        )
        print(f"日志数据 '{input_path}' 已成功转换为 '{output_path}'自测集")

    def test_badcase(self, input_path, output_path):
        df = pd.read_csv(input_path, sep='\t')
        df["LLM预测"] = df["对话"].apply(self.assign_tool_label_based_on_llm)
        df.to_csv(output_path, sep='\t', index=False)
        print(f"文件处理完成！结果已保存到：{output_path}")

    def process_sample_one(self, output_path, row):
        # 0512/log数据有slots字段,0513至往后无slots字段
        if "上文" in row:
            shangwen = row.get("上文", "")
        elif "上文session" in row:
            shangwen = row.get("上文session", "")
        context_list = json.loads(shangwen)
        current_query = row.get("当前query", "")
        appname = row.get("APPNAME", "")
        # 0512/log数据有slots字段,0513至往后无slots字段
        if "slots" in row:
            slots = row.get("slots", "")
        else:
            slots = "{}"

        # 对assistant连续对话的异常样本处理
        cleaned_list = []
        previous_role = None
        for current_item in context_list:
            current_role = current_item['role']
            if current_role == "assistant" and previous_role == "assistant":
                continue
            else:
                cleaned_list.append(current_item)
            previous_role = current_role
        tool_label = None
        params_label = "{}"
        history = cleaned_list.copy()
        cleaned_list.append({"role": "user", "content": current_query})
        dialog_str, _ = build_prompt(cleaned_list)
        dialog = prompt2dialog(dialog_str)
        # 设定工具标签
        answer = self.assign_tool_label_based_on_llm(dialog)
        if answer == None:
            return
        tool_label = answer["tool_label"]
        analyse = answer["analyse"]
        # 设定参数标签
        if slots != "" and slots != "不测":
            params_label = slots
        else:
            params_label = "{}"
        result_list = [{"对话": dialog, "工具": tool_label,
                        "参数": params_label, "场景": "NONE", "小程序": appname, "analyse": analyse}]
        self.save_result(output_path, result_list)

    def save_result(self, output_path, result_list):
        with self.file_lock:
            fieldnames = result_list[0].keys()
            file_exists = os.path.isfile(output_path) and os.path.getsize(output_path) > 0
            with open(output_path, "a", encoding="utf-8", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter="\t")
                if not file_exists:
                    writer.writeheader()
                writer.writerows(result_list)

    def assign_tool_label_based_on_llm(self, session):
        new_session = re.sub(r'user:( [^\n]*)$', r'最新话语:\1', session)
        model_answer = self.call_llm(new_session)
        if model_answer is None:
            return None
        answer_parsed = self.parse_answer(model_answer)
        return answer_parsed

    def call_llm(self, session):
        delimiter = "最新话语:"
        split_point = session.find(delimiter)
        history = session[:split_point].strip()
        user_latest = session[split_point:].strip()
        prompt = [
            {
                "role": "system", "content": self.system_prompt.strip()
            },
            {
                "role": "user", "content": self.user_prompt.strip().format(history=history, user_latest=user_latest)}
        ]
        answer = self.api_obj.v1_chat_completions(self.model, prompt)
        return answer

    def parse_answer(self, model_answer):
        try:
            data = json.loads(model_answer)
        except Exception as e:
            try:
                data = json.loads(model_answer.strip().strip(
                    '`').replace("json", '').replace("\n", ""))
            except Exception as e:
                logger.warning("[Answer]" + str(e))
                logger.warning("[Answer]" + model_answer)
                return None
        return data


# --- 使用示例 ---
if __name__ == "__main__":
    share_dir = "data/cloud_share/cua/plan/sample/eval"
    myself_dir = "data/cloud/cua/plan/sample/eval"
    dataset_version = 'V3'
    # gpt-4o,qwen-32b,deepseek-v3
    model_name = 'deepseek-v3'
    obj = CUALogProcess(model_name)
    # Badcase测试
    # obj.test_badcase(f"{share_dir}/log_source/badcase_test.tsv", f"{share_dir}/log_processed/badcase_test.tsv")
    # # "test_log_0609"
    need_process_list = ["test_log_0609"]
    input_list = [f"{share_dir}/log_source/{item}.tsv" for item in need_process_list]
    output_list = [f"{share_dir}/log_processed/{item}.tsv" for item in need_process_list]
    # 执行转换
    for index in range(len(input_list)):
        obj.process(input_list[index], output_list[index], date_need_process=["20250609"])

# python -m cua.plan.eval.utils.log_data_process
