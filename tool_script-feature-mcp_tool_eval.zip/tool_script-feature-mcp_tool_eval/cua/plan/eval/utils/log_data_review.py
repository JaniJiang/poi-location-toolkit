import csv
import pandas as pd
from utils.file_utils import check_output_path


class CUALogReview:
    def process(self, input_path, output_path):
        """
        指定Review LLM预测日志工具label常出错的类型
        """
        new_data = []
        fieldnames = []
        with open(input_path, 'r', encoding='utf-8') as infile:
            csv_reader = csv.DictReader(infile, delimiter='\t')
            fieldnames = csv_reader.fieldnames
            fieldnames.append("是否需要review")
            for idx, row in enumerate(csv_reader):
                dialog = row.get("对话", "")
                LLM_label = row.get("工具", "")
                row["是否需要review"] = 0
                if self.check_if_need_review(dialog, LLM_label):
                    row["是否需要review"] = 1
                new_data.append(row)
        with open(output_path, 'w', encoding='utf-8', newline='') as outfile:
            csv_writer = csv.DictWriter(
                outfile, fieldnames=fieldnames, delimiter='\t')
            csv_writer.writeheader()  # 写入表头
            csv_writer.writerows(new_data)  # 写入所有行
            print(f"\n所有数据已处理完毕，并保存到 '{output_path}'")

    def check_if_need_review(self, dialog, LLM_label):
        """
        检查对话是否需要review
        """
        last_assistant_content, last_user_content = self.get_last_content(
            dialog)
        if not last_assistant_content:
            if LLM_label == "cu_agent_continue":
                return True
        else:
            if any(keyword in last_user_content for keyword in ["继续", "点", "下单"]) and not any(keyword in last_user_content for keyword in ["杯", "甜", "糖"]):
                if LLM_label == "cu_agent_continue":
                    return True
        return False

    def get_last_content(self, dialog):
        """
        获取user和assistant最新的内容
        """
        lines = dialog.strip().split('\n')
        # 找到最后一个 assistant 和 user 的内容
        last_assistant_content = ""
        last_user_content = ""
        # 从后往前遍历
        for i in range(len(lines) - 1, -1, -1):
            line = lines[i]
            if line.startswith("assistant: ") and not last_assistant_content:
                last_assistant_content = line.replace(
                    "assistant: ", "").strip()
            elif line.startswith("user: ") and not last_user_content:
                last_user_content = line.replace("user: ", "").strip()
            # 如果两者都找到了，就停止遍历
            if last_assistant_content and last_user_content:
                break
        return last_assistant_content, last_user_content


# --- 使用示例 ---
if __name__ == "__main__":
    sample_dir = "data/cloud_share/cua/plan/sample/eval"
    obj = CUALogReview()
    # "test_log_0512.tsv","test_log_0513.tsv","test_log_0514.tsv", "test_log_0525-28"
    need_process_list = ["test_log_0529_llm"]
    input_list = [
        f"{sample_dir}/log_processed/{item}.tsv" for item in need_process_list]
    output_list = [
        f"{sample_dir}/log_processed/{item}_need_review.tsv" for item in need_process_list]
    for index in range(len(input_list)):
        obj.process(input_list[index], output_list[index])
# python -m cua.plan.eval.utils.log_data_review
