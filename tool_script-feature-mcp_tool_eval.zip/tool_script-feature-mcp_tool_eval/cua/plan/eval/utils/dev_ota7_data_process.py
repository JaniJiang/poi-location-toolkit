import json
import pandas as pd
from tqdm import tqdm
from cua.plan.sample.meta import *
from cua.plan.sample.prompt import *


class DevOta7DataProcess:

    def __init__(self, input_path, output_path):
        self.input_path = input_path
        self.output_path = output_path

    def process(self):
        input_df = pd.read_csv(self.input_path, sep="\t")
        # 按照字段分组
        grouped = input_df.groupby("OrderNo")
        # 遍历每个分组
        output_list = []
        for group_name, group_df in tqdm(grouped, total=len(grouped)):
            if len(group_df) <= 1:  # 时间紧张，首轮不在主线范围内，先不放在评估集里面了
                continue
            group_conversation_list = []
            is_legal = True
            for _, row in group_df.iterrows():
                pos = row["GroupId"]
                context = row["上文"]
                if pos > 1 and pd.isna(context):
                    is_legal = False
                    break
                conversation_list = []
                if pos == 1:
                    continue
                    # 时间紧张，首轮不在主线范围内，先不放在评估集里面了
                    # conversation_list.append({"role": "user", "content": row["Query"]})  # TODO: 处理参数
                else:
                    context_list = json.loads(context)
                    for context_one in context_list:
                        if "user" in context_one:
                            content = context_one["user"].replace("\n", "，")
                            conversation_list.append({"role": "user", "content": content})
                        if "assistant" in context_one:
                            content = context_one["assistant"].replace("\n", "，")
                            conversation_list.append({"role": "assistant", "content": content})
                    conversation_list.append({"role": "user", "content": row["Query"]})
                if len(conversation_list) > 0:
                    group_conversation_list.append(conversation_list)
            if is_legal is False:
                continue
            for conversation_list in group_conversation_list:
                prompt, _ = build_prompt(conversation_list)
                dialog = prompt2dialog(prompt)
                output_list.append({"对话": dialog, "工具": TOOL_NAME_CU_AGENT_CONTINUE,
                                   "参数": "{}", "场景": "NONE", "小程序": "NONE"})
        # 保存结果到文件
        output_df = pd.DataFrame(output_list)
        output_df.to_csv(self.output_path, sep="\t", index=False, header=True)


if __name__ == "__main__":
    input_path = f"{SAMPLE_DIR}/eval/source/dev_ota7.tsv"
    dataset_version = "V3"
    output_path = f"{SAMPLE_DIR}/eval/{dataset_version}/dev_ota7.tsv"
    obj = DevOta7DataProcess(input_path, output_path)
    obj.process()

# python -m cua.plan.eval.utils.dev_ota7_data_process
