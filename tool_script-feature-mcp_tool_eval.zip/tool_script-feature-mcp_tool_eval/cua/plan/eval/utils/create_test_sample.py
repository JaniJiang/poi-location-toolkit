import json
import csv
import re
from loguru import logger
from collections import defaultdict
from cua.plan.sample.func import *
from cua.plan.sample.meta import *
from cua.plan.sample.prompt import *
from cua.plan.eval.test_data import *
from cua.plan.sample.func import reorder_dict_items
from utils.file_utils import read_json_file, check_output_path
from cua.plan.sample.merge_sample.extend_sample import ExtendSample
from cua.plan.sample.merge_sample.extend_data import NEW_APP_NAMES, appName_Dict, taskType_Dict


class CreateTest(ExtendSample):
    def __init__(self, sample_source, output_path):
        self.sample_source = sample_source
        self.output_path = output_path
        self.create_start_num = 6
        self.create_continue_num = 15
        check_output_path(output_path)

    def process_one_item(self, item, one_alias, app_name, data):
        new_item = item.copy()
        new_item["instruction"] = new_item["instruction"].replace("<brand>", one_alias)
        new_item["output"] = new_item["output"].replace("<brand>", app_name)
        dialog = prompt2dialog(new_item["instruction"])
        match = re.search(r'```function_call\s*\n(.*?)```', new_item["output"], flags=re.DOTALL)
        result = json.loads(match.group(1))[0]
        data.append([dialog, result["name"], json.dumps(result["arguments"], ensure_ascii=False), "NONE", "NONE"])

    def build_test_sample_for_vehicle_park(self, data):
        self.extract_and_process_data(check_scene="travel_vehicle_park")
        for app_name, alias in NEW_APP_NAMES.items():
            logger.info(f"正在为App '{app_name}' 生成数据...")
            for one_alias in alias:
                selected_start_data, selected_continue_data = self.sample_data()
                for item in selected_start_data:
                    self.process_one_item(item, one_alias, app_name, data)
                for item in selected_continue_data:
                    self.process_one_item(item, one_alias, app_name, data)
            logger.info(
                f"为App '{app_name}' 生成了 {(len(selected_start_data) + len(selected_continue_data)) * len(alias)} 条数据。")
        logger.info(f"所有App共生成 {len(data)} 条数据。")

    def build_continue_test_sample(self, conversations_cache, data, assis_query, res, stage_index):
        """构造continue样本"""
        choiced_conversations = my_random.choice(conversations_cache[f"stage_{stage_index-1}"]).copy()
        if isinstance(assis_query, list):
            if "tail_number" in assis_query[0]:
                num_rep, cn_rep = self.generate_random_response("phoneNumber", "detail")
                tail_num = num_rep[-4:]
            num_rep, cn_rep, amount = self.generate_random_response("amount", "detail")
            for query in assis_query:
                tmp_conver = choiced_conversations.copy()
                if "tail_number" in query:
                    self.append_conversations(tmp_conver, "assistant", query.format(
                        tail_number=tail_num, amount=amount))
                else:
                    self.append_conversations(tmp_conver, "assistant", query.format(amount=amount))
                self.append_conversations(tmp_conver, "user", res)
                dialog = conversations2dialog(tmp_conver)
                data.append([dialog, "cu_agent_continue", {}, "NONE", "NONE"])
                conversations_cache[f"stage_{stage_index}"].append(choiced_conversations)
        else:
            self.append_conversations(choiced_conversations, "assistant", assis_query)
            self.append_conversations(choiced_conversations, "user", res)
            dialog = conversations2dialog(choiced_conversations)
            data.append([dialog, "cu_agent_continue", {}, "NONE", "NONE"])
            conversations_cache[f"stage_{stage_index}"].append(choiced_conversations)

    def build_test_sample_for_living_Di(self, data):
        self.extract_and_process_data()
        for scene_name, action_dict in start_sample.items():
            for action_name, start_list in action_dict.items():
                for one_start in start_list:
                    selected_start_data, _ = self.sample_data()
                    for item in selected_start_data:
                        conversations = prompt2conversations(item["instruction"])
                        conversations[-1]["content"] = one_start
                        dialog = conversations2dialog(conversations)
                        arguments = {}
                        arguments["appName"] = appName_Dict[scene_name]
                        arguments["taskType"] = taskType_Dict[scene_name][action_name]
                        arguments["query"] = one_start
                        reordered_dict = reorder_dict_items(arguments)
                        data.append([dialog, "cu_agent_start", json.dumps(
                            reordered_dict, ensure_ascii=False), "NONE", "NONE"])
                conversations = []
                conversations_cache = defaultdict(list)
                one_start = my_random.choice(start_list)
                self.append_conversations(conversations, "user", one_start)
                conversations_cache["stage_-1"] = [conversations]
                for stage_index, conversation_step in enumerate(continue_workflow[scene_name][action_name]):
                    assis_query = conversation_step["assis"]
                    user_res_type = conversation_step["user"]
                    if "继续" not in user_res_type:
                        for res in user_response[user_res_type]:
                            self.build_continue_test_sample(conversations_cache, data, assis_query, res, stage_index)
                    else:
                        self.build_continue_test_sample(conversations_cache, data,
                                                        assis_query, user_res_type, stage_index)

    def process(self, sample_type=None):
        headers = ["对话", "工具", "参数", "场景", "小程序"]
        data = []
        if sample_type == "vehicle_park":
            self.build_test_sample_for_vehicle_park(data)
        else:
            self.build_test_sample_for_living_Di(data)
        with open(self.output_path, 'w', newline='', encoding='utf-8') as tsvfile:
            tsv_writer = csv.writer(tsvfile, delimiter='\t')
            tsv_writer.writerow(headers)
            tsv_writer.writerows(data)
        logger.info(f"生成数据至:{self.output_path}")


# --- 示例用法 ---
if __name__ == "__main__":
    sample_source = f"{DATASET_DIR}/v13-20250703/merge_sample.True.instruction.mindgpt.json"
    output_path = f"{SAMPLE_DIR}/eval/V3/test_living_Di.debug.tsv"
    obj = CreateTest(sample_source, output_path)
    obj.process()

# python -m cua.plan.eval.utils.create_test_sample
