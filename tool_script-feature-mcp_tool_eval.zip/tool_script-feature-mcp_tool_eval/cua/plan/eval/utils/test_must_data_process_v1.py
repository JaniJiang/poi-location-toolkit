import pandas as pd
from tqdm import tqdm
from cua.plan.sample.meta import *
from cua.plan.sample.scene import *
from cua.plan.sample.prompt import *
from utils.file_utils import read_jsonl_file


class TestMustDataProcessV1:

    def __init__(self, input_path, output_path):
        self.input_path = input_path
        self.output_path = output_path
        self.brand2scene_dict = get_brand2scene_dict()

    def process(self):
        input_list = read_jsonl_file(self.input_path)
        output_list = []
        for input_one in tqdm(input_list, total=len(input_list)):
            # 解析messages
            messages = input_one["messages"]
            messages_num = len(messages)
            if messages_num == 0:
                continue
            # 解析output
            arguments = input_one["output"][0]["content"][0]["arguments"]
            # 判断app_name和scene
            app_name = input_one["appName"]
            if app_name == "":
                app_name = arguments.get("appName", "未知")
            scene = self.brand2scene_dict.get(app_name, "")
            # 对话信息
            prompt, _ = build_prompt(messages)
            dialog = prompt2dialog(prompt)
            # 工具和参数
            if messages_num == 1:
                tool_name = TOOL_NAME_CU_AGENT_START
                param_dict = {
                    "appName": arguments.get("appName", ""),
                    "taskType": arguments.get("taskType", ""),
                    "query": arguments.get("query", ""),
                }
                format_param_dict = start_arguments_filter(param_dict)
                params = json.dumps(format_param_dict, ensure_ascii=False, indent=4)
            else:
                tool_name = TOOL_NAME_CU_AGENT_CONTINUE
                params = "{}"
            output_list.append({"对话": dialog, "工具": tool_name, "参数": params, "场景": scene, "小程序": app_name})
        # 保存结果到文件
        output_df = pd.DataFrame(output_list)
        output_df.to_csv(self.output_path, sep="\t", index=False, header=True)


def start_arguments_filter(arguments: Dict[str, str]) -> Dict[str, str]:
    """cu_agent_start工具的参数过滤"""
    arguments_filtered = {}
    for key, value in arguments.items():
        if value == "":
            continue
        arguments_filtered[key] = value
    return arguments_filtered


if __name__ == "__main__":
    input_path = f"{SAMPLE_DIR}/eval/source/test_must.v1.jsonl"
    dataset_version = "V3"
    output_path = f"{SAMPLE_DIR}/eval/{dataset_version}/test_must.tsv"
    obj = TestMustDataProcessV1(input_path, output_path)
    obj.process()

# python -m cua.plan.eval.utils.test_must_data_process_v1
