import os
import csv
import json
import threading
import random
import pandas as pd
from tqdm import tqdm
from joblib import Parallel, delayed
from utils.llm_utils.openai_style_api import OpenAIStyleAPI
from utils.file_utils import read_jsonl_file, check_output_path
from cua.plan.sample.meta import *
from cua.plan.sample.prompt import *


class DataProcess:
    def __init__(self):
        self.path_list = [
            {
                "input_type": "excel",
                "input_path": f"{SAMPLE_DIR}/eval/yabo/星巴克数据.xlsx"
            },
            {
                "input_type": "csv",
                "input_path": f"{SAMPLE_DIR}/eval/zoucha/0421上午走查query.csv"
            },
            {
                "input_type": "csv",
                "input_path": f"{SAMPLE_DIR}/eval/zoucha/0421中午走查query.csv"
            }
        ]
        self.output_path = f"{SAMPLE_DIR}/eval/merge_yabo_zoucha.tsv"

    def data_process(self):

        result = []
        texts = [
            "已为您下单。",
            "还有5分钟送达。",
            "订单已提交，正在为您准备。",
            "您的咖啡已开始配送，请耐心等待。",
            "为您找到以下商品，您想要喝什么？浓缩咖啡、美式咖啡、拿铁、卡布奇诺、摩卡、焦糖玛奇朵、星冰乐、红茶拿铁、抹茶拿铁、水果茶、热巧克力、热苹果酒、茶星冰乐、果汁星冰乐。",
            "请问您想要哪一款饮品？",
            "要大杯还是小杯？",
            "需要中杯、大杯还是超大杯？",
            "请问您的配送地址是？",
            "请选择饮品的温度（热/冷）。",
            "需要加糖吗？可以选择‘不加糖’、‘少糖’、‘正常糖’、‘多糖’等。",
            "请问需要哪种甜度？可选：不加糖、不另外加糖、加糖、少糖、正常糖、多糖、少少甜、标准甜、少甜、微甜。",
            "需要牛奶还是燕麦奶或豆奶等其他选择吗？",
            "饮品预计20分钟送达，如有变动会及时通知。",
            "饮品已送达，请注意查收。",
            "感谢您的下单，祝您用餐愉快！",
            "还有其他需要帮您点餐的吗？"
        ]
        excel_rows = []
        for path_item in tqdm(self.path_list, total=len(self.path_list)):
            if path_item['input_type'] == "csv":
                df_tmp = pd.read_csv(path_item['input_path'])
                df_tmp = df_tmp.sort_values('timestamp')
                grouped = df_tmp.groupby('source')

                for _, group in grouped:
                    user_queries = group['taskformer-query'].tolist()
                    for i in range(50):
                        nums = [3, 4, 5, 6, 7]
                        num = random.choice(nums)
                        if len(user_queries) < num:
                            selected_users = user_queries
                        else:
                            selected_users = random.sample(user_queries, num)

                        # 构造turn，除了最后一个不带assistant
                        dialogue_text = ""
                        for idx, user_query in enumerate(selected_users):
                            dialogue_text += f"user: {user_query}\n"
                            if idx != len(selected_users) - 1:
                                dialogue_text += f"assistant: {random.choice(texts)}\n"
                        result.append({
                            "query": dialogue_text,
                            "output_real": ""
                        })
            elif path_item['input_type'] == 'excel':
                df_excel = pd.read_excel(path_item['input_path'], sheet_name='澄清')

                for index, row in df_excel.iterrows():
                    excel_rows.append({
                        'query': row['query'],
                        'output_real': TOOL_NAME_CU_AGENT_CONTINUE
                    })

        result.extend(excel_rows)
        self.save_result(self.output_path, result)

    def save_result(self, output_path, result_list):
        fieldnames = result_list[0].keys()
        file_exists = os.path.isfile(output_path) and os.path.getsize(output_path) > 0
        with open(output_path, "a", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter="\t")
            if not file_exists:
                writer.writeheader()
            writer.writerows(result_list)


if __name__ == "__main__":
    obj = DataProcess()
    obj.data_process()
