import csv
import re
import pandas as pd
from tqdm import tqdm
from loguru import logger
import threading
from cua.plan.sample.func import *
from cua.plan.sample.qwen3_sample.llm_create_think import API_DICT
from joblib import Parallel, delayed
from utils.llm_utils.openai_style_api import OpenAIStyleAPI
from utils.file_utils import check_output_path


class SlotsGenerator:
    def __init__(self, model_name):
        self.n_jobs = 3
        self.file_lock = threading.Lock()
        self.model, self.url = API_DICT[model_name]["model"], API_DICT[model_name]["url"]
        self.api_obj = OpenAIStyleAPI(self.url)
        self.system_prompt = """
        你是一个经验丰富的提取槽位专家，擅长根据详细的任务描述提取出对应的槽位。
        <槽位简介>当前你需要提取3个槽位分别为"appName","taskType"和"query"
        "appName": "小程序名称,取值必须在["星巴克", "蜜雪冰城", ""霸王茶姬", "古茗", "喜茶", "瑞幸咖啡","肯德基", "麦当劳", "华莱士", "汉堡王", "达美乐","美味不用等","捷停车", "支付宝停车", "ETCP停车", "停简单", "乐速通", "ETC服务","支付宝我的快递", "菜鸟裹裹", "中通快递", "圆通快递", "申通快递", "EMS中国邮政速递物流", "顺丰速运", "韵达快递"]
        "taskType": "当前任务类型,取值必须在['点单', '查询订单进展', '排号', '预约定座', '停车缴费', '查询ETC账单', '查询快递进展']
        "query": "输入query原句", 若无任何槽位信息则返回空字典。
        <输出要求>
        你必须以json格式输出提取出的槽位。
        如: {"appName":"星巴克", "taskType": "点单", "query":"帮我点一杯星巴克咖啡"}
        <示例>
        输入为: "暂停点咖啡"
        输出为: {"taskType": "点单", "query":"暂停点咖啡"}
        """
        self.user_prompt = """
        <输入>
        {query}
        <输出>
        """

    def assign_slots_based_on_llm(self, dialog):
        new_dialog = re.sub(r'user:( [^\n]*)$', r'query:\1', dialog)
        model_answer = self.call_llm(new_dialog)
        if model_answer is None:
            return None
        try:
            arguments = json.loads(model_answer)
        except:
            try:
                arguments = json.loads(model_answer.strip().strip('`').replace("json", '').replace("\n", ""))
            except:
                logger.info(f"解析出错, 模型返回为:{model_answer}")
                return None
        desired_order = ["appName", "taskType", "query"]
        reordered_dict = {}
        for key in desired_order:
            if key in arguments:
                if arguments[key] != "":
                    reordered_dict[key] = arguments[key]
        return reordered_dict

    def call_llm(self, dialog):
        history, user_latest = split_dialog(dialog, "query:")
        prompt = [
            {
                "role": "system", "content": self.system_prompt.strip()
            },
            {
                "role": "user", "content": self.user_prompt.strip().format(query=user_latest)}
        ]
        answer = self.api_obj.v1_chat_completions(self.model, prompt)
        return answer

    def rewrite_by_tool_label(self, tool_labels, input_path, output_path):
        """模型撰写slots"""
        check_output_path(output_path)
        sample_df = pd.read_csv(input_path, sep="\t")
        target_indices = sample_df[sample_df["工具"].isin(tool_labels) & (sample_df["参数"] == "{}")].index
        if len(target_indices) == 0:
            logger.info(f"文件内没有需要重写的样本")
            return
        update_results = {}
        results_lock = threading.Lock()

        def process_row(idx):
            row_data = sample_df.loc[idx]
            llm_slots = self.assign_slots_based_on_llm(row_data["对话"])
            if llm_slots is None:
                llm_slots = {"error": "需要人工处理"}
            with results_lock:
                update_results[idx] = llm_slots
        # 并发处理
        Parallel(n_jobs=self.n_jobs, prefer="threads")(
            delayed(process_row)(idx) for idx in tqdm(target_indices, total=len(target_indices))
        )
        # 更新并保存
        if update_results:
            for idx, llm_slots in update_results.items():
                sample_df.loc[idx, "参数"] = json.dumps(llm_slots, ensure_ascii=False)
            sample_df.to_csv(output_path, sep="\t", index=False, encoding="utf-8")


# --- 使用示例 ---
if __name__ == "__main__":
    # gpt-4o,qwen-32b,deepseek-v3
    model_name = 'deepseek-v3'
    obj = SlotsGenerator(model_name)
    # LLM撰写slots
    share_path = "data/cloud_share/cua/plan/sample/eval/log_processed"
    tool_labels = ["cu_agent_start"]
    input_path = f"{share_path}/test_log_0513.tsv"
    output_path = f"{share_path}/test_log_0513_rewritted.tsv"
    obj.rewrite_by_tool_label(tool_labels, input_path, output_path)

# python -m cua.plan.eval.utils.log_slots_process
