import re
from loguru import logger
from cua.plan.sample.prompt import *
from cua.plan.sample.func import split_dialog
from cua.plan.eval.eval_sample_qwen3 import EvalSampleQwen3
from cua.plan.eval.eval_sample import API_DICT


class EvalPrompt(EvalSampleQwen3):
    def __init__(self, env):
        super().__init__(env)
        self.n_jobs = 3
        # "dev_easy", "dev_middle", "dev_ota7", "test_must", "test_log", "test_new_app", "test_living_Di"
        self.human_dataset_name_list = []
        # "test_log_merged", "test_log_0622", "test_log_0623", "test_log_0624"
        self.log_dataset_name_list = ["test_log_0622"]
        self.dataset_name_list = self.human_dataset_name_list + self.log_dataset_name_list
        # 推理接口参数
        self.model, self.url = API_DICT[env]["model"], API_DICT[env]["url"]
        self.system_prompt = """你是一位文本分类专家,需要根据用户的分类规则给出最正确的答案和分类理由,并输出标准化的 JSON 结果
        <输出要求>
        请仅输出如下格式的 JSON：
        {"tool_label": "分类标签","analyse":分类理由}
        [任务描述占位符]"""
        self.system_prompt = fill_template_with_label_defnition(
            self.system_prompt, Label_definition, task="log_process")

    def process_sample_one(self, output_path, sample_row):
        dialog, tool_real, arguments_real, scene_name, app_name = sample_row[
            "对话"], sample_row["工具"], sample_row["参数"], sample_row["场景"], sample_row["小程序"]
        message = self.build_message(dialog)
        try:
            arguments_real_dict = json.loads(arguments_real)
        except Exception as e:
            logger.warning("[arguments_real]" + str(e))
            logger.warning("[arguments_real]" + arguments_real)
            return
        # 请求推理接口
        pred_str = self.api_obj.v1_chat_completions(self.model, message, temperature=0.0)
        if pred_str is None:
            return
        tool_pred, analyse = self.parse_pred_str(pred_str)
        if tool_pred is None:
            return
        # 计算是否工具、槽位和改写Query正确
        tool_acc = ""
        if tool_pred != "":
            tool_acc = self.calculate_acc(tool_real, tool_pred)
        # 格式化结果
        result_list = [{
            "对话": dialog,
            "工具": tool_real,
            "工具-预测": tool_pred,
            "工具是否正确": tool_acc,
            "思考过程": analyse,
        }]
        # 保存处理结果
        self.save_result(output_path, result_list)

    def parse_pred_str(self, pred_str):
        try:
            match = re.search(r'\{.*\}', pred_str)
            json_str = match.group(0)
            json_result = json.loads(json_str)
            return json_result["tool_label"], json_result["analyse"]
        except Exception as e:
            logger.warning("[pred_str]" + str(e))
            logger.warning("[pred_str]" + pred_str)
            return None, None

    def calculate_acc(self, tool_real, tool_pred):
        # 判断工具是否正确
        tool_acc = "1" if tool_real == tool_pred else "0"
        return tool_acc

    def build_message(self, dialog):
        dialog_processed = re.sub(r'user:( [^\n]*)$', r'最新话语:\1', dialog)
        delimiter = "最新话语:"
        history, user_latest = split_dialog(dialog_processed, delimiter)
        user_input = Qwen3_Prompt["input"].strip().format(
            history=history, user_latest=user_latest)
        message = [
            {
                "role": "system", "content": self.system_prompt.strip()
            },
            {
                "role": "user", "content": user_input}
        ]
        return message

    def test_one_sample(self, dialog):
        message = self.build_message(dialog)
        pred_str = self.api_obj.v1_chat_completions(self.model, message, temperature=0.0)
        print(pred_str)


if __name__ == "__main__":
    env = "deepseek-v3"  # my_model_qwen3_local | lpai_qwen3 | testtwo | my_model
    # 模型推理
    obj = EvalPrompt(env)
    # obj.process(env="my_model_qwen3")

    # 测试单个样本
    test_sample = """user: 帮我在瑞幸点杯咖啡
user: 选择到店取
assistant: 你想在哪个门店下单呢？
user: 第一个
assistant: 你想在哪个门店下单呢？
user: 第一个
assistant: 你想在哪个门店下单呢？
assistant: 你想在哪个门店下单呢？
assistant: 你想在哪个门店下单呢？
user: 幸福广场店
user: 帮我点一杯橙C美式"""
    obj.test_one_sample(test_sample)

# python -m cua.plan.eval.eval_prompt
