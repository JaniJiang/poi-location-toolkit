import re
from loguru import logger
from cua.plan.sample.prompt import *
from cua.plan.eval.eval_sample import *
from cua.plan.eval.calculate_metrics import CalculateMetrics


class EvalSampleQwen3(EvalSample):
    def __init__(self, env):
        super().__init__(env, "")
        # "dev_easy", "dev_middle", "dev_ota7", "test_must", "test_log"
        self.human_dataset_name_list = []
        # "test_log_0513", "test_log_0514", "test_log_0525-28", "test_log_0605-09", "test_log_deduped_1000"
        self.log_dataset_name_list = ["test_log_0622", "test_log_0623", "test_log_0624"]
        self.dataset_name_list = self.human_dataset_name_list + self.log_dataset_name_list
        # 推理接口参数
        self.model, self.url = API_DICT[env]["model"], API_DICT[env]["url"]

    def process_sample_one(self, output_path, sample_row):
        dialog, tool_real, arguments_real, scene_name, app_name = sample_row[
            "对话"], sample_row["工具"], sample_row["参数"], sample_row["场景"], sample_row["小程序"]
        if self.need_reduce_dialog is True:
            dialog = self.process_reduce_dialog(dialog)
        message = self.build_message(dialog)
        try:
            arguments_real_dict = json.loads(arguments_real)
        except Exception as e:
            logger.warning("[arguments_real]" + str(e))
            logger.warning("[arguments_real]" + arguments_real)
            return
        # 请求推理接口
        pred_str = self.api_obj.v1_chat_completions(self.model, message, temperature=0.2)
        tool_pred, arguments_pred = self.parse_pred_str(pred_str)
        if tool_pred == None:
            return
        # 计算是否工具、槽位和改写Query正确
        tool_acc, slot_acc, query_acc = "", "", ""
        if tool_pred != "":
            tool_acc, arguments_acc = self.calculate_acc(tool_real, arguments_real_dict, tool_pred, arguments_pred)
        # 格式化结果
        result_list = [{
            "对话": dialog,
            "工具": tool_real,
            "参数": arguments_real,
            "场景": scene_name,
            "小程序": app_name,
            "工具-预测": tool_pred,
            "参数-预测": arguments_pred,
            "工具是否正确": tool_acc,
            "参数是否正确": arguments_acc,
            "原始预测结果": pred_str,
        }]
        # 保存处理结果
        self.save_result(output_path, result_list)

    def parse_pred_str(self, pred_str):
        if pred_str is None:
            return None, None
        try:
            match = re.search(r'(\{.*\})', pred_str)
            json_result = json.loads(match.group(1))
            return json_result["tool_label"], json_result["arguments"]
        except Exception as e:
            logger.warning("[pred_str]" + str(e))
            logger.warning("[pred_str]" + pred_str)
            return None, None

    def calculate_acc(self, tool_real, arguments_real, tool_pred, arguments_pred):
        # 判断工具是否正确
        tool_acc = "1" if tool_real == tool_pred else "0"
        if "query" in arguments_real:
            del arguments_real["query"]
        arguments_acc = "1" if arguments_real == arguments_pred else "0"
        return tool_acc, arguments_acc

    def build_message(self, dialog):
        dialog_processed = re.sub(r'user:( [^\n]*)$', r'最新话语:\1', dialog)
        delimiter = "最新话语:"
        history, user_latest = split_dialog(dialog_processed, delimiter)
        user_latest = user_latest.replace("最新话语: ", "")
        system_prompt = Qwen3_Prompt["system"]
        user_instruction = Qwen3_Prompt["instruction"].strip()
        user_input = {
            "对话历史": history,
            "最新话语": user_latest
        }
        if "qwen3" in self.env:
            instruction = user_instruction + "\n" + json.dumps(user_input, ensure_ascii=False)
            instruction = instruction + "\n" + "/no_think"
        else:
            instruction = user_instruction + "\n" + json.dumps(user_input, ensure_ascii=False)
        message = [
            {
                "role": "system", "content": system_prompt
            },
            {
                "role": "user", "content": instruction}
        ]
        return message

    def test_one_sample(self, dialog):
        message = self.build_message(dialog)
        pred_str = self.api_obj.v1_chat_completions(self.model, message, temperature=0.2)
        print(pred_str)


if __name__ == "__main__":
    env = "my_model_qwen3"  # lpai_qwen2 | lpai_qwen3 | testtwo | my_model
    # 模型推理
    eval_sample_obj = EvalSampleQwen3(env)
    eval_sample_obj.process(env="my_model_qwen3")
    # 指标计算
    calculate_metrics_obj = CalculateMetrics()
    calculate_metrics_obj.process(env=env)
    # 测试单个样本
#     test_sample = """user: 帮我点一杯瑞幸咖啡
# user: 帮我点一杯瑞幸咖啡的橙c美式"""
#     eval_sample_obj.test_one_sample(test_sample)


# python -m cua.plan.eval.eval_sample_qwen3
