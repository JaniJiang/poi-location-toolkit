#!/bin/bash
# bash cua/plan/sample/run_pipeline.sh
# nohup bash cua/plan/sample/run_pipeline.sh > log/cua/plan/sample/run_pipeline.log 2>&1 &

###### 正式样本构建流程 ######
# 构建场景样本
bash cua/plan/sample/run_scene_sample.sh
# 合并场景样本（负例构建也是在这一步实现的）
python -m cua.plan.sample.merge_sample.merge_sample
# 格式化数据到LiSFT格式
python -m cua.plan.sample.merge_sample.trans_sample

###### 样本分析流程 ######
# 分析样本分布
python -m cua.plan.sample.analyse.analyse_merge_sample
