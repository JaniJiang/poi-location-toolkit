from tqdm import tqdm
from loguru import logger
import csv
import re
import os
import pandas as pd
from utils.file_utils import write_json_file, check_output_path
from cua.plan.sample.prompt import *
from cua.plan.sample.meta import *
from cua.plan.sample.func import *


class TransSample:
    def __init__(self, input_list, model_type):
        # 数据集提示词配置
        self.model_type = model_type
        self.system = Qwen3_Prompt["system"]
        self.instruction = Qwen3_Prompt["instruction"].strip()
        self.sample_name = "samples"
        self.input_path = [
            f"{SAMPLE_DIR}/qwen3_processed/{QWEN3_SAMPLE_VERSION}/badcases/{item}.tsv" for item in input_list]
        # 输出路径
        self.merged_output_path = f"{SAMPLE_DIR}/qwen3_processed/{QWEN3_SAMPLE_VERSION}/merged_samples.tsv"
        if model_type == "Qwen3":
            dataset_version = QWEN3_DATASET_VERSION
        else:
            dataset_version = QWEN2_DATASET_VERSION
        self.analyse_output_path = f"{SAMPLE_DIR}/qwen3_processed/{QWEN3_SAMPLE_VERSION}/analyse.tsv"
        self.dataset_output_path = f"{DATASET_DIR}/{dataset_version}/{self.sample_name}.json"
        check_output_path(self.merged_output_path)
        check_output_path(self.analyse_output_path)
        check_output_path(self.dataset_output_path)

    def process(self):
        # 读取输入数据
        logger.info("读取输入数据")
        self.check_tsv_column_for_value_simple()
        merge_tsv_sample(self.input_path, self.merged_output_path)
        # self.data_analyse()
        sample_list = []
        with open(self.merged_output_path, 'r', newline='', encoding='utf-8') as tsvfile:
            reader = csv.DictReader(tsvfile, delimiter='\t')
            for row in reader:
                sample_list.append(row)
        logger.info(f"样本数量: {len(sample_list)}")
        # 随机打乱数据顺序
        logger.info("随机打乱数据顺序")
        my_random.shuffle(sample_list)
        # 格式化数据到训练格式
        logger.info("格式化数据到训练格式")
        result_list = []
        for sample_one in tqdm(sample_list, total=len(sample_list)):
            think = sample_one["thought"].strip()
            if sample_one["参数模型"] == "{}":
                arguments = {}
            else:
                new_arguments = sample_one["参数模型"].replace("'", '"')
                arguments = json.loads(new_arguments)
            result_json = {"tool_label": sample_one["tool类别"], "arguments": arguments}
            input_data = re.sub(r'user:( [^\n]*)$', r'最新话语:\1', sample_one["对话样本"])
            input_data = self.build_input(input_data)
            if self.model_type == "Qwen3":
                output_data = f"<think>\n\n</think>\n{think}{json.dumps(result_json, ensure_ascii=False)}"
            else:
                input_data = input_data + "/n" + "/no_think"
                output_data = think + json.dumps(result_json, ensure_ascii=False)
                # output_data = json.dumps(result_json, ensure_ascii=False)
            data_one = {
                "instruction": self.instruction,
                "input": input_data,
                "output": output_data,
                "system": self.system,
            }
            result_list.append(data_one)
            # 保存处理结果
        logger.info(f"保存处理结果，样本量{len(result_list)}")
        write_json_file(result_list, self.dataset_output_path)
        logger.info(f"数据集保存至{self.dataset_output_path}")

    def build_input(self, dialog):
        delimiter = "最新话语:"
        history, user_latest = split_dialog(dialog, delimiter)
        user_latest = user_latest.replace("最新话语: ", "")
        input_data = {
            "对话历史": history,
            "最新话语": user_latest
        }
        return json.dumps(input_data, ensure_ascii=False)

    # def data_analyse(self):
    #     """数据集分析, 统计当前不同情景类别的数量"""
    #     logger.info("统计当前数据集不同情景类别数量")
    #     df = pd.read_csv(self.merged_output_path, sep='\t')
    #     counts = df["tool类别"].value_counts().reset_index()
    #     counts.columns = ["情景类别", 'count_情景']
    #     unique_pairs = df[["tool类别", "情景类别"]].drop_duplicates()
    #     final_df = pd.merge(unique_pairs, counts, on="情景类别", how='left')
    #     final_df = final_df[["tool类别", "情景类别", 'count_情景']]
    #     final_df.to_csv(self.analyse_output_path, sep='\t', index=False)
    #     logger.info(f"Analysis complete. Results saved to '{self.analyse_output_path}'.")

    def check_tsv_column_for_value_simple(self):
        found_files = []
        for file_path in self.input_path:
            df = pd.read_csv(file_path, sep='\t')
            if (df["tool类别"] == "回答问题(配送方式)").any():
                found_files.append(file_path)
        print(found_files)


if __name__ == "__main__":
    input_list = ["standard_sample_v2.debug", "extend_data_0731.debug", "extend_data_0801_1.debug"]
    obj = TransSample(input_list, model_type="Qwen2")
    obj.process()

# python -m cua.plan.sample.qwen3_sample.trans_qwen3_sample
