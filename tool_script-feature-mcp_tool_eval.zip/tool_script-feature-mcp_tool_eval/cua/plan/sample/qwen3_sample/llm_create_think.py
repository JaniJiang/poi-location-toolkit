import csv
import os
import re
import pandas as pd
from tqdm import tqdm
from loguru import logger
import threading
from cua.plan.sample.meta import *
from cua.plan.sample.prompt import *
from cua.plan.sample.func import *
from joblib import Parallel, delayed
from utils.llm_utils.openai_style_api import OpenAIStyleAPI
from utils.file_utils import check_output_path

API_DICT = {
    "gpt-4o": {
        "model": "gpt-4o",
        "url": "https://xuzhou1-tool-llm.ontest.fc.chj.cloud/gpt-4o",
    },
    'qwen-32b': {
        "model": "deepseek-r1-distill-qwen-32b",
        "url": "https://xuzhou1-tool-llm.ontest.fc.chj.cloud/deepseek-r1-distill-qwen-32b"
    },
    'deepseek-v3': {
        "model": "deepseek-v3",
        "url": "https://xuzhou1-tool-llm.ontest.fc.chj.cloud/deepseek-v3"
    },
}


class LLMGenerator:
    def __init__(self, model_name):
        self.n_jobs = 3
        self.file_lock = threading.Lock()
        self.model, self.url = API_DICT[model_name]["model"], API_DICT[model_name]["url"]
        self.api_obj = OpenAIStyleAPI(self.url)
        self.appName_list = ["星巴克", "蜜雪冰城", "霸王茶姬", "古茗", "喜茶", "瑞幸咖啡", "肯德基", "麦当劳", "华莱士", "汉堡王", "达美乐", "必胜客", "美味不用等", "捷停车",
                             "支付宝停车", "ETCP停车", "停简单", "乐速通", "ETC服务", "支付宝我的快递", "菜鸟裹裹", "中通快递", "圆通快递", "申通快递", "EMS中国邮政速递物流", "顺丰速运", "韵达快递"]
        self.taskType_list = ['点单', '查询订单进展', '排号', '预约定座', '停车缴费', '查询ETC账单', '查询快递进展']
        self.system_prompt = """
        你是一个专业的文本分类专家，精通用户意图的判断、逻辑推理和实体信息抽取。你的任务是根据给定的对话情境和用户最新话语，**准确判断用户意图并给出分类标签 (`tool_label`)、推导出详细的思考过程 (`thought`)，并根据分类定义抽取出相应的参数 (`arguments`)**。
        请严格遵循以下要求：
        1.  **输入信息：** 你将接收到以下 JSON 格式的输入，其中包含了对话历史、用户最新话语，以及已经确定的分类标签：
        {
        "对话历史": "用户: [用户对话历史]\n助手: [助手对话历史]",
        "最新话语": "[用户最新话语]",
        "tool_label": "[已确定的分类标签，例如 'cu_agent_start', 'cu_agent_continue', 'other' 等]"
        }
        2.  **分类定义参考：** 请严格参考以下你所熟知的分类定义和场景范畴来构建你的思考过程。即使你已知最终分类，也需要通过这些定义来反向推导其逻辑，从而形成完整的思考过程。
        [任务描述占位符]
        3.  **思考过程 (`thought`) 生成要求：**
        * `thought` 字段应详细说明判断 `tool_label` 的逻辑和理由。
        * 请清晰地指出 `最新话语` 的意图或含义是什么, 以及是如何符合某一个条件的。
        * 如果涉及到 `cu_agent_start` 且 `arguments` 非空，思考过程应解释 `appName` 和 `taskType` 的推导来源。
        * 语言需专业、逻辑连贯
        * thought内容不应过长。
        4.  **输出格式：**
        请直接输出一个 JSON 对象，其中包含 `thought`、 `tool_label`和 `arguments` 三个字段。
        **输出格式示例：**
        {
        "thought": "",
        "tool_label": "",
        "arguments": {}
        }
        """
        self.system_prompt = fill_template_with_label_defnition(
            self.system_prompt, Label_definition, Arguments_definition)

    def process(self, input_path, output_path):
        """
        LLM生成Think伪标签
        """
        # 并发处理
        sample_df = pd.read_csv(input_path, sep="\t")
        # sample_df = sample_df.head(10)
        check_output_path(output_path)
        Parallel(n_jobs=self.n_jobs, prefer="threads")(
            delayed(self.process_sample_one)(output_path, sample_row)
            for _, sample_row in tqdm(sample_df.iterrows(), total=len(sample_df))
        )
        print(f"已成功生成thought到 '{output_path}'")

    def process_sample_one(self, output_path, row):
        # 设定工具标签
        dialog = row["对话"]
        conversations = dialog2conversations(dialog)
        tool_label = row["工具"]
        arguments_label = row["参数"]
        answer = self.assign_thought_based_on_llm(dialog, tool_label)
        try:
            if answer == None:
                tool_model = "NONE"
                answer = "API调用失败需重新处理"
                arguments_model = {}
                arguments_flag = 1
                tool_flag = 1
                thought_content = ""
            else:
                try:
                    json_result = json.loads(answer)
                except:
                    answer = answer.replace("json", "").replace("`", "").strip()
                    json_result = json.loads(answer)
                tool_model = json_result["tool_label"]
                thought_content = json_result["thought"]
                arguments_model = json_result["arguments"]
                arguments_flag = 1
                tool_flag = 1
                if arguments_model != {}:
                    app_name = arguments_model.get("appName", "")
                    task_type = arguments_model.get("taskType", "")
                    arguments_model = json.dumps(arguments_model, ensure_ascii=False)
                    if app_name:
                        if app_name not in self.appName_list:
                            arguments_flag = 0
                    if task_type:
                        if task_type not in self.taskType_list:
                            arguments_flag = 0
                if tool_model != tool_label:
                    tool_flag = 0
            result_list = [{"对话样本": dialog, "tool类别": tool_label, "参数": arguments_label,
                            "tool类别-模型": tool_model, "参数模型": arguments_model, "参数-幻觉": arguments_flag, "tool-幻觉": tool_flag, "thought": thought_content}]
            self.save_result(output_path, result_list)
        except:
            logger.info(f"解析回复发生错误， 模型answer为:{answer}")

    def save_result(self, output_path, result_list):
        with self.file_lock:
            fieldnames = result_list[0].keys()
            file_exists = os.path.isfile(output_path) and os.path.getsize(output_path) > 0
            with open(output_path, "a", encoding="utf-8", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter="\t")
                if not file_exists:
                    writer.writeheader()
                writer.writerows(result_list)

    def assign_thought_based_on_llm(self, dialog, tool_label):
        new_dialog = re.sub(r'user:( [^\n]*)$', r'最新话语:\1', dialog)
        model_answer = self.call_llm(new_dialog, tool_label)
        if model_answer is None:
            return None
        return model_answer

    def call_llm(self, dialog, tool_label):
        history, user_latest = split_dialog(dialog, "最新话语:")
        user_latest = user_latest.replace("最新话语: ", "")
        user_prompt = {
            "对话历史": history,
            "最新话语": user_latest,
            "tool_label": tool_label,
        }
        prompt = [
            {
                "role": "system", "content": self.system_prompt.strip()
            },
            {
                "role": "user", "content": json.dumps(user_prompt, ensure_ascii=False)}
        ]
        answer = self.api_obj.v1_chat_completions(self.model, prompt, temperature=0.7)
        return answer

    def rewrite_by_situation_label(self, situation_label, input_path, output_path):
        """按照情景类别取值重写相应的thought"""
        check_output_path(output_path)
        sample_df = pd.read_csv(input_path, sep="\t")
        target_indices = sample_df[sample_df["情景类别"] == situation_label].index
        if len(target_indices) == 0:
            logger.info(f"文件内没有需要重写的样本")
            return
        update_results = {}
        results_lock = threading.Lock()

        def process_row(idx):
            row_data = sample_df.loc[idx]
            new_thought = self.assign_thought_based_on_llm(
                row_data["对话样本"],
                row_data["tool类别"],
                row_data["情景类别"]
            )
            if new_thought is not None:
                with results_lock:
                    update_results[idx] = new_thought
        # 并发处理
        Parallel(n_jobs=self.n_jobs, prefer="threads")(
            delayed(process_row)(idx) for idx in tqdm(target_indices, total=len(target_indices))
        )
        # 更新并保存
        if update_results:
            for idx, new_thought in update_results.items():
                sample_df.loc[idx, "thought"] = new_thought
            sample_df.to_csv(output_path, sep="\t", index=False, encoding="utf-8")


# --- 使用示例 ---
if __name__ == "__main__":
    # gpt-4o,qwen-32b,deepseek-v3
    model_name = 'deepseek-v3'
    obj = LLMGenerator(model_name)
    # 指定文件名使用大模型写thought
    input_list = ["extend_data_0802_4"]
    for item in input_list:
        input_path = f"{SAMPLE_DIR}/qwen3_source/{item}.tsv"
        output_path = f"{SAMPLE_DIR}/qwen3_processed/{QWEN3_SAMPLE_VERSION}/badcases/{item}.debug.tsv"
        obj.process(input_path, output_path)

    # 指定情景类别重写thought
    # input_name_list = ["badcase0625_2", "badcase0626_1", "merged_source"]
    # input_path_list = [
    #     f"{SAMPLE_DIR}/qwen3_processed/{QWEN3_SAMPLE_VERSION}/badcases/{name}.tsv" for name in input_name_list]
    # output_path_list = ["reviewed" + path for path in input_path_list]
    # for index in range(len(input_path_list)):
    #     obj.rewrite_by_situation_label("超出支持范围", input_path_list[index], output_path_list[index])

    # 合并指定source
    # for filename in os.listdir(f"{SAMPLE_DIR}/qwen3_source"):
    #     if "standard" not in filename:
    #         input_list.append(f"{SAMPLE_DIR}/qwen3_source/{filename}")
    # merge_tsv_sample(input_list, f"{SAMPLE_DIR}/qwen3_source/merged_source_17-30.tsv")


# python -m cua.plan.sample.qwen3_sample.llm_create_think
