import json
import csv
from loguru import logger
from collections import defaultdict
from cua.plan.sample.func import *
from cua.plan.sample.meta import *
from cua.plan.sample.prompt import *
from utils.file_utils import read_jsonl_file, write_json_file, check_output_path


class SampleData:
    """
    从全量数据集中抽取样本用于Qwen3学习
    """

    def __init__(self, sample_source: str, output_path: str):
        self.sample_config = {
            "cu_agent_start": {
                "type": "per_scene",
                "n": 100,
                "dedup_rule": "user"
            },
            "cu_agent_continue": {
                "type": "global",
                "n": 1500,
                "dedup_rule": "user_and_asst"
            },
            "cu_agent_cancel": {
                "type": "global",
                "n": 200,
                "dedup_rule": "user"
            },
            "cu_agent_pause": {
                "type": "global",
                "n": 200,
                "dedup_rule": "user"
            },
            "cu_agent_resume": {
                "type": "global",
                "n": 200,
                "dedup_rule": "user"
            },
            "cu_agent_quit": {
                "type": "global",
                "n": 200,
                "dedup_rule": "user"
            },
            "other": {
                "type": "global",
                "n": 1000,
                "dedup_rule": "user"
            },
            "qasearch": {
                "type": "global",
                "n": 100,
                "dedup_rule": "user"
            }
        }
        self.sample_source = sample_source
        check_output_path(output_path)
        self.output_path = output_path

    def get_dedup_value(self, dedup_rule, conversations):
        user_utterance, assis_utterance = None, None
        if conversations[-2]["role"] == "user":
            user_utterance = conversations[-2]["content"]
        if len(conversations) >= 3:
            if conversations[-3]["role"] == "assistant":
                assis_utterance = conversations[-3]["content"]
        if dedup_rule == "user":
            return user_utterance
        elif dedup_rule == "user_and_asst":
            if assis_utterance is None:
                return None
            return user_utterance+assis_utterance

    def sample_data_by_rule(self):
        structured_data = defaultdict(lambda: defaultdict(list))
        global_data = defaultdict(list)
        logger.info(f"开始读取数据文件：{self.sample_source}")
        all_samples = read_jsonl_file(self.sample_source)
        logger.info(f"数据读取完成，共 {len(all_samples)} 条样本。")
        for sample in all_samples:
            tool_label = sample.get("type")
            scene_type = sample.get("scene")
            rule_type = self.sample_config[tool_label]["type"]
            if rule_type == "per_scene":
                structured_data[tool_label][scene_type].append(sample)
            elif rule_type == "global":
                global_data[tool_label].append(sample)
        sampled_results = defaultdict(list)
        # 2. 根据分类好的数据进行抽样
        for tool_label, rules in self.sample_config.items():
            if rules["type"] == "per_scene":
                # 按场景抽样
                for scene_type, samples in structured_data[tool_label].items():
                    unique_samples_pool = {}
                    for s in samples:
                        dedup_value = self.get_dedup_value(rules["dedup_rule"], s["conversations"])
                        if dedup_value not in unique_samples_pool:
                            unique_samples_pool[dedup_value] = s
                    num_to_sample = min(rules["n"], len(unique_samples_pool))
                    sampled = my_random.sample(list(unique_samples_pool.values()), num_to_sample)
                    sampled_results[tool_label].extend(sampled)
            elif rules["type"] == "global":
                # 从全局分类数据中抽样
                all_category_samples = global_data[tool_label]
                # 同样尝试根据指定字段的独特性来抽样
                unique_samples_pool = {}
                for s in all_category_samples:
                    dedup_value = self.get_dedup_value(rules["dedup_rule"], s["conversations"])
                    if dedup_value not in unique_samples_pool and dedup_value is not None:
                        unique_samples_pool[dedup_value] = s
                num_to_sample = min(rules["n"], len(unique_samples_pool))
                sampled = my_random.sample(list(unique_samples_pool.values()), num_to_sample)
                sampled_results[tool_label].extend(sampled)
        return sampled_results

    def process(self):
        logger.info("开始执行完整的数据抽取流程...")
        sampled_data = self.sample_data_by_rule()
        logger.info(f"数据抽取流程完成, 开始保存抽样结果到TSV文件：{self.output_path}")
        with open(self.output_path, 'w', encoding='utf-8', newline='') as f:
            writer = csv.writer(f, delimiter='\t')
            writer.writerow(["对话", "工具", "参数", "场景", "小程序"])
            for category, samples in sampled_data.items():
                for sample in samples:
                    dialog = conversations2dialog(sample.get("conversations", ""))
                    tool_label = sample["type"]
                    arguments = sample["conversations"][-1]["arguments"]
                    writer.writerow([dialog, tool_label, arguments, "NONE", "NONE"])
        logger.info(f"TSV文件保存成功！")


# --- 示例用法 ---
if __name__ == "__main__":
    sample_source = f"{SAMPLE_DIR}/v13-20250703/merge_sample.jsonl"
    output_path = f"{SAMPLE_DIR}/qwen3_source/standard_sample_v3.tsv"
    obj = SampleData(sample_source, output_path)
    obj.process()

# python -m cua.plan.sample.qwen3_sample.sample_data
