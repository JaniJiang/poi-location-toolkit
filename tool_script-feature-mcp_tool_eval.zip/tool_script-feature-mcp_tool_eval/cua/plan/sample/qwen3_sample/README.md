# Qwen3 训练集构造
## 请参考在线文档https://li.feishu.cn/wiki/Eh9awPhtOiG1IKkDxLpcMHOUnzb?fromScene=spaceOverview
```bash
# 采用LLM生成think
python -m cua.plan.sample.qwen3_sample.llm_create_think

# 转换样本为Alpaca格式
python -m cua.plan.sample.merge_sample.trans_qwen3_sample

# 验证模型效果
python -m cua.plan.eval.eval_sample_qwen3
```
