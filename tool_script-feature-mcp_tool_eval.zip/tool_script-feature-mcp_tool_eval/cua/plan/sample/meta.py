from cua.plan.sample.tool import *

# 样本配置
SAMPLE_DIR = "data/cloud_share/cua/plan/sample"
SAMPLE_VERSION = "v13-20250703"
QWEN3_SAMPLE_VERSION = "v1-20250728-qwen3-1_7b"
REVIEW_SAMPLE_NUM = 4000

# 数据集配置
DATASET_DIR = "data/cloud_share/cua/plan/dataset"
DATASET_VERSION = "v13-20250806-extend"  # v13-20250703_full-2, v13-20250716-extend
QWEN3_DATASET_VERSION = "v1-20250728-qwen3-1_7b"
QWEN2_DATASET_VERSION = "v1-20250728-qwen2-1_5b"


# 评估配置
EVAL_DIR = "data/cloud_share/cua/plan/eval"
EVAL_VERSION = "v13-20250806-extend"
QWEN3_EVAL_VERSION = "20250806-qwen2"

# 样本类型
TYPE_FIRST_ORDER = "first_order"
TYPE_APP_CLARIFY = "app_clarify"
TYPE_CONFIRM_CLARIFY = "confirm_clarify"
TYPE_LIST_CLARIFY = "list_clarify"
TYPE_SLOT_CLARIFY = "slot_clarify"
TYPE_NEG_CASE_CLARIFY = "neg_case_clarify"
TYPE_ADD_CONDITION = "add_condition"
TYPE_DELETE_CONDITION = "delete_condition"
TYPE_MODIFY_CONDITION = "modify_condition"
TYPE_BREAK_NEG_CASE = "break_neg_case"
TYPE_ASK_PRIVACY_AGREEMENT = "privacy_agreement"
TYPE_ASK_LOCATION_AGREEMENT = "location_agreement"
TYPE_ASK_TAKE_ORDER_TIME = "task_time_clarify"
TYPE_ASK_OTHER_DEMAND = "other_demand_clarify"
TYPE_ASK_FINAL_ORDER_CONFIRM = "final_order_confirm"
TYPE_ASK_FINAL_ORDER_LOGIN = "final_order_login"
TYPE_ASK_FINAL_ORDER = "final_order_clarify"
TYPE_ASK_STATUS = "status_clarify"
TYPE_ASK_AMOUNT = "amount_clarify"
TYPE_ASK_PHONENUMBER = "phoneNumber_clarify"
TYPE_ASK_LOCATION = "location_clarify"
TYPE_ASK_SERVERTYPE = "server_type_clarify"
TYPE_MULTI_ROUND = "multi_round"
TYPE_NOTIFY_SUCCESS = "notify_success"
TYPE_NOTIFY_PROGRESS = "notify_progress"

# 任务类型
TASK_TYPE_ORDER = "点单"
TASK_TYPE_ASK_STATUS = "查询订单进展"
TASK_TYPE_EXPRESS_STATUS = "查询快递进展"
TASK_TYPE_MEAL_NUMBER = "排号"
TASK_TYPE_MEAL_OEDER = "预约定座"
TASK_TYPE_PARK_FEE = "停车缴费"
TASK_TYPE_PARK_ETC = "查询ETC账单"
TASK_TYPE_ELEC_CHECK = "查电费"
TASK_TYPE_ELEC_PAY = "交电费"
TASK_TYPE_PHONE_CHECK = "查话费"
TASK_TYPE_PHONE_PAY = "交话费"
TASK_TYPE_DI_QUICK = "一键代驾"
TASK_TYPE_DI_INSTANT = "代驾"

TASK_TYPE_DICT = {
    "drink_coffee": TASK_TYPE_ORDER,
    "drink_tea": TASK_TYPE_ORDER,
    "takeout_western_hamburger": TASK_TYPE_ORDER,
    "takeout_western_pizza": TASK_TYPE_ORDER,
    "express": TASK_TYPE_EXPRESS_STATUS,
    "electric_pay": TASK_TYPE_ELEC_PAY,
    "electric_check": TASK_TYPE_ELEC_CHECK,
    "phone_pay": TASK_TYPE_PHONE_PAY,
    "phone_check": TASK_TYPE_PHONE_CHECK,
    "di_di_quick": TASK_TYPE_DI_QUICK,
    "di_di_instant": TASK_TYPE_DI_INSTANT,
    # meal_order 和 travel_vehicle_park 需要特殊处理
    "meal_order": {"预约": TASK_TYPE_MEAL_OEDER, "排号": TASK_TYPE_MEAL_NUMBER},
    "travel_vehicle_park": {"ETC": TASK_TYPE_PARK_ETC, "FEE": TASK_TYPE_PARK_FEE},
}

# Query类型
QUERY_TYPE_CONFIRM = "confirm"
QUERY_TYPE_DENY = "deny"
QUERY_TYPE_SELECT = "select"
QUERY_TYPE_OTHER = "other"
QUERY_TYPE_HUMAN = "human"

# 取餐方式
PICKUP_LIST = ["自取", "外送"]
PICKUP_TERM_LIST = ["到家", "到学校", "到公司", "去拿", "去取", "店里"]

# Category
CATEGORY_LIST = ["咖啡", "奶茶", "果汁", "汉堡", "薯条", "炸鸡", "披萨", "意面", "沙拉", "比萨棒"]

# User回复话术
EXACT_CONFIRM_QUERY_LIST = [
    "好", "是", "对", "行",
    "好的", "是的", "对的", "行的", "嗯是", "好了", "就是",
    "好的的", "是的的", "对的的", "行的的",
    "好谢谢", "好的谢谢", "是谢谢", "是的谢谢", "对谢谢", "对的谢谢", "行谢谢", "行的谢谢", "嗯谢谢",
    "确定", "确认", "可以", "ok", "ok好", "ok好的", "嗯ok", "嗯对",
    "确定哦", "确认哦", "可以的", "就这个",
    # 否定
    "不确认", "不行", "不允许",
] + ["嗯"] * 5
EXACT_DENY_QUERY_LIST = ["不是", "不是这个", "no"]
CONFIRM_PREFIX_TERM_LIST = [
    "要", "想要", "我要", "我想要", "要个", "我想要个", "我想要一个", "我需要",
    "点", "想点", "我点", "我想点", "我要点", "帮我点", "给我点", "点个", "给我点个", "给我点一个", "请给我",
    "选", "想选", "我选", "我想选", "我要选", "帮我选", "给我选", "给我选个", "给我选一个", "请给我",
    "订", "想订", "我订", "我想订", "我要订",
    "定", "想定", "我定", "我想定", "我要定",
    "选择", "想选择", "我选择", "我想选择", "帮我选择", "给我选择", "给我选择个", "给我选择一个",
    "用", "使用", "设定为", "设置为",
]
CONFIRM_PREFIX_DRINK_TERM_LIST = ["喝", "想喝", "我喝", "我想喝", "我要喝"]
CONFIRM_PREFIX_EAT_TERM_LIST = ["吃", "想吃", "我吃", "我想吃", "我要吃"]
CONFIRM_SUFFIX_TERM_LIST = ["的"] * 6 + [
    "呀", "啊", "吧", "的吧",
    "那个", "就行", "就行了", "的那个", "的就行", "的就行了",
    "那个吧", "就行吧", "就行了吧", "的那个吧", "的就行吧", "的就行了吧",
]
COMMON_CONTINUE_QUERY_LIST = [  # 简单话术 + resume冲突话术 + cancel冲突话术
    "继续", "继续点单",  "不继续点单", "取消", "取消点单", "退出吧"
] * 10 + [  # 泛化话术
    "不了", "不买了", "不想买了", "可以",
    "不想点了", "不想要了", "不想订了", "不点了", "不要了", "不订了",
    "不需要", "不需要了", "我不需要了", "我不买了", "我不点了", "我不要了", "我不订了",
    "对不起不想买了", "对不起不想点了", "对不起不想要了", "对不起不想订了",
]
PICKUP_CONTINUE_QUERY_LIST = [
    "一会去取", "一会去取哈", "一会去喝", "一会去店里取", "一会去店里拿", "一会取", "一会拿", "去店里吃",
    "我一会儿去店里拿吧", "我一会去吃", "我一会取", "我一会拿",
    "我去", "我去店里喝", "我去拿", "我在店里喝", "我想去门店取", "我想去门店取货", "我等下去拿",
    "我马上到店", "我马上去取", "立马去拿", "自己去吃", "自己去拿", "这就去取",
] + ["继续点单", "确认点单", "确定点单", "取消点单"] * 10  # 冲突话术
COMMON_CONTINUE_ORDER_QUERY_LIST = [
    "继续", "继续提交", "继续订单", "继续提交订单", "帮我继续提交", "赶紧点单吧", "赶快提交吧", "帮我提交订单", "帮我继续订单", "帮我继续提交订单",
    "在小程序里帮我继续订单", "在小程序里帮我继续提交订单",
    "继续点单", "继续提交点单", "帮我提交点单", "帮我继续点单", "帮我继续提交点单",
    "在小程序里帮我继续点单", "在小程序里帮我继续提交点单",
]

EXPRESS_TYPE_QUERY_LIST = [
    "我收的", "我的寄件", "我寄的", "我退的", "我关注的", "我的收件", "我的退件", "我的关注",
    "我寄出的", "我的寄出", "还没寄出的", "还没支付的",
]

# Assistant通知话术
NOTIFY_ORDER_SUCCESS = ["下单成功", "已为您下单"]
NOTIFY_ORDER_PROGRESS = [
    "您的订单正在制作中", "订单制作中",
    "您的订单制作完成，骑手取货中", "骑手取货中",
    "您的订单正在配送中", "订单配送中",
    "您的订单还有10分钟送达", "还有5分钟送达",
]
NOTIFY_NUMBER_SUCCESS = ["预约成功", "已为您排号"]
NOTIFY_NUMBER_PROGRESS = ["正在排号中", "还剩下五桌到您", "还剩下十桌到您"]
NOTIFY_EXPENSES_SUCCESS = ["缴费成功", "已为您缴费"]
NOTIFY_EXPENSES_PROGRESS = ["正在支付中", "支付完成", "费用缴纳完毕"]
NOTIFY_DICT = {
    "drink_coffee": {"SUCCESS": NOTIFY_ORDER_SUCCESS, "PROGRESS": NOTIFY_ORDER_PROGRESS},
    "drink_tea": {"SUCCESS": NOTIFY_ORDER_SUCCESS, "PROGRESS": NOTIFY_ORDER_PROGRESS},
    "takeout_western_hamburger": {"SUCCESS": NOTIFY_ORDER_SUCCESS, "PROGRESS": NOTIFY_ORDER_PROGRESS},
    "takeout_western_pizza": {"SUCCESS": NOTIFY_ORDER_SUCCESS, "PROGRESS": NOTIFY_ORDER_PROGRESS},
    "takeout_korean": {"SUCCESS": NOTIFY_ORDER_SUCCESS, "PROGRESS": NOTIFY_ORDER_PROGRESS},
    "takeout_chinese": {"SUCCESS": NOTIFY_ORDER_SUCCESS, "PROGRESS": NOTIFY_ORDER_PROGRESS},
    "meal_order": {"SUCCESS": NOTIFY_NUMBER_SUCCESS, "PROGRESS": NOTIFY_NUMBER_PROGRESS},
    "express": {"SUCCESS": [], "PROGRESS": []},
    "travel_vehicle_park": {"SUCCESS": [], "PROGRESS": []},
    "travel_vehicle_charge": {"SUCCESS": [], "PROGRESS": []},
    "living_expenses": {"SUCCESS": NOTIFY_EXPENSES_SUCCESS, "PROGRESS": NOTIFY_EXPENSES_PROGRESS},
}

# 隐私协议话术
PRIVACY_AGREEMENT_ASSISTANT_LIST = [
    "请问您是否同意隐私协议？",
    "使用支付宝需要同意用户协议哦，请问你同意吗？",
    "使用支付宝需要申请必要权限哦，请问你同意吗？",
    "要继续点单的话，需要同意用户协议哦，请问你同意吗",
    "请阅读温馨提示，请确认是否同意？",
]
PRIVACY_AGREEMENT_DIDI_ASSISTANT_LIST = ["使用滴滴代驾需要授权你的账号信息，请问你同意吗"]
PRIVACY_AGREEMENT_ASSISTANT_FOR_SPECIAL_SCENE = {
    "电费-查询": ["继续查询的话,需要你登录支付宝账号,请问你同意吗?"],
    "电费-缴费": ["继续缴费的话,需要你登录支付宝账号,请问你同意吗?"],
    "滴滴-代驾": PRIVACY_AGREEMENT_DIDI_ASSISTANT_LIST,
    "滴滴-一键": PRIVACY_AGREEMENT_DIDI_ASSISTANT_LIST,
}
# 位置协议话术
LOCATION_AGREEMENT_ASSISTANT_LIST = [
    "是否允许获取你的位置信息？",
    "需要同意位置权限，请问你同意吗？",
    "申请获取你的位置信息，请问你允许吗？",
    "支付宝申请获取你的位置信息，请问你允许吗？",
    "请问您允许还是拒绝获取您的位置信息请求？",
    "需要开启位置服务才能授予位置权限，请问可以开启吗？",
    "要继续点单的话，需要同意位置权限申请哦，请问你同意吗",
    "支付宝申请位置权限，请问你要“允许一年”、“允许本次”还是“不允许”？",
    "支付宝王申请向你发送活动提醒消息，请问你同意吗",
]
LOCATION_AGREEMENT_DIDI_ASSISTANT_LIST = ["使用滴滴代驾需要授权位置信息，请问你同意吗"]
# 协议回复话术
AGREEMENT_USER_LIST = [
    "同意", "同意吧", "同意呀", "同意啊", "不同意", "我同意", "我不同意", "同意一年", "同意本次",
    "允许", "允许啊", "不允许",  "允许一年", "允许本次", "我没意见",
    "开启", "开启吧", "不开启", "开启一年", "开启本次",
    "拒绝", "我拒绝", "算了吧", "不弄了", "不了", "不整了", "别了", "一会再说",
    "不行", "不行啊", "否", "我不太想",
    # cancel冲突话术
    "取消", "取消吧", "取消呀", "取消啊",
]

# 电话号码询问话术
PHONENUMBER_ASSISTANT_DICT = {
    "话费-查询": "要查询当前号码话费余额吗",
    "话费-缴费": "要为当前号码充值话费吗",
}
PHONENUMBER_USER_LIST = [
    "好", "是", "对", "行",
    "好的", "是的", "对的", "行的", "嗯是", "好了", "就是",
    "好的的", "是的的", "对的的",
    "是谢谢", "是的谢谢", "对谢谢", "对的谢谢",
    "确定", "确认", "可以", "嗯ok", "嗯对",
    "确定哦", "确认哦", "可以的", "就这个",
    "不是", "不对"]
WHICHNUMBER_ASSISTANT_DICT = {
    "话费-查询": "请说出想要查询的号码",
    "话费-缴费": "请说出想要充值的号码",
}
# 代驾地址询问话术
STRAT_LOCALTION_CHECK_ASSISTANT_LIST = ["从当前定位出发，告诉我终点地址吧；你也可以跟我说修改起点"]
STRAT_LOCALTION_ASSISTANT_LIST = ["告诉我起点地址吧"]
FINAL_LOCALTION_ASSISTANT_LIST = ["告诉我终点地址吧"]
FINAL_LOCALTION_2_ASSISTANT_LIST = ["未预设地址，直接告诉我终点地址吧"]
COMMON_LOCATION_USER_LIT = [
    "公司", "我家", "火车站", "机场", "地铁站", "医院",
    "学校", "酒店", "公园", "体育馆", "咖啡馆", "电影院", "KTV",
    "图书馆", "超市", "博物馆",
]

# 代驾类型询问话术
SERVER_TYPT_ASSISTANT_LIST = ["你要选择哪种代驾？ 也可以跟我说立即呼叫"]
SERVER_TYPT_USER_LIST = ["当前勾选", "特惠代驾", "滴滴代驾", "青桔代驾", "星享代驾", "默认", "全选", "最便宜"] + ["立即呼叫"] * 3 + ["全部"] * 10

# 取餐时间话术
TAKE_ORDER_TIME_ASSISTANT_LIST = [
    "选择取单时间",
    "您要什么时候取单呢",
    "请问您预计几点来取单",
    "请问您什么时候方便过来取单",
    "您的取单时间是什么时候",
    "请问大概多长时间后取单呢",
]
TAKE_ORDER_TIME_USER_LIST = [
    "一会就行", "一会去拿", "一会", "等下我去取", "我一会去",
    "马上", "我现在就过去", "立刻", "我现在就来取", "我马上就到", "现在", "现在就去拿",
    "五分钟后取", "十分钟后取", "二十分钟后取", "五分钟后取餐", "十分钟后取餐", "二十分钟后取餐",
    "立即取单", "即刻取单", "马上取单",
]

CHARGE_AMOUNT_ELECTRIC_ASSISTANT_LIST = ["你要为当前户号充多少电费呢"]
CHARGE_AMOUNT_PHONE_ASSISTANT_LIST = ["你要选择哪个充值金额呢"]
CHARGE_AMOUNT_ASSISTANT_DICT = {
    "电费-查询": CHARGE_AMOUNT_ELECTRIC_ASSISTANT_LIST,
    "电费-缴费": CHARGE_AMOUNT_ELECTRIC_ASSISTANT_LIST,
    "话费-缴费": CHARGE_AMOUNT_PHONE_ASSISTANT_LIST,
}

# 其他需求话术
OTHER_DEMAND_DEFAULT_ASSISTANT_LIST = ["您还有其他要求吗", "您还有其他需求吗", "请问您还需要选择其他的嘛"]
OTHER_DEMAND_DEFAULT_USER_LIST = [
    "没有", "没有了", "没有要求", "没有需求", "没有其他要求", "没有其他需求", "没有其他要求了", "没有其他需求了"
]
OTHER_DEMAND_EXPRESS_ASSISTANT_LIST = ["是否还需要查看其它类型快递信息"]
OTHER_DEMAND_EXPRESS_USER_LIST = [
    "不需要了", "不需要", "不需要查看了", "查看收件", "收件", "再查看下收件", "寄件", "查看寄件", "再查看下寄件",
    "不需要查看", "查看寄出信息", "查看收到信息", "查看关注信息", "查看收件信息", "查看寄退信息",
    "不一定需要检查了", "不再看也行了", "不再确认也可以了", "不必再确认了",
    "不用再查看了吧", "不用再看了", "不用再确认一遍了", "不用再确认了", "不用查了吧", "不用核对了", "不用检查也没关系", "不用检查了",
    "不需要再查了", "不需要再确认了", "可以不用查看了", "好像可以不用看了", "完全不需要查看了", "完全可以不用看了",
    "就不用再看了", "就别查了吧", "就放着不看了吧", "应该不用再看了", "忽略也可以了", "忽略查看吧",
    "无需再核对了", "无需再看了", "无需再费力查看了", "无需再重复查看了", "无需查了", "查不查都没事了",
    "查也可以先不查了", "查也没必要了吧", "查看就不需要了", "检查就不需要了吧", "没必要再查了", "没必要再看了", "没有必要再核对了",
    "省掉查看吧", "看一下可能也不用了", "看与不看都行了", "确认啥的就省了吧", "确认就不需要了吧",
    "这就不用再核对了吧", "这次不用再看了",
] + ["我的寄件"] * 5 + [f"继续查看{item}" for item in ["我收的", "我寄的", "我退的", "我关注的"]]
OTHER_DEMAND_ELECTRIC_ASSISTANT_LIST = ["是否还需要为当前户号充电费呢"]
OTHER_DEMAND_ELECTRIC_USER_LIST = [
    "不需要", "不需要了", "我不需要了", "暂时不用", "先不用", "先这样吧",
    "是", "是的", "否", "需要", "我需要",
]
OTHER_DEMAND_ASSISTANT_DICT = {
    "茶饮": OTHER_DEMAND_DEFAULT_ASSISTANT_LIST,
    "快餐": OTHER_DEMAND_DEFAULT_ASSISTANT_LIST,
    "快递": OTHER_DEMAND_EXPRESS_ASSISTANT_LIST,
    "电费-查询": OTHER_DEMAND_ELECTRIC_ASSISTANT_LIST,
}
OTHER_DEMAND_USER_DICT = {
    "茶饮": OTHER_DEMAND_DEFAULT_USER_LIST,
    "快餐": OTHER_DEMAND_DEFAULT_USER_LIST,
    "快递": OTHER_DEMAND_EXPRESS_USER_LIST,
    "电费-查询": OTHER_DEMAND_ELECTRIC_USER_LIST,
}

# 下单前确认隐私条款
FINAL_ORDER_CONFIRM_ASSISTANT_LIST = [
    "下单之前，需要同意条款哦，请问你同意吗",
    "继续点单的话，需要同意条款哦，请问你同意吗",
    "下单前要先同意隐私协议，请问你同意吗",
    "下单前要先同意隐私协议，同意吗？",
    "继续点单要先同意隐私协议，同意吗？",
    "继续点单的话，需要通过订单服务信息授权页哦，请问你同意吗",
]
# 下单前确认登录
FINAL_ORDER_LOGIN_ASSISTANT_LIST = [
    "继续点单，需要登录支付宝账号哦，你同意吗",
    "继续点单的话，需要登录支付宝账号哦，你同意吗",
    "如果继续点单，需要登录支付宝账号哦，你同意吗",
    "继续点单的话，需要支付宝账号登录会员哦，请问你同意吗",
    "继续点单的话，需要获取你的手机号码哦，请问你同意吗",
]
# 最终下单话术
FINAL_ORDER_ASSISTANT_LIST = [
    "请问是否下单",
    "请问是否立即下单",
    "请问是否支付",
    "请问是否开始支付",
    "是否确认支付订单？",
    "请核对订单信息，是否提交订单？",
    "我已经帮你点好啦，立即支付吗？",
    "我已经帮您点好啦，立即支付吗？",
    "我已经帮您点好啦，请问是否支付？",
    "我已经帮你点好啦，是否立即支付？",
    "已完成点单流程，请问你同意支付订单吗？",
    "我已经帮你点好啦，想让我帮你下单的话，请说立即支付",
    "我已经帮你点好啦，想让我帮你下单的话，请说立即下单",
    "我已经帮你点好啦，想让我帮你下单的话，请说提交订单",
]
FINAL_ORDER_USER_LIST = [
    "继续", "可以", "同意", "退出", "不同意", "立即同意", "不立即同意", "确认同意",
    "下单", "不下单", "立即下单", "不立即下单", "确认下单", "同意下单", "不同意下单",
    "支付", "不支付", "立即支付", "不立即支付", "确认支付", "同意支付", "不同意支付",
    "下单下单", "确认下单、下单", "同意下单，下单",
    "支付支付", "确认支付，支付", "同意支付、支付",
]
FINAL_ORDER_ELECTRIC_ASSISTANT_LIST = ["为当前户号交费{amount}元,确认支付吗?", "为当前户号交费{amount}元,确认交费吗?"]
FINAL_ORDER_PHONE_ASSISTANT_LIST = ["为尾号{tail_number}号码充值{amount}元,确认支付吗", "为尾号{tail_number}号码充值{amount}元,确认充值吗"]
FINAL_ORDER_DIDI_ASSISTANT_LIST = ["当前需要预付车费，立即支付吗"]
FINAL_ORDER_PHONE_USER_LIST = ["充值", "不充值", "立即充值", "不立即充值", "确认充值", "同意充值", "不同意充值",]
FINAL_ORDER_ASSISTANT_DICT = {
    "茶饮": FINAL_ORDER_ASSISTANT_LIST,
    "快餐": FINAL_ORDER_ASSISTANT_LIST,
    "电费-查询": FINAL_ORDER_ELECTRIC_ASSISTANT_LIST,
    "电费-缴费": FINAL_ORDER_ELECTRIC_ASSISTANT_LIST,
    "话费-缴费": FINAL_ORDER_PHONE_ASSISTANT_LIST,
    "滴滴-一键": FINAL_ORDER_DIDI_ASSISTANT_LIST,
    "滴滴-代驾": FINAL_ORDER_DIDI_ASSISTANT_LIST,
}
FINAL_ORDER_USER_DICT = {
    "茶饮": FINAL_ORDER_USER_LIST,
    "快餐": FINAL_ORDER_USER_LIST,
    "电费-查询": FINAL_ORDER_USER_LIST,
    "电费-缴费": FINAL_ORDER_USER_LIST,
    "话费-缴费": FINAL_ORDER_USER_LIST+FINAL_ORDER_PHONE_USER_LIST,
    "滴滴-一键": FINAL_ORDER_USER_LIST,
    "滴滴-代驾": FINAL_ORDER_USER_LIST,
}
# 冲突话术汇总
# CONFLICT_USER_QUERY_LIST = EXACT_CONFIRM_QUERY_LIST + AGREEMENT_USER_LIST + TAKE_ORDER_TIME_USER_LIST + \
#     OTHER_DEMAND_DEFAULT_USER_LIST + FINAL_ORDER_USER_LIST + \
#     COMMON_CONTINUE_QUERY_LIST + PICKUP_CONTINUE_QUERY_LIST + COMMON_CONTINUE_ORDER_QUERY_LIST + EXPRESS_TYPE_QUERY_LIST
CONFLICT_USER_QUERY_LIST = EXACT_CONFIRM_QUERY_LIST + AGREEMENT_USER_LIST + TAKE_ORDER_TIME_USER_LIST + \
    OTHER_DEMAND_DEFAULT_USER_LIST + FINAL_ORDER_USER_LIST

# 控制类工具-简单
CU_AGENT_CONTROL_TEMPLATE_DEFAULT = {
    TOOL_NAME_CU_AGENT_PAUSE: [
        "暂停小程序", "暂停小程序任务", "暂停小程序执行",
        "暂停操控小程序", "暂停操作小程序", "暂停执行小程序", "暂停cua", "暂停cua执行",
    ],
    TOOL_NAME_CU_AGENT_RESUME: [
        "继续小程序", "继续小程序任务", "继续小程序执行",
        "继续操控小程序", "继续操作小程序", "继续执行小程序",
        "恢复小程序", "恢复小程序任务", "恢复小程序执行",
        "恢复操控小程序", "恢复操作小程序", "恢复执行小程序",
        "继续执行CUA", "继续执行生活助手", "继续cua", "继续cua执行",
    ],
    TOOL_NAME_CU_AGENT_CANCEL: [
        "取消小程序", "取消小程序任务", "取消小程序执行", "取消cua", "取消cua执行",
        "取消操控小程序", "取消操作小程序", "取消执行小程序",
    ],
    TOOL_NAME_CU_AGENT_QUIT: [
        "退出小程序", "退出小程序任务", "退出小程序执行", "关闭小程序", "关闭cua", "关闭cua执行",
        "退出操控小程序", "退出操作小程序", "退出执行小程序",
    ]
}


def check_conflict(query):
    if query in CONFLICT_USER_QUERY_LIST:
        return True
    for term in CONFLICT_USER_QUERY_LIST:
        if term in query:
            return True
    return False
