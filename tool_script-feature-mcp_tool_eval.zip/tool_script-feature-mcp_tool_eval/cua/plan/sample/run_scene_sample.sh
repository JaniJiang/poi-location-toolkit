#!/bin/bash
# bash cua/plan/sample/run_scene_sample.sh

# P0场景
python -m cua.plan.sample.scene_sample.scene_drink_coffee
python -m cua.plan.sample.scene_sample.scene_drink_tea
python -m cua.plan.sample.scene_sample.scene_takeout_western_hamburger
python -m cua.plan.sample.scene_sample.scene_takeout_western_pizza
python -m cua.plan.sample.scene_sample.scene_meal_order
python -m cua.plan.sample.scene_sample.scene_express
python -m cua.plan.sample.scene_sample.scene_travel_vehicle_park

# 新增生活缴费以及代驾场景
python -m cua.plan.sample.scene_sample.scene_electric_check
python -m cua.plan.sample.scene_sample.scene_electric_pay
python -m cua.plan.sample.scene_sample.scene_phone_check
python -m cua.plan.sample.scene_sample.scene_phone_pay
python -m cua.plan.sample.scene_sample.scene_didi_quick
python -m cua.plan.sample.scene_sample.scene_didi_instant

# P1场景
# python -m cua.plan.sample.scene_sample.scene_takeout_korean
# python -m cua.plan.sample.scene_sample.scene_takeout_chinese
# python -m cua.plan.sample.scene_sample.scene_travel_vehicle_charge
# python -m cua.plan.sample.scene_sample.scene_living_expenses
