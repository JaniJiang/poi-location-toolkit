import json
import re
from typing import List
from cua.plan.sample.tool import *
from cua.plan.sample.scene import *
from cua.plan.sample.func import reorder_dict_items

# SYSTEM_PROMPT_V1
SYSTEM_PROMPT_V1 = f"""你要进行一个语言理解任务。
# Tools
## Functions
{TOOL_STRING_V1}"""

# SYSTEM_PROMPT_V2
SYSTEM_PROMPT_V2 = f"""你要进行一个语言理解任务，给你一段用户和语音助手的对话流，最后一轮表示新的发话，请判断用户新的发话是否想要参与历史对话流。
# Tools
## Functions
{TOOL_STRING_V2}"""

# SYSTEM_PROMPT_V3
SYSTEM_PROMPT_V3 = f"""你在进行场景规划任务，根据场景对话历史和当前用户问题，判断用户意图并规划到对应Function。
# Tools
## Functions
{TOOL_STRING_V3}"""

# SYSTEM_PROMPT_V4
SYSTEM_PROMPT_V4 = f"""你在进行场景规划任务，根据场景对话历史和当前用户问题，判断用户意图并规划到对应Function。
# Tools
## Functions
{TOOL_STRING_V4}"""

# SYSTEM_PROMPT_V5
SYSTEM_PROMPT_V5 = f"""你在进行对话场景规划任务，给你一段用户和助手的对话流，最后一轮表示用户新的发话，基于用户新的发话、判断用户意图并规划到对应Function。
# Tools
## Functions
{TOOL_STRING_V5}"""

# SYSTEM_PROMPT
SYSTEM_PROMPT = SYSTEM_PROMPT_V4

# Prompt类型
PROMPT_TYPE = "instruction"  # instruction | messages
# Prompt版本
PROMPT_VERSION = "v4"  # v1 | v2 | v3 | v4 | v5
# special_token类型
SPECIAL_TOKEN_TYPE = "mindgpt"  # mindgpt | qwen


def build_prompt(conversations, feature_dict={}):
    if PROMPT_TYPE == "instruction":
        return build_instruction(conversations, feature_dict)
    elif PROMPT_TYPE == "messages":
        return build_messages(conversations, feature_dict)
    else:
        raise ValueError(f"Prompt类型[{PROMPT_TYPE}]不存在")


def build_messages(conversations, feature_dict):
    if PROMPT_VERSION == "v4":
        return build_messages_v4(conversations)
    else:
        raise ValueError(f"Prompt版本[{PROMPT_VERSION}]不存在")


def build_messages_v4(conversations):
    """第4版messages"""
    # TODO: 待实现
    return


def build_instruction(conversations, feature_dict):
    if PROMPT_VERSION == "v1":
        return build_instruction_v1(conversations)
    elif PROMPT_VERSION == "v2":
        return build_instruction_v2(conversations)
    elif PROMPT_VERSION == "v3":
        return build_instruction_v3(conversations)
    elif PROMPT_VERSION == "v4":
        return build_instruction_v4(conversations)
    elif PROMPT_VERSION == "v5":
        return build_instruction_v5(conversations, feature_dict)
    else:
        raise ValueError(f"Prompt版本[{PROMPT_VERSION}]不存在")


def build_instruction_v1(conversations):
    """第1版instruction"""
    instruction = ""
    output = ""
    if len(conversations) == 0:
        return instruction, output
    has_system_role = False
    for conversation in conversations:
        role = conversation["role"]
        content = conversation["content"]
        if role == "system":
            has_system_role = True
            instruction += buile_role_prompt(role, SYSTEM_PROMPT_V1)
        elif role in ["user", "assistant"]:
            instruction += buile_role_prompt(role, content)
        elif role == "tool":
            output = content
    # 兼容没有传SYSTEM_PROMPT的情况
    if has_system_role is False:
        instruction = buile_role_prompt("system", SYSTEM_PROMPT_V1) + instruction
    return instruction, output.strip()


def build_instruction_v2(conversations):
    """第2版instruction"""
    instruction = ""
    output = ""
    if len(conversations) == 0:
        return instruction, output
    has_system_role = False
    for conversation in conversations:
        role = conversation["role"]
        content = conversation["content"]
        if role == "system":
            has_system_role = True
            instruction += buile_role_prompt(role, SYSTEM_PROMPT_V2)
        elif role in ["user", "assistant"]:
            instruction += buile_role_prompt(role, content)
        elif role == "tool":
            arguments = conversation.get("arguments", {})
            output = build_tool_prompt_v2(content, arguments)
    # 兼容没有传SYSTEM_PROMPT的情况
    if has_system_role is False:
        instruction = buile_role_prompt("system", SYSTEM_PROMPT_V2) + instruction
    return instruction, output.strip()


def build_instruction_v3(conversations):
    """第3版instruction"""
    instruction = ""
    output = ""
    if len(conversations) == 0:
        return instruction, output
    has_system_role = False
    for conversation in conversations:
        role = conversation["role"]
        content = conversation["content"]
        if role == "system":
            has_system_role = True
            instruction += buile_role_prompt(role, SYSTEM_PROMPT_V3)
        elif role in ["user", "assistant"]:
            instruction += buile_role_prompt(role, content)
        elif role == "tool":
            arguments = conversation.get("arguments", {})
            output = build_tool_prompt_v3(content, arguments)
    # 兼容没有传SYSTEM_PROMPT的情况
    if has_system_role is False:
        instruction = buile_role_prompt("system", SYSTEM_PROMPT_V3) + instruction
    return instruction, output.strip()


def build_instruction_v4(conversations):
    """第4版instruction"""
    instruction = ""
    output = ""
    if len(conversations) == 0:
        return instruction, output
    has_system_role = False
    for conversation in conversations:
        role = conversation["role"]
        content = conversation["content"]
        if role == "system":
            has_system_role = True
            instruction += buile_role_prompt(role, SYSTEM_PROMPT_V4)
        elif role in ["user", "assistant"]:
            instruction += buile_role_prompt(role, content)
        elif role == "tool":
            arguments = conversation.get("arguments", {})
            output = build_tool_prompt_v4(content, arguments)
    # 兼容没有传SYSTEM_PROMPT的情况
    if has_system_role is False:
        instruction = buile_role_prompt("system", SYSTEM_PROMPT_V4) + instruction
    return instruction, output.strip()


def build_instruction_v5(conversations, feature_dict):
    """第5版instruction"""
    instruction = ""
    output = ""
    if len(conversations) == 0:
        return instruction, output
    has_system_role = False
    pre_arguments = {}
    last_user_content = ""
    last_assistent_content = ""
    for conversation in conversations:
        role = conversation["role"]
        content = conversation["content"]
        arguments = conversation.get("arguments", {})
        if role == "system":
            has_system_role = True
            instruction += buile_role_prompt(role, SYSTEM_PROMPT_V5)
        elif role == "user":
            instruction += buile_role_prompt(role, content)
            last_user_content = content
        elif role == "assistant":
            instruction += buile_role_prompt(role, content)
            last_assistent_content = content
        elif role == "tool":
            output = build_tool_prompt_v5(last_user_content, last_assistent_content, content,
                                          arguments, pre_arguments, feature_dict)
        pre_arguments.update(arguments)
    # 兼容没有传SYSTEM_PROMPT的情况
    if has_system_role is False:
        instruction = buile_role_prompt("system", SYSTEM_PROMPT_V5) + instruction
    return instruction, output.strip()


def get_special_token():
    start_token = "<|im_start|>" if SPECIAL_TOKEN_TYPE == "qwen" else "[unused0]"
    end_token = "<|im_end|>" if SPECIAL_TOKEN_TYPE == "qwen" else "[unused1]"
    return start_token, end_token


def get_think_special_token():
    think_start_token = "<think>"
    think_end_token = "</think>"
    return think_start_token, think_end_token


def buile_role_prompt(role, content):
    start_token, end_token = get_special_token()
    return f"{start_token}{role}\n{content}{end_token}\n"


def build_tool_prompt_v2(tool_name, arguments):
    _, end_token = get_special_token()
    tool_desc = TOOL_DICT_V2[tool_name]
    function_list = [{"thought": tool_desc, "name": tool_name, "arguments": arguments}]
    function_str = json.dumps(function_list, ensure_ascii=False)
    return f"```function_call\n{function_str}\n```{end_token}"


def build_tool_prompt_v3(tool_name, arguments):
    _, end_token = get_special_token()
    tool_desc = TOOL_DICT_V3[tool_name]
    function_list = [{"thought": tool_desc, "name": tool_name, "arguments": arguments}]
    function_str = json.dumps(function_list, ensure_ascii=False)
    return f"```function_call\n{function_str}\n```{end_token}"


def build_tool_prompt_v4(tool_name, arguments):
    _, end_token = get_special_token()
    tool_desc = TOOL_DICT_V4[tool_name]
    reordered_dict = reorder_dict_items(arguments)
    function_list = [{"thought": tool_desc, "name": tool_name, "arguments": reordered_dict}]
    function_str = json.dumps(function_list, ensure_ascii=False)
    return f"```function_call\n{function_str}\n```{end_token}"


def build_tool_prompt_v5(user_content, assistent_content, tool_name, arguments, pre_arguments, feature_dict):
    _, end_token = get_special_token()
    think_start_token, think_end_token = get_think_special_token()
    tool_desc = TOOL_DICT_V5[tool_name]
    function_list = [{"thought": tool_desc, "name": tool_name, "arguments": arguments}]
    function_str = json.dumps(function_list, ensure_ascii=False)
    think_str = build_think(user_content, assistent_content, tool_name,
                            tool_desc, arguments, pre_arguments, feature_dict)
    return f"{think_start_token}{think_str}{think_end_token}\n```function_call\n{function_str}\n```{end_token}"


brand2scene_dict = get_brand2scene_dict()


def build_think(user_content, assistent_content, tool_name, tool_desc, arguments, pre_arguments, feature_dict):
    hidden_feature = feature_dict["hidden_feature"]
    hidden_brand = hidden_feature["brand"]
    scene_name = brand2scene_dict[hidden_brand].split("-", 1)[0]
    real_brand = pre_arguments.get("appName", "")
    think_str = f"对话流是{scene_name}场景"
    if real_brand != "":
        think_str += f"，用户在使用{real_brand}"
    if tool_name == TOOL_NAME_CU_AGENT_START:
        task_type = arguments.get("taskType", "")
        app_name = arguments.get("appName", "")
        if assistent_content != "":
            think_str += f"；但是用户新的发话[{user_content}]没有回答助手的问题[{assistent_content}]，而是重新开始{task_type}"
            if app_name != "":
                think_str += f"，使用的是{app_name}"
        else:
            think_str += f"；但是用户新的发话[{user_content}]没有上文"
    elif tool_name == TOOL_NAME_CU_AGENT_CONTINUE:
        think_str += f"；并且用户新的发话[{user_content}]回答了助手的问题[{assistent_content}]，仍然在{scene_name}场景"
        if real_brand != "":
            think_str += f"使用{real_brand}"
    elif tool_name == TOOL_NAME_QASEARCH:
        think_str += f"；但是用户新的发话[{user_content}]没有回答助手的问题[{assistent_content}]，而是提出和场景有一定关系的其他问题"
    elif tool_name == TOOL_NAME_OTHER:
        think_str += f"；但是用户新的发话[{user_content}]没有回答助手的问题[{assistent_content}]，回答和问题完全无关"
    elif tool_name == TOOL_NAME_CU_AGENT_PAUSE:
        think_str += f"；但是用户新的发话[{user_content}]没有回答助手的问题[{assistent_content}]，而是提出要暂停场景"
    elif tool_name == TOOL_NAME_CU_AGENT_RESUME:
        think_str += f"；但是用户新的发话[{user_content}]没有回答助手的问题[{assistent_content}]，而是提出要继续或恢复场景"
    elif tool_name == TOOL_NAME_CU_AGENT_CANCEL:
        think_str += f"；但是用户新的发话[{user_content}]没有回答助手的问题[{assistent_content}]，而是提出要取消场景"
    elif tool_name == TOOL_NAME_CU_AGENT_QUIT:
        think_str += f"；但是用户新的发话[{user_content}]没有回答助手的问题[{assistent_content}]，而是提出要退出场景"
    else:
        raise ValueError(f"工具名称[{tool_name}]不存在")
    think_str += f"；因此，属于{tool_desc}，规划到{tool_name}。"
    return think_str


def prompt2dialog(prompt: str) -> str:
    start_token, end_token = get_special_token()
    parts = prompt.split(start_token)
    dialog_list = []
    for part in parts:
        if part.startswith("system"):
            continue
        part = part.replace(end_token, "").strip()
        if not part:
            continue
        if part.startswith("user"):
            content = part[4:].strip()
            dialog_list.append(f"user: {content}")
        elif part.startswith("assistant"):
            content = part[9:].strip()
            dialog_list.append(f"assistant: {content}")
    return "\n".join(dialog_list)


def dialog2prompt(dialog_str: str) -> str:
    conversations = dialog2conversations(dialog_str)
    prompt, _ = build_prompt(conversations)
    return prompt


def dialog2conversations(dialog_str: str) -> List[Dict[str, str]]:
    dialog_list = dialog_str.strip().split("\n")
    conversations = []
    for one_str in dialog_list:
        one_segs = one_str.split(": ")
        conversations.append({"role": one_segs[0], "content": one_segs[1]})
    return conversations


def conversations2dialog(conversations: List[Dict[str, str]]) -> str:
    dialog_list = []
    for conversation in conversations:
        role = conversation["role"]
        content = conversation["content"]
        if role not in ["user", "assistant"]:
            continue
        dialog_list.append(f"{role}: {content}")
    return "\n".join(dialog_list)


def prompt2conversations(prompt: str) -> List[Dict[str, str]]:
    start_token, end_token = get_special_token()
    parts = prompt.split(start_token)
    conversations = []
    for part in parts:
        part = part.replace(end_token, "").strip()
        if part == "":
            continue
        for role in ["system", "user", "assistant"]:
            if part.startswith(role) is True:
                content = part[len(role):].strip()
                conversations.append({"role": role, "content": content})
                break
    return conversations


def fill_template_with_label_defnition(template, label_definition, arguments_definition=None, task=None):
    """
    用给定的类别定义内容填充模板字符串中的占位符。
    Args:
        template (str): 包含占位符的原始模板字符串。
        label_definition (str): 要填充到占位符位置的类别定义内容。
        arguments_definition (str): 槽位定义
        task (str): 当前使用模板的任务,可取值["log_process"]
    Returns:
        str: 填充了类别定义后的新字符串。
    """
    compiled_placeholder = re.compile(r'\[任务描述占位符\]')
    # 使用 sub 方法进行替换
    if task == "log_process":
        filled_str = compiled_placeholder.sub(label_definition, template)
    else:
        filled_str = compiled_placeholder.sub(arguments_definition.strip()+label_definition, template)
    return filled_str


# 不同类别定义
Arguments_definition = """
**arguments 字段定义**：
arguments内容要求：仅 "cu_agent_start" 和中断类 (pause/cancel/quit/resume)可能不为空字典,其余一定为空字典{}。
**arguments 内字段定义**: 
"appName": "小程序名称,取值必须在["星巴克", "蜜雪冰城", "霸王茶姬", "古茗", "喜茶", "瑞幸咖啡","肯德基", "麦当劳", "华莱士", "塔斯汀", "汉堡王", "达美乐", "必胜客","美味不用等","捷停车", "支付宝停车", "ETCP停车", "停简单", "乐速通", "ETC服务","支付宝我的快递", "菜鸟裹裹", "中通快递", "圆通快递", "申通快递", "EMS中国邮政速递物流", "顺丰速运", "韵达快递"]
"taskType": "当前任务类型,取值必须在["点单", "查询订单进展", "排号", "预约定座", "停车缴费", "查询ETC账单", "查询快递进展"]
arguments示例: "arguments": {"appName": "星巴克", "taskType": "点单"}
"""
Label_definition = """
**场景范畴**：
当前有且仅有这些场景：["点单", "查询订单进展", "排号", "预约定座", "停车缴费", "查询ETC账单", "查询快递进展"]
**分类名称**
当前只有8个类别分别为: cu_agent_start, cu_agent_continue, cu_agent_pause, cu_agent_cancel, cu_agent_resume, cu_agent_quit, qasearch, other
**分类定义**
1. cu_agent_continued定义：最新话语是回复助手提出的上一个问题（肯定或否定），或者是在已开始的任务中提供与场景相关的实体信息（如餐厅名、菜品）。
2. cu_agent_start定义：最新话语开始或重复开始一个场景任务。
3. cu_agent_pause/cancel/resume/quit：最新话语为[某种控制方式] + [明确的控制对象]。
控制方式：暂停, 取消, 继续(恢复), 退出。
控制对象：必须是小程序（或具体名称）、cua、点单或查询。没有控制对象或控制对象不在规定范围内，则归为other。
4. qasearch：最新话语为与场景有关的提问，但不属于上面cu_agent_start的特殊提问。
5. other：最新话语无法归于其他类（包括答非所问，语义不清，与场景范畴中任何场景无关/超出场景范畴等）或是仅有控制方式无控制对象（或控制对象不在规定范围内）的话语。
**该任务对于other的召回准确率要求较高一定要将超出场景范围的判为other。
**补充信息**
- “啡快”、“专星送” 是星巴克配送方式,"幸运送"是瑞幸咖啡的配送方式。
- 霸王茶姬是一家以传统文化为特色的奶茶店，其奶茶名称通常非常独特，很多名字取自古诗词、成语或文学作品，如“伯牙绝弦”、“木兰辞”等。
- 理想同学为语音助手的代理名称
- 餐厅取号或者预约座位任务默认appName为美味不用等
"""

# Qwen3 Prompt配置
instruction_template = """
**任务输入**
你将接收如下的json格式输入：
{
    "对话历史": 过去对话历史(字符串形式,从旧到新),你需要关注最近助手的提问是什么问题和最近是什么场景。,
    "最新话语": 用户的最新话语(字符串)
}
**输出要求**
请先说明你分类的理由再由json格式输出你最终对样本的分类结果,以及提取出的参数arguments结果。
示例：
最新话语"帮我买一份麦当劳的汉堡",为开始"餐饮订购"这一场景,符合cu_agent_start原则, 因此归类为cu_agent_start。并从最新话语中抽取appName为麦当劳，taskType为点单。{"tool_label": "cu_agent_start", "arguments": {"appName": "麦当劳", "taskType": "点单"}}
[任务描述占位符]
"""

Qwen3_Prompt = {
    "system": "你是一个专业的文本分类专家，需要根据对话历史和最新话语，准确判断用户意图，并将其归类到以下八个类别之一。请严格遵守分类定义，输出标准化的 JSON 结果。",
    "instruction": fill_template_with_label_defnition(instruction_template, Label_definition, Arguments_definition),
}

if __name__ == "__main__":
    conversations = [
        {"role": "user", "content": "点一杯星巴克咖啡"},
        {"role": "assistant", "content": "请选择配送方式"},
        {"role": "user", "content": "自取"},
    ]
    prompt, _ = build_prompt(conversations)
    print(f"\n[build_prompt]:\n{prompt}")
    # prompt2dialog
    dialog = prompt2dialog(prompt)
    print(f"\n[prompt2dialog]:\n{dialog}")
    # dialog2prompt
    prompt = dialog2prompt(dialog)
    print(f"\n[dialog2prompt]:\n{prompt}")
    # prompt2conversations
    conversations = prompt2conversations(prompt)
    print(f"\n[prompt2conversations]:\n{json.dumps(conversations, ensure_ascii=False)}")

# python -m cua.plan.sample.prompt
