import random
import statistics
from typing import List
from loguru import logger
import pandas as pd
from cn2an import an2cn
from faker import Faker
from phone_gen import PhoneNumber
from faker.providers.address.zh_CN import Provider as AddressProvider
from collections import defaultdict
from utils.data_utils.int_utils import num_to_chinese
from cua.plan.sample.meta import *
from cua.plan.sample.tool import *
from cua.plan.sample.merge_sample.extend_data import chinese_digits, user_response

# 设置随机数种子
my_random = random.Random()
my_random.seed(42)

# 实例化生成随机数据类
fake = Faker("zh_CN")
phonegen = PhoneNumber("CN")
AddressProvider.building_number_formats = ["{num}号", "{num}栋", "{num}单元", "{num}座", "{num}楼"]

CITY_LIST = ["上海", "北京", "广州", "深圳", "成都", "杭州", "武汉", "西安"]
ADDRESS_LIST = [
    # 内部配送地址
    "北京研发总部", "理想总部A区", "理想总部B区", "理想总部C区", "万科时代中心", "万科时代中心A座", "万科时代中心C座",
    "北京试制试验中心", "北京基地", "常州基地", "上海于田大厦", "上海虹桥天地", "上海协通园", "杭州菜鸟智谷", "深圳中科大厦",
    # 外部配送地址
    "望京SOHO塔1 B座1203室", "望京SOHO塔2 A座",
    "海淀区中关村大街27号", "中关村大街", "中关村广场购物中心B座",
    "顺义区空港工业区B区裕华路28号", "空港工业区",
    "昌平区回龙观西大街35号，龙冠商城3层", "回龙观西大街华联商厦",
    "浦东新区陆家嘴世纪金融广场3号楼25层", "陆家嘴世纪金融广场1号楼",
    "远洋山水小区5号楼2单元302室", "远洋山水小区",
    "桐梓林北路34号罗马假日广场", "罗马假日广场",
    "西湖区文三路456号东方通信大厦", "东方通信大厦",
]
MINUTE_LIST = [5, 10, 15, 20]


def num2cn(generate_num):
    """生成的数字样本转换为中文表述"""
    cn_rep = []
    for digit in generate_num:
        cn_rep.append(chinese_digits[digit])
    return "".join(cn_rep)


def random_city() -> str:
    """随机城市"""
    return my_random.choice(CITY_LIST)


def random_address() -> str:
    """随机地址"""
    return my_random.choice(ADDRESS_LIST)


def random_num(max_num: int = 10, num_list: List[int] = []) -> str:
    """随机数字(中文表示)"""
    if len(num_list) == 0:
        num_list = [i+1 for i in range(max_num)]
    return num_to_chinese(my_random.choice(num_list))


def random_minute() -> str:
    """随机分钟(中文表示)"""
    return random_num(num_list=MINUTE_LIST)


def random_cup(max_cup: int = 6) -> str:
    """随机杯数(中文表示)"""
    return random_num(max_num=max_cup)


def random_amount(generate_type=None):
    """随机金钱数量"""
    tail_str = ["元", "块", "块钱"]
    choised_tail = my_random.choice(tail_str)
    generated_amount = my_random.randint(1, 200)
    num_rep = f"{generated_amount}{choised_tail}"
    cn_rep = f"{an2cn(generated_amount)}{choised_tail}"
    if generate_type == "detail":
        return num_rep, cn_rep, generated_amount
    return my_random.choice([num_rep, cn_rep])


def random_phoneNumber(generate_type=None):
    """随机手机号"""
    generated_number = phonegen.get_mobile()[3:]
    cn_rep = num2cn(generated_number)
    if generate_type == "detail":
        return generated_number, cn_rep
    return my_random.choice([generated_number, cn_rep])


def random_captcha(generate_type=None):
    """随机验证码"""
    characters = "0123456789"
    generated_number = ''.join(my_random.choices(characters, k=4))
    cn_rep = num2cn(generated_number)
    if generate_type == "detail":
        return generated_number, cn_rep
    return my_random.choice([generated_number, cn_rep])


def random_location(start=False, location_only=False):
    """随机地址"""
    rand_int = my_random.randint(1, 10)
    street = fake.street_name()
    address = fake.building_number().format(num=rand_int)
    if my_random.random() < 0.3:
        full_address = my_random.choice(user_response["common location"])
    else:
        full_address = f"{street}{address}"
    # 只要生成地址无需口语化表述
    if location_only:
        return full_address
    # 随机添加口语化表述
    if start:
        start_str = my_random.choice(["起点是", "我现在在", "我在"])
        response = f"{start_str}{full_address}"
    else:
        start_str = my_random.choice(["我要去", "到", "去", "", "送我到", "终点是"])
        response = f"{start_str}{full_address}"
    return response


def random_servertype():
    """随机代驾类型"""
    server_list = ["特惠代驾", "滴滴代驾", "青桔代驾", "星享代驾"]
    return my_random.choice(server_list)


def execute_func_from_name(func_name):
    """通过名称执行函数"""
    if "location" in func_name:
        func_result = globals()["random_location"](location_only=True)
        return func_result
    else:
        func_result = globals()[func_name]()
        return func_result


def random_sample_by_field(data_list, field_name, sample_type, sample_num=None):
    """
    分组随机抽取数据
    参数:
        data_list: 数据列表
        field_name: 分组字段名
        sample_type: 决定采样数量的方式
            - middle: 使用所有分组数据量的平均值
            - median: 使用所有分组数据量的中位数
            - value: 使用传入的sample_num值
        sample_num: 每组抽样数量(当sample_type为value时使用)
    返回:
        随机抽样后的数据列表
    """
    # 按照指定字段进行分组
    grouped_data_list = defaultdict(list)
    for item in data_list:
        if field_name == "template":
            field_value = item.get("feature", {}).get(field_name, "")
        else:
            field_value = item.get(field_name, "")
        grouped_data_list[field_value].append(item)
    # 确定采样数量
    if sample_type == "middle":  # 平均值
        group_sizes = [len(items) for items in grouped_data_list.values()]
        sample_num = int(sum(group_sizes) / len(group_sizes)) if group_sizes else 0
    elif sample_type == "median":  # 中位数
        group_sizes = [len(items) for items in grouped_data_list.values()]
        sample_num = int(statistics.median(group_sizes)) if group_sizes else 0
    else:  # 使用传入的sample_num值
        pass
    # 从每个分组中随机抽取数据
    result_list = []
    for field_value, item_list in grouped_data_list.items():
        sampled_item_list = my_random.sample(item_list, min(sample_num, len(item_list)))
        result_list.extend(sampled_item_list)
    return result_list


def merge_tsv_sample(input_path, output_path):
    merged_data = pd.DataFrame()
    for file_path in input_path:
        df = pd.read_csv(file_path, sep='\t')
        num_samples = len(df)
        logger.info(f"{file_path}样本数量为:{num_samples}")
        merged_data = pd.concat([merged_data, df], ignore_index=True)
    merged_data.to_csv(output_path, sep='\t', index=False)
    logger.info(f"\nSuccessfully merged all TSV files into: {output_path}")


def split_dialog(dialog, delimiter):
    """依据delimiter划分对话"""
    split_point = dialog.find(delimiter)
    history = dialog[:split_point].strip()
    history = history.replace("user:", "用户:")
    history = history.replace("assistant:", "助手:")
    user_latest = dialog[split_point:].strip()
    return history, user_latest


def reorder_dict_items(arguments):
    desired_order = ["appName", "taskType", "query"]
    reordered_dict = {}
    for key in desired_order:
        if key in arguments:
            reordered_dict[key] = arguments[key]
    return reordered_dict


if __name__ == "__main__":
    print("random_city:", random_city(), execute_func_from_name("random_city"))
    print("random_num:", random_num(), execute_func_from_name("random_num"))
    print("random_minute:", random_minute(), execute_func_from_name("random_minute"))
    print("random_cup:", random_cup(), execute_func_from_name("random_cup"))
    print("random_address:", random_address(), execute_func_from_name("random_address"))

# python -m plan.cua.sample.func
