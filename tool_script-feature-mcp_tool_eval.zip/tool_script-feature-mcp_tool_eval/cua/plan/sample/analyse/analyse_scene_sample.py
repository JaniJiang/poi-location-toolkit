from tqdm import tqdm
from collections import Counter
from cua.plan.sample.meta import *
from cua.plan.sample.scene import *
from utils.file_utils import read_jsonl_file


class AnalyseSceneSample:
    """分析每种样本的数据量，用于决策样本均衡策略"""

    def __init__(self):
        self.sample_dir = f"{SAMPLE_DIR}/{SAMPLE_VERSION}/scene_sample"
        self.support_scene_list = get_scene_name_en_list()

    def process(self):
        for scene_name in tqdm(self.support_scene_list, total=len(self.support_scene_list)):
            scene_path = f"{self.sample_dir}/{scene_name}.jsonl"
            sample_list = read_jsonl_file(scene_path)
            sample_num = len(sample_list)
            print(f"{scene_name}\t{sample_num}")
            if sample_num == 0:
                continue
            conversation_type_list = []
            for sample_one in sample_list:
                conversations = sample_one["conversations"]
                for conversation in conversations:
                    conversation_type = conversation.get("type", "NONE")  # 样本类型
                    conversation_type_list.append(conversation_type)
            # 统计输出
            self.count_frequency("场景类型", scene_name, conversation_type_list)

    def count_frequency(self, sample_type, scene_name, data_list):
        counter = Counter(data_list)
        sorted_items = sorted(counter.items(), key=lambda x: x[1], reverse=True)
        print(f"### {scene_name} {sample_type}  ###")
        for sorted_item in sorted_items:
            print("\t".join([str(x) for x in sorted_item]))


if __name__ == "__main__":
    obj = AnalyseSceneSample()
    obj.process()

# python -m cua.plan.sample.analyse.analyse_scene_sample
