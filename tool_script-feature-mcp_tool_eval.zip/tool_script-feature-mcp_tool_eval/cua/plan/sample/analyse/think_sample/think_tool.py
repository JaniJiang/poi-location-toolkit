import json
import pandas as pd
import random
import os


def clear_screen():
    os.system("clear")


def export_sampled_dialogs_to_excel(jsonl_path, excel_path, sample_size=20):
    """
    从 JSONL 文件中随机抽取对话样本，并导出为 Excel 表格，供人工标注。

    参数:
    - jsonl_path: 输入 JSONL 文件路径
    - excel_path: 输出 Excel 文件路径
    - sample_size: 抽样数量（默认 20 条）
    """
    all_dialogs = []

    # 读取并解析 JSONL 文件
    with open(jsonl_path, "r", encoding="utf-8") as f:
        for line in f:
            try:
                data = json.loads(line)
                dialog = data.get("dialog_flow", "")
                think = data.get("think", "")
                all_dialogs.append({
                    "对话流": dialog,
                    "思考": think,
                    "是否合理": " "
                })
            except Exception as e:
                print(f"⚠️ 跳过无效数据：{e}")

    # 随机抽样
    if len(all_dialogs) >= sample_size:
        sampled = random.sample(all_dialogs, sample_size)
    else:
        print(f"⚠️ 数据不足 {sample_size} 条，仅导出 {len(all_dialogs)} 条")
        sampled = all_dialogs

    # 写入 Excel
    df = pd.DataFrame(sampled)
    df.to_excel(excel_path, index=False)
    print(f"✅ 成功导出 {len(sampled)} 条样本至: {excel_path}")


def preview_jsonl(path):
    with open(path, "r", encoding="utf-8") as f:
        for idx, line in enumerate(f):
            try:
                data = json.loads(line)
                dialog = data.get("dialog_flow", "")
                think = data.get("think", "")

                print(f"📝 第 {idx + 1} 条对话：\n")
                print("🗣️ 对话内容：\n" + dialog)
                print("\n🧠 模型思考：\n" + think)

                input("\n🔄 按 Enter 查看下一条（Ctrl+C 退出）...")
                clear_screen()

            except Exception as e:
                print("❌ 无法解析该行：", e)


if __name__ == "__main__":
    data_path = r"data/cloud_share/cua/plan/sample/v6-20250424-1/coffee_think.jsonl"
    save_path = r"data/cloud_share/cua/plan/sample/v6-20250424-1/coffee_think_sample.xlsx"
    # preview_jsonl(path=data_path)
    export_sampled_dialogs_to_excel(data_path, save_path)


# python -m cua.plan.sample.think_sample.think_tool
