from cua.plan.sample.think_sample.think_prompt import *
from utils.llm_utils.serverless_function import request_llm
import json

dialog_flow = """
在星巴克百子湾门店订一个中杯的摩卡，加燕麦奶，一会去取
为你搜索到了多家门店，请您选择一家门店进行点单
去洗车店
"""


_, response_data = request_llm([think_prompt_system_template.format(
    dialog_flow=dialog_flow), think_prompt_user_template])

print(think_prompt_system_template.format(
    dialog_flow=dialog_flow))
print(think_prompt_user_template)

print(response_data)
res = json.loads(response_data['choices'][0]['message']['content'])
think = res.get("think", "")

print("THINK:", think)

# python -m cua.plan.sample.think_sample.bad_case_test
