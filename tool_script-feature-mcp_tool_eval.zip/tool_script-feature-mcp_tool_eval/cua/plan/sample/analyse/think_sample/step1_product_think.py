import os
import json
import threading
from tqdm import tqdm
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from utils.llm_utils.serverless_function import request_llm
from cua.plan.sample.think_sample.think_prompt import *


class Product():
    def __init__(self, data_path: os.path, save_path: os.path, model="gpt-4o", max_workers=4):
        self.data_path = data_path
        self.save_path = save_path
        self.template = think_prompt_system_template
        self.model = model
        self.lock = threading.Lock()
        self.max_workers = max_workers

    def process_line(self, line):
        try:
            data = json.loads(line)
            con_list = data.get("conversations", [])
            dialog_flow = "\n".join([con.get("content", "") for con in con_list[:-1]])

            _, response_data = request_llm(
                [self.template.format(dialog_flow=dialog_flow), think_prompt_user_template],
                model=self.model
            )

            res = json.loads(response_data['choices'][0]['message']['content'])
            think = res.get("think", "")

            return {
                "dialog_flow": dialog_flow,
                "think": think
            }
        except Exception as e:
            return None

    def save_callback(self, future):
        result = future.result()
        if result:
            with self.lock:
                with open(self.save_path, "a", encoding="utf-8") as f_out:
                    f_out.write(json.dumps(result, ensure_ascii=False) + "\n")
        self.pbar.update(1)

    def run(self):
        Path(self.save_path).touch(exist_ok=True)

        with open(self.data_path, "r", encoding="utf-8") as f:
            lines = f.readlines()

        self.pbar = tqdm(total=len(lines), desc="Processing JSONL")

        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            for line in lines:
                future = executor.submit(self.process_line, line)
                future.add_done_callback(self.save_callback)

        self.pbar.close()


if __name__ == "__main__":
    data_path = r"data/cloud_share/cua/plan/sample/v6-20250424-1/merge_sample.jsonl"
    save_path = r"data/cloud_share/cua/plan/sample/v6-20250424-1/coffee_think.jsonl"
    Pro = Product(data_path, save_path)
    Pro.run()


# python -m cua.plan.sample.think_sample.step1_product_think
