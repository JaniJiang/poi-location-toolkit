import copy
import csv
import json
import random
import threading
from tqdm import tqdm
from joblib import Parallel, delayed
from cua.plan.sample.meta import *
from cua.plan.sample.scene import *
from cua.plan.sample.prompt import *
from utils.file_utils import read_jsonl_file, check_output_path

if __name__ == '__main__':
    merge_path = "/mnt/pfs-guan-ssai/nlu/zhaojiufeng/tool_script/data/cloud/cua/plan/sample/v6-20250429/merge_sample.jsonl"
    scene_sample_list = read_jsonl_file(merge_path)
    sample_list = my_random.sample(
        scene_sample_list, min(300, len(scene_sample_list)))
    data = []
    for sample in sample_list:
        text = ""
        tool_name = ""
        for conversation in sample['conversations']:
            if conversation['role'] == 'tool':
                tool_name = conversation['content']
                continue
            text += f"{conversation['role']}: {conversation['content']}\n"
        data.append({
            'prompt-标注前': text,
            '工具名称-标注前': tool_name
        })

    # data = {}
    # # data['input'] = res
    # # # print(data)
    # fieldnames = list(data.keys())
    # num_rows = len(next(iter(data.values())))  # 获取第一列的长度
    # with open('/mnt/pfs-guan-ssai/nlu/zhaojiufeng/tool_script/data/cloud/cua/plan/sample/v6-20250429/output.tsv', 'w', encoding='utf-8', newline='') as f:
    #     writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter='\t')
    #     writer.writeheader()
    #     # 将每行组装成字典
    #     for i in range(num_rows):
    #         row = {key: value[i] for key, value in data.items()}
    #         writer.writerow(row)

    with open('/mnt/pfs-guan-ssai/nlu/zhaojiufeng/tool_script/data/cloud/cua/plan/sample/v6-20250429/output.tsv', 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=['prompt-标注前', '工具名称-标注前'], delimiter='\t')
        writer.writeheader()
        for row in data:
            writer.writerow(row)
