from tqdm import tqdm
from collections import Counter
from utils.file_utils import read_jsonl_file, write_json_file, check_output_path
from cua.plan.sample.meta import *
from cua.plan.sample.func import *
from cua.plan.sample.prompt import *
from cua.plan.eval.eval_sample import EvalSample


class AnalyseMergeSample(EvalSample):
    """分析每种样本的数据量，用于决策样本均衡策略"""

    def __init__(self):
        self.input_path = f"{SAMPLE_DIR}/{SAMPLE_VERSION}/merge_sample.jsonl"
        self.output_path = f"{SAMPLE_DIR}/analyse/{SAMPLE_VERSION}/merge_sample"
        check_output_path(self.output_path + ".tsv")

    def process(self):
        # 读取完整样本
        sample_list = read_jsonl_file(self.input_path)
        # 随机少量数据验证
        self.check_random_sample(sample_list)
        # 统计数据分布
        scene_type_list = []
        sample_type_list = []
        content_type_list = []
        brand_name_list = []
        all_arguments_dict = {}
        tool_arguments_dict = {}
        tool_brand_arguments_dict = {}
        for sample_one in tqdm(sample_list, total=len(sample_list), desc="AnalyseMergeSample"):
            # 场景类型
            scene_type_list.append(sample_one.get("scene", "NONE"))
            # 正负样本类型
            sample_type_list.append(sample_one.get("type", "NONE"))
            # 样本话术类型
            conversations = sample_one["conversations"]
            for conversation in conversations:
                content_type_list.append(conversation.get("type", "NONE"))
                # 整体槽位
                arguments = conversation.get("arguments", {})
                for arg_name, arg_value in arguments.items():
                    if arg_name not in all_arguments_dict:
                        all_arguments_dict[arg_name] = 0
                    all_arguments_dict[arg_name] += 1
            # 品牌名称
            feature_dict = sample_one.get("feature", {})
            brand_name = feature_dict.get("query_feature", {}).get("brand", "EMPTY")
            brand_name_list.append(brand_name)
            # 工具槽位
            if brand_name not in tool_brand_arguments_dict:
                tool_brand_arguments_dict[brand_name] = {}
            tool_conversation = conversations[-1]
            tool_arguments = tool_conversation.get("arguments", {})
            for arg_name, arg_value in tool_arguments.items():
                if arg_name not in tool_arguments_dict:
                    tool_arguments_dict[arg_name] = 0
                tool_arguments_dict[arg_name] += 1
                if arg_name not in tool_brand_arguments_dict[brand_name]:
                    tool_brand_arguments_dict[brand_name][arg_name] = 0
                tool_brand_arguments_dict[brand_name][arg_name] += 1
        # 统计输出
        self.count_frequency("正负样本类型", sample_type_list)
        self.count_frequency("样本话术类型", content_type_list)
        self.count_frequency("场景类型", scene_type_list)
        self.count_frequency("品牌名称", brand_name_list)
        # 槽位分布
        write_json_file(self.sort_dict(all_arguments_dict), self.output_path + ".args_all.json")
        write_json_file(self.sort_dict(tool_arguments_dict), self.output_path + ".args_tool.json")
        write_json_file(tool_brand_arguments_dict, self.output_path + ".args_tool_brand.json")

    def count_frequency(self, sample_type, data_list):
        counter = Counter(data_list)
        sorted_items = sorted(counter.items(), key=lambda x: x[1], reverse=True)
        with open(self.output_path + ".tsv", "a") as f:
            f.write(f"\n{sample_type}\t数据量\n")
            for sorted_item in sorted_items:
                f.write("\t".join([str(x) for x in sorted_item]) + "\n")

    def check_random_sample(self, sample_list, sample_num=10):
        random_sample_list = random_sample_by_field(sample_list, "type", "value", sample_num)
        output_list = []
        for sample_one in random_sample_list:
            prompt, label_str = build_prompt(sample_one["conversations"], sample_one["feature"])
            dialog_str = prompt2dialog(prompt)
            dialog_list = dialog_str.split("\n")
            _, label_dict = self.parse_pred_str(label_str)
            output_list.append({
                "dialog": dialog_list,
                "label": label_dict,
            })
        write_json_file(output_list, self.output_path + ".random_sample.json")

    def sort_dict(self, origin_dict):
        sorted_dict = dict(sorted(origin_dict.items(), key=lambda item: item[1], reverse=True))
        return sorted_dict


if __name__ == "__main__":
    obj = AnalyseMergeSample()
    obj.process()

# python -m cua.plan.sample.analyse.analyse_merge_sample
