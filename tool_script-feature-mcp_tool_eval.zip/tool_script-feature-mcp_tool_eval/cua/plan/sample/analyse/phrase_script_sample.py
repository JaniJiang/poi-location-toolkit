import os
import json
import csv


class ScriptProcesser:
    """
    用于处理剧本文件夹中的 JSON 文件，并提取包含 clarifyTemplates 的步骤中的特定信息。
    将结果保存到 TSV 文件或返回数据列表。
    """

    def __init__(self, folder_path):
        """
        使用 剧本JSON 文件的文件夹路径初始化 ScriptProcesser

        Args:
            folder_path (str): 文件夹的路径。
        """
        self.folder_path = folder_path

    def process(self, output_tsv_path=None, output_dedup_by_app=None, output_dedup_by_slots=None, dedup_by_appname=False, dedup_by_slots=False):
        """
        处理指定文件夹中符合 'script_*.json' 模式的所有 JSON 文件。

        Args:
            output_tsv_path (str): 没有去重保存结果的 TSV 文件路径。默认为 None。
            output_dedup_by_app (str): appname去重保存结果的 TSV 文件路径。默认为 None。
            output_dedup_by_slots (str): slots去重保存结果的 TSV 文件路径。默认为 None。
            dedup_by_appname (bool): 是否根据appname去重
            dedup_by_slots (bool): 是否根据slots去重
        """
        results = []
        if dedup_by_appname:
            dedup_by_app_results = []
        if dedup_by_slots:
            seen_templates_slots = set()
            dedup_by_slots_results = []

        # 检查文件夹路径是否存在
        if not os.path.isdir(self.folder_path):
            print(f"错误: 文件夹 '{self.folder_path}' 未找到")
            return

        # 列出文件夹中的所有文件
        try:
            files = os.listdir(self.folder_path)
        except OSError as e:
            print(f"错误: 列出文件夹 '{self.folder_path}' 中的文件时出错: {e}")
            return

        # 过滤出符合 script_*.json 模式的 JSON 文件
        json_files = []
        for f in files:
            if f.startswith('script_') and f.endswith('.json'):
                json_files.append(f)
            else:
                print(f"文件 '{f}' 不符合 'script_*.json' 模式，跳过。")

        # 处理每个过滤后的 JSON 文件
        for filename in json_files:
            file_path = os.path.join(self.folder_path, filename)
            # 从文件名中提取小程序名称（移除 'script_' 和 '.json'）
            app_name = filename[len('script_'):-len('.json')]
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                if dedup_by_appname:
                    # 保存已经处理过的澄清话术模板
                    seen_templates = set()
                # 遍历顶级列表中的每个元素（字典）
                for item in data:
                    # 检查元素是否为字典，并且包含 'steps'
                    if isinstance(item, dict) and 'steps' in item and 'page_type' in item and 'description' in item:
                        steps = item['steps']
                        page_type = item['page_type']
                        description = item['description']
                        # 初始化用于存储该元素的格式化槽位信息字符串的列表
                        item_slots_list = []
                        # 遍历 'steps' 列表中的每个步骤
                        for step in steps:
                            params = step['params']
                            # 检查 'params' 是否为字典，并且包含所需的键
                            if isinstance(params, dict) and 'slotKey' in params and 'clarifyTemplates' in params:
                                slot_key = params.get('slotKey', 'N/A')
                                clarify_templates = params.get('clarifyTemplates', [])
                                candidates = params.get('candidates', [])
                                candidates_str = str(candidates)
                                # 格式化槽位信息
                                templates_str = str(clarify_templates)
                                # 跳过自动调用类型澄清话术
                                if "@" in templates_str:
                                    continue
                                # 构建结果slot信息
                                slot_info = f"slot_key: {slot_key}\ntemplate: {templates_str}\ncondidates: {candidates_str}"
                                item_slots_list.append(slot_info)
                                # 依据app去重
                                if dedup_by_appname:
                                    # 跳过已经处理过的澄清话术
                                    if templates_str not in seen_templates:
                                        seen_templates.add(templates_str)
                                        dedup_by_app_results.append({'app_name': app_name,  'slots': slot_info})
                                # 依据slots去重
                                if dedup_by_slots:
                                    if templates_str not in seen_templates_slots:
                                        seen_templates_slots.add(templates_str)
                                        dedup_by_slots_results.append({'slots': slot_info})
                            else:
                                # 非澄清类对话跳过
                                continue
                        if item_slots_list:
                            # 使用分隔符连接格式化的槽位信息字符串
                            result_slots_str = '-----------\n'.join(item_slots_list)
                            results.append({'app_name': app_name, 'page_type': page_type,
                                           'description': description, 'slots': result_slots_str})
            except json.JSONDecodeError:
                print(f"错误: 无法解析文件 '{filename}' 的 JSON。跳过。")
            except Exception as e:
                print(f"处理文件 '{filename}' 时发生意外错误: {e}")
        # 处理完所有文件后，根据 output_tsv_path 参数决定是保存到文件还是返回数据
        if output_tsv_path:
            try:
                with open(output_tsv_path, 'w', encoding='utf-8', newline='') as tsvfile:
                    writer = csv.writer(tsvfile, delimiter='\t', quoting=csv.QUOTE_MINIMAL)
                    writer.writerow(["app_name", "page_type", "description", "slots"])
                    for entry in results:
                        app_name = entry.get('app_name', '')
                        page_type = entry.get('page_type', '')
                        description = entry.get('description', '')
                        slots = entry.get('slots', '')
                        writer.writerow([app_name, page_type, description, slots])
                print(f"成功将结果保存到 TSV 文件: '{output_tsv_path}'")
            except IOError as e:
                print(f"错误: 写入 TSV 文件 '{output_tsv_path}' 时出错: {e}")
        if output_dedup_by_app:
            try:
                with open(output_dedup_by_app, 'w', encoding='utf-8', newline='') as tsvfile:
                    writer = csv.writer(tsvfile, delimiter='\t', quoting=csv.QUOTE_MINIMAL)
                    writer.writerow(["app_name", "slots"])
                    for entry in dedup_by_app_results:
                        app_name = entry.get('app_name', '')
                        slots = entry.get('slots', '')
                        writer.writerow([app_name, slots])
                print(f"成功将结果保存到 TSV 文件: '{output_dedup_by_app}'")
            except IOError as e:
                print(f"错误: 写入 TSV 文件 '{output_dedup_by_app}' 时出错: {e}")
        if output_dedup_by_slots:
            try:
                with open(output_dedup_by_slots, 'w', encoding='utf-8', newline='') as tsvfile:
                    writer = csv.writer(tsvfile, delimiter='\t', quoting=csv.QUOTE_MINIMAL)
                    writer.writerow(["slots"])
                    for entry in dedup_by_slots_results:
                        slots = entry.get('slots', '')
                        writer.writerow([slots])
                print(f"成功将结果保存到 TSV 文件: '{output_dedup_by_slots}'")
            except IOError as e:
                print(f"错误: 写入 TSV 文件 '{output_dedup_by_slots}' 时出错: {e}")


if __name__ == "__main__":
    share_ahead = 'data/cloud_share/cua/plan/sample/eval/scene_script'
    input_floer = f"{share_ahead}/origin"
    output_file = f"{share_ahead}/analyse/script_origin.tsv"
    dedup_by_app_file = f"{share_ahead}/analyse/script_dedup_app.tsv"
    dedup_by_slots_file = f"{share_ahead}/analyse/script_dedup_slots.tsv"
    obj = ScriptProcesser(input_floer)
    obj.process(output_tsv_path=output_file, output_dedup_by_app=dedup_by_app_file,
                output_dedup_by_slots=dedup_by_slots_file, dedup_by_appname=True, dedup_by_slots=True)
