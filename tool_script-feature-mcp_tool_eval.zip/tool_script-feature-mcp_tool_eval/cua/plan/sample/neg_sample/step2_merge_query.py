import re
import json
from tqdm import tqdm
from utils.file_utils import read_fuzzy_jsonl_file
from cua.plan.sample.meta import *
from cua.plan.sample.func import *


class MergeQuery:

    def __init__(self):
        self.data_dir = "data/cloud/ark_log/result/car_log_for_plan_daily_group_sampled"
        self.date_list = ["2025-04-02", "2025-04-03", "2025-04-04",
                          "2025-04-05", "2025-04-06", "2025-04-07", "2025-04-08"]
        self.output_path = f"{SAMPLE_DIR}/{SAMPLE_VERSION}/neg_query.jsonl"
        self.debug = False
        self.sample_num = 100

    def process(self):
        # 读取输入数据
        result_list = []
        for date_str in self.date_list:
            data_path = f"{self.data_dir}/{date_str}/part-00000-*.json"
            input_list = read_fuzzy_jsonl_file(data_path)
            print(date_str, len(input_list))
            for item in input_list:
                domain = item.get("domain_key", "")
                query = item.get("api_query", "") if item.get("api_query", "") != "" else item.get("query", "")
                if query == "":
                    continue
                result_list.append([domain, query])

        # 统计数据分布
        result_count, result_detail = self.calculate_domain_statistics(result_list)
        # print(json.dumps(result_count, ensure_ascii=False))

        # 保存处理结果
        with open(self.output_path, "w") as f:
            for domain, unique_queries in tqdm(result_detail.items(), total=len(result_detail)):
                for unique_query in unique_queries:
                    if self.debug is True and len(unique_query) > 4:
                        continue
                    query_type = self.check_query_type(unique_query)
                    f.write(json.dumps({
                        "domain": domain, "query": unique_query, "type": query_type,
                    }, ensure_ascii=False)+"\n")

    def calculate_domain_statistics(self, data):
        domain_stats = {}
        for domain, query in data:
            if domain not in domain_stats:
                domain_stats[domain] = {"total_count": 0, "unique_queries": set()}
            domain_stats[domain]["total_count"] += 1
            domain_stats[domain]["unique_queries"].add(query)
        result_count = {
            domain: {
                "total_count": stats["total_count"],
                "unique_query_count": len(stats["unique_queries"])
            }
            for domain, stats in domain_stats.items()
        }
        result_detail = {
            domain: my_random.sample(list(stats["unique_queries"]),
                                     min(self.sample_num, len(stats["unique_queries"])))
            for domain, stats in domain_stats.items()
        }
        return result_count, result_detail

    def check_query_type(self, query):
        # 确认类型
        if query in EXACT_CONFIRM_QUERY_LIST:
            return QUERY_TYPE_CONFIRM
        # 拒绝类型
        if query in EXACT_DENY_QUERY_LIST:
            return QUERY_TYPE_DENY
        # 选择类型
        select_pattern_list = [
            r'^(?:选择|呃|嗯)?第[一二三四五六七八九十百千万亿\d]+个$',
            r'^(?:选择|呃|嗯)?(?:第[一二三四五六七八九十百千万亿\d]+个)+$',
            r'^(?:选择|呃|嗯)?第[一二三四五六七八九十百千万亿\d]+个(?:和|与|以及|还有|、|,|，)?(?:第[一二三四五六七八九十百千万亿\d]+个)*$',
        ]
        for select_pattern in select_pattern_list:
            if re.match(select_pattern, query):
                return QUERY_TYPE_SELECT
        # 其他类型
        return QUERY_TYPE_OTHER


if __name__ == "__main__":
    obj = MergeQuery()
    obj.process()

# python -m cua.plan.sample.neg_sample.step2_merge_query
