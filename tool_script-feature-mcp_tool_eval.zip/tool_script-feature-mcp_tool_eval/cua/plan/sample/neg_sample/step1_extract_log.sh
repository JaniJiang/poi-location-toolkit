#!/bin/bash
# bash cua/plan/sample/neg_sample/step1_extract_log.sh

cd ark_script
dates=("2025-04-02" "2025-04-03" "2025-04-04" "2025-04-05" "2025-04-06" "2025-04-07" "2025-04-08")
for date in "${dates[@]}"
do
    /opt/spark/bin/spark-submit car_log_for_plan_daily.py --log_date=$date
done
