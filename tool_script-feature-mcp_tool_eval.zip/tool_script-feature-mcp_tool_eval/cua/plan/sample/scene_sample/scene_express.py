from cua.plan.sample.func import *
from cua.plan.sample.scene_base.scene_base import SceneBase


class SceneExpress(SceneBase):

    def __init__(self):
        super().__init__("express")


if __name__ == "__main__":
    obj = SceneExpress()
    obj.process()

# python -m cua.plan.sample.scene_sample.scene_express
