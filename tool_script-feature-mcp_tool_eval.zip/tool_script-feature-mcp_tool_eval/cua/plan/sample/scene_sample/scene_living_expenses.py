from cua.plan.sample.func import *
from cua.plan.sample.scene_base.scene_base import SceneBase


class SceneLivingExpenses(SceneBase):

    def __init__(self):
        super().__init__("living_expenses")

    def build_assistant_content(self, template, category, field_name, field_name_zh, field_value_list, field_choose_value, query_feature, special_multiple=2):
        """构建assistant的内容"""
        product = query_feature["product"]
        if field_name == "account":
            account_num = random_num(0, [2, 3])
            content_list = [
                f"当前有{account_num}个{product}账号，您需要选择哪一个呢？",
            ]
        elif field_name == "money":
            content_list = [
                f"您要充值的{field_name_zh}是多少呢？",
                f"您要充值的{product}{field_name_zh}是多少呢？",
            ]
        else:
            content_list = [
                f"请问{field_name_zh}是多少呢？",
                f"请问{product}的{field_name_zh}是多少呢？",
            ]
        return content_list


if __name__ == "__main__":
    obj = SceneLivingExpenses()
    obj.process()

# python -m cua.plan.sample.scene_sample.scene_living_expenses
