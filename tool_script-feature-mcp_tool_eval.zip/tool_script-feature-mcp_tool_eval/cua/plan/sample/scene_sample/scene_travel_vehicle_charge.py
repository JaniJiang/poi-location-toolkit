from cua.plan.sample.scene_base.scene_base import SceneBase


class SceneTravelVehicleCharge(SceneBase):

    def __init__(self):
        super().__init__("travel_vehicle_charge")


if __name__ == "__main__":
    obj = SceneTravelVehicleCharge()
    obj.process()

# python -m cua.plan.sample.scene_sample.scene_travel_vehicle_charge
