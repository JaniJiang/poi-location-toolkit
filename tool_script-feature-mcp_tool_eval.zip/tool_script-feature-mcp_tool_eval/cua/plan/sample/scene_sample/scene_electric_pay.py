from cua.plan.sample.scene_base.scene_base import SceneBase


class SceneElectricPay(SceneBase):

    def __init__(self):
        super().__init__("electric_pay")


if __name__ == "__main__":
    obj = SceneElectricPay()
    obj.process()

# python -m cua.plan.sample.scene_sample.scene_electric_pay
