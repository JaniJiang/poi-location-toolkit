from cua.plan.sample.scene_base.scene_base import SceneBase


class SceneDiDiInstant(SceneBase):

    def __init__(self):
        super().__init__("di_di_instant")


if __name__ == "__main__":
    obj = SceneDiDiInstant()
    obj.process()

# python -m cua.plan.sample.scene_sample.scene_didi_instant
