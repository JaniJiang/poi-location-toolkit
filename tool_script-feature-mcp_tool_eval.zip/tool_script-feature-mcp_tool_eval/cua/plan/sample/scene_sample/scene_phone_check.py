from cua.plan.sample.scene_base.scene_base import SceneBase


class ScenePhoneCheck(SceneBase):

    def __init__(self):
        super().__init__("phone_check")


if __name__ == "__main__":
    obj = ScenePhoneCheck()
    obj.process()

# python -m cua.plan.sample.scene_sample.scene_phone_check

