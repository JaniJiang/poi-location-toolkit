from cua.plan.sample.scene_base.scene_base import SceneBase


class SceneDiDiQuick(SceneBase):

    def __init__(self):
        super().__init__("di_di_quick")


if __name__ == "__main__":
    obj = SceneDiDiQuick()
    obj.process()

# python -m cua.plan.sample.scene_sample.scene_didi_quick

