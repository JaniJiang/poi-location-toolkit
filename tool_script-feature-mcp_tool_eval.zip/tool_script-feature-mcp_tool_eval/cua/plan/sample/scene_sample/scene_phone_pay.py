from cua.plan.sample.scene_base.scene_base import SceneBase


class ScenePhonePay(SceneBase):

    def __init__(self):
        super().__init__("phone_pay")


if __name__ == "__main__":
    obj = ScenePhonePay()
    obj.process()

# python -m cua.plan.sample.scene_sample.scene_phone_pay
