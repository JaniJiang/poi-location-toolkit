from cua.plan.sample.scene_base.scene_base import SceneBase


class SceneDrinkTea(SceneBase):

    def __init__(self):
        super().__init__("drink_tea")


if __name__ == "__main__":
    obj = SceneDrinkTea()
    obj.process()

# python -m cua.plan.sample.scene_sample.scene_drink_tea
