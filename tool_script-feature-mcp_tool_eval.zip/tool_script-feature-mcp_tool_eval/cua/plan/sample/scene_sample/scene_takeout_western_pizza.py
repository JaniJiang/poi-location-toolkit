from cua.plan.sample.scene_base.scene_base import SceneBase


class SceneTakeoutWesternPizza(SceneBase):

    def __init__(self):
        super().__init__("takeout_western_pizza")


if __name__ == "__main__":
    obj = SceneTakeoutWesternPizza()
    obj.process()

# python -m cua.plan.sample.scene_sample.scene_takeout_western_pizza
