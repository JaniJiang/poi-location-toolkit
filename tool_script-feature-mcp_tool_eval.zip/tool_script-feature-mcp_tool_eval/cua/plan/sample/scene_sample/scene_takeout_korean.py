from cua.plan.sample.scene_base.scene_base import SceneBase


class SceneTakeoutKorean(SceneBase):

    def __init__(self):
        super().__init__("takeout_korean")


if __name__ == "__main__":
    obj = SceneTakeoutKorean()
    obj.process()

# python -m cua.plan.sample.scene_sample.scene_takeout_korean
