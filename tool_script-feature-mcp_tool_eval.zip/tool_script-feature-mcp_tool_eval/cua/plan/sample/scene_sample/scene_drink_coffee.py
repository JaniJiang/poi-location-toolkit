from cua.plan.sample.scene_base.scene_base import SceneBase


class SceneDrinkCoffee(SceneBase):

    def __init__(self):
        super().__init__("drink_coffee")


if __name__ == "__main__":
    obj = SceneDrinkCoffee()
    obj.process()

# python -m cua.plan.sample.scene_sample.scene_drink_coffee
