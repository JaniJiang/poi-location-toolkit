from cua.plan.sample.scene_base.scene_base import SceneBase


class SceneTravelVehiclePark(SceneBase):

    def __init__(self):
        super().__init__("travel_vehicle_park")

    def build_assistant_content(self, template, category, field_name, field_name_zh, field_value_list, field_choose_value, query_feature, special_multiple=2):
        """构建assistant的内容"""
        content_list = [
            f"请问{field_name_zh}是多少呢？",
            f"请问您的{field_name_zh}是多少呢？",
            f"请填写{field_name_zh}",
        ]
        return content_list


if __name__ == "__main__":
    obj = SceneTravelVehiclePark()
    obj.process()

# python -m cua.plan.sample.scene_sample.scene_travel_vehicle_park
