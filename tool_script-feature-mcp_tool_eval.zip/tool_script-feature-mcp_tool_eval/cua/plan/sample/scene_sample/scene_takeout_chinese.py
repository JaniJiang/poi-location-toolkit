from cua.plan.sample.scene_base.scene_base import SceneBase


class SceneTakeoutChinese(SceneBase):

    def __init__(self):
        super().__init__("takeout_chinese")


if __name__ == "__main__":
    obj = SceneTakeoutChinese()
    obj.process()

# python -m cua.plan.sample.scene_sample.scene_takeout_chinese
