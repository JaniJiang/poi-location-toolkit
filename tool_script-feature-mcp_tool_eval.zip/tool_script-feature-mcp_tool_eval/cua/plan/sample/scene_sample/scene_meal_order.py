from cua.plan.sample.scene_base.scene_base import SceneBase


class SceneMealOrder(SceneBase):

    def __init__(self):
        super().__init__("meal_order")


if __name__ == "__main__":
    obj = SceneMealOrder()
    obj.process()

# python -m cua.plan.sample.scene_sample.scene_meal_order
