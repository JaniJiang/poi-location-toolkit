from cua.plan.sample.scene_base.scene_base import SceneBase


class SceneTakeoutWesternHamburger(SceneBase):

    def __init__(self):
        super().__init__("takeout_western_hamburger")


if __name__ == "__main__":
    obj = SceneTakeoutWesternHamburger()
    obj.process()

# python -m cua.plan.sample.scene_sample.scene_takeout_western_hamburger
