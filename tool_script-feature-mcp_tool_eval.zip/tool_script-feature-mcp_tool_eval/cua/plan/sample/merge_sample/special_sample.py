import copy
import json
import pandas as pd
from collections import defaultdict
from tqdm import tqdm
from loguru import logger
from utils.file_utils import check_output_path
from cua.plan.sample.meta import *
from cua.plan.sample.prompt import *
from cua.plan.sample.func import my_random
from cua.plan.sample.merge_sample.reduce_sample import ReduceSample


class SpecialSample(ReduceSample):

    def __init__(self):
        # "dev_ota7", "test_must", "special_sample_1"
        self.dataset_name_list = ["dev_ota7", "test_must", "special_sample_1"]
        self.dataset_version = "V3"
        self.output_origin_path = f"{SAMPLE_DIR}/eval/sample/special_origin_sample.jsonl"
        self.output_reduce_path = f"{SAMPLE_DIR}/eval/sample/special_reduce_sample.jsonl"
        check_output_path(self.output_origin_path)  # 校验原始输出路径
        check_output_path(self.output_reduce_path)  # 校验简化输出路径
        self.product_dict = self.get_product_dict()
        self.multi_order_temple_dict = self.generate_multi_order_template_dict()
        self.multi_order_gen_num = 6  # 多个产品样本生成数量
        self.repeat_times = 1  # 样本重复次数
        self.special_sample_resampl = 5  # 特殊样本重采样

    def process(self):
        origin_sample_list = []
        reduce_sample_list = []
        dialog_key_dict = {}
        for dataset_name in tqdm(self.dataset_name_list, total=(len(self.dataset_name_list))):
            input_path = f"{SAMPLE_DIR}/eval/{self.dataset_version}/{dataset_name}.tsv"
            input_df = pd.read_csv(input_path, sep="\t")
            for _, sample_row in tqdm(input_df.iterrows(), total=len(input_df), desc=dataset_name):
                dialog_str, tool_name, arguments, app_name = sample_row["对话"], sample_row["工具"], sample_row["参数"], sample_row["小程序"]
                if dataset_name == "special_sample_1":
                    arguments = json.loads(arguments)
                    conversations = self.dialog2conversations(dialog_str, tool_name, arguments=arguments)
                    for _ in range(self.special_sample_resampl):
                        self.add_new_conversations(conversations, tool_name, origin_sample_list,
                                                   reduce_sample_list, dialog_key_dict)
                else:
                    if tool_name != TOOL_NAME_CU_AGENT_CONTINUE:
                        continue
                    # 处理原始数据
                    dialog_segs = dialog_str.strip().split("\n")
                    last_role, last_content = dialog_segs[-1].split(": ", 1)
                    if last_role != "user" or last_content == "":
                        continue
                    if dataset_name == "test_must":
                        if app_name in self.product_dict:
                            last_content_new_list = self.generate_multi_order_list(app_name, last_content)
                        if app_name == "霸王茶姬":
                            last_content_new_list.extend(self.generate_new_content_for_bawang(last_content))
                    else:
                        last_content_new_list = [last_content]
                    # 生成新样本
                    for last_content_new in last_content_new_list:
                        dialog_segs[-1] = ": ".join(["user", last_content_new])
                        dialog_str_new = "\n".join(dialog_segs)
                        conversations = self.dialog2conversations(dialog_str_new, tool_name)
                        self.add_new_conversations(conversations, tool_name, origin_sample_list,
                                                   reduce_sample_list, dialog_key_dict)
        logger.info(f"原始样本量:{len(origin_sample_list)}, 简化样本量:{len(reduce_sample_list)}")
        # 保存原始对话
        with open(self.output_origin_path, "w") as f:
            for sample_one in origin_sample_list:
                for _ in range(self.repeat_times):
                    f.write(json.dumps(sample_one, ensure_ascii=False) + "\n")
        # 保存简化对话
        with open(self.output_reduce_path, "w") as f:
            for sample_one in reduce_sample_list:
                for _ in range(self.repeat_times):
                    f.write(json.dumps(sample_one, ensure_ascii=False) + "\n")

    def add_new_conversations(self, conversations, tool_name, origin_sample_list, reduce_sample_list, dialog_key_dict):
        # 构造原始对话
        sample_one = {"scene": "", "conversations": conversations, "feature": {}, "type": tool_name}
        origin_sample_list.append(sample_one)
        # 构造简化对话
        reduce_sample_one = self.process_reduce_sample(sample_one)
        # 通过hash进行简化对话去重
        dialog_key = self.generate_dialog_key(reduce_sample_one["conversations"])
        if dialog_key not in dialog_key_dict:
            reduce_sample_list.append(reduce_sample_one)
            dialog_key_dict[dialog_key] = True

    def dialog2conversations(self, dialog_str: str, tool_name: str, arguments=None):
        dialog_list = dialog_str.strip().split("\n")
        conversations = []
        for one_str in dialog_list:
            one_segs = one_str.split(": ")
            conversations.append({"role": one_segs[0], "content": one_segs[1]})
        conversations.append({"role": "tool", "content": tool_name,
                             "arguments": arguments if arguments != None else {}})
        return conversations

    def generate_new_content_for_bawang(self, last_content):
        """专门为霸王茶姬替换product的函数"""
        last_content_new_list = [last_content]
        hit_product, available_products = self.get_hit_and_available_product("霸王茶姬", last_content)
        if hit_product is None:
            return last_content_new_list
        for product in available_products:
            last_content_new = copy.deepcopy(last_content).replace(hit_product, product)
            last_content_new_list.append(last_content_new)
        return last_content_new_list

    def generate_multi_order_list(self, app_name, last_content):
        generated_list = []
        hit_product, available_products = self.get_hit_and_available_product(app_name, last_content)
        if hit_product is None:
            return [last_content]
        for _ in range(self.multi_order_gen_num):
            # 随机决定是添加1个还是2个产品
            num_additional_products = my_random.randint(1, 2)
            # 确保不会尝试选择比实际可用产品更多的数量
            if num_additional_products > len(available_products):
                num_additional_products = len(available_products)
            # 随机选择额外产品
            selected_products = my_random.sample(available_products, num_additional_products)
            all_products_for_template = [hit_product] + selected_products
            # 根据产品数量选择合适的模板并填充
            # 如果总共有2个产品
            if len(all_products_for_template) == 2:
                chosen_template = my_random.choice(self.multi_order_temple_dict["two_product"])
                generated_text = chosen_template.format(product1=all_products_for_template[0],
                                                        product2=all_products_for_template[1])
            # 如果总共有3个产品
            elif len(all_products_for_template) == 3:
                chosen_template = my_random.choice(self.multi_order_temple_dict["three_product"])
                generated_text = chosen_template.format(product1=all_products_for_template[0],
                                                        product2=all_products_for_template[1],
                                                        product3=all_products_for_template[2])
            prob = my_random.random()
            # 加入用户语气
            if prob <= 0.5:
                rand_str = my_random.choice(["嗯", "呃"])
                generated_text = rand_str + generated_text
            generated_list.append(generated_text)
        return generated_list

    def get_hit_and_available_product(self, app_name, last_content):
        hit_product = ""
        available_products = []
        for product in self.product_dict[app_name]:
            if product in last_content:
                hit_product = product
                break
        if hit_product == "":
            return None, None
        for product in self.product_dict[app_name]:
            if product == hit_product:
                continue
            available_products.append(product)
        return hit_product, available_products

    def get_product_dict(self):
        product_dict = defaultdict(list)
        # 需要获取product的场景列表
        need_process_list = ["drink_coffee", "drink_tea",
                             "takeout_western_hamburger", "takeout_western_pizza", "takeout_korean"]
        for scene_item in SCENE_LIST:
            if scene_item["scene_name_en"] in need_process_list:
                for brand_name, product_list in scene_item["product"].items():
                    # 这里要对产品按照长度进行排序防止后续查找hit_product时出现bug("拿铁"比"生椰拿铁"先hit)
                    product_dict[brand_name] = sorted(product_list, key=len, reverse=True)
        return product_dict

    def generate_multi_order_template_dict(self):
        multi_order_dict = {
            "two_product": [
                "我要一个{product1}，再来个{product2}。",
                "请给我准备{product1}和{product2}。",
                "来一份{product1}，然后加一个{product2}。",
                "我想点{product1}，配上{product2}。",
                "给我拿{product1}跟{product2}",
                "{product1}和{product2}",
            ] + ["点个{product1}和{product2}", "请给我{product1}和{product2}"] * 2,
            "three_product": [
                "我想要{product1}、{product2}，以及一份{product3}。",
                "请给我来{product1}、{product2}和{product3}这三样。",
                "一份{product1}、一个{product2}，再加个{product3}。",
                "我想点{product1}，还有{product2}和{product3}。",
                "麻烦给我{product1}、{product2}和{product3}。",
                "{product1},{product2}和{product3}",
            ] + ["我要{product1}、{product2}，还有一份{product3}。"] * 2
        }
        return multi_order_dict


if __name__ == "__main__":
    obj = SpecialSample()
    obj.process()
    # print(json.dumps(obj.get_product_dict(), ensure_ascii=False, indent=4))

# python -m cua.plan.sample.merge_sample.special_sample
