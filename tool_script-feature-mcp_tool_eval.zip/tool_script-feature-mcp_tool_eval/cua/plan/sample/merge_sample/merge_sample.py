import copy
import json
import threading
from tqdm import tqdm
from typing import Any
from loguru import logger
from joblib import Parallel, delayed
from cua.plan.sample.meta import *
from cua.plan.sample.scene import *
from cua.plan.sample.prompt import *
from cua.plan.sample.func import *
from cua.plan.sample.template import *
from utils.file_utils import read_jsonl_file, check_output_path
from cua.plan.sample.scene_base.scene_base import SceneBase


class MergeSample(SceneBase):

    def __init__(self):
        self.scene_sample_dir = f"{SAMPLE_DIR}/{SAMPLE_VERSION}/scene_sample"
        self.neg_query_path = f"{SAMPLE_DIR}/neg/neg_query.jsonl"
        self.output_path = f"{SAMPLE_DIR}/{SAMPLE_VERSION}/merge_sample.jsonl"
        check_output_path(self.output_path)
        # 场景参数
        self.support_scene_list = get_scene_name_en_list()
        self.scene_sample_num = 10000
        # 最大对话轮数
        self.max_round_num = 30
        self.pos_round_choose_version = "v0"  # v0 | v1 | v2
        self.neg_round_choose_version = "v2"  # v0 | v1 | v2
        # 工具采样参数
        self.large_sample_num = 30000
        self.middle_1_sample_num = 27500
        self.middle_2_sample_num = 25000
        self.small_sample_num = 1500
        # 全局首轮缓存
        self.tmp_new_order_conversations = []
        # 参数开关
        self.enable_continue_arguments = False
        # 设置并发控制参数
        self.n_jobs = len(self.support_scene_list)  # 并发度
        self.file_lock = threading.Lock()  # 文件锁

    def process(self):
        """主处理函数"""
        # 读取负例Query
        self.neg_query_list = []
        with open(self.neg_query_path, "r", encoding="utf-8") as f:
            for line in f:
                json_obj = json.loads(line.strip())
                if json_obj["type"] in [QUERY_TYPE_OTHER, QUERY_TYPE_HUMAN]:
                    self.neg_query_list.append(json_obj["query"])
        self._available_neg_query = copy.deepcopy(self.neg_query_list)
        # 并发处理
        Parallel(n_jobs=self.n_jobs, prefer="threads")(
            delayed(self.process_scene_and_save_sample)(scene_name_en)
            for scene_name_en in tqdm(self.support_scene_list, total=len(self.support_scene_list), desc="merge sample")
        )

    def process_scene_and_save_sample(self, scene_name_en):
        """处理场景并保存样本"""
        # 获取场景配置
        self.scene_conf = get_scene_conf(scene_name_en)
        self.scene_type = self.scene_conf["scene_type"]
        sample_list = self.process_scene(scene_name_en)
        if len(sample_list) > 0:
            with self.file_lock:
                with open(self.output_path, "a") as f:
                    for sample_one in tqdm(sample_list,
                                           total=len(sample_list),
                                           desc=f"save scene {scene_name_en}"):
                        f.write(json.dumps(sample_one, ensure_ascii=False) + "\n")

    def process_scene(self, scene_name_en):
        """处理场景样本"""
        # 读取场景样本
        scene_sample_path = f"{self.scene_sample_dir}/{scene_name_en}.jsonl"
        scene_sample_list = read_jsonl_file(scene_sample_path)
        if len(scene_sample_list) == 0:
            return []
        # 模板均衡策略: 每个模板随机n条数据
        if scene_name_en in ["meal_order", "express", "travel_vehicle_park"]:
            template_random_sample_list = scene_sample_list
        else:
            template_random_sample_list = random_sample_by_field(scene_sample_list, "template", "median")
        # 场景/小程序均衡策略：每个场景随机 scene_sample_num 条数据
        scene_random_sample_list = my_random.sample(
            template_random_sample_list, min(self.scene_sample_num, len(template_random_sample_list)))
        # 逐条处理样本
        merge_sample_list = []
        for sample_one in tqdm(scene_random_sample_list, total=len(scene_random_sample_list), desc=f"process scene {scene_name_en}"):
            pos_neg_sample_list = self.process_sample_one(sample_one)
            merge_sample_list.extend(pos_neg_sample_list)
        # 工具均衡策略：每个工具随机n条数据
        balance_sample_list = self.tool_balance_strategy(merge_sample_list)
        logger.info(
            f"[MergeSample][{scene_name_en}][origin:{len(scene_sample_list)}][template_random:{len(template_random_sample_list)}][scene_random:{len(scene_random_sample_list)}][merge:{len(merge_sample_list)}][balance:{len(balance_sample_list)}]")
        return balance_sample_list

    def tool_balance_strategy(self, merge_sample_list):
        large_sample_list = [sample_one for sample_one in merge_sample_list
                             if sample_one["type"] in LARGE_TOOL_LIST]
        middle_1_sample_list = [sample_one for sample_one in merge_sample_list
                                if sample_one["type"] in MIDDLE_1_TOOL_LIST]
        middle_2_sample_list = [sample_one for sample_one in merge_sample_list
                                if sample_one["type"] in MIDDLE_2_TOOL_LIST]
        small_sample_list = [sample_one for sample_one in merge_sample_list
                             if sample_one["type"] in SMALL_TOOL_LIST]
        balance_large_sample_list = random_sample_by_field(large_sample_list, "type", "value", self.large_sample_num)
        balance_middle_1_sample_list = random_sample_by_field(
            middle_1_sample_list, "type", "value", self.middle_1_sample_num)
        balance_middle_2_sample_list = random_sample_by_field(
            middle_2_sample_list, "type", "value", self.middle_2_sample_num)
        balance_small_sample_list = random_sample_by_field(small_sample_list, "type", "value", self.small_sample_num)
        balance_sample_list = balance_large_sample_list + balance_middle_1_sample_list + \
            balance_middle_2_sample_list + balance_small_sample_list
        return balance_sample_list

    def process_sample_one(self, sample_one):
        """处理场景单条样本"""
        pos_sample_list = []
        neg_sample_list = []
        tmp_conversations = []
        tmp_round = 1
        scene_conf = get_scene_conf(sample_one["scene"])
        for conversation in sample_one["conversations"]:
            # 构造正例
            if self.check_need_pos(tmp_round) is True:
                if conversation["role"] == "user":  # 当前轮是用户问题时，才需要做规划
                    tool_name, arguments, arguments_full, task_type = self.label_sample(
                        sample_one["scene"], sample_one["feature"], conversation)
                    pos_conversation = [
                        conversation,
                        {"role": "tool", "content": tool_name, "arguments": arguments},
                    ]
                    pos_conversations = copy.deepcopy(tmp_conversations) + pos_conversation
                    pos_sample_list.append({
                        "scene": sample_one["scene"],
                        "conversations": pos_conversations[-self.max_round_num:],
                        "feature": sample_one["feature"],
                        "type": tool_name,
                    })
                    # 构造用户连续说话样本
                    probability = my_random.random()
                    if probability <= 0.6:
                        pos_list, neg_list = self.generate_consecutive_user_sample(
                            sample_one["scene"], conversation, tmp_conversations, tool_name, arguments)
                        for item in pos_list:
                            item["new_conversations"].append(
                                {"role": "tool", "content": item["type"], "arguments": item["arguments"]})
                            pos_conversations = item["new_conversations"]
                            pos_sample_list.append({
                                "scene": sample_one["scene"],
                                "conversations": pos_conversations[-self.max_round_num:],
                                "feature": sample_one["feature"],
                                "type": item["type"],
                            })
                    #     for item in neg_list:
                    #         item["new_conversations"].append(
                    #             {"role": "tool", "content": item["type"], "arguments": item["arguments"]})
                    #         neg_conversations = item["new_conversations"]
                    #         neg_sample_list.append({
                    #             "scene": sample_one["scene"],
                    #             "conversations": neg_conversations[-self.max_round_num:],
                    #             "feature": sample_one["feature"],
                    #             "type": item["type"],
                    #         })
                # 构造发起新场景的样本
                    if len(self.tmp_new_order_conversations) > 0:
                        new_order_conversation = my_random.choice(self.tmp_new_order_conversations)
                        new_order_conversations = copy.deepcopy(tmp_conversations) + new_order_conversation
                        pos_sample_list.append({
                            "scene": sample_one["scene"],
                            "conversations": new_order_conversations[-self.max_round_num:],
                            "feature": sample_one["feature"],  # TODO: 当前随机轮次的feature没加进来
                            "type": TOOL_NAME_CU_AGENT_START,
                        })
                    # 处理首轮样本
                    if tool_name == TOOL_NAME_CU_AGENT_START:
                        # 构造查询订单进展的样本(兼容首轮没有TYPE_ASK_STATUS)
                        if task_type == TASK_TYPE_ASK_STATUS:
                            pos_sample_list.append({
                                "scene": sample_one["scene"],
                                "conversations": pos_conversation,
                                "feature": sample_one["feature"],
                                "type": TOOL_NAME_CU_AGENT_START,
                            })
                        # 缓存首轮样本
                        self.tmp_new_order_conversations.append(pos_conversation)
                    # 采用替换方式构造负样本: 场景转问答+控制工具
                    if tool_name == TOOL_NAME_CU_AGENT_CONTINUE:
                        # 构造场景转问答的样本(采用替换方式)
                        qasearch_conversation = self.build_qasearch_conversation(
                            sample_one["scene"], scene_conf, sample_one["feature"], arguments_full)
                        if len(qasearch_conversation) > 0:
                            qasearch_conversations = copy.deepcopy(tmp_conversations) + [
                                qasearch_conversation,
                                {"role": "tool", "content": TOOL_NAME_QASEARCH, "arguments": {}},
                            ]
                            pos_sample_list.append({
                                "scene": sample_one["scene"],
                                "conversations": qasearch_conversations[-self.max_round_num:],
                                "feature": sample_one["feature"],
                                "type": TOOL_NAME_QASEARCH,
                            })
                        # 构造控制工具的样本(采用替换方式)
                        for control_tool in CONTROL_TOOL_LIST:
                            control_conversation, control_arguments = self.build_control_conversation(
                                control_tool, sample_one["scene"], sample_one["feature"], tmp_conversations[-1])
                            if len(control_conversation) > 0:
                                control_conversations = copy.deepcopy(tmp_conversations) + [
                                    control_conversation,
                                    {"role": "tool", "content": control_tool, "arguments": control_arguments}
                                ]
                                pos_sample_list.append({
                                    "scene": sample_one["scene"],
                                    "conversations": control_conversations[-self.max_round_num:],
                                    "feature": sample_one["feature"],
                                    "type": control_tool,
                                })
            # 构造非场景的样本
            if len(tmp_conversations) > 0 and self.check_need_neg(tmp_round) is True:
                if tmp_conversations[-1]["role"] == "assistant":  # 模型澄清-澄清负例
                    sample_type = TYPE_NEG_CASE_CLARIFY
                else:  # 用户打断-打断负例
                    sample_type = TYPE_BREAK_NEG_CASE
                # 随机负例
                if self._available_neg_query == []:
                    self._available_neg_query = copy.deepcopy(self.neg_query_list)
                random_neg_query = my_random.choice(self._available_neg_query)
                self._available_neg_query.remove(random_neg_query)
                random_neg_conversations = copy.deepcopy(tmp_conversations) + [
                    {"role": "user", "content": random_neg_query, "type": sample_type},
                    {"role": "tool", "content": TOOL_NAME_OTHER, "arguments": {}},
                ]
                neg_sample_list.append({
                    "scene": sample_one["scene"],
                    "conversations": random_neg_conversations[-self.max_round_num:],
                    "feature": sample_one["feature"],
                    "type": TOOL_NAME_OTHER,
                })
                # 冲突负例
                if my_random.choice([True] + [False] * 3) and conversation["role"] == "user" and check_conflict(conversation["content"]) is False:
                    conflict_neg_query = my_random.choice(CONFLICT_USER_QUERY_LIST)
                    conflict_neg_conversations = copy.deepcopy(tmp_conversations) + [
                        {"role": "user", "content": conflict_neg_query, "type": sample_type},
                        {"role": "tool", "content": TOOL_NAME_OTHER, "arguments": {}},
                    ]
                    neg_sample_list.append({
                        "scene": sample_one["scene"],
                        "conversations": conflict_neg_conversations[-self.max_round_num:],
                        "feature": sample_one["feature"],
                        "type": TOOL_NAME_OTHER,
                    })
            # 缓存当前轮对话
            tmp_conversations.append(conversation)
            tmp_round = int(len(tmp_conversations) / 2)
        # 合并正负例
        pos_neg_sample_list = pos_sample_list + neg_sample_list
        return pos_neg_sample_list

    def generate_consecutive_user_sample(self, scene, conversation, tmp_conversations, current_tool_name, arguments):
        """
        生成用户连续说话样本
        示例:
            user: 帮我在星巴克点一杯中杯的抹茶可可碎片星冰乐，换成巴旦木奶，加经典糖，甜度要标准甜。
            user: 能帮我点摩卡吗？在星巴克的阜通东大街店
        参数:
            scene 场景名称
            conversation: 当前用户发言
            tmp_conversations: 历史对话记录
            current_tool_name: 当前用户发言的工具标签
            arguments: 当前用户发言的arguments
        返回:
            pos_sample_list 用户连续说的正样本列表(包含start/continue两种情况)
            neg_sample_list 用户语义不明样本列表(包含语义缺失/语义模糊两类)
        """
        pos_sample_list = []
        neg_sample_list = []

        if len(tmp_conversations) == 0:
            # 创建对话开始用户连续说话样本
            # 创建新点单任务的正例 (type: start)
            if len(self.tmp_new_order_conversations) > 0:
                selected_conversation = my_random.choice(self.tmp_new_order_conversations)
                new_order_conversation = selected_conversation[0]  # dict
                arguments = selected_conversation[1]["arguments"]
            else:
                new_order_conversation = conversation  # dict
                arguments = conversation["arguments"]
            new_conversations = [conversation, new_order_conversation]
            pos_sample_list.append({
                "new_conversations": new_conversations,
                "type": TOOL_NAME_CU_AGENT_START,
                "arguments": arguments
            })
        # 创建补充槽位的正例子
        # user: 点杯星巴克抹茶星冰乐要超大杯一会去万科时代门店去
        # assistant: 使用支付宝需要同意用户协议哦，请问你同意吗？
        # user: 同意
        # user: 少冰
        if scene in ["drink_tea", "drink_coffee"]:
            # 获取当前场景信息
            for one_scene in SCENE_LIST:
                if one_scene["scene_name_en"] == scene:
                    current_scene_info = one_scene
            slot_choosed = my_random.choice(["cup_shape", "temperature", "brix", "poi"])
            if slot_choosed != "poi":
                new_continue_conversation = my_random.choice(current_scene_info["slot"][slot_choosed]["value"])
            else:
                poi_type_list = ["normal", "special"]
                poi_type = my_random.choice(poi_type_list)
                special_poi_list = [
                    "送到家里", "送到单位", "送到公司", "送到我最常去的地方",
                    "送到我老婆单位", "送到我老公单位", "送到我爸公司", "送到我妈公司",
                    "送到我儿子学校", "送到我女儿学校", "送到我孩子幼儿园", "送到我孩子大学",
                    "给我老婆点的送过去", "给我老公点的送过去", "给我嫂子点的", "给我哥点的",
                    "送给我爸", "送给我妈", "送给我爷爷", "送给我奶奶", "送给我弟弟", "送给我妹妹",
                ]
                if poi_type == "normal":
                    random_locate = my_random.choice(POI_VALUE_LIST)
                    new_continue_conversation = f"帮我送到{my_random.choice(random_locate)}"
                else:
                    new_continue_conversation = my_random.choice(special_poi_list)
            new_continue_conversation = {
                "role": "user", "content": new_continue_conversation
            }
            new_conversations = copy.deepcopy(tmp_conversations) + [conversation, new_continue_conversation]
            pos_sample_list.append({
                "new_conversations": new_conversations,
                "type": TOOL_NAME_CU_AGENT_CONTINUE,
                "arguments": {}
            })
        # 创建连续说话负样本
        noisy_conversation = {
            "role": "user", "content": self.generate_noisy_sample(conversation["content"])
        }
        new_conversations = copy.deepcopy(tmp_conversations) + [conversation, noisy_conversation]
        neg_sample_list.append({
            "new_conversations": new_conversations,
            "type": TOOL_NAME_OTHER,
            "arguments": {}
        })
        return pos_sample_list, neg_sample_list

    def generate_noisy_sample(self, content):
        """
        对输入的文本生成两种简单的负面样本：
        1. 随机截断+随机添加中文字符。
        2. 随机截断文本。
        参数:
            content: 原始的用户对话文本。
        """
        def _truncate_text(input_text, ratio=0.25):
            """
            将文本截断。
            """
            keep_len = max(1, int(len(input_text) * ratio))  # 确保至少保留一个字符
            return input_text[:keep_len]

        def _get_random_chinese_char():
            """生成一个随机的语义片段"""
            choosed_query = my_random.choice(self.neg_query_list)
            choosed_query = _truncate_text(choosed_query, ratio=0.5)
            return choosed_query

        noisy_method = my_random.choice(["truncate", "noisy_word"])
        truncated_content = _truncate_text(content)
        if noisy_method == "truncate":
            return truncated_content
        else:
            random_char = _get_random_chinese_char()
            return truncated_content+random_char

    def label_sample(self, scene, feature_dict, conversation):
        content = conversation["content"]
        origin_arguments = conversation.get("arguments", {})
        # 判断task_type
        sample_type = conversation.get("type", "")
        task_type = self.generate_task_type(sample_type, content, scene, feature_dict)
        # 根据task_type判断tool_name和arguments
        if task_type == "":
            tool_name = TOOL_NAME_CU_AGENT_CONTINUE
            arguments, arguments_full = self.continue_arguments_filter(content, origin_arguments)
        else:
            tool_name = TOOL_NAME_CU_AGENT_START
            # TODO: app_name的正式逻辑暂未实现，以下是判断app_name的临时逻辑
            app_name = origin_arguments["appName"] if origin_arguments.get("appName", "") != "" else ""
            # 拼装arguments
            arguments = {
                "appName": app_name,
                "taskType": task_type,
                "query": content,  # TODO: Query改写策略需要细化
            }
            arguments = self.start_arguments_filter(arguments)
            arguments_full = arguments
        return tool_name, arguments, arguments_full, task_type

    def generate_task_type(self, sample_type, content, scene, feature_dict):
        # TODO: 临时逻辑映射到task_type，待优化
        task_type = ""
        if sample_type in [TYPE_FIRST_ORDER]:
            if scene in ["meal_order"]:
                if "预约" in content:
                    task_type = TASK_TYPE_DICT[scene]["预约"]
                else:
                    task_type = TASK_TYPE_DICT[scene]["排号"]
            elif scene in ["travel_vehicle_park"]:
                brand = feature_dict.get("query_feature", {}).get("brand", "")
                if brand in ["ETC服务", "ETC"]:
                    task_type = TASK_TYPE_DICT[scene]["ETC"]
                else:
                    task_type = TASK_TYPE_DICT[scene]["FEE"]
            else:
                task_type = TASK_TYPE_DICT[scene]
        elif sample_type in [TYPE_ASK_STATUS]:
            task_type = TASK_TYPE_ASK_STATUS
        return task_type

    def continue_arguments_filter(self, content: str, arguments: Dict[str, str]) -> Dict[str, str]:
        arguments_need_list = list(NAME_MAPPING.values())
        arguments_filtered = {}
        arguments_full = {}
        for key, value in arguments.items():
            if key not in arguments_need_list:  # 不需要的槽位
                continue
            arguments_full[key] = value
            if value not in content:  # 槽位值指代
                continue
            arguments_filtered[key] = value
        if self.enable_continue_arguments is True:
            return arguments_filtered, arguments_full
        else:
            return {}, arguments_full

    def start_arguments_filter(self, arguments: Dict[str, str]) -> Dict[str, str]:
        arguments_filtered = {}
        for key, value in arguments.items():
            if value == "":
                continue
            arguments_filtered[key] = value
        return arguments_filtered

    def build_qasearch_conversation(self, scene_name_en: str, scene_conf: Dict[str, Any], feature_dict: Dict[str, Any], arguments_full: Dict[str, str]) -> Dict[str, str]:
        # 选择参数
        if len(arguments_full) == 0:
            return {}
        arguments_keys = list(arguments_full.keys())
        choose_key = my_random.choice(arguments_keys)
        choose_key_origin = NAME_MAPPING_REVERSE.get(choose_key, "")
        if len(choose_key_origin) == 0:
            return {}
        # 获取qasearch模板
        template_list = QA_SEARCH_TEMPLATE_DICT.get(scene_name_en, "").get(choose_key_origin, [])
        if len(template_list) == 0:
            return {}
        template = my_random.choice(template_list)
        # 解析模板中的类目
        category = parse_category_from_template(template)
        # 解析模板中的参数名
        param_name_list = parse_template(template)
        if len(param_name_list) == 0:
            content = template
            qasearch_conversation = {"role": "user", "content": content, "type": TOOL_NAME_QASEARCH}
            return qasearch_conversation
        # 获取参数值&填充参数到模板
        hidden_feature = feature_dict["hidden_feature"]
        city = hidden_feature["city"]
        brand = hidden_feature["brand"]
        city_brand_sample_list = self.build_city_brand_sample(
            template, category, param_name_list, city, brand, scene_name_en, scene_conf)
        if len(city_brand_sample_list) == 0:
            return {}
        # 返回对话数据(TODO:输出槽位和改写Query)
        content = my_random.choice(city_brand_sample_list)["query"]
        qasearch_conversation = {"role": "user", "content": content, "type": TOOL_NAME_QASEARCH}
        return qasearch_conversation

    def build_control_conversation(self, control_tool, scene_name_en, feature_dict, last_conversation):
        assistant_content = last_conversation.get("content", "")
        assistant_type = last_conversation.get("type", "")
        if control_tool == TOOL_NAME_CU_AGENT_RESUME:  # 解决继续点单的冲突问题
            if "是否继续" in assistant_content or "确认点单" in assistant_content or "继续点单" in assistant_content \
                    or assistant_type in [TYPE_ASK_PRIVACY_AGREEMENT, TYPE_ASK_LOCATION_AGREEMENT, TYPE_ASK_FINAL_ORDER_CONFIRM, TYPE_ASK_FINAL_ORDER_LOGIN, TYPE_ASK_FINAL_ORDER]:
                return {}, {}
        if my_random.choice([1, 2]) == 1:  # 简单控制命令
            control_conversation = {
                "role": "user",
                "content": my_random.choice(CU_AGENT_CONTROL_TEMPLATE_DEFAULT[control_tool]),
                "type": control_tool
            }
            return control_conversation, {}
        else:  # 复杂控制命令
            if scene_name_en in ["drink_coffee", "drink_tea"]:
                content = "点单"
                if "brand" in feature_dict["query_feature"]:
                    if scene_name_en == "drink_tea":
                        content = my_random.choice(["点奶茶", "点单"])
                    elif scene_name_en == "drink_coffee":
                        content = my_random.choice(["点咖啡", "点单"])
                    if control_tool == TOOL_NAME_CU_AGENT_PAUSE:
                        pause_text = my_random.choice(["暂停*", "暂停查询*进度"])
                        content = pause_text.replace("*", content)
                    elif control_tool == TOOL_NAME_CU_AGENT_RESUME:
                        resume_text = my_random.choice(["继续*", "继续查询*进度"])
                        content = resume_text.replace("*", content)
                    elif control_tool == TOOL_NAME_CU_AGENT_CANCEL:
                        cancel_text = my_random.choice(["取消*", "取消查询*进度"])
                        content = cancel_text.replace("*", content)
                    else:
                        quit_text = my_random.choice(["退出*", "退出查询*进度"])
                        content = quit_text.replace("*", content)
                control_conversation = {"role": "user", "content": content, "type": control_tool}
                control_arguments = {"taskType": "点单"}
                if "查询" in content:
                    control_arguments = {"taskType": "查询订单进展"}
                return control_conversation, control_arguments
            else:
                return {}, {}

    def check_need_pos(self, tmp_pos_round: int) -> bool:
        if self.pos_round_choose_version == "v1":
            if tmp_pos_round < 3:
                return True
            elif tmp_pos_round == 3:
                return my_random.choice([True] + [False] * 5)
            elif tmp_pos_round == 4:
                return my_random.choice([True] + [False] * 10)
            elif tmp_pos_round == 5:
                return my_random.choice([True] + [False] * 15)
            elif tmp_pos_round >= 5 and tmp_pos_round < 10:
                return my_random.choice([True] + [False] * 20)
            elif tmp_pos_round >= 10 and tmp_pos_round < 20:
                return my_random.choice([True] + [False] * 25)
            else:
                return my_random.choice([True] + [False] * 30)
        elif self.pos_round_choose_version == "v2":
            if tmp_pos_round <= 10:
                return True
            elif tmp_pos_round > 10 and tmp_pos_round <= 15:
                return my_random.choice([True] + [False] * 4)
            else:
                return my_random.choice([True] + [False] * 9)
        else:
            return True

    def check_need_neg(self, tmp_pos_round: int) -> bool:
        if self.neg_round_choose_version == "v1":
            if tmp_pos_round < 3:
                return my_random.choice([True] + [False] * 5)
            elif tmp_pos_round >= 3 and tmp_pos_round < 5:
                return my_random.choice([True] + [False] * 10)
            elif tmp_pos_round >= 5 and tmp_pos_round < 10:
                return my_random.choice([True] + [False] * 15)
            elif tmp_pos_round >= 10 and tmp_pos_round < 20:
                return my_random.choice([True] + [False] * 20)
            else:
                return my_random.choice([True] + [False] * 25)
        elif self.neg_round_choose_version == "v2":
            if tmp_pos_round <= 10:
                return True
            elif tmp_pos_round > 10 and tmp_pos_round <= 15:
                return my_random.choice([True] + [False] * 4)
            else:
                return my_random.choice([True] + [False] * 9)
        else:
            return True


if __name__ == "__main__":
    obj = MergeSample()
    obj.process()

# python -m cua.plan.sample.merge_sample.merge_sample
