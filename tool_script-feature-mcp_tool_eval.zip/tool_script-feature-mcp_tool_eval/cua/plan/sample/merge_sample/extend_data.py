from cua.plan.sample.meta import *
import itertools
from cua.plan.sample.template import ORDER_TEMPLATE_DICT
# 依据必过集以及需求方案构造的一些用于训练的样本

# 原有brand
BRAND_KEYWORDS = ["车生活", "捷停车", "支付宝停车", "停简单", "乐速通"]
# 新小程序以及昵称
NEW_APP_NAMES = {
    "北京道路停车缴费": ["北京道路停车缴费"],
    "云中停": ["云中停"],
    "PP停车": ["PP停车"],
    "小艾停车助手": ["小艾停车助手"],
    "保信": ["保信"],
    "一点停": ["一点停"],
    "停简单": ["停简单"]
}

park_more_template = [
    "看一下[brand]的津E车的停车费用多少给交了"
    "[brand]里停车的钱帮我交一下",
    "在[brand]里把川A那个车的停车费交一下",
    "这次的[brand]停车订单花了多少钱",
    "把冀AF12345车辆的停车费交了在[brand]小程序​",
    "[brand]里京B56789的停车费用是多少",
    "记得在[brand]，把豫E55116的停车费交一下",
    "豫F那个车的停车费交一下记得用[brand]",
    "那个[brand]上把冀C281DX的停车费付一下",
    "请尽快帮我交豫F那个车的停车费在[brand]里",
    "这次的[brand]停车订单花了多少钱",
]

# 用于转换数字至中文表示
chinese_digits = {
    '0': '零', '1': '幺', '2': '二', '3': '三', '4': '四',
    '5': '五', '6': '六', '7': '七', '8': '八', '9': '九'
}

# taskType映射
taskType_Dict = {
    "Electric_bill": {
        "Check bill": "查电费",
        "Pay bill": "交电费",
    },
    "Phone_bill": {
        "Check bill": "查话费",
        "Pay bill": "交话费",
    },
    "Di Di": {
        "Quick Dial": "一键代驾",
        "Instant Call": "代驾",
    }
}

appName_Dict = {"Electric_bill": "网上国网", "Phone_bill": "手机营业厅", "Di Di": "滴滴代驾"}

# 模板映射
template_Dict = {
    "Electric_bill": {
        "Check bill": ORDER_TEMPLATE_DICT["electric_check"],
        "Pay bill": ORDER_TEMPLATE_DICT["electric_pay"],
    },
    "Phone_bill": {
        "Check bill": ORDER_TEMPLATE_DICT["phone_check"],
        "Pay bill": ORDER_TEMPLATE_DICT["phone_pay"],
    },
    "Di Di": {
        "Quick Dial": ORDER_TEMPLATE_DICT["di_di_quick"],
        "Instant Call": ORDER_TEMPLATE_DICT["di_di_instant"],
    }
}

# 不同场景下assistant问题, share为通用
assistant_query = {
    "Electric_bill": {
        "Share query": {
            "Link account": "请手动绑定用电户号,完成后请说继续执行小程序",
            "Amount query": CHARGE_AMOUNT_ELECTRIC_ASSISTANT_LIST[0],
            "Confirm payment": FINAL_ORDER_ELECTRIC_ASSISTANT_LIST,
        },
        "Check bill": {
            "Confirm login": PRIVACY_AGREEMENT_ASSISTANT_FOR_SPECIAL_SCENE["电费-查询"][0],
            "Recharge check": OTHER_DEMAND_ELECTRIC_ASSISTANT_LIST[0],
        },
        "Pay bill": {
            "Confirm login": PRIVACY_AGREEMENT_ASSISTANT_FOR_SPECIAL_SCENE["电费-缴费"][0],
        },
    },
    "Phone_bill": {
        "Check bill": {
            "Confirm check": PHONENUMBER_ASSISTANT_DICT["话费-查询"],
            "Number query": WHICHNUMBER_ASSISTANT_DICT["话费-查询"],
            "Captcha query": "验证码已经发送了,请说出验证码",
        },
        "Pay bill": {
            "Confirm pay": PHONENUMBER_ASSISTANT_DICT["话费-缴费"],
            "Number query": WHICHNUMBER_ASSISTANT_DICT["话费-缴费"],
            "Amount query": CHARGE_AMOUNT_PHONE_ASSISTANT_LIST[0],
            "Confirm payment": FINAL_ORDER_PHONE_ASSISTANT_LIST,
        },
    },
    "designated_driver": {
        "Share query": {
            "Account aggrement": PRIVACY_AGREEMENT_DIDI_ASSISTANT_LIST[0],
            "Location aggrement": LOCATION_AGREEMENT_DIDI_ASSISTANT_LIST[0],
            "Confirm payment": FINAL_ORDER_DIDI_ASSISTANT_LIST[0],
        },
        "Quick Dial": {},
        "Instant Call": {
            "Destination check": STRAT_LOCALTION_CHECK_ASSISTANT_LIST[0],
            "Start location": STRAT_LOCALTION_ASSISTANT_LIST[0],
            "Final location": FINAL_LOCALTION_ASSISTANT_LIST[0],
            "Final location_2": FINAL_LOCALTION_2_ASSISTANT_LIST[0],
            "Designated type": SERVER_TYPT_ASSISTANT_LIST[0],
        },
    },
}
servertype_need_combine = ["当前勾选", "特惠代驾", "滴滴代驾", "青桔代驾", "星享代驾", "最便宜"]
combinations = list(itertools.combinations(servertype_need_combine, 2))
combined = [f"{item[0]}和{item[1]}" for item in combinations]

# 不同情况下用户回复方式列表
user_response = {
    "Confirm login": [
        "同意", "同意吧", "同意呀", "同意啊", "不同意", "我同意", "我不同意", "我不太想", "算了吧", "一会再说", "不弄了", "不整了", "别了",
        "允许", "允许啊", "不允许", "拒绝", "我拒绝", "不行", "不行啊", "否", "取消", "取消吧", "取消呀", "取消啊", "我没意见"
    ],
    "Recharge check": [
        "是", "是的", "否", "需要", "不需要", "对的", "暂时不用", "先不用", "先这样吧",
    ],
    "Confirm payment": [
        "好", "是", "对", "行",
        "好的", "是的", "对的", "行的", "嗯是", "好了", "就是",
        "好的的", "是的的", "对的的", "行的的",
        "好谢谢", "好的谢谢", "是谢谢", "是的谢谢", "对谢谢", "对的谢谢", "行谢谢", "行的谢谢", "嗯谢谢",
        "确定", "确认", "可以", "ok", "ok好", "ok好的", "嗯ok", "嗯对",
        "确定哦", "确认哦", "可以的", "就这个",
        # 否定
        "不确认", "不行", "等等", "暂时不需要"],
    "Confirm check/pay": [
        "好", "是", "对", "行",
        "好的", "是的", "对的", "行的", "嗯是", "好了", "就是",
        "好的的", "是的的", "对的的",
        "是谢谢", "是的谢谢", "对谢谢", "对的谢谢",
        "确定", "确认", "可以", "嗯ok", "嗯对",
        "确定哦", "确认哦", "可以的", "就这个",
        # 否定
        "不是", "不对"],
    "common location": [
        "公司", "我家", "火车站", "机场", "地铁站", "医院",
        "学校", "酒店", "公园", "体育馆", "咖啡馆", "电影院", "KTV",
        "图书馆", "超市", "博物馆",
    ],
    "servertype": combined + ["当前勾选", "特惠代驾", "滴滴代驾", "青桔代驾", "星享代驾", "默认", "全选", "最便宜", "这几种都叫上"] + ["立即呼叫"] * 3 + ["全部"] * 10,
    "Confirm payment_didi": [
        "继续", "可以", "同意", "退出", "不同意", "立即同意", "不立即同意", "确认同意",
        "支付", "不支付", "立即支付", "不立即支付", "确认支付", "同意支付", "不同意支付",
        "支付支付", "确认支付，支付", "同意支付、支付",
    ]
}

# 不同场景对话流程
scene_workflow = {
    "Electric_bill": {
        "Check bill": [
            {"assis": assistant_query["Electric_bill"]["Check bill"]
             ["Confirm login"], "user": "Confirm login", "default": ""},
            {"assis": assistant_query["Electric_bill"]["Share query"]
             ["Link account"], "user": "", "default": "继续执行小程序"},
            {"assis": assistant_query["Electric_bill"]["Check bill"]
             ["Recharge check"], "user": "Recharge check", "default": ""},
            {"assis": assistant_query["Electric_bill"]["Share query"]
             ["Amount query"], "user": "generate_amount", "default": ""},
            {"assis": assistant_query["Electric_bill"]["Share query"]
             ["Confirm payment"], "user": "Confirm payment", "default": ""},
        ],
        "Pay bill": [
            {"assis": assistant_query["Electric_bill"]["Share query"]
             ["Amount query"], "user": "generate_amount", "default": ""},
            {"assis": assistant_query["Electric_bill"]["Share query"]
             ["Confirm payment"], "user": "Confirm payment", "default": ""},
        ],
    },
    "Phone_bill": {
        "Check bill": [
            {"assis": assistant_query["Phone_bill"]["Check bill"]
             ["Confirm check"], "user": "Confirm check/pay", "default": ""},
            {"assis": assistant_query["Phone_bill"]["Check bill"]
             ["Number query"], "user": "generate_phoneNumber", "default": ""},
            {"assis": assistant_query["Phone_bill"]["Check bill"]
             ["Captcha query"], "user": "generate_captcha", "default": ""},
        ],
        "Pay bill": [
            {"assis": assistant_query["Phone_bill"]["Pay bill"]
             ["Confirm pay"], "user": "Confirm check/pay", "default": ""},
            {"assis": assistant_query["Phone_bill"]["Pay bill"]
                ["Number query"], "user": "generate_phoneNumber", "default": ""},
            {"assis": assistant_query["Phone_bill"]["Pay bill"]
                ["Amount query"], "user": "generate_amount", "default": ""},
            {"assis": assistant_query["Phone_bill"]["Pay bill"]
                ["Confirm payment"], "user": "Confirm payment", "default": ""},
        ],
    },
    "Di Di": {
        "Quick Dial": [
            {"assis": assistant_query["designated_driver"]["Share query"]
                ["Confirm payment"], "user": "Confirm payment_didi", "default": ""},
        ],
        "Instant Call": [
            {"assis": assistant_query["designated_driver"]["Share query"]
                ["Account aggrement"], "user": "Confirm login", "default": ""},
            {"assis": assistant_query["designated_driver"]["Share query"]
                ["Location aggrement"], "user": "Confirm login", "default": ""},
            {"assis": assistant_query["designated_driver"]["Instant Call"]
                ["Destination check"], "user": "generate_location", "default": ["把起点位置调整一下", "修改起点"]},
            {"assis": assistant_query["designated_driver"]["Instant Call"]
                ["Start location"], "user": "generate_location_start", "default": ""},
            {"assis": assistant_query["designated_driver"]["Instant Call"]
                ["Final location"], "user": "generate_location", "default": ""},
            {"assis": assistant_query["designated_driver"]["Instant Call"]
                ["Final location_2"], "user": "generate_location", "default": ""},
            {"assis": assistant_query["designated_driver"]["Instant Call"]
                ["Designated type"], "user": "servertype", "default": ""},
            {"assis": assistant_query["designated_driver"]["Share query"]
                ["Confirm payment"], "user": "Confirm payment_didi", "default": ""},
        ],
    }
}
