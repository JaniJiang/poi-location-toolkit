from tqdm import tqdm
from loguru import logger
from utils.file_utils import read_jsonl_file, write_json_file, check_output_path
from cua.plan.sample.func import *
from cua.plan.sample.meta import *
from cua.plan.sample.prompt import *


class TransSample:

    def __init__(self):
        # 普通样本
        self.sample_name = "merge_sample"  # merge_sample | reduce_sample
        self.input_path = f"{SAMPLE_DIR}/{SAMPLE_VERSION}/{self.sample_name}.jsonl"
        # 特殊样本
        self.need_special = True
        self.if_extend = True
        self.input_special_path = f"{SAMPLE_DIR}/eval/sample/special_origin_sample.jsonl"
        if self.sample_name == "reduce_sample":
            self.input_special_path = f"{SAMPLE_DIR}/eval/sample/special_reduce_sample.jsonl"
        # 输出路径
        self.output_path = f"{DATASET_DIR}/{DATASET_VERSION}/{self.sample_name}.{self.need_special}.{PROMPT_TYPE}.{SPECIAL_TOKEN_TYPE}.{self.if_extend}.json"
        check_output_path(self.output_path)
        # 样本重复次数
        self.repeat_times = 1

    def process(self):
        # 读取输入数据
        logger.info("读取输入数据")
        if self.if_extend:
            sample_list = read_jsonl_file(self.input_path)[:REVIEW_SAMPLE_NUM]
        else:
            sample_list = read_jsonl_file(self.input_path)
        logger.info(f"普通样本数量: {len(sample_list)}")
        # 读取并合并特殊样本
        if self.need_special is True:
            special_sample_list = read_jsonl_file(self.input_special_path)
            logger.info(f"特殊样本数量: {len(special_sample_list)}")
            sample_list.extend(special_sample_list)
            logger.info(f"合并样本数量: {len(sample_list)}")
        # 随机打乱数据顺序
        logger.info("随机打乱数据顺序")
        my_random.shuffle(sample_list)
        # 格式化数据到训练格式
        logger.info("格式化数据到训练格式")
        result_list = []
        for sample_one in tqdm(sample_list, total=len(sample_list)):
            conversations = sample_one["conversations"]
            feature_dict = sample_one["feature"]
            instruction, output = build_prompt(conversations, feature_dict)
            if instruction == "" or output == "":
                continue
            # 先把种子样本重复几次，观察模型能否收敛
            for _ in range(self.repeat_times):
                result_list.append({"instruction": instruction, "input": "", "output": output})
        # 保存处理结果
        logger.info(f"保存处理结果，样本量{len(result_list)}")
        write_json_file(result_list, self.output_path)


if __name__ == "__main__":
    obj = TransSample()
    obj.process()

# python -m cua.plan.sample.merge_sample.trans_sample
