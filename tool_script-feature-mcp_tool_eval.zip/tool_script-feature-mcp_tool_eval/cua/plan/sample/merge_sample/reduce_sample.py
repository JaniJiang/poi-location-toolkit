import copy
import hashlib
from tqdm import tqdm
from loguru import logger
from utils.file_utils import read_jsonl_file, write_jsonl_file, check_output_path
from cua.plan.sample.meta import *


class ReduceSample:

    def __init__(self):
        self.input_path = f"{SAMPLE_DIR}/{SAMPLE_VERSION}/merge_sample.jsonl"
        self.output_path = f"{SAMPLE_DIR}/{SAMPLE_VERSION}/reduce_sample.jsonl"
        check_output_path(self.output_path)

    def process(self):
        # 读取输入数据
        logger.info("读取输入数据")
        input_sample_list = read_jsonl_file(self.input_path)
        logger.info(f"输入数据量: {len(input_sample_list)}")
        # 简化对话轮次
        reduce_sample_list = []
        dialog_key_dict = {}
        for sample_one in tqdm(input_sample_list, total=len(input_sample_list)):
            # 构造简化对话
            reduce_sample_one = self.process_reduce_sample(sample_one)
            # 通过hash进行简化对话去重
            dialog_key = self.generate_dialog_key(reduce_sample_one["conversations"])
            if dialog_key in dialog_key_dict:
                continue
            # 保存简化结果
            reduce_sample_list.append(reduce_sample_one)
            dialog_key_dict[dialog_key] = True
        # 保存处理结果
        logger.info(f"保存处理结果，样本量: {len(reduce_sample_list)}")
        write_jsonl_file(reduce_sample_list, self.output_path)

    def process_reduce_sample(self, sample_one):
        """构造简化样本"""
        reduce_sample_one = copy.deepcopy(sample_one)
        conversations = reduce_sample_one["conversations"]
        reduce_sample_one["conversations"] = self.process_reduce_conversations(conversations)
        return reduce_sample_one

    def process_reduce_conversations(self, conversations):
        """构造简化对话"""
        reduced_conversations = []
        # 获取首个和最后一个assistant的索引
        first_assistant_idx = None
        last_assistant_idx = None
        for idx, conversation in enumerate(conversations):
            if conversation["role"] == "assistant":
                if first_assistant_idx is None:
                    first_assistant_idx = idx
                last_assistant_idx = idx
        if first_assistant_idx is not None:  # 有assistant
            reduced_conversations.extend(conversations[:first_assistant_idx])
            reduced_conversations.extend(conversations[last_assistant_idx:])  # first不为空时，last也不为空
        else:  # 无assistant
            reduced_conversations = conversations
        return reduced_conversations

    def generate_dialog_key(self, conversations):
        dialog_list = []
        for conversation in conversations:
            role = conversation["role"]
            content = conversation["content"]
            if role == "system":
                continue
            dialog_list.append(f"{role}:{content}")
        dialog = "\n".join(dialog_list)
        dialog_key = hashlib.md5(dialog.encode("utf-8")).hexdigest()
        return dialog_key


if __name__ == "__main__":
    obj = ReduceSample()
    obj.process()

# python -m cua.plan.sample.merge_sample.reduce_sample
