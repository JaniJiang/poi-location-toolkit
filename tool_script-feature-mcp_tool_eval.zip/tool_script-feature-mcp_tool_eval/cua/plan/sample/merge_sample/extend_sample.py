import json
import re
from loguru import logger
from collections import defaultdict
from cua.plan.sample.func import *
from cua.plan.sample.meta import *
from cua.plan.sample.prompt import *
from cua.plan.sample.merge_sample.extend_data import *
from cua.plan.sample.template import ORDER_TEMPLATE_DICT, parse_template
from cua.plan.sample.scene import SCENE_LIST
from utils.file_utils import read_json_file, write_json_file, check_output_path


class ExtendSample:
    """
    抽取旧样本替换brand并追加到新数据集中
    """

    def __init__(self, sample_source: str, extend_source: str, output_path: str):
        self.sample_source = sample_source
        self.extend_source = extend_source
        check_output_path(output_path)
        self.output_path = output_path
        self.create_start_num = 35
        self.create_continue_num = 5
        self.all_generated_entries = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))

    def generate_random_response(self, user_res_type, generate_type=None):
        """
        根据用户回复type生成随机回复
        Args:
            user_res_type:用户回复type
        """
        if "amount" in user_res_type:
            return random_amount(generate_type)
        elif "phoneNumber" in user_res_type:
            return random_phoneNumber(generate_type)
        else:
            return random_captcha(generate_type)

    def fill_template_return_slots(self, template):
        """填充模板并返回槽位信息"""
        param_list = parse_template(template)
        if len(param_list) == 0:
            return template
        choiced_value_dict = {}
        for param in param_list:
            if "location" in param:
                location = random_location(location_only=True)
                choiced_value_dict[param] = location
            else:
                if "amount" in param:
                    num_rep, cn_rep, generated_amount = random_amount("detail")
                    choiced_value_dict[param] = my_random.choice([num_rep, cn_rep])
                elif "phone" in param:
                    num_rep, cn_rep = random_phoneNumber("detail")
                    choiced_value_dict[param] = my_random.choice([num_rep, cn_rep])
                else:
                    servertype = random_servertype()
                    choiced_value_dict[param] = servertype
        new_template = template.format(**choiced_value_dict)
        return new_template

    def build_continue_item(self, conversations, response):
        """构造continue样本"""
        tmp_conversations = conversations + [{"role": "user", "content": response}]
        new_item = {
            "instruction": build_prompt(tmp_conversations)[0],
            "input": "",
            "output": "```function_call\n[{\"thought\": \"继续当前场景\", \"name\": \"cu_agent_continue\", \"arguments\": {}}]\n```[unused1]"
        }
        return new_item

    def check_item(self, item, check_scene=None):
        """判断样本是否符合需求"""
        output_val = item.get("output", "")
        instruction_val = item.get("instruction", "")
        if check_scene == "travel_vehicle_park":
          # 条件一: output中必须有"continue"或"start"
            output_condition = "continue" in output_val or "start" in output_val
            if not output_condition:
                return False, []
            # 条件二: instruction中必须有某个品牌关键词
            instruction_condition = False
            matched_keywords = []
            for keyword in BRAND_KEYWORDS:
                if keyword in instruction_val:
                    instruction_condition = True
                    matched_keywords.append(keyword)
            if output_condition and instruction_condition:
                return True, matched_keywords
            else:
                return False, []
        else:
            output_condition = "start" in output_val
            if not output_condition:
                return False, []
            return True, []

    def append_conversations(self, conversations, role, content):
        """添加发言至多轮对话中"""
        conversations.append({"role": role, "content": content})

    def replace_brand(self, matched_keywords, item):
        """替换样本中匹配到的关键词为<brand>"""
        processed_item = item.copy()
        # 替换instruction中的品牌关键词为<brand>
        for keyword in matched_keywords:
            processed_item["instruction"] = processed_item["instruction"].replace(
                keyword, "<brand>")
            if "start" in processed_item.get("output", ""):
                processed_item["output"] = processed_item["output"].replace(
                    keyword, "<brand>")
        return processed_item

    def extract_and_process_data(self, check_scene=None):
        """
        从sample_source中抽取数据，根据条件过滤，替换品牌关键词，去重，并采样。
        """
        logger.info("开始从sample_source中抽取和处理数据...")
        source_data = read_json_file(self.sample_source)
        if check_scene != "travel_vehicle_park":
            source_data = source_data[:50000]
        self.processed_data_start = []
        self.processed_data_continue = []
        seen_instructions = set()  # 用于去重处理后的instruction
        for item in source_data:
            check_flag, matched_keywords = self.check_item(item, check_scene=check_scene)
            if check_flag:
                if check_scene == "travel_vehicle_park":
                    processed_item = self.replace_brand(matched_keywords, item)
                    # 去重：如果处理后的instruction已经存在，则跳过
                    if processed_item["instruction"] not in seen_instructions:
                        # 直接根据output值将处理后的数据添加到相应的列表中
                        if "start" in processed_item.get("output", ""):
                            self.processed_data_start.append(processed_item)
                        else:
                            self.processed_data_continue.append(processed_item)
                        seen_instructions.add(processed_item["instruction"])
                else:
                    if item["instruction"] not in seen_instructions:
                        self.processed_data_start.append(item)
                        seen_instructions.add(item["instruction"])

        logger.info(
            f"初步过滤并去重后，'start' 类型数据有 {len(self.processed_data_start)} 条，'continue' 类型数据有 {len(self.processed_data_continue)} 条。")

    def sample_data(self, special_times=None):
        """采样start以及continue样本"""
        if special_times is not special_times:
            selected_start_data = my_random.sample(self.processed_data_start, min(
                len(self.processed_data_start), self.create_start_num))
        else:
            selected_start_data = my_random.sample(self.processed_data_start, min(
                len(self.processed_data_start), self.create_start_num*special_times))
        selected_continue_data = my_random.sample(self.processed_data_continue,
                                                  min(len(self.processed_data_continue), self.create_continue_num))
        return selected_start_data, selected_continue_data

    def _sample_origin_data_for_vehicle_park(self):
        output_temp = '```function_call\n[{"thought": "发起新场景", "name": "cu_agent_start", "arguments": {"taskType": "停车缴费", "query": "[query]"}}]\n```[unused1]'
        start_without_appname = [
            "打开停车缴费",
            "打开停车缴费，帮我交一下"
            "帮我交一下停车费",
            "交一下停车费",
            "帮我看一下停车费",
            "我想交停车费",
            "湘A的那个车的停车费还没交，帮我交了吧",
            "豫B那个车的停车费，麻烦交一下",
            "给那辆豫B交一下停车费",
            "给云AV9587的停车费交一下",
            "停车费尽快结清吧，我的车牌是京D87512"
            "请帮我交一下京E那辆车的停车费",
            "现在给我交下京AF102K停车费吧",
        ]
        self.extract_and_process_data()
        for choiced_query in start_without_appname:
            for _ in range(9):
                item = my_random.choice(self.processed_data_start)
                new_item = item.copy()
                conversations = prompt2conversations(item["instruction"])
                conversations[-1]["content"] = choiced_query
                new_ins, _ = build_prompt(conversations)
                output = output_temp.replace("[query]", choiced_query)
                new_item["instruction"] = new_ins
                new_item["output"] = output
                self.all_generated_entries["no_app_park"]["停车缴费"]["start"].append(new_item)

    def _sample_origin_start_data(self):
        self.extract_and_process_data()
        selected_start_data = my_random.sample(self.processed_data_start, 150)
        for item in selected_start_data:
            self.all_generated_entries["origin_start"]["random_start"]["start"].append(item)

    def _generate_new_data_for_vehicle_park(self) -> list:
        """
        为每个新App名称生成新的数据条目，替换<brand>占位符。
        Returns:
            list: 包含所有新生成数据条目的列表。
        """
        start_output_tmp = '```function_call\n[{"thought": "发起新场景", "name": "cu_agent_start", "arguments": {"appName": "[app]", "taskType": "停车缴费", "query": "[query]"}}]\n```[unused1]'
        self.extract_and_process_data(check_scene="travel_vehicle_park")
        logger.info("开始为vehicle_park生成新App数据...")
        for app_name, alias in NEW_APP_NAMES.items():
            logger.info(f"正在为App '{app_name}' 生成数据...")
            for one_alias in alias:
                selected_start_data, selected_continue_data = self.sample_data(special_times=2)
                # 处理start数据
                for item in selected_start_data:
                    new_item = item.copy()
                    new_item["instruction"] = new_item["instruction"].replace("<brand>", one_alias)
                    new_item["output"] = new_item["output"].replace("<brand>", app_name)
                    self.all_generated_entries[app_name]["停车缴费"]["start"].append(new_item)
                # 添加start新模板
                for _ in range(2):
                    for temp in park_more_template:
                        choiced_item = my_random.choice(self.processed_data_start)
                        new_item = choiced_item.copy()
                        new_query = temp.replace("[brand]", one_alias)
                        conversations = prompt2conversations(new_item["instruction"])
                        conversations[-1]["content"] = new_query
                        new_item["instruction"], _ = build_prompt(conversations)
                        new_item["output"] = start_output_tmp.replace("[app]", app_name).replace("[query]", new_query)
                        self.all_generated_entries[app_name]["停车缴费"]["start"].append(new_item)
                # 处理continue数据
                for item in selected_continue_data:
                    new_item = item.copy()
                    new_item["instruction"] = new_item["instruction"].replace("<brand>", one_alias)
                    self.all_generated_entries[app_name]["停车缴费"]["continue"].append(new_item)

    def _generate_new_data_for_new_scene(self):
        """为生活缴费、滴滴代驾生成训练样本"""
        scene_list = ["living_expenses", "designated_driver"]
        for one_scene in scene_list:
            self.extract_and_process_data()
            for scene_name, sub_scene_dict in template_Dict.items():
                for action_name, templates in sub_scene_dict.items():
                    logger.info(f"正在为{scene_name}-{action_name}生成数据...")
                    for template in templates:
                        template = self.fill_template_return_slots(template)
                        choiced_start_sample = my_random.sample(self.processed_data_start, 3)
                        for item in choiced_start_sample:
                            # 处理start数据
                            new_item = item.copy()
                            conversations = prompt2conversations(new_item["instruction"])
                            conversations[-1]["content"] = template
                            new_item["instruction"], _ = build_prompt(conversations)
                            arguments = {}
                            arguments['appName'] = appName_Dict[scene_name]
                            arguments['taskType'] = taskType_Dict[scene_name][action_name]
                            arguments['query'] = template
                            new_item["output"] = build_tool_prompt_v4("cu_agent_start", arguments)
                            self.all_generated_entries[scene_name][action_name]["start"].append(new_item)
                    self._generate_conversations(templates, scene_name, action_name)

    def _generate_conversations(self, templates, scene_name, action_name):
        """为生活缴费和滴滴代驾生成多轮对话样本"""
        for template in my_random.sample(templates, 3):
            template = self.fill_template_return_slots(template)
            # 存储多轮对话中填充assistant query需要的槽位信息
            slots_dict = {
                "amount": "",
                "tail_num": "",
            }
            conversations = []
            self.append_conversations(conversations, "user", template)
            for conversation_step in scene_workflow[scene_name][action_name]:
                assis_query = conversation_step["assis"]
                user_res_type = conversation_step["user"]
                if user_res_type != "" and "generate" not in user_res_type:
                    user_res = user_response[user_res_type]
                else:
                    user_res = [conversation_step["default"]] * 5
                if isinstance(assis_query, list):
                    for query in assis_query:
                        if "tail_number" in query:
                            content = query.format(
                                tail_number=slots_dict["tail_num"], amount=slots_dict["amount"])
                        else:
                            content = query.format(amount=slots_dict["amount"])
                        tmp_conversations = conversations + \
                            [{"role": "assistant", "content": content}]
                        for res in user_res:
                            self.all_generated_entries[scene_name][action_name]["continue"].append(
                                self.build_continue_item(tmp_conversations, res))
                else:
                    self.append_conversations(conversations, "assistant", assis_query)
                    if "generate" not in user_res_type:
                        for res in user_res:
                            self.all_generated_entries[scene_name][action_name]["continue"].append(
                                self.build_continue_item(conversations, res))
                        self.append_conversations(conversations, "user", my_random.choice(user_res))
                    else:
                        if "location" not in user_res_type:
                            for _ in range(10):
                                generate_res = self.generate_random_response(user_res_type)
                                self.all_generated_entries[scene_name][action_name]["continue"].append(
                                    self.build_continue_item(conversations, generate_res))
                            if "phone" in user_res_type:
                                choiced_value, choiced_value_cn = self.generate_random_response(user_res_type, "detail")
                                slots_dict["tail_num"] = choiced_value[-4:]
                            elif "amount" in user_res_type:
                                choiced_value, choiced_value_cn, choiced_amount = self.generate_random_response(
                                    user_res_type, "detail")
                                slots_dict["amount"] = choiced_amount
                            else:
                                choiced_value = self.generate_random_response(user_res_type)
                            self.append_conversations(conversations, "user", choiced_value)
                        else:
                            if "start" in user_res_type:
                                flag = True
                            else:
                                flag = False
                            for _ in range(10):
                                self.all_generated_entries[scene_name][action_name]["continue"].append(
                                    self.build_continue_item(conversations, random_location(start=flag)))
                            if conversation_step["default"] != "":
                                if isinstance(conversation_step["default"], list):
                                    for default_value in conversation_step["default"]:
                                        self.all_generated_entries[scene_name][action_name]["continue"].append(
                                            self.build_continue_item(conversations, default_value))
                                    self.append_conversations(conversations, "user",
                                                              my_random.choice(conversation_step["default"]))
                                else:
                                    self.all_generated_entries[scene_name][action_name]["continue"].append(
                                        self.build_continue_item(conversations, conversation_step["default"]))
                                    self.append_conversations(conversations, "user", conversation_step["default"])
                            else:
                                self.append_conversations(conversations, "user", random_location(start=flag))

    def _append_to_json_file(self, ):
        origin_data = read_json_file(self.extend_source)
        analyse_data = []
        logger.info(f"原有数据量为:{len(origin_data)}")
        for name, sub_name_dict in self.all_generated_entries.items():
            for sub_name, tool_name_dict in sub_name_dict.items():
                for tool_name, data in tool_name_dict.items():
                    logger.info(f"名称为{name},动作为{sub_name},工具为{tool_name}创建了{len(data)}条数据")
                    choiced_dialog = [prompt2dialog(one_prom["instruction"])
                                      for one_prom in my_random.sample(data, 5)]
                    analyse_data.append(
                        {f"{name}_{sub_name}_{tool_name}": choiced_dialog})
                    for _ in range(2):
                        origin_data.extend(data)
        logger.info(f"扩充后数据量为:{len(origin_data)}")
        my_random.shuffle(origin_data)
        write_json_file(origin_data, self.output_path)
        write_json_file(analyse_data, f"{DATASET_DIR}/{DATASET_VERSION}/analyse_data.json")
        logger.info(f"处理结束, 存储至:{self.output_path}")

    def process(self):
        logger.info("开始执行完整的数据处理和追加流程...")
        self._sample_origin_data_for_vehicle_park()
        self._sample_origin_start_data()
        self._generate_new_data_for_vehicle_park()
        self._generate_new_data_for_new_scene()
        self._append_to_json_file()
        logger.info("数据处理和追加流程完成。")


# --- 示例用法 ---
if __name__ == "__main__":
    sample_source = f"{DATASET_DIR}/v13-20250703/merge_sample.True.instruction.mindgpt.json"
    extend_source = f"{DATASET_DIR}/v13-20250804-extend/merge_sample.True.instruction.mindgpt.True.json"
    output_path = f"{DATASET_DIR}/{DATASET_VERSION}/merge_sample.True.instruction.mindgpt.True.json"
    obj = ExtendSample(sample_source, extend_source, output_path)
    obj.process()

# python -m cua.plan.sample.merge_sample.extend_sample
