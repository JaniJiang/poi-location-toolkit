import json
from typing import Dict


# 工具名称
TOOL_NAME_CU_AGENT_START = "cu_agent_start"
TOOL_NAME_CU_AGENT_CONTINUE = "cu_agent_continue"
TOOL_NAME_QASEARCH = "qasearch"
TOOL_NAME_OTHER = "other"
TOOL_NAME_CU_AGENT_PAUSE = "cu_agent_pause"
TOOL_NAME_CU_AGENT_RESUME = "cu_agent_resume"
TOOL_NAME_CU_AGENT_CANCEL = "cu_agent_cancel"
TOOL_NAME_CU_AGENT_QUIT = "cu_agent_quit"

# 控制类工具
CONTROL_TOOL_LIST = [TOOL_NAME_CU_AGENT_PAUSE, TOOL_NAME_CU_AGENT_RESUME,
                     TOOL_NAME_CU_AGENT_CANCEL, TOOL_NAME_CU_AGENT_QUIT]

# 工具分布
LARGE_TOOL_LIST = [TOOL_NAME_CU_AGENT_CONTINUE]
MIDDLE_1_TOOL_LIST = [TOOL_NAME_OTHER]
MIDDLE_2_TOOL_LIST = [TOOL_NAME_CU_AGENT_START, TOOL_NAME_QASEARCH]
SMALL_TOOL_LIST = CONTROL_TOOL_LIST


def tool_dict2string(tool_dict: Dict[str, str]) -> str:
    tool_list = []
    for tool_name, tool_desc in tool_dict.items():
        if tool_desc != "":
            tool_item = {"name": tool_name, "description": tool_desc}
        else:
            tool_item = {"name": tool_name}
        tool_list.append(json.dumps(tool_item, ensure_ascii=False))
    tool_str = "\n".join(tool_list)
    return tool_str


# 第1版工具
TOOL_DICT_V1 = {
    TOOL_NAME_CU_AGENT_CONTINUE: "",
    TOOL_NAME_OTHER: "",
}
TOOL_STRING_V1 = tool_dict2string(TOOL_DICT_V1)

# 第2版工具
TOOL_DICT_V2 = {
    TOOL_NAME_CU_AGENT_CONTINUE: "对话内容和上文相关，用户新的发话想要参与历史对话流",
    TOOL_NAME_OTHER: "对话内容和上文无关，用户新的发话不想参与历史对话流",
}
TOOL_STRING_V2 = tool_dict2string(TOOL_DICT_V2)

# 第3版工具
TOOL_DICT_V3 = {
    TOOL_NAME_CU_AGENT_START: "发起新场景",
    TOOL_NAME_CU_AGENT_CONTINUE: "继续当前场景",
    TOOL_NAME_QASEARCH: "场景转问答",
    TOOL_NAME_OTHER: "其他和场景无关的情况",
}
TOOL_STRING_V3 = tool_dict2string(TOOL_DICT_V3)

# 第4版工具
TOOL_DICT_V4 = {
    TOOL_NAME_CU_AGENT_START: "发起新场景",
    TOOL_NAME_CU_AGENT_CONTINUE: "继续当前场景",
    TOOL_NAME_QASEARCH: "场景转问答",
    TOOL_NAME_OTHER: "其他和场景无关的情况",
    TOOL_NAME_CU_AGENT_PAUSE: "暂停场景",
    TOOL_NAME_CU_AGENT_RESUME: "继续场景",
    TOOL_NAME_CU_AGENT_CANCEL: "取消场景",
    TOOL_NAME_CU_AGENT_QUIT: "退出场景",
}
TOOL_STRING_V4 = tool_dict2string(TOOL_DICT_V4)

# 第5版工具
TOOL_DICT_V5 = {
    TOOL_NAME_CU_AGENT_START: "发起新场景",
    TOOL_NAME_CU_AGENT_CONTINUE: "继续当前场景",
    TOOL_NAME_QASEARCH: "场景转问答",
    TOOL_NAME_OTHER: "其他和场景无关的情况",
    TOOL_NAME_CU_AGENT_PAUSE: "暂停场景",
    TOOL_NAME_CU_AGENT_RESUME: "恢复场景",
    TOOL_NAME_CU_AGENT_CANCEL: "取消场景",
    TOOL_NAME_CU_AGENT_QUIT: "退出场景",
}
TOOL_STRING_V5 = tool_dict2string(TOOL_DICT_V5)

if __name__ == "__main__":
    print(f"\n[TOOL_STRING_V1]:\n{TOOL_STRING_V1}")
    print(f"\n[TOOL_STRING_V2]:\n{TOOL_STRING_V2}")
    print(f"\n[TOOL_STRING_V3]:\n{TOOL_STRING_V3}")
    print(f"\n[TOOL_STRING_V4]:\n{TOOL_STRING_V4}")
    print(f"\n[TOOL_STRING_V5]:\n{TOOL_STRING_V5}")

# python -m cua.plan.sample.tool
