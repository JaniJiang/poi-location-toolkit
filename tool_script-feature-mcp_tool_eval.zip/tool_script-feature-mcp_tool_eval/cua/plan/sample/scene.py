from cua.plan.sample.poi import *
from cua.plan.sample.func import *
from cua.plan.sample.meta import *

# TODO: 这份映射配置其实没有必要，直接把SCENE_LIST替换成正式槽位即可
NAME_MAPPING = {
    "brand": "appName",
    "pickup": "pickupType",
    "poi": "shopAddress",
    "random_address": "deliveryAddress",
    "product": "productName",
    "cup_shape": "cupShape",
    "temperature": "temperature",
    "random_cup": "productCount",
    # 0426 新增11个槽位
    "brix": "sweetnessLevel",
    "milk": "milkType",
    "process_type": "processType",  # 新增 加工方式
    "condense_method": "espressoType",
    "condense_num": "espressoShots",
    "flavour_type": "sugarFreeFlavor",  # 新增 无糖风味定制
    "milk_foam": "milkFoam",
    "drink_body": "beverageBase",  # 新增 饮品主体
    "drink_top": "beverageTop",  # 新增 饮品顶部
    "drip_sauce": "sauce",
    "random_minute": "pickupTime",
    "status": "status",
    "tea_base": "teaBase",
    "additions": "additions",
    "green": "green",
}
NAME_MAPPING_REVERSE = {v: k for k, v in NAME_MAPPING.items()}


SCENE_LIST = [
    {
        "scene_type": "茶饮",
        "scene_name": "咖啡",
        "scene_name_en": "drink_coffee",
        "brand": ["星巴克", "瑞幸咖啡"],
        "brand_alias": {
            "星巴克": ["星巴克咖啡"],
            "瑞幸咖啡": ["瑞幸"]
        },
        "product": {
            "星巴克": ["浓缩咖啡", "美式", "美式咖啡", "卡布奇诺", "摩卡", "馥芮白", "焦糖玛奇朵", "浓缩康保蓝",
                    "拿铁", "红茶拿铁", "抹茶拿铁", "椰子丝绒燕麦拿铁", "比利时黑巧拿铁", "燕麦拿铁", "金烘拿铁",
                    "星冰乐", "茶星冰乐", "果汁星冰乐", "抹茶星冰乐", "摩卡星冰乐", "白桃星冰乐", "浓缩咖啡星冰乐", "焦糖咖啡星冰乐",
                    "热巧克力", "热苹果酒", "经典巧克力", "粉粉生咖", "PinkDrink", "粉莓柠力生咖",
                    "水果茶", "伯爵调味红茶", "冰摇柠檬茶", "冰摇桃桃乌龙茶", "冰摇红莓黑加仑茶",
                    "原味蒸汽奶", "可可蒸汽奶", "香草味蒸汽奶", "大溪地风情绵云冷萃",
                    ],
            "瑞幸咖啡": ["美式", "美式咖啡", "凤梨美式", "加浓美式", "小黄油美式", "柚C美式", "柠C美式", "标准美式", "橙C美式",
                     "茉莉花香美式", "葡萄冰萃美式", "话梅气泡美式", "耶加雪菲美式", "冷萃", "大西瓜生椰冷萃",
                     "拿铁", "生椰拿铁", "椰云拿铁", "陨石拿铁", "厚乳拿铁", "酱香拿铁", "丝绒拿铁",
                     "小白梨拿铁", "小话梅拿铁", "小黄油拿铁", "燕麦拿铁", "耶加雪菲拿铁", "茉莉花香拿铁", "香草拿铁", "抹茶拿铁",
                     "卡布奇诺", "经典巧克力", "摩卡", "焦糖玛奇朵", "精萃澳瑞白", "雪菲澳瑞白", "黑巧", "纯牛奶",
                     "葡萄柠檬茶", "轻咖柠檬茶", "鲜脆轻轻茉莉", "杨梅瑞纳冰", "抹茶瑞纳冰", "橙C冰茶", "夏日西瓜冷萃",
                     ],
        },
        "poi": {
            "星巴克": POI_DEFAULT,
            "瑞幸咖啡": POI_DEFAULT,
        },
        "pickup": {
            "星巴克": PICKUP_LIST + ["啡快", "专星送"],
            "瑞幸咖啡": PICKUP_LIST,
        },
        "slot": {
            "cup_shape": {
                "name": "杯型",
                "value": ["中杯", "大杯", "超大杯"],
                "required": True,
            },
            "temperature": {
                "name": "温度",
                "value": ["热", "冰", "少冰", "去冰", "全冰", "特别热", "微热", "常温", "凉的"],
                "required": True,
            },
            "random_cup": {  # TODO: 和template中的random_cup有冲突
                "name": "商品数量",
                "value": ["1", "2", "3", "4", "5", "6", "一", "两", "三", "四", "五", "六"],
                "required": True,
            },
            "random_address": {  # TODO: 和template中的random_address有冲突
                "name": "配送地址",
                "value": ADDRESS_LIST,
                "required": True,
            },
            "brix": {
                "name": "甜度",
                "value": ["经典甜", "标准甜", "不另外加糖", "无糖"],
            },
            "milk": {
                "name": "牛奶",
                "value": ["全脂牛奶", "巴旦木牛奶", "燕麦奶", "脱脂牛奶", "全脂", "巴旦木奶", "燕麦", "脱脂"],
            },
            "process_type": {
                "name": "加工方式",
                "value": ["冷食", "加热"],
            },
            "condense_method": {
                "name": "浓缩咖啡类型",
                "value": ["经典浓缩", "原萃浓缩", "精萃浓缩", "金烘浓缩", "低因浓缩", "经典", "金烘", "低因", "深烘", "浅烘"],
            },
            "condense_num": {
                "name": "浓缩份数",
                "value": ["一份浓缩", "两份浓缩", "三份浓缩", "四份浓缩", "五份浓缩"],
            },
            "flavour_type": {
                "name": "无糖风味定制",
                "value": ["香草风味", "榛果风味", "海盐焦糖风味", "大溪地香草风味", "莓莓风味", "斑斓风味", "斑斓椰浆风味", "榛果海盐焦糖风味", "巧克力风味", "糯香斑斓风味", "桂花糕风味"],
            },
            "milk_foam": {
                "name": "奶泡",
                "value": ["标准奶泡", "去奶泡", "少奶泡", "多奶泡", "奶泡较多（干）", "奶泡较少（湿）", "需要奶泡", "不需要奶泡"],
            },
            "drink_body": {
                "name": "饮品主体",
                "value": ["稀奶油", "椰浆"],
            },
            "drink_top": {
                "name": "饮品顶部",
                "value": ["标准搅打稀奶油", "去搅打稀奶油", "少搅打稀奶油", "多搅打稀奶油"],
            },
            "drip_sauce": {
                "name": "淋酱",
                "value": ["焦糖风味酱", "摩卡淋酱", "焦糖", "摩卡", "可可碎片", "可可碎"],
            },
        }
    },
    {
        "scene_type": "茶饮",
        "scene_name": "奶茶",
        "scene_name_en": "drink_tea",
        "brand": ["蜜雪冰城", "霸王茶姬", "古茗", "喜茶"],
        "brand_alias": {
            "古茗": ["古茗茶饮"],
        },
        "product": {
            "蜜雪冰城": ["美式咖啡", "拿铁", "生椰拿铁", "椰云拿铁", "陨石拿铁", "厚乳拿铁", "龙井拿铁", "椰椰拿铁", "拿铁咖啡", "葡萄冰美式",
                     "红豆奶茶", "四季春奶茶", "三拼霸霸奶茶", "珍珠奶茶", "双拼奶茶", "原味奶茶", "布丁奶茶", "椰果奶茶", "芋圆奶茶",
                     "蓝莓摇摇奶昔", "抹茶摇摇奶昔", "桑葚摇摇奶昔", "草莓摇摇奶昔", "香芋摇摇奶昔",
                     "柠檬芦荟茶", "芝士红茶", "芝士四季春", "蜂蜜柚子茶", "新鲜冰淇淋", "香芋冰淇淋", "香芋双炫冰淇淋",
                     "芝士绿茶", "柠檬绿茶", "香柠绿茶", "芝士奶盖绿茶", "茉莉绿茶", "富桂糯糯茶", "春日龙井茶", "高山四季春茶",
                     "柠檬水", "蜜桃四季春", "草莓啵啵", "鲜橙益菌多", "棒打西柚", "棒打鲜橙",
                     "东方乌龙茶奶盖", "冰鲜柠檬水", "四季春轻乳茶", "山楂莓莓", "山楂酸奶", "桂花奶盖", "桃喜芒芒", "桑葚莓莓",
                     "港式杨枝甘露", "满杯百香果", "脆皮大圣代", "芋圆葡萄", "芝士奶盖四季春", "茉莉奶绿", "草莓桃桃酸奶",
                     "菠萝百香果", "蜜桃甘露", "雪王大圣代", "雪王雪顶咖啡", "香柠百香果", "香芋脆皮小圣代",
                     ],
            "霸王茶姬": ["霸气拿铁", "抹茶拿铁", "悠悠玫瑰", "春日桃桃", "乌山可可", "青青糯山", "霸气芝士奶绿",
                     "霸气柠檬绿", "栀香水光柠檬茶", "百香果绿茶", "牛油果霸霸茶", "寻香山茶", "浮生梦媞",
                     "夏梦玫珑", "花田乌龙", "金乌扶摇", "白雾红尘", "桂馥兰香", "醒时春山", "伯牙绝弦",
                     "去云南玫瑰普洱", "轻因伯牙鲜沏", "轻因伯牙绝弦", "山野栀子", "晴山栖谷", "伯牙鲜沏", "桂子飘飘",
                     "东美人", "七里香", "桃花茉", "万象春", "云中绿", "山茶君", "扶摇起", "折桂令", "木兰辞",
                     "花田坞", "酌红袍", "醒春山", "野栀子", "千峰翠", "琥珀光", "万里木兰", "关山木兰",
                     ] + ["伯牙绝弦", "扶摇起", "折桂令", "木兰辞", "醒时春山", "万象春", "万象春和"],
            "古茗": ["招牌奶茶", "古茗奶茶", "大叔奶茶", "黑糖珍珠奶茶", "冰淇淋奶茶", "桃花醉", "桂花酒酿小丸子",
                   "抹茶绿意", "菊花乌龙", "龙井茶", "果蔬养生茶", "桂花龙眼椰", "桂花乌龙奶芙", "茉香云顶抹茶", "芋见青稞抹茶",
                   "杨枝甘露", "芒果冰沙", "泡鲁达", "芝士椰椰", "西瓜椰椰", "百香双重奏", "超A芝士葡萄",
                   "功夫拿铁", "功夫生椰拿铁", "功夫美式", "大橘美式", "提拉米苏拿铁", "椰椰冰淇淋拿铁", "焦糖丝绒拿铁",
                   "维A果蔬美式", "山茶生椰芒芒", "杨枝甘露椰奶", "杨枝甘露轻盈版", "百香芒芒大橘", "维A果蔬瓶", "苹果金凤梨",
                   "超A葡萄冰", "轻体果蔬瓶", "云顶抹茶龙井", "布丁西米露", "布蕾脆脆奶芙", "茉莉奶绿",
                   "龙井香青团", "云岭茉莉白", "初春山茶香", "曲香茉莉", "清饮龙井", "西子龙井春", "芝士茉莉",
                   ],
            "喜茶": ["多肉葡萄", "芝芝莓莓", "多肉芒芒甘露", "芝芝芒芒", "芝芝桃桃", "满杯红柚", "椰椰芒芒", "多肉芒芒", "芒芒甘露",
                   "烤黑糖波波牛乳", "热芋泥波波牛乳", "冰博克超厚牛乳波波", "桂花乌龙", "多肉青提冻", "生打椰椰奶冻",
                   "芝芝多肉葡萄", "超多肉芒芒甘露", "轻芝多肉葡萄", "酷黑莓桑", "鸭喜香青柠茶",
                   "嫣红牛乳茶", "英红牛乳茶", "清爽芭乐提", "清爽芭乐葡", "清爽巴乐提", "清爽巴乐葡",
                   "烤黑糖波波牛乳茶", "热烤黑糖波波牛乳", "热烤黑糖波波牛乳茶",
                   ],
        },
        "poi": {
            "蜜雪冰城": POI_DEFAULT,
            "霸王茶姬": POI_DEFAULT,
            "古茗": POI_DEFAULT,
            "喜茶": POI_DEFAULT,
        },
        "pickup": {
            "蜜雪冰城": PICKUP_LIST,
            "霸王茶姬": PICKUP_LIST,
            "古茗": PICKUP_LIST,
            "喜茶": PICKUP_LIST,
        },
        "slot": {
            "cup_shape": {
                "name": "杯型",
                "value": ["标准", "中杯", "大杯", "超大杯"],
                "required": True,
            },
            "temperature": {
                "name": "温度",
                "value": ["热", "冰", "热饮", "冷饮", "冰饮", "常温", "不加冰", "加冰", "少少冰", "少冰", "标准冰", "正常冰", "多冰", "去冰", "全冰", "凉的"],
                "required": True,
            },
            "random_cup": {
                "name": "商品数量",
                "value": ["1", "2", "3", "4", "5", "6", "一", "两", "三", "四", "五", "六"],
                "required": True,
            },
            "random_address": {
                "name": "配送地址",
                "value": ADDRESS_LIST,
                "required": True,
            },
            "brix": {
                "name": ["糖度", "甜度"],
                "value": ["无糖", "不加糖", "不另外加糖", "加糖", "微糖", "少糖", "半糖", "正常糖", "多糖", "七分糖", "五分糖", "三分糖",
                          "少少少甜", "少少甜", "标准甜", "少甜", "微甜", "多甜"],
            },
            "status": {
                "name": "状态",
                "value": ["冰沙", "非冰沙"],
            },
            "tea_base": {
                "name": "茶底",
                "value": ["抹茶", "绿妍", "去茶底"]
            },
            "additions": {
                "name": "加料",
                "value": ["标准", "珍珠", "椰果", "脆啵啵", "芋圆", "橙粒", "红豆", "饼干碎", "奶布丁", "果肉"]
            },
            "green": {
                "name": "吸管",
                "value": ["可降解吸管", "不使用吸管"]
            },
        }
    },
    {
        "scene_type": "快餐",
        "scene_name": "西餐-汉堡",
        "scene_name_en": "takeout_western_hamburger",
        "brand": ["麦当劳", "肯德基", "塔斯汀", "华莱士", "汉堡王"],
        "brand_alias": {
            "麦当劳": ["金拱门"],
            "肯德基": ["KFC"],
        },
        "product": {
            "麦当劳": ["金拱门双人煲", "辣腿薯乐四件套", "精选单人餐", "麦辣鸡腿汉堡套餐", "板烧鸡腿堡套餐", "麦辣鸡翅", "麦乐鸡", "巨无霸套餐", "双层深海鳕鱼堡", "麦香鱼套餐", "培根安格斯厚牛堡套餐", "培根芝士双牛堡"],
            "肯德基": ["招牌汉堡四件套", "三人随心配", "炸鸡随心选", "香辣鸡腿汉堡", "劲脆鸡腿汉堡", "新奥尔良炸鸡腿堡", "老北京鸡肉卷", "藤椒风味SPA堡", "吮指原味鸡", "黄金脆皮鸡", "香辣鸡翅", "劲爆鸡米花"],
            "塔斯汀": ["香辣鸡腿中国汉堡", "香辣鸡翅中国汉堡", "藤椒鸡腿中国汉堡", "培根煎蛋中国汉堡", "原味鸡腿中国汉堡", "盐酥鸡米花", "塔塔几块", "塔塔香鸡腿"],
            "华莱士": ["超值尝鲜三件套", "香酥多肉双人套餐", "蜜汁手扒鸡", "脆皮全鸡", "三味全鸡", "深海鳕鱼", "辣味鸡肉卷", "劲脆鲜虾堡"],
            "汉堡王": ["芝士牛堡", "火烤猪颈肉皇堡", "火烤传承单人餐", "火烧猪肘堡", "火烤风味蝴蝶翅"],
        },
        "poi": {
            "麦当劳": POI_DEFAULT,
            "肯德基": POI_DEFAULT,
            "塔斯汀": POI_DEFAULT,
            "华莱士": POI_DEFAULT,
            "汉堡王": POI_DEFAULT,
        },
        "pickup": {
            "麦当劳": PICKUP_LIST,
            "肯德基": PICKUP_LIST,
            "塔斯汀": PICKUP_LIST,
            "华莱士": PICKUP_LIST,
            "汉堡王": PICKUP_LIST,
        },
        "slot": {
            "random_cup": {
                "name": "商品数量",
                "value": ["1", "2", "3", "4", "5", "6", "一", "两", "三", "四", "五", "六"],
                "required": True,
            },
            "random_address": {
                "name": "配送地址",
                "value": ADDRESS_LIST,
                "required": True,
            },
            "cup_shape": {
                "name": "杯型",
                "value": ["标准", "中杯", "大杯", "超大杯"],
            },
            "temperature": {
                "name": "温度",
                "value": ["热", "冰", "热饮", "冷饮", "冰饮", "常温", "不加冰", "加冰", "少少冰", "少冰", "标准冰", "正常冰", "多冰", "去冰", "全冰", "凉的"],
            },
            "brix": {
                "name": ["糖度", "甜度"],
                "value": ["无糖", "不加糖", "不另外加糖", "加糖", "微糖", "少糖", "半糖", "正常糖", "多糖", "七分糖", "五分糖", "三分糖",
                          "少少少甜", "少少甜", "标准甜", "少甜", "微甜", "多甜"],
            },
        }
    },
    {
        "scene_type": "快餐",
        "scene_name": "西餐-披萨",
        "scene_name_en": "takeout_western_pizza",
        "brand": ["必胜客", "达美乐"],
        "brand_alias": {},
        "product": {
            "必胜客": ["披萨丰盛双人餐", "披萨汉堡超值双人餐", "披萨面饭一人食", "金枕榴莲波菠芝士系列卷边", "超级至尊卷边", "意式肉酱披萨", "夏威夷风情铁盘", "新奥尔良鸡肉意面"],
            "达美乐": ["土豆培根披萨", "金枪鱼海鲜荟萃披萨", "红薯薯泥流心卷边", "小龙虾香酥鸡比萨"],
        },
        "poi": {
            "必胜客": POI_DEFAULT,
            "达美乐": POI_DEFAULT,
        },
        "pickup": {
            "必胜客": PICKUP_LIST,
            "达美乐": PICKUP_LIST,
        },
        "slot": {
            "pizzaSize": {
                "name": ["份量", "尺寸"],
                "value": [
                    "9", "12", "9寸", "12寸", "9英寸", "12英寸", "2-3人份", "2人份",
                    "九", "十二", "九寸", "十二寸", "九英寸", "十二英寸", "三人份", "两人份",
                ],
                "required": True,
            },
            "flavor": {
                "name": "口味",
                "value": ["烤肉", "海鲜", "蔬菜", "榴莲", "巧克力"],
            },
            "crust": {
                "name": "饼底",
                "value": ["经典手拍", "轻巧薄脆", "酥香烤盘风味"],
            },
            "sauce": {
                "name": "底酱",
                "value": ["经典番茄酱", "奶油白酱", "香菜青酱", "番茄辣椒酱", "橄榄酱", "芝麻酱"],
            },
            "topping": {
                "name": "配料",
                "value": ["加榴莲", "加芝士", "加榴莲&芝士", "不额外加料"],
            },
        }
    },
    {
        "scene_type": "快餐",
        "scene_name": "韩餐",
        "scene_name_en": "takeout_korean",
        "brand": ["米村拌饭"],
        "brand_alias": {},
        "product": {
            "米村拌饭": ["烤牛肉拌饭", "经典三杯鸡", "招牌肥牛锅", "非遗石锅拌饭", "香辣鱿鱼", "石板肉酱豆腐"]
        },
        "poi": {
            "米村拌饭": POI_DEFAULT,
        },
        "pickup": {
            "米村拌饭": PICKUP_LIST,
        },
        "slot": {}
    },
    {
        "scene_type": "快餐",
        "scene_name": "中餐",
        "scene_name_en": "takeout_chinese",
        "brand": ["美团", "饿了么"],
        "brand_alias": {
            "美团": ["美团外卖"],
            "饿了么": ["饿了么外卖"],
        },
        "product": {
            "美团": ["老乡鸡", "嘉和一品", "西贝", "望京小腰", "海底捞", "魏家凉皮"],
            "饿了么": ["南城香", "永和大王", "西少爷", "海盗虾饭", "呷哺火锅", "疙瘩汤"],
        },
        "poi": {
            "美团": POI_DEFAULT,
            "饿了么": POI_DEFAULT,
        },
        "pickup": {
            "美团": PICKUP_LIST,
            "饿了么": PICKUP_LIST,
        },
        "slot": {}
    },
    {
        "scene_type": "正餐排号",
        "scene_name": "正餐排号",
        "scene_name_en": "meal_order",
        "brand": ["美味不用等"],
        "brand_alias": {},
        "product": {
            "美味不用等": MEAL_ORDER_POI_DEFAULT,
        },
        "poi": {
            "美味不用等": POI_DEFAULT,
        },
        "pickup": {},
        "slot": {
            "roomType": {
                "name": ["位置", "订座类型"],
                "value": ["均可", "大厅", "包间"],
                "required": True,
            },
            "attendance": {
                "name": ["人数", "就餐人数"],
                "value": [
                    "两人", "四人", "六人", "八人", "十人", "2人", "4人", "6人", "8人", "10人",
                    "两个", "四个", "六个", "八个", "十个", "2个", "4个", "6个", "8个", "10个",
                ],
                "required": True,
            },
            "mealDate": {
                "name": ["日期", "就餐日期"],
                "value": ["今天", "明天", "后天", "这周三", "周六"],
                "required": True,  # 可选槽转为必选槽，为了多生成一些样本
            },
            "mealTime": {
                "name": ["时间", "就餐时间"],
                "value": ["上午八点", "中午十一点", "中午十二点", "晚上六点", "晚上九点"],
                "required": True,  # 可选槽转为必选槽，为了多生成一些样本
            },
        }
    },
    {
        "scene_type": "快递",
        "scene_name": "快递",
        "scene_name_en": "express",
        "brand": ["支付宝我的快递", "菜鸟裹裹", "顺丰速运", "中通快递", "圆通快递", "申通快递", "韵达快递", "EMS中国邮政速递物流"],
        "brand_alias": {
            "支付宝我的快递": ["支付宝"],
            "菜鸟裹裹": ["菜鸟"],
            "顺丰速运": ["顺丰", "顺丰快递", "顺丰速递"],
            "中通快递": ["中通"],
            "圆通快递": ["圆通"],
            "申通快递": ["申通"],
            "韵达快递": ["韵达"],
            "EMS中国邮政速递物流": ["EMS"],
        },
        "product": {},
        "poi": {},
        "pickup": {},
        "slot": {
            "expressType": {
                "name": "快递类型",
                "value": ["寄出", "收到", "关注"],
                "required": True,
            },
            "expressStatus": {
                "name": "快递状态",
                "value": ["未发货", "待取件", "待寄退", "待支付", "在途", "运输中", "派送中", "待收件", "已签收"],
                "required": True,
            },
        }
    },
    {
        "scene_type": "日常出行用车",
        "scene_name": "停车",
        "scene_name_en": "travel_vehicle_park",
        "brand": ["车生活", "捷停车", "支付宝停车", "ETCP停车", "停简单", "乐速通", "ETC服务", "北京道路停车缴费", "云中停", "PP停车", "小艾停车助手", "保信", "一点停"],
        "brand_alias": {
            "ETC服务": ["ETC"],
            "ETCP停车": ["ETCP"],
            "北京道路停车缴费": ["北京道路停车"],
            "小艾停车助手": ["小艾停车"],
        },
        "product": {},
        "poi": {},
        "pickup": {},
        "slot": {
            "province": {
                "name": "省份",
                "value": ["京", "津", "冀", "鲁", "赣", "浙", "北京", "天津", "河北", "山东", "江西", "浙江"],
                "required": True,
            },
            "plateNum": {
                "name": "车牌号",
                "value": ["AV3H68", "B7F2K9", "C5D8L1", "DR6T32", "E2G7N5", "G4S1P8"],
                "required": True,
            },
        }
    },
    {
        "scene_type": "日常出行用车",
        "scene_name": "充电",
        "scene_name_en": "travel_vehicle_charge",
        "brand": ["支付宝充电", "星星充电", "小桔充电", "新电途", "特来电", "快电"],
        "brand_alias": {},
        "product": {},
        "poi": {},
        "pickup": {},
        "slot": {}
    },
    {
        "scene_type": "电费-缴费",
        "scene_name": "生活缴费",
        "scene_name_en": "electric_pay",
        "brand": ["网上国网"],
        "brand_alias": {},
        "product": {},
        "poi": {},
        "pickup": {},
        "slot": {}
    },
    {
        "scene_type": "电费-查询",
        "scene_name": "生活缴费",
        "scene_name_en": "electric_check",
        "brand": ["网上国网"],
        "brand_alias": {},
        "product": {},
        "poi": {},
        "pickup": {},
        "slot": {}
    },
    {
        "scene_type": "话费-缴费",
        "scene_name": "生活缴费",
        "scene_name_en": "phone_pay",
        "brand": ["手机营业厅"],
        "brand_alias": {},
        "product": {},
        "poi": {},
        "pickup": {},
        "slot": {}
    },
    {
        "scene_type": "话费-查询",
        "scene_name": "生活缴费",
        "scene_name_en": "phone_check",
        "brand": ["手机营业厅"],
        "brand_alias": {},
        "product": {},
        "poi": {},
        "pickup": {},
        "slot": {}
    },
    {
        "scene_type": "滴滴-一键",
        "scene_name": "代驾",
        "scene_name_en": "di_di_quick",
        "brand": ["滴滴代驾"],
        "brand_alias": {},
        "product": {},
        "poi": {},
        "pickup": {},
        "slot": {}
    },
    {
        "scene_type": "滴滴-代驾",
        "scene_name": "代驾",
        "scene_name_en": "di_di_instant",
        "brand": ["滴滴代驾"],
        "brand_alias": {},
        "product": {},
        "poi": {},
        "pickup": {},
        "slot": {}
    },
]


def get_scene_type_list():
    return [scene_item["scene_type"] for scene_item in SCENE_LIST]


def get_scene_name_list():
    return [scene_item["scene_name"] for scene_item in SCENE_LIST]


def get_scene_name_en_list():
    return [scene_item["scene_name_en"] for scene_item in SCENE_LIST]


def get_brand2scene_dict():
    return {brand: scene_item["scene_name"] for scene_item in SCENE_LIST for brand in scene_item["brand"]}


def get_scene_conf(scene_name_en):
    """获取场景配置"""
    for scene_item in SCENE_LIST:
        if scene_item.get("scene_name_en", "") == scene_name_en:
            return scene_item
    raise Exception(f"scene_name_en={scene_name_en} scene_conf does not exist.")


if __name__ == "__main__":
    print("scene_type:", get_scene_type_list())
    print("scene_name:", get_scene_name_list())
    print("scene_name_en:", get_scene_name_en_list())
    print("brand2scene:", get_brand2scene_dict())
    print("scene_conf:", get_scene_conf("drink_coffee"))

# python -m cua.plan.sample.scene
