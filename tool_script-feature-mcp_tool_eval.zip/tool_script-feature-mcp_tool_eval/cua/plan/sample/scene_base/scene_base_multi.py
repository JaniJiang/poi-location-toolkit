import copy
from utils.data_utils.int_utils import num_to_chinese
from cua.plan.sample.meta import *
from cua.plan.sample.func import *
from cua.plan.sample.scene import *
from cua.plan.sample.template import *


class SceneBaseMulti:

    def __init__(self, scene_name_en):
        self.scene_name_en = scene_name_en
        # 获取场景配置
        self.scene_conf = get_scene_conf(self.scene_name_en)
        self.scene_type = self.scene_conf["scene_type"]
        # 获取模板配置
        self.order_template_list, self.status_template_list = self.get_template_dict()
        # 获取其他配置
        self.notify_success = NOTIFY_DICT.get(self.scene_name_en, {}).get("SUCCESS", [])
        self.notify_progress = NOTIFY_DICT.get(self.scene_name_en, {}).get("PROGRESS", [])

    def get_template_dict(self):
        """获取模板配置"""
        order_template_list = ORDER_TEMPLATE_DICT.get(self.scene_name_en, [])
        status_template_list = STATUS_TEMPLATE_DICT.get(self.scene_name_en, [])
        if len(order_template_list) > 0:
            return order_template_list, status_template_list
        raise Exception(f"scene_name_en={self.scene_name_en} template_list does not exist.")

    def merge_conversations(self, origin_multi_conversations, new_multi_conversations):
        """合并多轮对话"""
        if len(new_multi_conversations) == 0:
            return origin_multi_conversations
        elif len(origin_multi_conversations) == 0:
            return new_multi_conversations
        merged_multi_conversations = []
        for origin_conversations in origin_multi_conversations:
            for new_conversations in new_multi_conversations:
                merged_multi_conversations.append(origin_conversations + new_conversations)
        return merged_multi_conversations

    def app_clarify(self, template, query_feature, hidden_feature):
        """模型澄清-应用澄清"""
        if self.scene_type in ["电费-查询", "电费-缴费", "话费-查询", "话费-缴费", "滴滴-一键", "滴滴-代驾"]:
            query_feature["brand"] = self.scene_conf["brand"][0]
            return [], query_feature
        multi_conversations = []
        if "brand" not in query_feature:
            brand_list = self.scene_conf["brand"]
            brand_choose_value = hidden_feature["brand"]
            # 兼容无需品牌的情况，比如生活缴费
            if brand_choose_value == "NONE":
                query_feature["brand"] = brand_choose_value
                return multi_conversations, query_feature
            # 构造额外槽位: 随机槽位+商品
            extra_slots = {}
            # if my_random.choice([True] + [False] * 3) is True:
            #     random_slot_dict = self.get_random_slot_dict()
            #     extra_slots.update(random_slot_dict)
            # 构造应用澄清对话(复用列表澄清list_clarify_choice)
            multi_conversations, query_feature = self.list_clarify_choice(
                template, query_feature, hidden_feature, "brand", "品牌", brand_list, brand_choose_value, TYPE_APP_CLARIFY, extra_slots)
            query_feature["brand"] = brand_choose_value
        return multi_conversations, query_feature

    def confirm_clarify(self, query_feature, hidden_feature):
        """模型澄清-肯否澄清"""
        multi_conversations = []
        # 已经在 list_clarify_choice 函数中处理，此处不再单独处理。
        return multi_conversations, query_feature

    def list_clarify(self, template, query_feature, hidden_feature, field_name):
        """模型澄清-列表澄清"""
        def get_poi_list():
            if len(self.scene_conf["poi"]) == 0:
                return []
            brand = query_feature["brand"]
            hidden_city = hidden_feature["city"]
            poi_list = self.scene_conf["poi"][brand][hidden_city]
            return poi_list

        multi_conversations = []
        if field_name not in query_feature:
            if field_name == "pickup":
                if self.scene_type not in ["茶饮", "快餐"]:
                    return multi_conversations, query_feature
                # TODO: 所有槽位都需要有term判断逻辑
                for pickup_term in PICKUP_TERM_LIST:
                    if pickup_term in template:
                        return multi_conversations, query_feature
                pickup_list = self.scene_conf["pickup"][query_feature["brand"]]
                pickup_choose_value = my_random.choice(pickup_list)
                # 构造额外槽位: 门店+配送方式
                extra_slots = {}
                if my_random.choice([True] + [False] * 3) is True:
                    poi_list = get_poi_list()
                    if len(poi_list) > 0:  # 兼容无需门店的情况，比如生活缴费
                        poi_choose_value = my_random.choice(poi_list)
                        extra_slots["poi"] = {"pos": "left", "value": poi_choose_value}
                # 构造列表澄清对话
                multi_conversations, query_feature = self.list_clarify_choice(
                    template, query_feature, hidden_feature, "pickup", "取餐方式", pickup_list, pickup_choose_value, TYPE_LIST_CLARIFY, extra_slots)
            elif field_name == "poi":
                poi_list = get_poi_list()
                if len(poi_list) == 0:  # 兼容无需门店的情况，比如生活缴费
                    return multi_conversations, query_feature
                poi_choose_value = my_random.choice(poi_list)
                if self.scene_type in ["正餐排号"] and query_feature.get("product", "").endswith("店") is True:
                    return multi_conversations, query_feature
                # 构造列表澄清对话
                multi_conversations, query_feature = self.list_clarify_choice(
                    template, query_feature, hidden_feature, "poi", "门店", poi_list, poi_choose_value, TYPE_LIST_CLARIFY)
            elif field_name == "product":
                brand = query_feature["brand"]
                product_list = self.scene_conf.get("product", {}).get(brand, [])
                if len(product_list) == 0:  # 兼容无需产品的情况
                    return multi_conversations, query_feature
                product_choose_value = my_random.choice(product_list)
                # 构造额外槽位: 基于多轮模板
                extra_slots, extra_template = {}, ""
                if my_random.choice([True] + [False] * 1) is True:
                    query_feature[field_name] = product_choose_value
                    extra_slots, extra_template = self.get_multi_round_slots(field_name, query_feature)
                # 构造列表澄清对话
                field_name_zh = "餐厅" if self.scene_type in ["正餐排号"] else "商品"
                multi_conversations, query_feature = self.list_clarify_choice(
                    template, query_feature, hidden_feature, "product", field_name_zh, product_list, product_choose_value, TYPE_LIST_CLARIFY, extra_slots, extra_template)
            elif field_name == "link_account":
                user_response = "继续执行小程序"
                current_conversations = [
                    {"role": "assistant", "content": "请手动绑定用电户号,完成后请说继续执行小程序", "type": TYPE_LIST_CLARIFY},
                    {
                        "role": "user",
                        "content": user_response,
                        "arguments": {field_name: user_response},
                        "type": TYPE_MULTI_ROUND,
                    },
                ]
                multi_conversations.append(current_conversations)
        return multi_conversations, query_feature

    def get_multi_round_slots(self, field_name, query_feature):
        template_list = MULTI_ROUND_TEMPLATE_DICT.get(self.scene_name_en, {}).get(field_name, [])
        if len(template_list) == 0:
            return {}, ""
        template = my_random.choice(template_list)
        param_name_list = parse_template(template)
        specify_slot_dict = self.get_specify_slot_dict(param_name_list, query_feature)
        return specify_slot_dict, template

    def get_specify_slot_dict(self, slot_name_list: List[str], query_feature):
        slot_dict = copy.deepcopy(self.scene_conf["slot"])
        specify_slot_dict = {}
        for slot_name in slot_name_list:
            if slot_name.startswith("slot__") is True:
                param_name_segs = slot_name.split("__")
                slot_name = param_name_segs[1]
                slot_value = my_random.choice(slot_dict[slot_name]["value"])
                specify_slot_dict[slot_name] = {"value": slot_value}
            elif slot_name in query_feature:
                specify_slot_dict[slot_name] = {"value": query_feature[slot_name]}
            else:
                raise
                return {}
        return specify_slot_dict

    def get_random_slot_dict(self):
        slot_dict = copy.deepcopy(self.scene_conf["slot"])
        slot_name_list = [slot_name for slot_name in list(slot_dict.keys())
                          if slot_name in WHITE_SLOT_NAME_LIST]
        if len(slot_name_list) == 0:
            return {}
        random_slot_name_list = my_random.sample(slot_name_list,
                                                 min(len(slot_name_list), my_random.choice([1, 2, 3])))
        random_slot_dict = {slot_name: {"value": my_random.choice(slot_dict[slot_name]["value"])}
                            for slot_name in random_slot_name_list}
        return random_slot_dict

    def slot_clarify(self, template, query_feature, hidden_feature):
        """模型澄清-槽位澄清"""
        multi_conversations = []
        slot_dict = self.scene_conf["slot"]
        for field_name, field_item in slot_dict.items():
            # 判断槽位是否已存在
            if field_name in query_feature:
                continue
            # 判断是否使用槽位
            if self.check_need_slot(field_item, template) is False:
                continue
            # 生成该槽位的样本
            field_name_zh = self.get_field_name(field_item["name"])
            field_value_list = field_item["value"]
            field_choose_value = my_random.choice(field_value_list)
            current_multi_conversations, query_feature = self.list_clarify_choice(
                template, query_feature, hidden_feature, field_name, field_name_zh, field_value_list, field_choose_value, TYPE_SLOT_CLARIFY)
            choose_multi_conversations = my_random.sample(current_multi_conversations, 1)
            multi_conversations = self.merge_conversations(multi_conversations, choose_multi_conversations)
        return multi_conversations, query_feature

    def check_need_slot(self, slot_conf, template):
        """判断是否使用槽位"""
        if slot_conf.get("required", False) is True:
            return True
        return my_random.choice([True] + [False] * 9)

    def get_field_name(self, field_name):
        if type(field_name) is list:
            return my_random.choice(field_name)
        return field_name

    def add_condition(self, query_feature, clarify_type):
        """用户打断-增加条件"""
        need_add_condition = True if my_random.choice([True] + [False] * 9) is True else False
        if clarify_type not in [TYPE_SLOT_CLARIFY] or need_add_condition is False:
            return [], {}
        # 添加操作
        slot_dict = copy.deepcopy(self.scene_conf["slot"])
        all_slot_name_list = list(slot_dict.keys())
        all_feature_name_list = list(query_feature.keys())
        add_field_name_list = [x for x in all_slot_name_list if x not in all_feature_name_list]
        if len(add_field_name_list) == 0:
            return [], {}
        field_name = my_random.choice(add_field_name_list)
        field_name_zh = self.get_field_name(slot_dict[field_name]["name"])
        field_value_list = slot_dict[field_name]["value"]
        field_choose_value = my_random.choice(field_value_list)
        add_content_list = [
            f"{field_choose_value}",
            f"要{field_choose_value}的",
            f"{field_name_zh}要{field_choose_value}的",
        ]
        add_content = my_random.choice(add_content_list)
        add_query_feature = {field_name: field_choose_value}
        add_conversations = [
            {
                "role": "user", "content": add_content,
                "type": TYPE_ADD_CONDITION, "arguments": add_query_feature,
            },
            {"role": "assistant", "content": f"好的，已增加{field_name_zh}为{field_choose_value}"},
        ]
        return add_conversations, add_query_feature

    def delete_condition(self, query_feature, clarify_type):
        """用户打断-删除条件"""
        need_delete_condition = True if my_random.choice([True] + [False] * 9) is True else False
        if clarify_type not in [TYPE_SLOT_CLARIFY] or need_delete_condition is False:
            return [], {}
        # 删除操作
        slot_dict = copy.deepcopy(self.scene_conf["slot"])
        all_feature_name_list = list(query_feature.keys())
        all_slot_name_list = list(slot_dict.keys())
        delete_field_name_list = [x for x in all_slot_name_list if x in all_feature_name_list]
        if len(delete_field_name_list) == 0:
            return [], {}
        field_name = my_random.choice(delete_field_name_list)
        field_name_zh = self.get_field_name(slot_dict[field_name]["name"])
        field_value = query_feature[field_name]
        if type(field_value) is list:
            field_value = field_value[0]
        delete_content_list = [
            f"不要{field_value}",
            f"不要{field_value}的",
            f"哦不要{field_value}的",
            f"噢不要{field_value}的",
            f"{field_name_zh}不要{field_value}的",
            f"{field_name_zh}删除{field_value}",
        ]
        delete_content = my_random.choice(delete_content_list)
        delete_query_feature = {field_name: field_value}
        delete_conversations = [
            {
                "role": "user", "content": delete_content,
                "type": TYPE_DELETE_CONDITION, "arguments": delete_query_feature,
            },
            {"role": "assistant", "content": f"好的，{field_name_zh}已去掉{field_value}"},
        ]
        return delete_conversations, delete_query_feature

    def modify_condition(self, query_feature, clarify_type):
        """用户打断-修改条件"""
        need_modify_condition = True if my_random.choice([True] + [False] * 9) is True else False
        if clarify_type not in [TYPE_SLOT_CLARIFY] or need_modify_condition is False:
            return [], {}
        # 修改操作
        slot_dict = copy.deepcopy(self.scene_conf["slot"])
        all_feature_name_list = list(query_feature.keys())
        all_slot_name_list = list(slot_dict.keys())
        modify_field_name_list = [x for x in all_slot_name_list if x in all_feature_name_list]
        if len(modify_field_name_list) == 0:
            return [], {}
        field_name = my_random.choice(modify_field_name_list)
        field_value = query_feature[field_name]
        field_name_zh = self.get_field_name(slot_dict[field_name]["name"])
        field_value_list = slot_dict[field_name]["value"]
        if field_value in field_value_list:  # TODO: 临时fix
            field_value_list.remove(field_value)
        field_choose_value = my_random.choice(field_value_list)
        modify_content_list = [
            f"要{field_choose_value}",
            f"要{field_choose_value}的",
            f"哦不对要{field_choose_value}的",
            f"噢不对要{field_choose_value}的",
            f"{field_name_zh}修改为{field_choose_value}",
            f"{field_name_zh}更新为{field_choose_value}",
            f"还是换成{field_choose_value}的吧，最近在减肥",
        ]
        modify_content = my_random.choice(modify_content_list)
        modify_query_feature = {field_name: field_choose_value}
        modify_conversations = [
            {
                "role": "user", "content": modify_content,
                "type": TYPE_MODIFY_CONDITION, "arguments": modify_query_feature,
            },
            {"role": "assistant", "content": f"好的，已修改{field_name_zh}为{field_choose_value}"},
        ]
        return modify_conversations, modify_query_feature

    def ask_privacy_agreement(self, template, query_feature):
        """模型澄清-槽位澄清-隐私协议"""
        if self.scene_type not in ["茶饮", "快餐", "正餐排号", "电费-查询", "电费-缴费", "滴滴-代驾", "滴滴-一键"]:
            return []
        if my_random.choice([True] + [False] * 4) is False:
            return []
        # 隐私协议
        if self.scene_type in ["电费-查询", "电费-缴费", "滴滴-代驾", "滴滴-一键"]:
            assistant_list = PRIVACY_AGREEMENT_ASSISTANT_FOR_SPECIAL_SCENE[self.scene_type]
        else:
            assistant_list = PRIVACY_AGREEMENT_ASSISTANT_LIST
        privacy_assistant_content = my_random.choice(assistant_list)
        privacy_user_content = my_random.choice(AGREEMENT_USER_LIST)
        privacy_user_content = self.set_user_suffix_continue(
            privacy_user_content, template, query_feature)
        privacy_agreement_conversations = [
            {"role": "assistant", "content": privacy_assistant_content, "type": TYPE_ASK_PRIVACY_AGREEMENT},
            {"role": "user", "content": privacy_user_content},
        ]
        if self.scene_type in ["电费-查询", "电费-缴费"]:
            return [privacy_agreement_conversations]
        # 位置协议
        if self.scene_type in ["滴滴-代驾", "滴滴-一键"]:
            assistant_list = LOCATION_AGREEMENT_DIDI_ASSISTANT_LIST
        else:
            assistant_list = LOCATION_AGREEMENT_ASSISTANT_LIST
        location_assistant_content = my_random.choice(assistant_list)
        location_user_content = my_random.choice(AGREEMENT_USER_LIST)
        location_user_content = self.set_user_suffix_continue(location_user_content, template, query_feature)
        location_agreement_conversations = [
            {"role": "assistant", "content": location_assistant_content, "type": TYPE_ASK_LOCATION_AGREEMENT},
            {"role": "user", "content": location_user_content},
        ]
        # 合并对话
        multi_conversations = [privacy_agreement_conversations + location_agreement_conversations]
        return multi_conversations

    def ask_phone_number(self, template, query_feature):
        """模型澄清-槽位澄清-电话号码"""
        if self.scene_type not in ["话费-查询", "话费-缴费"]:
            return [], query_feature
        multi_conversations = []
        if "random_phoneNumber" in query_feature:
            assistant_content = PHONENUMBER_ASSISTANT_DICT[self.scene_type]
            user_content = my_random.choice(PHONENUMBER_USER_LIST)
            current_conversations = [
                {"role": "assistant", "content": assistant_content, "type": TYPE_ASK_PHONENUMBER},
                {"role": "user", "content": user_content},
            ]
            multi_conversations.extend(current_conversations)
        assistant_content = WHICHNUMBER_ASSISTANT_DICT[self.scene_type]
        generated_number, cn_rep = random_phoneNumber("detail")
        user_content = my_random.choice([generated_number, cn_rep])
        query_feature["random_phoneNumber"] = generated_number[-4:]
        current_conversations = [
            {"role": "assistant", "content": assistant_content, "type": TYPE_ASK_PHONENUMBER},
            {"role": "user", "content": user_content},
        ]
        multi_conversations.extend(current_conversations)
        if self.scene_type in ["话费-查询"]:
            assistant_content = "验证码已经发送了,请说出验证码"
            user_content = random_captcha()
            current_conversations = [
                {"role": "assistant", "content": assistant_content, "type": TYPE_ASK_PHONENUMBER},
                {"role": "user", "content": user_content},
            ]
            multi_conversations.extend(current_conversations)
        return [multi_conversations], query_feature

    def ask_location(self, template, query_feature):
        """模型澄清-列表澄清-代驾地点"""
        if self.scene_type not in ["滴滴-代驾"]:
            return [], query_feature
        multi_conversations = []
        assistant_content = my_random.choice(STRAT_LOCALTION_CHECK_ASSISTANT_LIST)
        choiced_index = my_random.randint(0, 2)
        if my_random.random() < 0.33:
            user_content = "修改起点"
        else:
            if my_random.random() < 0.5:
                start_location = random_location(start=True)
                query_feature["start_location"] = start_location
                user_content = "修改起点," + start_location
            else:
                final_location = random_location()
                query_feature["final_location"] = final_location
                user_content = final_location
        current_conversations = [
            {"role": "assistant", "content": assistant_content, "type": TYPE_ASK_LOCATION},
            {"role": "user", "content": user_content},
        ]
        multi_conversations.extend(current_conversations)
        if user_content == "修改起点":
            assistant_content = my_random.choice(STRAT_LOCALTION_ASSISTANT_LIST)
            start_location = random_location(start=True)
            query_feature["start_location"] = start_location
            user_content = start_location
            current_conversations = [
                {"role": "assistant", "content": assistant_content, "type": TYPE_ASK_LOCATION},
                {"role": "user", "content": user_content},
            ]
            multi_conversations.extend(current_conversations)
        if "final_location" not in query_feature:
            assistant_content = my_random.choice(FINAL_LOCALTION_ASSISTANT_LIST)
            final_location = random_location()
            user_content = final_location
            current_conversations = [
                {"role": "assistant", "content": assistant_content, "type": TYPE_ASK_LOCATION},
                {"role": "user", "content": user_content},
            ]
            multi_conversations.extend(current_conversations)
        assistant_content = my_random.choice(FINAL_LOCALTION_2_ASSISTANT_LIST)
        final_location = random_location()
        query_feature["final_location"] = final_location
        user_content = final_location
        current_conversations = [
            {"role": "assistant", "content": assistant_content, "type": TYPE_ASK_LOCATION},
            {"role": "user", "content": user_content},
        ]
        multi_conversations.extend(current_conversations)
        return [multi_conversations], query_feature

    def ask_server_type(self, template, query_feature):
        """模型澄清-槽位澄清-代驾类型"""
        if self.scene_type not in ["滴滴-代驾"]:
            return [], query_feature
        assistant_content = my_random.choice(SERVER_TYPT_ASSISTANT_LIST)
        user_content = my_random.choice(SERVER_TYPT_USER_LIST)
        query_feature["server_type"] = user_content
        multi_conversations = [[
            {"role": "assistant", "content": assistant_content, "type": TYPE_ASK_SERVERTYPE},
            {"role": "user", "content": user_content},
        ]]
        return multi_conversations, query_feature

    def ask_take_order_time(self, template, query_feature):
        """模型澄清-槽位澄清-取餐时间"""
        if self.scene_type not in ["茶饮", "快餐"]:
            return []
        assistant_content = my_random.choice(TAKE_ORDER_TIME_ASSISTANT_LIST)
        user_content = my_random.choice(TAKE_ORDER_TIME_USER_LIST)
        user_content = self.set_user_suffix_continue(user_content, template, query_feature)
        take_order_time_multi_conversations = [[
            {"role": "assistant", "content": assistant_content, "type": TYPE_ASK_TAKE_ORDER_TIME},
            {"role": "user", "content": user_content},
        ]]
        return take_order_time_multi_conversations

    def ask_charge_amount(self, query_feature):
        if self.scene_type not in ["电费-查询", "电费-缴费", "话费-缴费"]:
            return [], query_feature
        if "random_amount" not in query_feature:
            assistant_content = my_random.choice(CHARGE_AMOUNT_ASSISTANT_DICT[self.scene_type])
            num_rep, cn_rep, generated_amount = random_amount("detail")
            user_content = my_random.choice([num_rep, cn_rep])
            charge_amount_multi_conversations = [[
                {"role": "assistant", "content": assistant_content, "type": TYPE_ASK_AMOUNT},
                {"role": "user", "content": user_content},
            ]]
            query_feature["random_amount"] = generated_amount
            return charge_amount_multi_conversations, query_feature
        else:
            return [], query_feature

    def ask_other_demand(self, template, query_feature):
        """模型澄清-槽位澄清-其他需求"""
        other_demand_assistant_list = OTHER_DEMAND_ASSISTANT_DICT.get(self.scene_type, [])
        other_demand_user_list = OTHER_DEMAND_USER_DICT.get(self.scene_type, [])
        if len(other_demand_assistant_list) == 0 or other_demand_user_list == 0:
            return []
        assistant_content = my_random.choice(other_demand_assistant_list)
        user_content = my_random.choice(other_demand_user_list)
        user_content = self.set_user_suffix_continue(user_content, template, query_feature)
        other_demand_multi_conversations = [[
            {"role": "assistant", "content": assistant_content, "type": TYPE_ASK_OTHER_DEMAND},
            {"role": "user", "content": user_content},
        ]]
        return other_demand_multi_conversations

    def ask_final_order(self, template, query_feature):
        """模型澄清-槽位澄清-最终下单"""
        if self.scene_type not in ["茶饮", "快餐", "电费-查询", "电费-缴费", "话费-缴费", "滴滴-一键", "滴滴-代驾"]:
            return []
        final_order_multi_conversation = []
        if self.scene_type in ["茶饮", "快餐"]:
            # 下单前确认隐私条款
            if my_random.choice([True] + [False] * 4) is True:
                confirm_assistant_content = my_random.choice(FINAL_ORDER_CONFIRM_ASSISTANT_LIST)
                confirm_user_content = my_random.choice(AGREEMENT_USER_LIST * 5 + EXACT_CONFIRM_QUERY_LIST)
                confirm_user_content = self.set_user_suffix_continue(confirm_user_content, template, query_feature)
                final_order_multi_conversation.extend([
                    {"role": "assistant", "content": confirm_assistant_content, "type": TYPE_ASK_FINAL_ORDER_CONFIRM},
                    {"role": "user", "content": confirm_user_content},
                ])
            # 下单前确认登录
            if my_random.choice([True] + [False] * 4) is True:
                login_assistant_content = my_random.choice(FINAL_ORDER_LOGIN_ASSISTANT_LIST)
                login_user_content = my_random.choice(AGREEMENT_USER_LIST * 5 + EXACT_CONFIRM_QUERY_LIST)
                login_user_content = self.set_user_suffix_continue(login_user_content, template, query_feature)
                final_order_multi_conversation.extend([
                    {"role": "assistant", "content": login_assistant_content, "type": TYPE_ASK_FINAL_ORDER_LOGIN},
                    {"role": "user", "content": login_user_content},
                ])
        # 确认下单/支付
        assistant_content = my_random.choice(FINAL_ORDER_ASSISTANT_DICT[self.scene_type])
        if self.scene_type in ["电费-查询", "电费-缴费"]:
            assistant_content = assistant_content.format(amount=query_feature["random_amount"])
        elif self.scene_type in ["话费-缴费"]:
            assistant_content = assistant_content.format(
                tail_number=query_feature["random_phoneNumber"], amount=query_feature["random_amount"])
        user_content = my_random.choice(FINAL_ORDER_USER_DICT[self.scene_type] * 5 + EXACT_CONFIRM_QUERY_LIST)
        user_content = self.set_user_suffix_continue(user_content, template, query_feature)
        final_order_multi_conversation.extend([
            {"role": "assistant", "content": assistant_content, "type": TYPE_ASK_FINAL_ORDER},
            {"role": "user", "content": user_content},
        ])
        # 模型澄清完成后，通知用户下单成功
        if user_content.startswith("不") is False and len(self.notify_success) > 0:
            final_order_multi_conversation.append(
                {"role": "assistant", "content": my_random.choice(self.notify_success), "type": TYPE_NOTIFY_SUCCESS}
            )
        final_order_multi_conversations = [final_order_multi_conversation]
        return final_order_multi_conversations

    def set_user_suffix_continue(self, user_content, template, query_feature):
        if self.scene_type not in ["茶饮", "快餐"] or "不" in user_content:
            return user_content
        if my_random.choice([True] + [False] * 2) is False:
            return user_content
        suffix_continue_value_list = copy.deepcopy(COMMON_CONTINUE_ORDER_QUERY_LIST)
        # 填充brand
        brand = query_feature.get("brand", "")
        if brand != "":
            suffix_continue_value_list.extend([
                f"在{brand}继续", f"在{brand}继续点单", f"在{brand}继续提交订单", f"在{brand}继续订单",
                f"在{brand}帮我继续", f"在{brand}帮我继续点单", f"在{brand}帮我继续提交订单", f"在{brand}帮我继续订单",
                f"在{brand}小程序里帮我继续", f"在{brand}小程序里帮我继续点单", f"在{brand}小程序里帮我继续提交订单", f"在{brand}小程序里帮我继续订单",
            ])
        # 填充category
        category = parse_category_from_template(template)
        if category != "":
            suffix_continue_value_list.extend([
                f"继续点{category}", f"继续点单{category}",
                f"帮我继续点{category}", f"帮我继续点单{category}",
            ])
        user_content = user_content + "，" + my_random.choice(suffix_continue_value_list)
        return user_content

    def ask_status(self, query_feature, hidden_feature, status_template):
        """询问状态"""
        status_query = copy.deepcopy(status_template)
        arguments = {}
        for key, value in query_feature.items():
            placeholder = f"{{{key}}}"
            if placeholder not in status_query:
                continue
            if isinstance(value, list):  # 对于列表类型的变量
                value = "和".join(value)
                return []  # 列表类型的先不问状态了(因为影响提槽)
            status_query = status_query.replace(placeholder, str(value))
            arguments[key] = str(value)
        multi_conversations = [[
            {"role": "user", "content": status_query, "type": TYPE_ASK_STATUS, "arguments": arguments},
            {"role": "assistant", "content": my_random.choice(self.notify_progress), "type": TYPE_NOTIFY_PROGRESS},
        ]]
        return multi_conversations

    def neg_case_clarify(self):
        """模型澄清-澄清负例"""
        multi_conversations = []
        return multi_conversations

    def break_neg_case(self):
        """用户打断-打断负例"""
        multi_conversations = []
        return multi_conversations

    def list_clarify_choice(self, template, query_feature, hidden_feature, field_name, field_name_zh, field_value_list, field_choose_value, clarify_type, extra_slots={}, extra_template=""):
        """模型澄清-列表澄清样本构建"""
        # 更新特征
        query_feature[field_name] = field_choose_value
        user_arguments = {field_name: field_choose_value}
        if len(extra_slots) > 0:
            for k, v_dict in extra_slots.items():
                query_feature[k] = v_dict["value"]
                user_arguments[k] = v_dict["value"]
        # 构造模型回复内容
        category = hidden_feature["category"]
        assistant_content_list = self.build_assistant_content(
            template, category, field_name, field_name_zh, field_value_list, field_choose_value, query_feature)

        # 多轮指定用户回复话术
        multi_conversations = []
        if len(extra_slots) > 0 and extra_template != "":
            for _ in range(min(5, len(assistant_content_list))):
                assistant_content = my_random.choice(assistant_content_list)
                current_conversations = [
                    {"role": "assistant", "content": assistant_content, "type": clarify_type},
                    {
                        "role": "user",
                        "content": self.build_user_content_specify(extra_slots, extra_template),
                        "arguments": user_arguments,
                        "type": TYPE_MULTI_ROUND,
                    },
                ]
                multi_conversations.append(current_conversations)
            return multi_conversations, query_feature

        # 用户打断-增加条件
        add_conversations, add_query_feature = self.add_condition(query_feature, clarify_type)
        query_feature.update(add_query_feature)
        # 用户打断-删除条件
        delete_conversations, delete_query_feature = self.delete_condition(query_feature, clarify_type)
        for delete_field_name, delete_field_value in delete_query_feature.items():
            if delete_field_name in query_feature:
                current_field_value = query_feature[delete_field_name]
                if type(current_field_value) is list:
                    if delete_field_value in current_field_value:
                        current_field_value.remove(delete_field_value)
                        query_feature[delete_field_name] = current_field_value
                else:
                    del query_feature[delete_field_name]
        # 用户打断-更新条件
        modify_conversations, modify_query_feature = self.modify_condition(query_feature, clarify_type)
        for modify_field_name, modify_field_value in modify_query_feature.items():
            query_feature[modify_field_name] = modify_field_value

        # 用户回复字段名称
        for _ in range(min(5, len(assistant_content_list))):
            assistant_content = my_random.choice(assistant_content_list)
            user_content = self.build_user_content_value(
                field_name, field_name_zh, field_choose_value, extra_slots, user_arguments, clarify_type, assistant_content, category)
            current_conversations = [
                {"role": "assistant", "content": assistant_content, "type": clarify_type},
                {"role": "user", "content": user_content, "arguments": user_arguments},
            ]
            multi_conversations.append(current_conversations +
                                       add_conversations + delete_conversations + modify_conversations)
        # 用户回复字段索引
        if len(field_value_list) > 1 and my_random.choice([True] + [False] * 4) is True:
            for assistant_content in my_random.sample(assistant_content_list, min(3, len(assistant_content_list))):
                if self.need_user_index(field_name, assistant_content) is True:
                    user_index_content = self.build_user_content_index(
                        field_name, field_name_zh, field_value_list, field_choose_value)
                    current_conversations = [
                        {"role": "assistant", "content": assistant_content, "type": clarify_type},
                        {"role": "user", "content": user_index_content, "arguments": user_arguments},
                    ]
                    if my_random.choice([True] + [False] * 4) is True:  # 肯否澄清
                        current_conversations.extend([
                            {"role": "assistant", "content": f"确认是{field_choose_value}吗？", "type": TYPE_CONFIRM_CLARIFY},
                            {"role": "user", "content": my_random.choice(EXACT_CONFIRM_QUERY_LIST)},
                        ])
                    multi_conversations.append(current_conversations +
                                               add_conversations + delete_conversations + modify_conversations)
        return multi_conversations, query_feature

    def build_user_content_specify(self, extra_slots, extra_template):
        content = copy.deepcopy(extra_template)
        for slot_name, v_dict in extra_slots.items():
            slot_value = str(v_dict["value"])
            placeholder_a = f"{{{slot_name}}}"
            placeholder_b = f"{{slot__{slot_name}__1}}"
            if placeholder_a in content:
                content = content.replace(placeholder_a, slot_value)
            elif placeholder_b in content:
                content = content.replace(placeholder_b, slot_value)
        return content

    def build_user_content_value(self, field_name, field_name_zh, field_choose_value, extra_slots, query_feature, clarify_type, assistant_content, category):
        """用户回复列表中的内容"""
        product = ""
        if "product" in query_feature and type(query_feature["product"]) is str:
            product = query_feature["product"]
        result_user_content_list = []
        ###### 挑选默认回复话术 ######
        # 默认回复话术列表
        default_candidate_value_list = []
        if "是否继续" in assistant_content or "确认点单" in assistant_content or "继续点单" in assistant_content:
            default_candidate_value_list.extend(COMMON_CONTINUE_QUERY_LIST * 5 + EXACT_CONFIRM_QUERY_LIST)
            if field_name == "pickup":
                default_candidate_value_list.extend(PICKUP_CONTINUE_QUERY_LIST * 2)
        else:
            default_candidate_value_list = [field_choose_value] * 10
        # 挑选默认回复话术
        default_content_list = my_random.sample(default_candidate_value_list, min(len(default_candidate_value_list), 5))
        processed_contents = set()
        for content in default_content_list:
            if content in processed_contents:
                continue
            processed_contents.add(content)
            # 用户同时描述多个槽位，比如[门店]和[取餐方式]
            if len(extra_slots) > 0:
                for _, v_dict in extra_slots.items():
                    slot_pos = v_dict.get("pos", "right")
                    slot_value = v_dict["value"]
                    if slot_pos == "left":  # 扩展槽位加在左侧
                        content = slot_value + content
                    else:  # 扩展槽位加在右侧
                        content = content + "，" + slot_value
            # 增加产品后缀
            product_suffix = False
            if my_random.choice([True] + [False] * 4) is True \
                    and clarify_type in [TYPE_SLOT_CLARIFY] \
                    and content.endswith("的") is True \
                    and product != "":
                content = content + product
                product_suffix = True
            # 增加类别后缀
            if my_random.choice([True] + [False] * 4) is True \
                    and clarify_type in [TYPE_SLOT_CLARIFY] \
                    and content.endswith("的") is True \
                    and category != "" \
                    and product_suffix is False:
                content = content + category
            # 增加口语化前后缀
            content = self.set_user_affix(field_name, field_name_zh, content)
            result_user_content_list.append(content)

        ###### 挑选特殊回复话术 ######
        # 特殊回复话术列表
        special_candidate_value_list = [
            "默认选项", "默认就行",
            # 结合记忆
            "和上次一样", "和以前一样", "和昨天一样", "我要和昨天一样的",
            "按照我的习惯来", "根据我的习惯选择即可", "我最常选择的选项",
        ]
        if field_name_zh in ["商品"]:  # 根据槽位名称增加特殊回复话术
            special_candidate_value_list.extend([
                f"上次买的{field_choose_value}还不错，帮我再点一杯",
                f"上次点的{field_choose_value}味道还不错，这次还能再点吗？",
                f"一杯{field_choose_value}, 一会去拿"
            ])
        if field_name_zh in ["配送地址"]:  # 根据槽位名称增加特殊回复话术
            special_candidate_value_list.extend([
                "送到家里", "送到单位", "送到公司", "送到我最常去的地方",
                "送到我老婆单位", "送到我老公单位", "送到我爸公司", "送到我妈公司",
                "送到我儿子学校", "送到我女儿学校", "送到我孩子幼儿园", "送到我孩子大学",
                "给我老婆点的送过去", "给我老公点的送过去", "给我嫂子点的", "给我哥点的",
                "送给我爸", "送给我妈", "送给我爷爷", "送给我奶奶", "送给我弟弟", "送给我妹妹",
            ])
        if field_name_zh in ["温度"]:  # 根据槽位名称增加特殊回复话术
            special_candidate_value_list.extend([
                "最热的", "温度低一点", "温度高一点", "来个热点的吧",
                f"上次选的{field_name_zh}太烫了，这次能提醒下门店吗",
                f"上次选的{field_choose_value}太烫了，这次能提醒下门店吗",
            ])
            if category != "":
                special_candidate_value_list.extend([
                    f"{field_choose_value}{category}", f"{field_choose_value}{category}。"
                    f"{field_choose_value}的{category}", f"{field_choose_value}的{category}。"
                ])
            if product != "":
                special_candidate_value_list.extend([
                    f"{field_choose_value}{product}", f"{field_choose_value}{product}。",
                    f"{field_choose_value}的{product}", f"{field_choose_value}的{product}。",
                ])
        if field_name_zh in ["商品数量"]:
            special_candidate_value_list.extend([f"{field_choose_value}杯"])
            if category != "":
                special_candidate_value_list.extend([
                    f"{field_choose_value}杯{category}", f"{field_choose_value}杯{category}。",
                ])
            if product != "":
                special_candidate_value_list.extend([
                    f"{field_choose_value}杯{product}", f"{field_choose_value}杯{product}。",
                ])
        if field_name in ["poi"]:
            special_candidate_value_list.extend([
                "最近门店", "最近的门店", "离得近的门店", "离我近的门店", "我最近的门店", "附近的门店", "附近门店",
                "最近的", "近一点的", "收藏的第一个门店", "收藏的门店",
                f"是{field_choose_value}", f"就是{field_choose_value}", f"是那个{field_choose_value}",
                f"在{field_choose_value}", f"下单在{field_choose_value}", f"点单在{field_choose_value}",
                f"在我旁边的{field_choose_value}", f"离我最近的{field_choose_value}", f"就在{field_choose_value}离得近",
                f"看下在{field_choose_value}", f"{field_choose_value}那儿新开了一家", f"{field_choose_value}哪儿新开了一家",
            ])
        if field_name in ["expressType"]:
            special_candidate_value_list.extend(EXPRESS_TYPE_QUERY_LIST * 2)
        if self.scene_type in ["正餐排号"]:
            if field_name in ["product"]:
                special_candidate_value_list.extend([
                    f"我吃{field_choose_value}", f"我要吃{field_choose_value}", f"我想吃{field_choose_value}",
                    f"取个{field_choose_value}呗", f"取个{field_choose_value}的号呗", f"帮我取个{field_choose_value}",
                ])
            if field_name in ["attendance"]:
                special_candidate_value_list.extend([
                    f"差不多{field_choose_value}", f"我们差不多{field_choose_value}",
                    f"我们人差不多{field_choose_value}", f"我们人好多差不多{field_choose_value}",
                    f"我们人好多差不多算{field_choose_value}", f"我们人好多差不多有{field_choose_value}",
                    f"我们人好多差不多算是{field_choose_value}",
                ])
        if clarify_type in [TYPE_SLOT_CLARIFY]:  # 根据澄清类型增加特殊回复话术
            special_candidate_value_list.extend([
                f"和以前一样，不要再提醒我选{field_name_zh}", f"和昨天一样就行，不用提醒我选{field_name_zh}了",
            ])
        # 挑选殊回复话术
        special_content_list = my_random.sample(special_candidate_value_list, min(len(special_candidate_value_list), 2))
        for content in special_content_list:
            # 增加口语化前后缀
            content = self.set_user_affix(field_name, field_name_zh, content, "special")
            result_user_content_list.append(content)
        # 随机挑选一个作为回复
        result_user_content = my_random.choice(result_user_content_list)
        return result_user_content

    def build_user_content_index(self, field_name, field_name_zh, field_value_list, field_choose_value):
        """用户回复列表中的索引"""
        field_choose_idx_int = field_value_list.index(field_choose_value)
        field_choose_idx_zh = num_to_chinese(field_choose_idx_int + 1)
        if field_choose_idx_int == 0:  # 第一个
            if my_random.choice([True] + [False] * 4) is True:
                content = "左上角"
            else:
                content = f"第{field_choose_idx_zh}个"
        elif field_choose_idx_int == len(field_value_list) - 1:  # 最后一个
            if my_random.choice([True] + [False] * 4) is True:
                content = my_random.choice(["右上角", "右下角", "最后一个"])
            else:
                content = f"第{field_choose_idx_zh}个"
        else:  # 中间的
            content = f"第{field_choose_idx_zh}个"
            if my_random.choice([True] + [False] * 4) is True:
                content = "倒数" + content
        # 增加口语化前后缀
        content = self.set_user_affix(field_name, field_name_zh, content)
        return content

    def need_user_index(self, field_name, assistant_content):
        if "是否继续" in assistant_content:
            return False
        return True

    def set_user_affix(self, field_name, field_name_zh, content, content_type="default", rate_num=9):
        if content_type == "default":
            # 增加口语化前缀
            if my_random.choice([True] + [False] * rate_num) is True:
                if self.scene_type in ["茶饮"]:
                    content = my_random.choice(CONFIRM_PREFIX_TERM_LIST + CONFIRM_PREFIX_DRINK_TERM_LIST) + content
                elif self.scene_type in ["快餐"]:
                    content = my_random.choice(CONFIRM_PREFIX_TERM_LIST + CONFIRM_PREFIX_EAT_TERM_LIST) + content
                else:
                    content = my_random.choice(CONFIRM_PREFIX_TERM_LIST) + content
            # 增加槽位名前缀
            if my_random.choice([True] + [False] * rate_num) is True:
                content = field_name_zh + content
                if "设定" in content or "设置" in content:
                    content = my_random.choice(["将", "把", ""]) + content
            # 增加槽位值后缀
            if my_random.choice([True] + [False] * rate_num) is True:
                if field_name in ["poi"]:
                    poi_suffix = my_random.choice(["店", "餐厅", "附近"])
                    if content.endswith(poi_suffix) is False:
                        content = content + poi_suffix
            # 增加口语化后缀
            if my_random.choice([True] + [False] * rate_num) is True:
                content = content + my_random.choice(CONFIRM_SUFFIX_TERM_LIST)
        # 增加理想同学前缀
        if my_random.choice([True] + [False] * rate_num * 2) is True:
            content = "理想同学" + content
        # 增加谢谢后缀
        if my_random.choice([True] + [False] * rate_num * 2) is True:
            content = content + "谢谢"
        return content

    def build_assistant_content(self, template, category, field_name, field_name_zh, field_value_list, field_choose_value, query_feature, special_multiple=2):
        """构建assistant的内容"""
        if field_name == "brand":
            field_name_zh_new = my_random.choice(["品牌", "小程序"])
        else:
            field_name_zh_new = field_name_zh
        field_value_num = len(field_value_list)
        if field_value_num == 1:
            content_list = [
                f"请问你是要点{field_value_list[0]}吗",
                f"您要下单的{field_name_zh_new}是哪一个呢？",
            ]
        elif field_value_num == 2:
            if field_name in ["brand", "poi", "product"]:
                content_list = [
                    "您要" + "还是".join(field_value_list) + "呢？",
                    f"找到以下{field_name_zh_new}，选择哪个",
                    f"您要选择哪个{field_name_zh_new}呢？",
                ]
            else:
                content_list = [
                    f"请选择{field_name_zh_new}：" + "、".join(field_value_list),
                    f"请选择{field_name_zh_new}",
                    f"{field_name_zh_new}有多个选项，您要选择哪种{field_name_zh_new}呢？",
                ]
            if field_name in ["pickup"]:
                content_list.extend([
                    f"当前仅{field_choose_value}，确认点单吗？",
                    f"当前仅{field_choose_value}，请问您要继续点单吗？",
                    f"当前仅支持{field_choose_value}，确认点单吗？",
                    f"当前仅支持{field_choose_value}，请问你确认点单吗？",
                    f"当前门店仅支持{field_choose_value}，确认点单吗？",
                    f"当前门店仅支持{field_choose_value}，请问你确认点单吗？",
                    f"当前仅支持{field_choose_value}，请问是否继续？",
                    f"当前仅支持{field_choose_value}，请问是否继续点单？",
                    f"{field_name_zh}当前仅支持{field_choose_value}，请问是否继续？",
                    f"{field_name_zh}当前仅支持{field_choose_value}，请问是否继续点单？",
                ] * special_multiple)
        else:
            content_list = [
                f"请选择{field_name_zh_new}",
                f"找到以下{field_name_zh_new}，选择哪个",
                f"您要选择哪个{field_name_zh_new}呢？",
                f"你要什么{field_name_zh_new}呢？",
            ]
            if field_name == "product":
                if category != "":
                    content_list.extend([f"你想点什么{category}？", f"您要点哪种{category}？"] * special_multiple)
                if self.scene_type in ["茶饮"]:
                    content_list.extend(["你要喝什么？", "您想喝什么？", "您想喝点什么呢？"] * special_multiple)
                elif self.scene_type in ["快餐"]:
                    content_list.extend(["你要吃什么？", "您想吃什么？", "您想吃点什么呢？"] * special_multiple)
                elif self.scene_type in ["正餐排号"]:
                    content_list.extend(["要在哪个餐厅就餐呢？", "您想在哪个餐厅就餐呢？"] * special_multiple)
            if field_name in ["pickup"]:
                content_list.extend([
                    f"当前仅{field_choose_value}，确认点单吗？",
                    f"当前仅{field_choose_value}，请问您要继续点单吗？",
                    f"当前仅支持{field_choose_value}，确认点单吗？",
                    f"当前仅支持{field_choose_value}，请问你确认点单吗？",
                    f"当前门店仅支持{field_choose_value}，确认点单吗？",
                    f"当前门店仅支持{field_choose_value}，请问你确认点单吗？",
                    f"当前仅支持{field_choose_value}，请问是否继续？",
                    f"当前仅支持{field_choose_value}，请问是否继续点单？",
                    f"{field_name_zh}当前仅支持{field_choose_value}，请问是否继续？",
                    f"{field_name_zh}当前仅支持{field_choose_value}，请问是否继续点单？",
                ] * special_multiple)
            if field_name in ["poi"]:
                content_list.extend([f"{field_name_zh}位置是哪里呢？", f"要在哪个{field_name_zh}下单呢？"] * special_multiple)
                if query_feature.get("pickup", "") != "":
                    content_list.extend([f"你想要在哪个{field_name_zh}{query_feature['pickup']}？"] * special_multiple)
            if field_name in ["expressType"]:
                content_list.extend([f"您想查看哪种{field_name_zh}呢", f"请问您想查看哪种{field_name_zh}呢"] * special_multiple)
            if field_name in ["attendance"]:
                content_list.extend(["就餐人数是几人呢？", "请问就餐人数是多少呢？"] * special_multiple)
            if field_name in ["random_cup"]:
                content_list.extend(["你要几杯？", "您想要几杯？", "您要点几杯呢？"] * special_multiple)
        return content_list
