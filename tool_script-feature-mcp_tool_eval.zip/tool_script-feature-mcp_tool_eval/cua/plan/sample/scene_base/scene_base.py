import copy
import json
import itertools
import threading
from tqdm import tqdm
from loguru import logger
from typing import Any, Dict, List
from joblib import Parallel, delayed
from utils.file_utils import check_output_path
from cua.plan.sample.meta import *
from cua.plan.sample.func import *
from cua.plan.sample.scene import *
from cua.plan.sample.template import *
from cua.plan.sample.scene_base.scene_base_multi import SceneBaseMulti


class SceneBase(SceneBaseMulti):

    def __init__(self, scene_name_en):
        super().__init__(scene_name_en)
        logger.info(f"process scene: {scene_name_en}")
        # 校验输出路径
        self.output_path = f"{SAMPLE_DIR}/{SAMPLE_VERSION}/scene_sample/{self.scene_name_en}.jsonl"
        check_output_path(self.output_path)
        # 设置并发控制参数
        self.n_jobs = 10  # 并发度
        self.file_lock = threading.Lock()  # 文件锁

    def process(self):
        """主处理函数"""
        Parallel(n_jobs=self.n_jobs, prefer="threads")(
            delayed(self.process_template_and_save_sample)(order_template)
            for order_template in tqdm(self.order_template_list,
                                       total=len(self.order_template_list),
                                       desc=f"build sample {self.scene_name_en}")
        )

    def process_template_and_save_sample(self, template):
        """处理模板并保存样本"""
        def slot_name_trans(multi_sample_one):
            for conversation in multi_sample_one["conversations"]:
                if conversation["role"] == "user" and "arguments" in conversation:
                    new_arguments = {}
                    for key, value in conversation["arguments"].items():
                        new_key = NAME_MAPPING.get(key, key)
                        new_arguments[new_key] = value
                    conversation["arguments"] = new_arguments
            return multi_sample_one

        multi_sample_list = self.process_template(template)
        if len(multi_sample_list) > 0:
            with self.file_lock:
                with open(self.output_path, "a") as f:
                    for multi_sample_one in multi_sample_list:
                        multi_sample_one = slot_name_trans(multi_sample_one)
                        multi_sample_one["scene"] = self.scene_name_en
                        f.write(json.dumps(multi_sample_one, ensure_ascii=False) + "\n")

    def process_template(self, template):
        """处理模板"""
        if len(template) == "":
            return []
        # 解析模板中的类目
        category = parse_category_from_template(template)
        # 解析模板中的参数名
        param_name_list = parse_template(template)
        # 基于模板和参数构造单轮样本
        scene_name_en = copy.deepcopy(self.scene_name_en)
        scene_conf = copy.deepcopy(self.scene_conf)
        sample_list = []
        for city in CITY_LIST:
            for brand in scene_conf["brand"]:
                # 获取参数值&填充参数到模板
                city_brand_sample_list = self.build_city_brand_sample(
                    template, category, param_name_list, city, brand, scene_name_en, scene_conf)
                sample_list.extend(city_brand_sample_list)
        # 构造二级场景多轮样本
        multi_sample_list = []
        for sample_one in sample_list:
            multi_sample_list.extend(self.process_multi_conversations(sample_one))
        return multi_sample_list

    def build_city_brand_sample(self, template, category, param_name_list, city, brand, scene_name_en, scene_conf):
        hidden_feature = {"city": city, "brand": brand, "category": category}
        # 获取参数值
        variables = {}
        for param_name in param_name_list:
            param_value, query_feature = self.get_param_value(param_name, city, brand, scene_name_en, scene_conf)
            variables[param_name] = {"value": param_value, "query_feature": query_feature}
        # 补充品牌别名
        if "brand" in variables:
            variables["brand"]["value"] = [brand] + scene_conf.get("brand_alias", {}).get(brand, [])
        # 填充参数到模板
        city_brand_sample_list = self.fill_template(template, variables, hidden_feature)
        return city_brand_sample_list

    def get_param_value(self, param_name: str, city: str, brand: str,
                        scene_name_en: str, scene_conf: Dict[str, Any], sample_num: int = 2):
        """获取参数值"""
        param_value = ""
        feature_list = []
        if param_name.startswith("random_") is True:
            param_value = execute_func_from_name(param_name)
            if param_name in ["random_cup", "random_address"]:  
                feature_list.append({param_name: param_value})
        else:
            # 解析参数及出现次数
            param_name_segs = param_name.split("__")
            param_name_key = param_name_segs[0]
            if len(param_name_segs) == 3:
                param_name_real = param_name_segs[1]
                multiple = int(param_name_segs[2])
            else:
                param_name_real = ""
                multiple = 1
            # 获取配置中的参数值
            if param_name_key not in scene_conf:
                raise Exception(f"[SceneBase] scene_name_en={scene_name_en} param={param_name} does not exist.")
            param_value_origin = copy.deepcopy(scene_conf[param_name_key])
            # 获取对应品牌的参数
            if type(param_value_origin) is dict and brand in param_value_origin:
                param_value_origin = param_value_origin[brand]
            # 获取槽位
            if param_name_key == "brand":  # 用于qasearch
                if multiple == 1:
                    param_value = [brand]
                    feature_list = [{"brand": item} for item in param_value]
                else:
                    param_value = ["和".join(my_random.sample(param_value_origin, multiple))]
                    feature_list = [{"brand": item} for item in param_value]
            elif param_name_key == "poi":  # poi区分城市，随机一个poi
                poi_list = param_value_origin.get(city, [])
                param_value = [my_random.choice(poi_list)]
                feature_list = [{"poi": item} for item in param_value]
            elif param_name_key == "pickup":  # 取餐方式
                if multiple == 1:
                    param_value = my_random.sample(param_value_origin, sample_num)
                    feature_list = [{"pickup": item} for item in param_value]
                else:
                    param_value = ["和".join(my_random.sample(param_value_origin, multiple))]
                    feature_list = [{"pickup": item} for item in param_value]
            elif param_name_key == "product":  # 随机产品
                if multiple == 1:
                    param_value = my_random.sample(param_value_origin, sample_num)
                    # 还原槽位特征
                    feature_list = [{"product": item} for item in param_value]
                else:
                    permutation_list = sorted(list(itertools.permutations(param_value_origin, multiple)))
                    product_multiple_list = my_random.sample(permutation_list, sample_num)
                    param_value = ["和".join(item) for item in product_multiple_list]
                    # 还原槽位特征
                    feature_list = [{"product": item} for item in product_multiple_list]
            elif param_name_key == "slot":  # 随机槽位
                if param_name_real in param_value_origin:  # 指定槽位
                    param_value = ["和".join(my_random.sample(param_value_origin[param_name_real]["value"], multiple))]
                    feature_list = [{"param_name_real": item} for item in param_value]
                else:  # 未指定槽位
                    slot_name_list = list(param_value_origin.keys())
                    slot_name_choose_list = my_random.sample(slot_name_list, multiple)
                    slot_value_choose_list = []
                    for slot_name_choose in slot_name_choose_list:
                        slot_value_choose_list.append(
                            my_random.sample(param_value_origin[slot_name_choose]["value"], sample_num))
                    product_list = list(itertools.product(*slot_value_choose_list))
                    param_value = ["".join(item) for item in product_list]
                    # 还原槽位特征
                    for item in product_list:
                        slot_dict = {}
                        for i, slot_value in enumerate(item):
                            slot_name = slot_name_choose_list[i]
                            slot_dict[slot_name] = slot_value
                        feature_list.append(slot_dict)
        return param_value, feature_list

    def fill_template(self, template: str, variables: Dict[str, Dict], hidden_feature: Dict[str, str]) -> List[Dict]:
        """
        填充模板字符串，其中变量可以是字符串或列表。对于列表类型的变量，会为列表中的每个元素生成一个单独的结果字符串。
        同时记录每个结果对应的变量值。
        参数:
            template (str): 带有占位符的模板字符串，如 {variable_name}
            variables (Dict[str, Union[str, List[str]]]): 变量名称到值的映射字典，值可以是字符串或字符串列表
            hidden_feature (Dict[str, str]): 隐藏特征，变量名称和值都是字符串
        返回:
            List[Dict]: 包含填充后的字符串和使用的变量值
        """
        # 初始化结果列表，包含初始模板和空的特征字典
        results = [{"query": template, "template": template, "query_feature": {}, "hidden_feature": hidden_feature}]
        if self.scene_type in ["电费-查询", "电费-缴费", "话费-查询", "话费-缴费", "滴滴-一键", "滴滴-代驾"]:
            results[0]["query_feature"] = {"brand": self.scene_conf["brand"][0]}
        # 逐个处理变量
        for key, value_dict in variables.items():
            value = value_dict["value"]
            input_feature = value_dict["query_feature"]
            new_results = []
            placeholder = f"{{{key}}}"
            if isinstance(value, list):  # 对于列表类型的变量
                for result_dict in results:
                    partial_result = result_dict["query"]
                    feature_dict = result_dict["query_feature"].copy()  # 复制特征字典以避免引用问题
                    for idx, value_one in enumerate(value):  # 创建新的结果字典，包含填充后的字符串和更新的特征字典
                        new_feature_dict = feature_dict.copy()
                        if key.startswith("slot") or key.startswith("product"):
                            new_feature_dict.update(input_feature[idx])
                        elif key == "brand" and key in hidden_feature:  # 解决品牌别名问题
                            new_feature_dict[key] = hidden_feature[key]
                        else:
                            new_feature_dict[key] = str(value_one)
                        new_results.append({
                            "query": partial_result.replace(placeholder, str(value_one)),
                            "template": template, "query_feature": new_feature_dict, "hidden_feature": hidden_feature,
                        })
            else:  # 对于字符串类型的变量(因为变量候选值都是数组，代码实际走不到这个分支)
                for result_dict in results:
                    partial_result = result_dict["query"]
                    feature_dict = result_dict["query_feature"].copy()
                    # 更新特征字典并创建新的结果
                    feature_dict[key] = str(value)
                    new_results.append({
                        "query": partial_result.replace(placeholder, str(value)),
                        "template": template, "query_feature": feature_dict, "hidden_feature": hidden_feature,
                    })
            results = new_results
        return results

    def process_multi_conversations(self, sample_one):
        multi_sample_list = []
        # 获取特征
        query = sample_one["query"]
        template = sample_one["template"]
        query_feature = sample_one["query_feature"]
        hidden_feature = sample_one["hidden_feature"]
        # 构造首轮
        new_arguments = {}
        for key, value in query_feature.items():
            if isinstance(value, str):
                new_arguments[key] = value
        multi_conversations = [[{"role": "user", "content": query,
                                 "type": TYPE_FIRST_ORDER, "arguments": new_arguments}]]
        # 模型澄清-应用澄清-品牌
        app_clarify_multi_conversations, query_feature = self.app_clarify(template, query_feature, hidden_feature)
        multi_conversations = self.merge_conversations(multi_conversations, app_clarify_multi_conversations)
        # 模型澄清-槽位澄清-手机号码
        phone_clarify_multi_conversations, query_feature = self.ask_phone_number(template, query_feature)
        multi_conversations = self.merge_conversations(multi_conversations, phone_clarify_multi_conversations)
        # 模型澄清-槽位澄清-隐私协议
        privacy_agreement_multi_conversations = self.ask_privacy_agreement(template, query_feature)
        multi_conversations = self.merge_conversations(multi_conversations, privacy_agreement_multi_conversations)
        # 模型澄清-列表澄清-代驾地点
        location_clarify_multi_conversations, query_feature = self.ask_location(template, query_feature)
        multi_conversations = self.merge_conversations(multi_conversations, location_clarify_multi_conversations)
        # 模型澄清-槽位澄清-代驾类型
        servertype_clarify_multi_conversations, query_feature = self.ask_server_type(template, query_feature)
        multi_conversations = self.merge_conversations(multi_conversations, servertype_clarify_multi_conversations)
        # 模型澄清-列表澄清-取餐方式
        pickup_clarify_multi_conversations, query_feature = self.list_clarify(
            template, query_feature, hidden_feature, "pickup")
        multi_conversations = self.merge_conversations(multi_conversations, pickup_clarify_multi_conversations)
        if self.scene_type in ["电费-查询", "电费-缴费"]:
            # 模型澄清-列表澄清-绑定账号
            link_clarify_multi_conversations, query_feature = self.list_clarify(
                template, query_feature, hidden_feature, "link_account")
            multi_conversations = self.merge_conversations(multi_conversations, link_clarify_multi_conversations)
        if self.scene_type in ["正餐排号"]:
            # 模型澄清-列表澄清-餐厅
            product_clarify_multi_conversations, query_feature = self.list_clarify(
                template, query_feature, hidden_feature, "product")
            multi_conversations = self.merge_conversations(multi_conversations, product_clarify_multi_conversations)
            # 模型澄清-列表澄清-门店
            poi_clarify_multi_conversations, query_feature = self.list_clarify(
                template, query_feature, hidden_feature, "poi")
            multi_conversations = self.merge_conversations(multi_conversations, poi_clarify_multi_conversations)
        else:
            # 模型澄清-列表澄清-门店
            poi_clarify_multi_conversations, query_feature = self.list_clarify(
                template, query_feature, hidden_feature, "poi")
            multi_conversations = self.merge_conversations(multi_conversations, poi_clarify_multi_conversations)
            # 模型澄清-列表澄清-产品
            product_clarify_multi_conversations, query_feature = self.list_clarify(
                template, query_feature, hidden_feature, "product")
            multi_conversations = self.merge_conversations(multi_conversations, product_clarify_multi_conversations)
        # 模型澄清-槽位澄清
        slot_clarify_multi_conversations, query_feature = self.slot_clarify(template, query_feature, hidden_feature)
        multi_conversations = self.merge_conversations(multi_conversations, slot_clarify_multi_conversations)
        # 模型澄清-槽位澄清-取餐时间
        take_order_time_multi_conversations = self.ask_take_order_time(template, query_feature)
        multi_conversations = self.merge_conversations(multi_conversations, take_order_time_multi_conversations)
        # 模型澄清-槽位澄清-其他需求
        other_demand_multi_conversations = self.ask_other_demand(template, query_feature)
        multi_conversations = self.merge_conversations(multi_conversations, other_demand_multi_conversations)
        # 模型澄清-槽位澄清-充值金额
        charge_amount_multi_conversations, query_feature = self.ask_charge_amount(query_feature)
        multi_conversations = self.merge_conversations(multi_conversations, charge_amount_multi_conversations)
        # 模型澄清-槽位澄清-最终下单
        final_order_multi_conversations = self.ask_final_order(template, query_feature)
        multi_conversations = self.merge_conversations(multi_conversations, final_order_multi_conversations)

        # 模型澄清-肯否澄清: 已经在 list_clarify 函数中处理
        # 用户打断-增加条件/删除条件/修改条件: 已经在 slot_clarify 函数中处理
        # 模型澄清-澄清负例: 在后续 MergeSample 阶段处理
        # 用户打断-打断负例: 在后续 MergeSample 阶段处理

        # 询问状态
        if len(self.status_template_list) > 0:
            status_template = my_random.choice(self.status_template_list)
            ask_status_multi_conversations = self.ask_status(query_feature, hidden_feature, status_template)
            multi_conversations = self.merge_conversations(multi_conversations, ask_status_multi_conversations)
        else:
            status_template = ""

        # 格式化结果
        for conversations in multi_conversations:
            multi_sample_one = {
                "conversations": conversations,
                "feature": {
                    "template": template,
                    "status_template": status_template,
                    "query_feature": query_feature,
                    "hidden_feature": hidden_feature,
                }
            }
            multi_sample_list.append(multi_sample_one)
        return multi_sample_list
