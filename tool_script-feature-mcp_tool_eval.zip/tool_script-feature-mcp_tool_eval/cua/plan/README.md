# CUA多轮规划
## 样本构建
```bash
# 构建场景样本
bash plan/cua/sample/scene_sample/run_scene_sample.sh
# 合并场景样本（负例构建也是在这一步实现的）
python -m cua.plan.sample.merge_sample.merge_sample
# 格式化数据到LiSFT格式
python -m cua.plan.sample.merge_sample.trans_sample

# 分析场景样本
python -m plan.cua.sample.analyse.analyse_scene_sample
# 分析合并样本
python -m plan.cua.sample.analyse.analyse_merge_sample
# 评估
python -m cua.plan.eval.eval_sample
```

## 模型训练(lizrun+lisft)
```bash
# 启动模型训练
cd /mnt/pfs-guan-ssai/nlu/xuzhou1/tool_script/lisft/
NCCL_P2P_DISABLE=1 NCCL_IB_DISABLE=1 python run_sft_train.py --sft_train_config /mnt/pfs-guan-ssai/nlu/zhaojiufeng/tool_script/cua/plan/config/qwen-full-v1-20250429.ini

llamafactory-cli train examples/extras/muon/qwen2_full_sft.yaml
# 训练进度查看
lizrun pool list
lizrun list
lizrun list -j xxx
lizrun logs xxx
```

## 模型训练(lpai)
参考：https://lpai.lixiang.com/lpaiweb/xspacex_ss-sai/subApp/components/v2/index
