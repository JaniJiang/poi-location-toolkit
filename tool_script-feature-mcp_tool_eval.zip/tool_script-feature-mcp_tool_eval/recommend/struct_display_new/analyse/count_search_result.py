import os
import json
import pandas as pd


class CountSearchResult:

    def __init__(self):
        self.input_path_list = [
            "data/cloud_share/recommend/struct_display_new/analyse/count_search_result/music_video_20250801.tsv",
            "data/cloud_share/recommend/struct_display_new/analyse/count_search_result/music_video_20250806.tsv",
        ]
        self.output_path_list = [
            "data/cloud_share/recommend/struct_display_new/analyse/count_search_result/music_video_20250801_output.tsv",
            "data/cloud_share/recommend/struct_display_new/analyse/count_search_result/music_video_20250806_output.tsv",
        ]
        self.need_resource_list = ["音乐", "影视"]
        self.need_api_name_list = ["QASearch"]

    def process(self):
        for idx, input_path in enumerate(self.input_path_list):
            output_list = []
            input_df = pd.read_csv(input_path, sep="\t").fillna("")
            for _, row in input_df.iterrows():
                try:
                    resource = row["一级分类"]
                    if resource not in self.need_resource_list:
                        continue
                    query = row["Query"]
                    # 获取落域信息
                    api_name = self.parse_slots(row["dialogActsDassSlots"])
                    if api_name not in self.need_api_name_list:
                        continue
                    # 统计搜索结果数量
                    result_count = 0
                    extend_count = 0
                    for search_col in ["search1", "search2", "search3", "search4"]:
                        search_result_str = row[search_col]
                        search_line_list = search_result_str.split("\n")
                        for search_line in search_line_list:
                            if search_line.startswith("context") is True:
                                result_count += 1
                            if search_line == "searchType:扩展":
                                extend_count += 1
                    output_list.append({
                        "resource": resource,
                        "query": query,
                        "api_name": api_name,
                        "result_count": result_count,
                        "extend_count": extend_count,
                    })
                except Exception as e:
                    print(e)
            # 保存检索结果
            output_df = pd.DataFrame(output_list)
            output_df.to_csv(self.output_path_list[idx], sep="\t", index=False, header=True)
            # 计算平均搜索结果条数
            self.calculate_avg_search_result(os.path.basename(input_path), output_df)

    def parse_slots(self, slot_str):
        try:
            slot_list = json.loads(slot_str)
            for slot_item in slot_list:
                api_name = slot_item["APINAME"]
                if api_name in ["MEDIASearch", "QASearch", "AUTOSearch"]:
                    return api_name
        except:
            return ""

    def calculate_avg_search_result(self, input_name, output_df):
        for resource in self.need_resource_list:
            resource_df = output_df[output_df["resource"] == resource]
            avg_mean_result_count = round(resource_df["result_count"].mean(), 2)
            avg_mean_extend_count = round(resource_df["extend_count"].mean(), 2)
            avg_median_result_count = round(resource_df["result_count"].median(), 2)
            avg_median_extend_count = round(resource_df["extend_count"].median(), 2)
            print("\t".join([str(x) for x in [
                input_name,
                resource,
                avg_mean_result_count,
                avg_mean_extend_count,
                avg_median_result_count,
                avg_median_extend_count,
            ]]))


if __name__ == "__main__":
    obj = CountSearchResult()
    obj.process()

# python -m recommend.struct_display_new.analyse.count_search_result
