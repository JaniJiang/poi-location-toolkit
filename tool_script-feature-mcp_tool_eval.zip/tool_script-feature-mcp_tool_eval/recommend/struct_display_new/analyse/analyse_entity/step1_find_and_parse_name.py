import json
import pandas as pd
from retry import retry
from tqdm import tqdm
from utils.llm_utils.serverless_function import request_llm
from recommend.struct_display_new.parse_utils import parse_struct_block_contents

sys_prompt = """"任务描述
你的主要任务是从一句话中提取演员和歌手，这些演员和歌手可以来自电影、音乐等领域。你需要识别出所有提到的演员和歌手名字，并确保提取到的名字是准确的。提取后的结果需要按名字排序，并且对每个提取到的演员和歌手，提供简短的背景描述。要求能够处理复杂的句子结构，并能够识别多名人物或非典型表达的名字。

输入
输入为一段自然语言的文本，可以包含多个句子，文本中可能会提到一个或多个演员和歌手。每个演员或歌手可能会有不同的称呼，可能是全名、昵称、职务等。

示例1：
输入：成龙导演的电影《急先锋》最近在全球上映，票房成绩表现强劲。成龙不仅是这部影片的主演，还亲自参与了动作设计和导演工作，继续展现了他在动作片领域的绝对优势。
输出：
[
  {
    "name": "成龙",
    "description": "香港著名演员，擅长动作片和功夫喜剧，代表作包括《醉拳》《警察故事》《尖峰时刻》等，是全球最知名的动作影星之一。"
  }
]

示例2：
输入：汪峰最近发布了新专辑《不忘初心》，该专辑收录了多首关于生活和爱情的深情歌曲。汪峰一直以来是中国流行音乐界的代表性人物之一，他的歌曲以激励人心的歌词和独特的嗓音风格著称。
输出：
[
  {
    "name": "汪峰",
    "description": "中国著名摇滚歌手，代表作包括《突然好想你》《北京北京》等。他的音乐风格深情且富有力量，深受乐迷喜爱。"
  }
]
"""
user_prompt = """输入：{spoken}
注意：
1. 你只需要识别演员和歌手，其他无需匹配。
2. 你仅仅只需要以JSON字符串格式回复非Markdown格式。"""


class FindAndParseName():
    def __init__(self):
        self.input_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_entity/step1_find_and_parse_name/input.tsv"
        self.output_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_entity/step1_find_and_parse_name/output.tsv"
        self.df = pd.read_csv(self.input_path, sep="\t").fillna("")
        self.df_len = len(self.df)
        self.max_threads = 3

    def process(self):
        data_list = []
        for _, row in tqdm(self.df.iterrows(), desc="Processing", total=self.df_len):
            query = row["Query"]
            field = row["一级分类"]
            StructBlockContents = row["StructBlockContents"]
            for source in parse_struct_block_contents(StructBlockContents)[1:-1]:
                try:
                    spoken = source["spoken"]
                    if "content" in source:
                        content = source["content"]
                    else:
                        continue
                    block = {
                        "content": content,
                        "spoken": spoken
                    }
                    title_entity_title = content["title"]
                    if "singer" in content:
                        key = "singer"
                    elif "actors" in content:
                        key = "actors"
                    else:
                        continue
                    title_entity_role = content[key]
                    title_entity = {
                        "title": title_entity_title,
                        key: title_entity_role
                    }
                    spoken_role_list = self.parse_role_by_llm(spoken)
                    data_list.append({
                        "field": field,
                        "query": query,
                        "block": json.dumps(block, indent=2, ensure_ascii=False),
                        "spoken_role_list": spoken_role_list,
                        "title_entity": title_entity,
                    })
                except Exception as e:
                    print(source)
                    print(e)
                    continue
        pd.DataFrame(data_list).to_csv(self.output_path, sep="\t", index=False)
        print(f"文件已成功保存至： {self.output_path}")

    @retry(tries=3, delay=1)
    def parse_role_by_llm(self, spoken: str):
        try:
            role_list = []
            _, res = request_llm([sys_prompt, user_prompt.format(spoken=spoken)])
            response = json.loads(res["choices"][0]["message"]["content"])
            for role in response:
                if "name" in role:
                    role_list.append(role["name"])
            return role_list
        except Exception as e:
            pass
        return None


if __name__ == "__main__":
    obj = FindAndParseName()
    obj.process()
    # python -m recommend.struct_display_new.analyse.analyse_entity.step1_find_and_parse_name
