import re
import json
import requests
import pandas as pd
from tqdm import tqdm


class GetEntitAndAcc():

    def __init__(self):
        self.input_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_entity/step1_find_and_parse_name/output.tsv"
        self.output_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_entity/step2_get_entity_and_acc/output.tsv"
        self.df = pd.read_csv(self.input_path, sep="\t").fillna("")
        self.df_len = len(self.df)

    def process(self):
        self.df["title_entity_new"] = None
        self.df["spoken_entity"] = None
        self.df["title_acc"] = None
        self.df["spoken_acc"] = None
        self.df["gsb"] = None
        self.df["entity_equal"] = None
        for idx, row in tqdm(self.df.iterrows(), desc="Processing", total=self.df_len):
            try:
                spoken = json.loads(row["block"])["spoken"]
                spoken_role_list = eval(row["spoken_role_list"])
                title_entity = eval(row["title_entity"])
                title = title_entity["title"]
                key = "singer" if "singer" in title_entity else "actors"
                # title结果
                title_acc = 0
                title_entity_new = self.get_text_entity(f"《{title}》", key)
                if title_entity_new is not None:
                    title_acc = self.check_element_in_lists(title_entity_new[key], spoken_role_list)
                    self.df.at[idx, "title_entity_new"] = title_entity_new
                    self.df.at[idx, "title_acc"] = title_acc
                # spoken结果
                spoken_acc = 0
                spoken_entity = self.get_text_entity(spoken, key)
                if spoken_entity is not None:
                    spoken_acc = self.check_element_in_lists(spoken_entity[key], spoken_role_list)
                    self.df.at[idx, "spoken_entity"] = spoken_entity
                    self.df.at[idx, "spoken_acc"] = spoken_acc
                # gsb
                if spoken_acc > title_acc:
                    gsb = "g"
                elif spoken_acc == title_acc:
                    gsb = "s"
                else:
                    gsb = "b"
                self.df.at[idx, "gsb"] = gsb
                # entity_equal
                if title_entity_new is not None and spoken_entity is not None:
                    self.df.at[idx, "entity_equal"] = self.check_element_in_lists(
                        title_entity_new[key], spoken_entity[key])
            except Exception as e:
                print("process row failed: ", e)
        self.df.to_csv(self.output_path, sep="\t", index=False)
        print(f"文件已成功保存至： {self.output_path}")

    def get_text_entity(self, text, key):
        try:
            linkType = "LT_MUSIC" if key == "singer" else "LT_Movie"
            URL = "http://ks-engine-server-inference.ssai-apis-staging.chj.cloud:80/cloud/inner/nlp/kg/knowledge-search-engine/entity-link"
            payload = {"metadata": {}, "query": text, "linkType": linkType}
            resp = requests.post(URL, json=payload, headers={"Content-Type": "application/json"})
            resp.raise_for_status()
            if key == "singer":
                music_item = resp.json()["data"][0]["music"]
                return {
                    "title": music_item["song_name"],
                    key: music_item["singer"]
                }
            else:
                movie_item = resp.json()["data"][0]["movie"]
                return {
                    "title": movie_item["title"],
                    key: movie_item["actors"]
                }
        except Exception as e:
            print("process get_text_entity failed: ", e)
            return None

    def check_element_in_lists(self, match_list, spoken_list):
        # 检查是否有元素在列表B中
        return 1 if set(match_list) == set(spoken_list) else 0


if __name__ == "__main__":
    obj = GetEntitAndAcc()
    obj.process()

# python -m recommend.struct_display_new.analyse.analyse_entity.step2_get_entity_and_acc
