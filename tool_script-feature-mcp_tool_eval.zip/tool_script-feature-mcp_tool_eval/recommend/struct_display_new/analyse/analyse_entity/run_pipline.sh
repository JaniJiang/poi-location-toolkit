

python -m recommend.struct_display_new.analyse.analyse_entity.step1_find_and_parse_name
python -m recommend.struct_display_new.analyse.analyse_entity.step2_get_entity_and_acc
