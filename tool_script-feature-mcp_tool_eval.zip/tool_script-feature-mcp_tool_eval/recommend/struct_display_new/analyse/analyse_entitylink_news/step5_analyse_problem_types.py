import csv
import json
import difflib
from datetime import datetime
from collections import Counter


class AnalyseProblemTypes:
    def __init__(self):
        self.data_file = "data/cloud_share/recommend/struct_display_new/analyse/analyse_entitylink_news/news_entitylink_all.tsv"
        self.out_file = "data/cloud_share/recommend/struct_display_new/analyse/analyse_entitylink_news/problem_news.tsv"

    def is_similar(self, a, b, th=0.8):
        return bool(a and b and difflib.SequenceMatcher(None, a, b).ratio() >= th)

    def parse_media_search_result(self, raw_str):
        raw_str = (raw_str or "").strip()
        if not raw_str:
            return []

        try:
            obj = json.loads(raw_str)
            if isinstance(obj, dict):
                return obj.get("data", [])
            elif isinstance(obj, list):
                if not obj:
                    return []
                if isinstance(obj[0], dict) and "data" in obj[0]:
                    return obj[0]["data"]
                return obj
            return []
        except Exception:
            return []

    def normalize_tags(self, tags_str):
        # 财经类 TAG 映射表
        TAG_EQUIV = {
            "财经": "财经",
            "经济": "财经",
            "金融": "财经",
        }

        tags = tags_str.split("&")
        norm_tags = []
        for t in tags:
            t = t.strip()
            if not t:
                continue
            norm_tags.append(TAG_EQUIV.get(t, t))
        return set(norm_tags)

    def check_row(self, row):
        problems, query = [], row["query"]

        data = self.parse_media_search_result(row.get("media_search_result", ""))
        try:
            tag_obj = json.loads((row.get("tags") or "{}").strip())
            if not isinstance(tag_obj, dict):
                tag_obj = {}
        except Exception:
            tag_obj = {}

        # 1. 速览新闻
        title_triggers = ["速递", "速览", "一览", "新闻热点", "新闻早餐", "三分钟新闻", "新闻早知道", "隔夜要闻"]
        titles = [(i.get("title") or "").lower() for i in data]
        if any(any(kw.lower() in title for kw in title_triggers) for title in titles):
            problems.append("一句话速览新闻")

        # 2. 视频新闻
        if any("video" in i.get("extend_data", {}).get("external_url", "") for i in data):
            problems.append("视频新闻")

        # 3. 雷同新闻
        texts = [i.get("title", "") for i in data] + [i.get("content", "") for i in data]
        if any(self.is_similar(texts[i], texts[j]) for i in range(len(texts)) for j in range(i + 1, len(texts))):
            problems.append("语义重复新闻")

        # 4. 新闻内容与 query 不符
        if tag_obj:
            query_tag_raw = tag_obj.get("query_tag", "")
            if query_tag_raw and query_tag_raw != "新闻":
                query_tags = self.normalize_tags(query_tag_raw)

                mismatch_found = False
                for title in tag_obj.get("titles", []):
                    title_tag_raw = title.get("title_tag", "")
                    if not title_tag_raw:
                        continue
                    title_tags = self.normalize_tags(title_tag_raw)

                    # 如果 query_tags 和 title_tags 没有交集，则认为不符
                    if query_tags.isdisjoint(title_tags):
                        mismatch_found = True
                        break

                if mismatch_found:
                    problems.append("相关性问题")

        # 5. 时效性问题
        for i in data:
            ts = i.get("extend_data", {}).get("doc_timestamp")
            if ts:
                try:
                    dt = datetime.strptime(ts, "%Y-%m-%d %H:%M:%S")
                    if dt <= datetime(2025, 8, 31):
                        problems.append("时效性问题")
                        break
                except Exception:
                    continue

        # 6. 特殊需求
        if "财联社" in query:
            problems.append("新闻平台需求")

        # 7. 数据清洗问题
        for i in data:
            title = i.get("title", "")
            content = i.get("content", "")
            if title and content:
                if not self.is_similar(title, content, th=0.005):
                    problems.append("脏数据")
                    break

        # 8. 返回资源不足
        news_count = len(data)
        if news_count <= 5:
            problems.append("返回资源不足")

        return list(set(problems)), tag_obj.get("query_tag", "")

    def process(self):
        problem_counter = Counter()
        query_tag_counter = Counter()

        with open(self.data_file, "r", encoding="utf-8") as f_data, \
                open(self.out_file, "w", encoding="utf-8", newline="") as out:

            reader = csv.DictReader(f_data, delimiter="\t")
            fieldnames = ["dt", "vin", "query", "query_tag", "problems"]
            writer = csv.DictWriter(out, fieldnames=fieldnames, delimiter="\t")
            writer.writeheader()

            for row in reader:
                problems, query_tag = self.check_row(row)
                if problems:
                    problem_counter.update(problems)
                    if query_tag:
                        # print(query_tag)
                        for tag in query_tag.split("&"):
                            tag = tag.strip()
                            if tag:
                                query_tag_counter.update([tag])

                writer.writerow({
                    "dt": row["dt"],
                    "vin": row["vin"],
                    "query": row["query"],
                    "query_tag": query_tag or "",
                    "problems": "[" + ", ".join(problems) + "]" if problems else "[]"
                })

        total = sum(problem_counter.values())
        print("\n问题统计：")
        for prob, count in problem_counter.most_common():
            ratio = count / total * 100 if total > 0 else 0
            print(f"{prob}: {count} ({ratio:.2f}%)")

        total_tags = sum(query_tag_counter.values())
        print("\n存在问题的 query_tag 分布：")
        for tag, count in query_tag_counter.most_common():
            ratio = count / total_tags * 100 if total_tags > 0 else 0
            print(f"{tag}: {count} ({ratio:.2f}%)")


if __name__ == "__main__":
    obj = AnalyseProblemTypes()
    obj.process()
