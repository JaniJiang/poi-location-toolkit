import pandas as pd
import json
import difflib
import re


class GetNewsEntityLinkTargetPos:
    def __init__(self):
        self.base_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_entitylink_news/news_entitylink_positive_diff.tsv"
        self.output_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_entitylink_news/step3_positions.tsv"
        # self.base_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_entitylink_news/news_entitylink_all.tsv"
        # self.output_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_entitylink_news/news_entitylink_positions.tsv"

    def clean_title(self, text: str) -> str:
        """清洗标题，去掉前缀、标点"""
        text = re.sub(r"^.*?\|", "", text)
        text = re.sub(r"[^\u4e00-\u9fa5a-zA-Z0-9]", "", text)
        return text.lower()

    def jaccard_similarity(self, a: str, b: str) -> float:
        """Jaccard 相似度，按字符集计算"""
        set_a, set_b = set(a), set(b)
        if not set_a or not set_b:
            return 0.0
        return len(set_a & set_b) / len(set_a | set_b)

    def get_closest_index(self, title, media_titles):
        """
        在 media_titles 里找与 title 最接近的一个标题的下标
        使用综合相似度（difflib + jaccard），要求分数 > 0.3
        """
        title_clean = self.clean_title(title)
        best_idx = -1
        best_score = 0.0

        for i, mt in enumerate(media_titles):
            mt_clean = self.clean_title(mt)

            seq_score = difflib.SequenceMatcher(None, title_clean, mt_clean).ratio()
            jac_score = self.jaccard_similarity(title_clean, mt_clean)

            score = 0.6 * seq_score + 0.4 * jac_score
            if score > best_score:
                best_score = score
                best_idx = i

        if best_score >= 0.1:  # 阈值
            return best_idx
        return -1

    def process(self):
        df = pd.read_csv(self.base_path, sep="\t")

        positions_list = []

        for idx, row in df.iterrows():
            try:
                # 解析 crania_resp
                crania_resp = row["crania_resp"]
                crania_titles = []
                if isinstance(crania_resp, str) and crania_resp.strip():
                    crania_json = json.loads(crania_resp)
                    recv_resp = crania_json.get("recv_async_generate_result_response", {})
                    block_contents = recv_resp.get("struct_block_contents", [])
                    for block in block_contents:
                        if block.get("block_name") == "custom_card":
                            try:
                                content_json = json.loads(block.get("content", "{}"))
                                title = content_json.get("title", "")
                                if title:
                                    crania_titles.append(title)
                            except Exception:
                                pass

                # 解析 media_search_result
                media_resp = row["media_search_result"]
                media_titles = []
                if isinstance(media_resp, str) and media_resp.strip():
                    media_json = json.loads(media_resp)
                    if isinstance(media_json, list) and media_json:
                        media_data = media_json[0].get("data", [])
                        for item in media_data:
                            t = item.get("title", "")
                            if t:
                                media_titles.append(t)

                total_media = len(media_titles)
                positions = []
                if total_media > 0:
                    for ct in crania_titles:
                        pos = self.get_closest_index(ct, media_titles)
                        if pos >= 0:
                            positions.append(f"{pos+1}/{total_media}")
                        else:
                            positions.append(f"-1/{total_media}")  # 未找到对应的新闻搜索结果

                positions_list.append(",".join(positions))

            except Exception as e:
                print(f"解析失败 idx={idx}, err={e}")
                positions_list.append("")

        result_df = pd.DataFrame({"positions": positions_list})
        result_df.to_csv(self.output_path, sep="\t", index=False)
        print(f"结果已保存到 {self.output_path}")
        return result_df


if __name__ == "__main__":
    obj = GetNewsEntityLinkTargetPos()
    df = obj.process()
    print(df.head(10))
