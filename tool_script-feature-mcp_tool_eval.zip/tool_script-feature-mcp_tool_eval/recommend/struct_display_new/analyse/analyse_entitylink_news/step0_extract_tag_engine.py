import json
from retry import retry
from utils.llm_utils.serverless_function import request_llm


sys_prompt_query = """
## 1. 任务描述
你是一个用户 query 拆解专家，需要从用户 query 中精准提取关于 query 的 tag（分类标签）。tag 用于对用户需求进行领域维度或对象维度的分类，需简洁通用。

## 2. 任务输入
输入为一个用户 query，可以包含多个句子。

## 3. 提取规则
tag 需要源于用户 query 或基于用户 query 信息进行合理关联推导，严禁脱离文本实际含义编造不存在的概念。
分为以下 3 种情况，用户 query 只需要满足其中一种情况即可，不要提取不同情况的 tag：
（1）如果用户 query 所需要的是一个具体的事件或对象，则提取该事件或对象作为 tag。
（2）如果用户 query 存在领域类(军事、财经、科技、金融、娱乐)或地域类（国际、国内）分类关键词 / 短语，则提取领域类或地域类 tag。
（3）如果用户 query 不存在领域类或地域类 tag，也不是一个具体的事件或对象，则将 tag 置为 “新闻” 即可。

## 4. 任务输出
必须使用 JSON 格式输出，JSON 结构固定包含一个键：
“tag”：值为 tag 字符串；若为第二种情况，存在多个 tag，用 “&” 分隔；若无 tag，默认值为 “新闻”。
输出只需要包括 tag 即可，不需要其他文字表述。

## 5. 示例参考
### 示例1：
输入：播放最近的股市新闻
输出：{"tag":"股市"}

### 示例2：
输入：帮我播放一下早间财经新闻
输出：{"tag":"财经"}

### 示例3：
输入：播放一下国际军事热点新闻
输出：{"tag":"国际&军事"}

### 示例4：
输入：看一下关于西贝的新闻
输出：{"tag":"西贝"}
"""
sys_prompt_title = """
## 1. 任务描述
你是一个新闻内容拆解专家，需要从新闻文本中精准提取tag（分类标签）。tag 用于对新闻文本进行领域维度的分类，需简洁通用。

## 2. 任务输入
输入为一个新闻标题或完整的新闻文本，可以包含多个句子。

## 3. 提取规则
tag 需要源于文本内容或基于文本信息进行合理关联推导，严禁脱离文本实际含义编造不存在的概念。
tag 需为领域类(政治、军事、财经、科技、娱乐、金融、经济、教育、体育、健康、法律、文旅、民生、汽车、房产等)或地域类（国际、国内、xx省、xx市、长三角、珠三角、京津冀、大湾区等）分类关键词 / 短语。
如果不存在上面提及的领域类 tag，则将 tag 置为 “新闻” 即可。

## 4. 任务输出
必须使用 JSON 格式输出，JSON 结构固定包含 tag 列表；若无 tag，默认值为 [""]。
输出只需要包括 tag 即可，不需要其他文字表述。

## 5. 示例参考
### 示例1：
输入：高端访谈｜铭记共同历史　携手为实现俄中繁荣昌盛而奋斗——访俄罗斯总统普京
输出：{"tag": ["国际", "政治"]}

### 示例2：
输入：中老铁路上的“信号守护者”
输出：{"tag": ["交通"]}
"""

user_prompt = """输入：{news_content}"""


class ExtraxtTagFromQueryAndTitle():
    def __init__(self):
        self.prompts = {
            "query": sys_prompt_query,
            "title": sys_prompt_title
        }

    def process(self, request_json):
        news_content = request_json.get("text", "").strip()
        text_type = request_json.get("type", "query").strip().lower()

        if news_content == "":
            return {"code": 1, "msg": "news_content empty", "result": {}}

        tag = self.extract_tag_by_llm(news_content, text_type)

        return {
            "code": 0,
            "msg": "success",
            "res": tag
        }

    @retry(tries=3, delay=1)
    def extract_tag_by_llm(self, news_content: str, text_type: str):
        try:
            sys_prompt = self.prompts.get(text_type, "")
            _, res = request_llm(history=[sys_prompt, user_prompt.format(
                news_content=news_content)], model='qwen__qwen3-8b', temperature=0, max_tokens=200)
            tag = res["choices"][0]["message"]["content"].strip()
            # print(f"[{text_type}] {tag}")
            return tag if tag else ''
        except Exception as e:
            print(f"extract_tag_by_llm error: {e}")
        return ''


if __name__ == "__main__":
    # query
    request_json_query = {
        "text": "搜索今天中午火灾的新闻",
        "type": "query"
    }
    # title
    request_json_title = {
        "text": "山东省深化零基预算改革方案",
        "type": "title"
    }

    engine = ExtraxtTagFromQueryAndTitle()
    response1 = engine.process(request_json_query)
    print(json.dumps(response1, ensure_ascii=False, indent=2))

    response2 = engine.process(request_json_title)
    print(json.dumps(response2, ensure_ascii=False, indent=2))
