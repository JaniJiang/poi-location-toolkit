import json
import pandas as pd
from collections import Counter


class AnalyseTagDistribution:
    def __init__(self):
        self.tags_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_entitylink_news/step2_tags.tsv"
        self.positions_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_entitylink_news/step3_positions.tsv"
        self.output_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_entitylink_news/step4_tags_distribution.tsv"

    def split_tags(self, tag_str):
        if not isinstance(tag_str, str) or not tag_str.strip():
            return []
        return [t.strip() for t in tag_str.split("&") if t.strip()]

    def process(self):
        tags_data = []
        with open(self.tags_path, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    tags_data.append(json.loads(line))
                except Exception:
                    continue

        pos_df = pd.read_csv(self.positions_path, sep="\t")
        positions_list = pos_df["positions"].tolist()

        pos_tag_counter = Counter()
        pos_qt_counter = Counter()
        nonpos_tag_counter = Counter()
        nonpos_qt_counter = Counter()
        query_tag_counter = Counter()

        for idx, row in enumerate(tags_data):
            query_tag_str = row.get("query_tag", "")
            query_tags = self.split_tags(query_tag_str)
            for qt in query_tags:
                query_tag_counter[qt] += 1

            titles = row.get("titles", [])
            title_tags = [self.split_tags(t.get("title_tag", "")) for t in titles]

            positions = []
            if idx < len(positions_list):
                raw_pos = positions_list[idx]
                if isinstance(raw_pos, str) and raw_pos.strip():
                    positions = raw_pos.split(",")

            match_indices = set()
            for p in positions:
                try:
                    pos_num, total = p.split("/")
                    pos_num = int(pos_num)
                    if pos_num > 0:
                        match_indices.add(pos_num - 1)
                except Exception:
                    continue

            for i, tags in enumerate(title_tags):
                if not tags:
                    continue
                if i in match_indices:
                    for t in tags:
                        pos_tag_counter[t] += 1
                        for qt in query_tags:
                            pos_qt_counter[(qt, t)] += 1
                else:
                    for t in tags:
                        nonpos_tag_counter[t] += 1
                        for qt in query_tags:
                            nonpos_qt_counter[(qt, t)] += 1

        output_rows = []

        def counter_to_rows(counter, prefix):
            rows = []
            for k, v in counter.most_common():
                if isinstance(k, tuple):
                    rows.append({"type": prefix, "key": json.dumps(k, ensure_ascii=False), "count": v})
                else:
                    rows.append({"type": prefix, "key": k, "count": v})
            return rows

        output_rows.extend(counter_to_rows(query_tag_counter, "query_tag"))
        output_rows.extend(counter_to_rows(pos_tag_counter, "position_tag"))
        output_rows.extend(counter_to_rows(pos_qt_counter, "position_query_tag"))
        output_rows.extend(counter_to_rows(nonpos_tag_counter, "nonposition_tag"))
        output_rows.extend(counter_to_rows(nonpos_qt_counter, "nonposition_query_tag"))

        out_df = pd.DataFrame(output_rows)
        out_df.to_csv(self.output_path, sep="\t", index=False)
        print(f"分析结果已保存到 {self.output_path}")


if __name__ == "__main__":
    obj = AnalyseTagDistribution()
    obj.process()
