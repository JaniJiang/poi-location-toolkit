import pandas as pd
import json
from collections import Counter


class AnalyseNewsEntity():
    def __init__(self):
        base_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_entity/"
        self.file_path = base_path + "news_entitylink.csv"
        self.negative_output = base_path + "news_entitylink_negative_diff.tsv"
        self.distribution_output = base_path + "media_crania_distribution.tsv"

    def analyse_media_search_result(self, df):
        counts = []
        for _, row in df.iterrows():
            try:
                results = json.loads(row["media_search_result"])
                if isinstance(results, list) and len(results) > 0 and "data" in results[0]:
                    counts.append(len(results[0]["data"]))
                else:
                    counts.append(0)
            except Exception:
                counts.append(0)
        return counts

    def analyse_crania_resp(self, df):
        counts = []
        for _, row in df.iterrows():
            try:
                resp = json.loads(row["crania_resp"])
                blocks = resp.get("recv_async_generate_result_response", {}).get("struct_block_contents", [])
                count = sum(1 for b in blocks if b.get("block_name") == "custom_card")
                counts.append(count)
            except Exception:
                counts.append(0)
        return counts

    def process(self):
        df = pd.read_csv(self.file_path)

        media_counts = self.analyse_media_search_result(df) if "media_search_result" in df.columns else []
        crania_counts = self.analyse_crania_resp(df) if "crania_resp" in df.columns else []

        # --- media_counts 分布 ---
        media_dist = Counter(media_counts) if media_counts else {}
        print("========== media_search_result -> data 数量分布：")
        for k, v in sorted(media_dist.items()):
            print(f"数量 {k} -> {v} 条记录")

        # --- custom_card 分布 ---
        crania_dist = Counter(crania_counts) if crania_counts else {}
        print("\n========== crania_resp -> custom_card 数量分布：")
        for k, v in sorted(crania_dist.items()):
            print(f"数量 {k} -> {v} 条记录")

        # --- 差值分布 ---
        diff_dist = {}
        if media_counts and crania_counts and len(media_counts) == len(crania_counts):
            diffs = [m - c for m, c in zip(media_counts, crania_counts)]
            df["media_count"] = media_counts
            df["crania_count"] = crania_counts
            df["diff"] = diffs

            diff_dist = Counter(diffs)
            print("\n========== 差值 (media_search_result.data数量 - crania_resp.custom_card数量) 分布：")
            for k, v in sorted(diff_dist.items()):
                print(f"差值 {k} -> {v} 条记录")

            negative_df = df[df["diff"] < 0]
            if not negative_df.empty:
                negative_df.to_csv(self.negative_output, sep="\t", index=False, encoding="utf-8-sig")
                print(f"\n- 已保存差值 < 0 的记录到: {self.negative_output}")
            else:
                print("\n- 没有差值 < 0 的记录")

            positive_df = df[(df["diff"] >= 3) & (df["diff"] <= 10)]
            print(len(positive_df))
            if not positive_df.empty:
                positive_output = self.file_path.replace(".csv", "_positive_diff.tsv")
                positive_df.to_csv(positive_output, sep="\t", index=False, encoding="utf-8-sig")
                print(f"\n- 已保存差值 > 4 的记录到: {positive_output}")

        # 保存分布结果
        media_df = pd.DataFrame(sorted(media_dist.items()), columns=["media_value", "media_count"])
        crania_df = pd.DataFrame(sorted(crania_dist.items()), columns=["crania_value", "crania_count"])
        diff_df = pd.DataFrame(sorted(diff_dist.items()), columns=[
                               "diff_value", "diff_count"]) if diff_dist else pd.DataFrame()

        dist_df = pd.concat(
            [
                media_df,
                pd.DataFrame({"": []}),
                crania_df,
                pd.DataFrame({"": []}),
                diff_df
            ],
            axis=1
        )
        dist_df.to_csv(self.distribution_output, sep="\t", index=False, encoding="utf-8-sig")
        print(f"\n- 已保存分布统计结果到: {self.distribution_output}")

        # 保存统计结果
        if media_counts and crania_counts and len(media_counts) == len(crania_counts):
            diffs = [m - c for m, c in zip(media_counts, crania_counts)]
            df["media_count"] = media_counts
            df["crania_count"] = crania_counts
            df["diff"] = diffs

            enriched_output = self.file_path.replace(".csv", "_with_counts.tsv")
            df.to_csv(enriched_output, sep="\t", index=False, encoding="utf-8-sig")
            print(f"\n- 已保存新增三列 (media_count, crania_count, diff) 的数据到: {enriched_output}")


if __name__ == "__main__":
    obj = AnalyseNewsEntity()
    obj.process()
