import pandas as pd
import json
from step0_extract_tag_engine import ExtraxtTagFromQueryAndTitle


class ExtractNewsEntityLinkTags():
    def __init__(self):
        # self.base_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_entity/news_entitylink_positive_diff.tsv"
        # self.save_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_entitylink_news/step2_tags.tsv"
        self.base_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_entitylink_news/news_entitylink_all.tsv"
        self.save_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_entitylink_news/news_entitylink_all_tags.tsv"
        self.extractor = ExtraxtTagFromQueryAndTitle()

    def process(self):
        df = pd.read_csv(self.base_path, sep="\t")

        with open(self.save_path, "w", encoding="utf-8") as fout:
            for idx, row in df.iterrows():
                query = row["query"]
                # query 抽取
                query_response = self.extractor.process({"text": query, "type": "query"})
                query_res = query_response.get("res", {})
                if isinstance(query_res, str):
                    try:
                        query_res = json.loads(query_res)
                    except Exception:
                        query_res = {}
                query_tag = query_res.get("tag", "") if isinstance(query_res, dict) else ""
                print(f"{idx}: query = {query}, tag = {query_tag}")

                row_result = {
                    "query": query,
                    "query_tag": query_tag,
                    "titles": []
                }

                media_search_result = row["media_search_result"]
                try:
                    media_json = json.loads(media_search_result)
                    data_list = []
                    if isinstance(media_json, dict):
                        data_list = media_json.get("data", [])
                    elif isinstance(media_json, list) and len(media_json) > 0:
                        first = media_json[0]
                        if isinstance(first, dict):
                            data_list = first.get("data", [])
                    else:
                        data_list = []

                    for item in data_list:
                        title = item.get("title", "")

                        # title 抽取
                        title_response = self.extractor.process({"text": title, "type": "title"})
                        title_res = title_response.get("res", {})
                        if isinstance(title_res, str):
                            try:
                                title_res = json.loads(title_res)
                            except Exception:
                                title_res = {}

                        title_tag = title_res.get("tag", "") if isinstance(title_res, dict) else ""
                        print(f"{title}: {title_tag}")

                        row_result["titles"].append({
                            "title": title,
                            "title_tag": title_tag
                        })
                except Exception as e:
                    print(f"解析失败 row={idx}, err={e}")

                fout.write(json.dumps(row_result, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    obj = ExtractNewsEntityLinkTags()
    obj.process()
