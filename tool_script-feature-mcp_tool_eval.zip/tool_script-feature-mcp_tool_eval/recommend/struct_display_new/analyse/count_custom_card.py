import json
import pandas as pd


class CountCustomCard:

    def __init__(self):
        self.input_path = "data/cloud_share/recommend/struct_display_new/analyse/count_custom_card/input.tsv"
        self.output_path = "data/cloud_share/recommend/struct_display_new/analyse/count_custom_card/output.tsv"
        self.new_cols = ["search_result", "search_count", "search_news_count", "llm_news_counts"]
        self.count_line = "block_type:news"

    def process(self):
        input_df = pd.read_csv(self.input_path, sep="\t").fillna("")
        for col in self.new_cols:
            input_df[col] = ""
        for idx, row in input_df.iterrows():
            try:
                # 计算模型预测数据量
                struct_block_contents = row["StructBlockContents"].split("\n")
                llm_news_counts = struct_block_contents.count(self.count_line)
                input_df.loc[idx, "llm_news_counts"] = llm_news_counts
                # 获取搜索结果
                pro_message_list = json.loads(row["proMessages"])
                search_result_list = []
                for pro_message_dict in pro_message_list:
                    if pro_message_dict["role"] == "tool":
                        content_list = pro_message_dict["content"]
                        if len(content_list) == 0 or content_list[0] == "":
                            continue
                        search_result_list = content_list
                        break
                input_df.loc[idx, "search_result"] = json.dumps(search_result_list, ensure_ascii=False, indent=4)
                input_df.loc[idx, "search_count"] = len(search_result_list)
            except Exception as e:
                print(e)
        # 保存检索结果
        input_df.to_csv(self.output_path, sep="\t", index=False, header=True)


if __name__ == "__main__":
    obj = CountCustomCard()
    obj.process()

# python -m recommend.struct_display_new.analyse.count_custom_card
