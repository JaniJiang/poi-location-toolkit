import copy
import json
import pandas as pd
from tqdm import tqdm
from recommend.struct_display_new.parse_utils import parse_struct_block_contents
import ast

def process_single_file(input_path):
    data_list = []
    input_df = pd.read_csv(input_path, sep="\t").fillna("")
    for _, row in tqdm(input_df.iterrows(), desc=f"Processing {input_path}", total=len(input_df)):
        case_id = row["CaseID"]
        category = row["一级分类"]
        dataset = row["业务类型"]
        query = row["Query"]
        try:
            recall_list = ast.literal_eval(row["媒体资源统计"])
        except:
            recall_list = []
        if type(recall_list) is not list or len(recall_list) == 0:
            continue
        if row['相关性'] == "1" and row['真实性'] == "1":
            auto_acc = 1
        else:
            auto_acc = 0
        block_list = parse_struct_block_contents(row["StructBlockContents"])
        counter = 0
        for block_item in block_list:
            try:
                if block_item["block_type"] not in ["music", "video"]:
                    continue
                spoken = block_item["spoken"]
                if "content" in block_item:
                    content = block_item["content"]
                else:
                    continue
                block_auto_acc = copy.deepcopy(auto_acc)
                block_auto_recall = recall_list[counter]
                if block_auto_recall == 0:
                    block_auto_acc = "NULL"
                data_list.append({
                    "CaseID": case_id,
                    "category": category,
                    "dataset": dataset,
                    "query": query,
                    "block": json.dumps({"content": content, "spoken": spoken}, indent=4, ensure_ascii=False),
                    "auto_recall": block_auto_recall,
                    "auto_acc": block_auto_acc,
                    "human_acc": "",
                })
                counter += 1
            except Exception as e:
                print(e)
    return data_list

def main():
    input_path_list = [
        "data/cloud_share/recommend/struct_display_new/analyse/analyse_metrics/input1.tsv",
        "data/cloud_share/recommend/struct_display_new/analyse/analyse_metrics/input2.tsv",
    ]
    output_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_metrics/output.tsv"

    output_data_list = []
    for input_path in input_path_list:
        single_data_list = process_single_file(input_path)
        output_data_list.extend(single_data_list)
    output_df = pd.DataFrame(output_data_list)
    output_df.to_csv(output_path, sep="\t", index=False)
    print(f"文件已成功保存至： {output_path}")

if __name__ == "__main__":
    main()
