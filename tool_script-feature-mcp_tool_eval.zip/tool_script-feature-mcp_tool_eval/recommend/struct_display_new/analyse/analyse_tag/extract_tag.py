import sys
import os
import re
import json
import pandas as pd
from retry import retry
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor, as_completed
from utils.llm_utils.serverless_function import request_llm


sys_prompt = """"
任务描述
你是一个信息提取专家，任务是从输入文本中准确提取所有有意义的关键实体或主题标签（tag）。

任务输入
输入为一段自然语言的文本，可以包含多个句子，文本中可能会提到一个或多个tag。

任务要求
1. 每个tag应是一个简洁的关键词或短语，如人名、作品名、事件、领域等。
2. 提取规则：
   a. 当文本围绕某一核心主题展开多维度描述，或存在较为抽象、复杂的表述时，需基于文本整体语义进行归纳，提炼出能精准涵盖核心内容的高度概括性tag（如示例1中，从“发展与保护”“经济社会发展与人口、资源、环境相协调”等表述中，提炼出“协调发展”这一概括性tag）。
   b. 在文本明确提及特定实体、事件或领域的基础上，可结合常识或该领域的关联性，向外延伸或扩大tag范围，挖掘与文本内容紧密相关的上位概念、同类范畴或关联领域的tag（如示例2中，从“WTA1000蒙特利尔站双打半决赛”这一具体赛事，外推扩充出“网球赛”“体育”“运动”等相关tag）。
   c. 所有tag必须源于文本内容或基于文本信息的合理关联推导，严禁脱离文本实际含义编造不存在的实体、事件或概念作为tag。
3. 多个tag之间用&连接，格式如：tag1&tag2&tag3。
4. 如果没有可提取的tag，输出空字符串。

示例1：
输入：发展与保护，不再是非此即彼的“单选题”。通过转变发展理念、优化发展路径，绿水青山可以转化为金山银山，实现经济社会发展与人口、资源、环境相协调。
输出：经济发展&环境保护&协调发展&绿水青山

示例2：
输入：WTA1000蒙特利尔站双打半决赛，3号种子张帅/汤森德以6-2 6-4淘汰肯宁/多勒海德，连续两站击败对手，北美硬地豪取一波八连胜，背靠背晋级决赛。对张帅而言，这也是她职业生涯第三次跻身1000赛双打决赛。接下来，她们将和高芙/凯斯勒争夺冠军。
输出：网球赛&体育&运动&WTA1000蒙特利尔站
"""
user_prompt = """输入：{news_content}"""


class ExtraxtTag():
    def __init__(self):
        self.input_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_tag/media_search_result_500.tsv"
        self.output_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_tag/media_search_tag_500.tsv"
        self.output_cols = ["content", "tag"]

    def process(self):
        input_df = pd.read_csv(self.input_path, sep="\t", dtype=str).fillna("")

        contents = []
        tags = []

        for _, row in input_df.iterrows():
            text = row["media_search_result"].strip()
            if not text or text == '[]':
                continue
            try:
                data = json.loads(text)
                if isinstance(data, list):
                    items = data[0].get("data", [])
                else:
                    items = data.get("data", [])
                for item in items:
                    content_str = item.get("content", "")
                    if content_str:
                        content_json = json.loads(content_str)
                        news_content = content_json.get("新闻内容", "").strip()
                        if news_content:
                            # contents.append(news_content)
                            # tags.append(self.extract_tag_by_llm(news_content))
                            tag = self.extract_tag_by_llm(news_content)
                            pd.DataFrame([[news_content, tag]], columns=self.output_cols).to_csv(
                                self.output_path, sep="\t", mode="a", header=False, index=False
                            )
            except Exception as e:
                print(f"Error parsing row: {e}")

        # output_df = pd.DataFrame({
        #     "content": contents,
        #     "tag": tags
        # })
        # print(output_df)
        # output_df.to_csv(self.output_path, sep="\t", index=False)
        print(f"文件已成功保存至： {self.output_path}")

    @retry(tries=3, delay=1)
    def extract_tag_by_llm(self, news_content: str):
        try:
            _, res = request_llm([sys_prompt, user_prompt.format(news_content=news_content)])
            tag = res["choices"][0]["message"]["content"].strip()
            print(tag)
            return tag if tag else ''
        except Exception as e:
            pass
        return ''


if __name__ == "__main__":
    obj = ExtraxtTag()
    obj.process()
