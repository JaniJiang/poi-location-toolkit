import pandas as pd
import json
import re
from collections import Counter, defaultdict
import numpy as np


class AnalyseMediaSearchResult():
    def __init__(self):
        # self.file_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_tag/media_search_result.csv"
        self.file_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_entity/news_20250911_20250917.csv"

    def fix_json_str(self, s):
        s = s.strip()
        if s.startswith('"') and s.endswith('"'):
            s = s[1:-1]
        s = s.replace('""', '"')
        return s

    def extract_url_prefix(self, url):
        if not isinstance(url, str) or not url.strip():
            return "未知前缀"
        match = re.search(
            r'(https?://[^/]+?\.(com\.cn|net\.cn|org\.cn|gov\.cn|co\.uk|com|cn|net|org|gov|edu|info|co|tv))', url, re.I)
        if match:
            return match.group(1).lower()
        match = re.search(r'(https?://[^/]+)', url, re.I)
        return match.group(1).lower() if match else "非标准前缀"

    def safe_json_loads(self, json_str, default=None):
        if default is None:
            default = {}
        try:
            return json.loads(json_str)
        except Exception as e:
            return default

    def analyze_news_data(self, file_path):
        try:
            df = pd.read_csv(file_path)
        except Exception as e:
            print(f"读取文件错误: {str(e)}")
            return

        total_news, parse_failures = 0, 0
        data_list_lengths = []
        content_lengths, url_prefixes = [], []
        null_counts = defaultdict(int)
        null_check_fields = ["新闻发布时间", "新闻地点等实体信息", "新闻标题", "新闻类型"]

        for idx, row in df.iterrows():
            raw_str = str(row["media_search_result"]).strip()
            if not raw_str:
                continue

            cleaned_str = self.fix_json_str(raw_str)
            outer = self.safe_json_loads(cleaned_str)

            if isinstance(outer, list):
                if not outer:
                    continue
                outer = outer[0]
            if not isinstance(outer, dict):
                continue

            data_list = outer.get("data", [])
            data_list_len = len(data_list)
            data_list_lengths.append(data_list_len)
            if not isinstance(data_list, list):
                continue

            for news in data_list:
                total_news += 1
                content_str = news.get("content", "{}")
                content_json = self.safe_json_loads(content_str)
                if not isinstance(content_json, dict):
                    content_json = {}
                    parse_failures += 1
                news_content = content_json.get("新闻内容", "").strip()
                content_lengths.append(len(news_content))
                for field in null_check_fields:
                    field_value = content_json.get(field, "").strip()
                    if not field_value:
                        null_counts[field] += 1
                media_resources = news.get("media_resources", [])
                if isinstance(media_resources, list):
                    for resource in media_resources:
                        if isinstance(resource, dict):
                            play_urls = resource.get("play_url", [])
                            if isinstance(play_urls, list):
                                for url in play_urls:
                                    if url and isinstance(url, str):
                                        prefix = self.extract_url_prefix(url)
                                        url_prefixes.append(prefix)

        if total_news == 0:
            print("未解析到任何有效新闻数据")
            return

        avg_per_data_cnt = np.mean(data_list_lengths) if data_list_lengths else 0
        avg_length = np.mean(content_lengths) if content_lengths else 0
        length_distribution = Counter(content_lengths)
        null_ratio = {field: (count / total_news) * 100 for field, count in null_counts.items()}
        url_prefix_stat = Counter(url_prefixes)
        parse_failure_ratio = (parse_failures / total_news) * 100 if total_news > 0 else 0

        print("=" * 80)
        print("                      新闻数据统计结果")
        print("=" * 80)

        print(f"1. 基础统计：")
        print(f"   - 新闻搜索结果平均数量：{avg_per_data_cnt} 条")
        print(f"   - 总解析新闻数量：{total_news} 条")
        print(f"   - 新闻内容平均长度：{avg_length:.2f} 字符")
        print(f"   - content字段解析失败率：{parse_failure_ratio:.2f}%（{parse_failures}/{total_news}）")

        print(f"2. 新闻内容长度分布（前10个常见长度）：")
        sorted_lengths = sorted(length_distribution.items(), key=lambda x: x[1], reverse=True)[:10]
        for length, count in sorted_lengths:
            ratio = (count / total_news) * 100
            print(f"   - 长度 {length} 字符：{count} 条（{ratio:.2f}%）")

        print(f"3. 各字段空值占比：")
        for field in null_check_fields:
            count = null_counts.get(field, 0)
            ratio = (count / total_news) * 100
            print(f"   - {field}：{count} 条空值（{ratio:.2f}%）")

        print(f"4. play_url前缀统计（前10个常见前缀）：")
        if url_prefixes:
            sorted_prefixes = sorted(url_prefix_stat.items(), key=lambda x: x[1], reverse=True)[:10]
            total_urls = len(url_prefixes)
            for prefix, count in sorted_prefixes:
                ratio = (count / total_urls) * 100
                print(f"   - {prefix}：{count} 次（{ratio:.2f}%）")
        else:
            print("   - 未找到有效URL")
        print("=" * 80)

    def process(self):
        self.analyze_news_data(self.file_path)


if __name__ == "__main__":
    obj = AnalyseMediaSearchResult()
    obj.process()
