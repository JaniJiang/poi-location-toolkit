import json
import pandas as pd


class CountTagDistribution:

    def __init__(self):
        self.input_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_tag/news_log.tsv"
        self.output_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_tag/tag_distribution.tsv"
        # self.input_cols = ["record_id", "raw_query", "query", "content"]
        self.output_cols = ["tag_name", "tag_count", "tag_ratio"]

    def process(self):
        input_df = pd.read_csv(self.input_path, sep="\t", dtype=str).fillna("")

        def extract_category(x):
            try:
                return json.loads(x).get('CATEGORY', '') if x else ''
            except:
                return ''

        input_df['tags'] = input_df['content'].apply(extract_category)
        tag_series = input_df['tags'].str.split('&', expand=True).stack()
        tag_series = tag_series[tag_series != '']

        output_df = tag_series.value_counts().reset_index()
        output_df.columns = self.output_cols[:2]
        tag_total = output_df['tag_count'].sum()
        output_df['tag_ratio'] = (output_df['tag_count'] / tag_total).round(4)

        print(output_df)
        output_df.to_csv(self.output_path, sep="\t", index=False)


if __name__ == "__main__":
    obj = CountTagDistribution()
    obj.process()
