import json
import re

def parse_struct_block_contents(contents):
    blocks = re.split(r',\s*index:', contents.strip())
    result = []
    for block in blocks:
        if block.strip():
            block_dict = {}
            # 提取每个字段
            index_match = re.search(r'index:(\d+)', block)
            if index_match:
                block_dict['index'] = int(index_match.group(1))

            block_name_match = re.search(r'block_name:([^\n,]+)', block)
            if block_name_match:
                block_dict['block_name'] = block_name_match.group(1)

            block_type_match = re.search(r'block_type:([^\n,]*)', block)
            if block_type_match:
                block_dict['block_type'] = block_type_match.group(1)

            content_match = re.search(r'content:({.*?})', block, re.DOTALL)
            if content_match:
                try:
                    block_dict['content'] = json.loads(content_match.group(1))
                except json.JSONDecodeError:
                    block_dict['content'] = None

            spoken_match = re.search(r'spoken:([^\n,]*)', block)
            if spoken_match:
                block_dict['spoken'] = spoken_match.group(1).strip()

            status_match = re.search(r'status:(\d+)', block)
            if status_match:
                block_dict['status'] = int(status_match.group(1))

            result.append(block_dict)

    return result
