import pandas as pd
from tqdm import tqdm
import json
class AnalyseEntityLinkRecall:
    """分析EntityLink的召回问题"""

    def __init__(self):
        self.input_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_metrics/name_and_singer_label.tsv"
        self.out_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_metrics/recall.tsv"

    def process(self):
        input_df = pd.read_csv(self.input_path, sep="\t", dtype=str).fillna("")
        input_df["recall_现象"] = "EMPTY"
        input_df["recall_es"] = "EMPTY"
        input_df["recall_根因"] = "EMPTY"
        for idx, row in tqdm(input_df.iterrows(), desc="Processing", total=len(input_df)):
            try:
                entitylink_response = json.loads(row["entitylink_response"])
                code = entitylink_response.get("code", 0)
                message = str(entitylink_response.get("message", "")).lower()
                extra = entitylink_response.get("extra", {})
                metions = extra.get("metions", "")
                if code == -1:
                    if "metion rescore fail all < score" in message:
                        input_df.at[idx, "recall_现象"] = "相关性过滤"
                    elif "fail elastic search empty" in message:
                        input_df.at[idx, "recall_现象"] = "召回为空"
                    elif "extract movie empty" in message and (metions == "null" or not metions.strip()):
                        input_df.at[idx, "recall_现象"] = "spoken问题"
                else: 
                    input_df.at[idx, "recall_现象"] = 1
            except:
                input_df.at[idx, "recall_现象"] = "FAIL"
                input_df.at[idx, "recall_es"] = "FAIL"
                input_df.at[idx, "recall_根因"] = "FAIL"
        input_df.to_csv(self.out_path, sep="\t", index=False)

if __name__ == "__main__":
    obj = AnalyseEntityLinkRecall()
    obj.process()

# python -m recommend.entity_link.analyse.step3_analyse_entitylink_recall
