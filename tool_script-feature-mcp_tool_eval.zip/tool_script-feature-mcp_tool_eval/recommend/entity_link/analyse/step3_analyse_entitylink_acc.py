import json
import pandas as pd
from tqdm import tqdm

class AnalyseEntityLinkAcc:
    """分析EntityLink的准确问题"""

    def __init__(self):
        self.input_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_metrics/name_and_singer.tsv"
        self.out_path = "data/cloud_share/recommend/struct_display_new/analyse/analyse_metrics/name_and_singer_label.tsv"

    def process(self):
        input_df = pd.read_csv(self.input_path, sep="\t", dtype=str).fillna("")
        input_df["acc"] = "EMPTY"
        for idx, row in tqdm(input_df.iterrows(), desc="Processing", total=len(input_df)):
            category = row["category"]
            try:
                entitylink_response = json.loads(row["entitylink_response"])
                if category == "音乐":
                    spoken_role_list = json.loads(row["spoken_role_list"])
                    music_block = entitylink_response["data"][0]["music"]

                    if spoken_role_list[0]["spoken_name"] == music_block["song_name"]:
                        if not spoken_role_list[0]["spoken_singer"]:
                            input_df.at[idx, "acc"] = 1
                        elif spoken_role_list[0]["spoken_singer"] == music_block["singer"]:
                            input_df.at[idx, "acc"] = 1
                        else:
                            input_df.at[idx, "acc"] = 0
                    else:
                        input_df.at[idx, "acc"] = 0
                else:
                    movies_bolock = entitylink_response["data"][0]["movie"]
                    if row["title"] == movies_bolock["title"]:
                        input_df.at[idx, "acc"] = 1
                    else:
                        input_df.at[idx, "acc"] = 0
            except:
                input_df.at[idx, "acc"] = "FAIL"
        input_df.to_csv(self.out_path, sep="\t", index=False)

if __name__ == "__main__":
    obj = AnalyseEntityLinkAcc()
    obj.process()

# python -m recommend.entity_link.analyse.step3_analyse_entitylink_acc