import re
import json
import csv
from typing import List, Dict, Optional, Any, Set
from utils.tool_utils.media_entity_search import MediaEntitySearch


class AnalyseEntityLinkProblemType:
    def __init__(self):
        self.input_path = 'data/cloud_share/recommend/struct_display_new/analyse/analyse_metrics/entitylink_result_with_name.tsv'
        self.output_path = 'data/cloud_share/recommend/struct_display_new/analyse/analyse_metrics/entitylink_problem_type.tsv'

    def process(self) -> None:

        with open(self.input_path, 'r', encoding='utf-8') as infile, \
                open(self.output_path, 'w', encoding='utf-8', newline='') as outfile:

            reader = csv.DictReader(infile, delimiter='\t')
            fieldnames = reader.fieldnames + ['es_result', 'is_problem', 'problem_type']
            writer = csv.DictWriter(outfile, fieldnames=fieldnames, delimiter='\t')
            writer.writeheader()

            for row in reader:
                entitylink_response = row['entitylink_response']
                category = row['category']
                role_list = self._parse_role_list(row.get('spoken_role_list', ''))

                # 提取并清理关键信息
                spoken_name = self._extract_spoken_name(role_list)
                singer_spoken = self._extract_singers(role_list)
                title = self._clean_text(row.get('title', ''))

                # 处理实体链接响应
                is_problem, es_result, problem_type = self._process_entitylink_response(
                    entitylink_response, category, role_list, spoken_name,
                    singer_spoken, title
                )

                row['es_result'] = es_result
                row['is_problem'] = is_problem
                row['problem_type'] = problem_type
                writer.writerow(row)

    def _parse_role_list(self, role_list_str: str) -> List[Dict[str, Any]]:
        if not role_list_str:
            return []
        try:
            return json.loads(role_list_str)
        except json.JSONDecodeError:
            return []

    def _clean_text(self, text: str) -> str:
        if not text:
            return ""

        # 移除括号内容和特殊字符，英文转小写
        cleaned = re.sub(r'[\(\[\{（【｛].*?[\)\]\}）】｝]', '', text).strip()
        cleaned = cleaned.replace('·', '').strip()

        if cleaned.isascii():
            cleaned = cleaned.lower().strip()

        return cleaned

    def _is_prefix_or_suffix(self, str1, str2):
        if not str1 or not str2:
            return False
        is_prefix = str2.startswith(str1) or str1.startswith(str2)
        is_suffix = str2.endswith(str1) or str1.endswith(str2)
        return is_prefix or is_suffix

    def _extract_spoken_name(self, role_list: List[Dict[str, Any]]) -> str:
        if not role_list:
            return ""
        spoken_name = role_list[0].get('spoken_name', '').strip()
        return self._clean_text(spoken_name)

    def _extract_singers(self, role_list: List[Dict[str, Any]]) -> List[str]:
        if not role_list:
            return []

        singers = []
        raw_singers = role_list[0].get('spoken_singer', [])
        for singer in raw_singers:
            cleaned_singer = self._clean_text(singer)
            if cleaned_singer:
                singers.append(cleaned_singer)
        return singers

    def _call_es_service(
        self,
        category: str,
        role_list: List[Dict[str, Any]],
        title: str
    ) -> str:
        es_result = ""

        try:
            if category == '音乐':
                entity_name = role_list[0].get('spoken_name', '') if role_list else ''
                entity_name = self._clean_text(entity_name)
                searcher = MediaEntitySearch('music')
            elif category == '影视':
                entity_name = title
                title = self._clean_text(title)
                searcher = MediaEntitySearch('video')
            else:
                return es_result

            if not searcher or not entity_name:
                return es_result

            # 调用本地服务
            result = searcher.search(entity_name)
            es_result = json.dumps(result, ensure_ascii=False, indent=4)

            return es_result

        except Exception as e:
            print(f"调用 es 服务出现异常: {str(e)}")

    def _judge_final_problem_type(
            self,
            problem_type_el,
            problem_type_es,
            entitylink_response
    ) -> str:

        problem_type = ""

        if problem_type_el == '数据缺失问题':
            if problem_type_es == '数据缺失问题':  # el 无数据，es 无数据
                problem_type = '数据缺失问题'
            elif problem_type_es == '召回策略问题':  # el 无数据，es 成功召回，且排序在第一位
                problem_type = '召回策略问题'
            elif problem_type_es == '排序模型问题':  # el 无数据，es 成功召回，但排序不在第一位
                problem_type = '召回策略问题、排序模型问题'
            elif problem_type_es == '数据缺失-其他同名数据':  # el 无数据，es 成功召回，但召回的是同名数据
                problem_type = '召回策略问题、数据缺失-其他同名数据'
            elif problem_type_es == '数据缺失-其他系列数据':  # el 无数据，es 成功召回，但召回的是系列数据
                problem_type = '召回策略问题、数据缺失-其他系列数据'

        elif problem_type_el == '排序模型问题':  # el 有数据，但是被打分阈值过滤，或目标 entity 不在第一位
            if problem_type_es == '数据缺失问题':  # es 无数据
                problem_type = '排序模型问题'
            elif problem_type_es == '召回策略问题':  # es 成功召回，且排序在第一位
                if 'score' in entitylink_response:
                    problem_type = '排序模型问题'
                else:
                    problem_type = '召回策略问题'
            elif problem_type_es == '排序模型问题':
                problem_type = '排序模型问题'  # es 成功召回，但排序不在第一位
            elif problem_type_es == '数据缺失-其他同名数据':
                problem_type = '数据缺失-其他同名数据'  # es 成功召回，但召回的是同名数据
            elif problem_type_es == '数据缺失-其他系列数据':
                problem_type = '数据缺失-其他系列数据'  # es 成功召回，但召回的是系列数据

        elif problem_type_el == '数据缺失-其他同名数据':  # el 有数据，但召回的是其他同名数据（音乐）
            if problem_type_es == '数据缺失问题':
                problem_type = '数据缺失-其他同名数据'
            elif problem_type_es == '召回策略问题':  # es 成功召回，且排序在第一位
                problem_type = '召回策略问题'
            elif problem_type_es == '排序模型问题':
                problem_type = '排序模型问题'  # es 成功召回，但排序不在第一位
            elif problem_type_es == '数据缺失-其他同名数据':
                problem_type = '数据缺失-其他同名数据'
            elif problem_type_es == '数据缺失-其他系列数据':
                problem_type = '数据缺失-其他系列数据'

        elif problem_type_el == '数据缺失-其他系列数据':  # el 有数据，但召回的是其他系列数据（影视）
            if problem_type_es == '数据缺失问题':
                problem_type = '数据缺失-其他系列数据'
            elif problem_type_es == '召回策略问题':
                problem_type = '召回策略问题'
            elif problem_type_es == '排序模型问题':
                problem_type = '排序模型问题'
            elif problem_type_es == '数据缺失-其他同名数据':
                problem_type = '数据缺失-其他同名数据'
            elif problem_type_es == '数据缺失-其他系列数据':
                problem_type = '数据缺失-其他系列数据'

        return problem_type

    def _process_entitylink_response(
        self,
        entitylink_response: str,
        category: str,
        role_list: List[Dict[str, Any]],
        spoken_name: str,
        singer_spoken: List[str],
        title: str
    ) -> tuple[str, str]:

        is_problem = 1
        es_result = ""
        problem_type_el = ""
        problem_type_es = ""
        problem_type = ""

        # 判断 entitylink_response 是否存在问题
        if 'empty' not in entitylink_response and 'score' not in entitylink_response:
            is_problem, problem_type_el = self._judge_is_problem(
                entitylink_response, category, spoken_name, singer_spoken, title
            )

        if is_problem:
            if 'empty' in entitylink_response:
                problem_type_el = '数据缺失问题'
                es_result, problem_type_es = self._handle_response(
                    category, role_list, spoken_name, singer_spoken, title
                )

            elif 'score' in entitylink_response:
                problem_type_el = '排序模型问题'
                es_result, problem_type_es = self._handle_response(
                    category, role_list, spoken_name, singer_spoken, title
                )

            else:
                es_result, problem_type_es = self._handle_response(
                    category, role_list, spoken_name, singer_spoken, title
                )

            problem_type = self._judge_final_problem_type(problem_type_el, problem_type_es, entitylink_response)

        else:
            problem_type = '调用成功'

        return is_problem, es_result, problem_type

    def _handle_response(
        self,
        category: str,
        role_list: List[Dict[str, Any]],
        spoken_name: str,
        singer_spoken: List[str],
        title: str
    ) -> tuple[str, str]:

        es_result = self._call_es_service(category, role_list, title)
        problem_type = ""

        try:
            if es_result == '[]':
                return es_result, '数据缺失问题'

            if category == '音乐':
                entity_name = role_list[0].get('spoken_name', '') if role_list else ''
                entity_name = self._clean_text(entity_name)
                problem_type = self._analyse_music_problem_type(
                    es_result, entity_name, singer_spoken
                )
            elif category == '影视':
                entity_name = title
                entity_name = self._clean_text(entity_name)
                problem_type = self._analyse_video_problem_type(
                    es_result, entity_name
                )

        except Exception as e:
            problem_type = '处理异常'
            print(f"处理异常: {str(e)}")

        return es_result, problem_type

    def _analyse_music_problem_type(
        self,
        es_result: str,
        entity_name: str,
        singer_spoken: List[str]
    ) -> str:

        try:
            entity_name = self._clean_text(entity_name)
            es_result_list = json.loads(es_result)
            if not es_result_list:
                return '数据缺失问题'

            has_same_name = False

            for idx, es_res in enumerate(es_result_list):
                local_song_name = self._clean_text(es_res.get('song_name', ''))
                local_singer = [self._clean_text(s) for s in es_res.get('singer', [])]

                # 检查歌手匹配
                has_matched_singer = bool(set(local_singer) & set(singer_spoken))

                # 歌曲名匹配的情况
                if idx == 0 and entity_name == local_song_name:
                    if not singer_spoken:  # spoken 中未提及歌手姓名的情况
                        return '召回策略问题'
                    if has_matched_singer:
                        return '召回策略问题'
                    else:
                        has_same_name = True

                if idx >= 1 and entity_name == local_song_name:
                    if has_matched_singer:
                        return '排序模型问题'  # 召回策略问题、排序模型问题
                    else:
                        has_same_name = True

                if idx == len(es_result_list)-1:
                    if entity_name == local_song_name and not has_matched_singer:
                        return '数据缺失-其他同名数据'
                    elif entity_name != local_song_name:
                        if has_same_name:
                            return '数据缺失-其他同名数据' if has_same_name else '数据缺失问题'

                return '数据缺失问题'
        except Exception as e:
            print(f"音乐问题类型分析异常: {str(e)}")
            return '处理异常'

    def _analyse_video_problem_type(
        self,
        es_result: str,
        entity_name: str
    ) -> str:

        try:
            local_data_list = json.loads(es_result)
            if not local_data_list:
                return '数据缺失问题'

            is_fix = 0
            for idx, local_data in enumerate(local_data_list):
                local_title = self._clean_text(local_data.get('title', ''))
                local_alias_list = local_data.get('alias', '')
                local_alias_list = [self._clean_text(alias) for alias in local_alias_list]

                title_matches = self._is_prefix_or_suffix(entity_name, local_title)
                alias_matches = any(self._is_prefix_or_suffix(entity_name, alias) for alias in local_alias_list)

                if entity_name == local_title or entity_name in local_alias_list:
                    if idx == 0:
                        return '召回策略问题'
                    else:
                        return '排序模型问题'  # 召回策略问题、排序模型问题
                elif title_matches or alias_matches:
                    is_fix = 1
                    if idx == len(local_alias_list)-1:
                        return '数据缺失-其他系列数据'

            return '数据缺失-其他系列数据' if is_fix else '数据缺失问题'

        except Exception as e:
            print(f"影视问题类型分析异常: {str(e)}")
            return '处理异常'

    def _judge_is_problem(
        self,
        entitylink_response: str,
        category: str,
        spoken_name: str,
        singer_spoken: List[str],
        title: str
    ) -> tuple[str, str]:

        try:
            el_json = json.loads(entitylink_response)
            el_datas = el_json.get('data', [])

            if category == '音乐':
                return self._judge_music_is_problem(
                    el_datas, spoken_name, singer_spoken
                )
            elif category == '影视':
                return self._judge_video_is_problem(
                    el_datas, title
                )

            return 1, ''
        except Exception as e:
            print(f"解析异常: {str(e)}")
            return '解析异常'

    def _judge_music_is_problem(
        self,
        el_datas: List[Dict[str, Any]],
        spoken_name: str,
        singer_spoken: List[str]
    ) -> tuple[str, str]:

        for idx, el_data in enumerate(el_datas):
            song_name = self._clean_text(el_data.get('music', {}).get('song_name', ''))
            singer_el = [self._clean_text(s) for s in el_data.get('music', {}).get('singer', [])]

            # spoken 中未提及歌手姓名的情况
            if not singer_spoken:
                if song_name == spoken_name:
                    return 0, '调用成功'
                continue

            # 检查歌手匹配
            has_matched_singer = bool(set(singer_el) & set(singer_spoken))

            if idx == 0:
                if song_name == spoken_name:
                    if has_matched_singer:
                        return 0, '调用成功'
                    else:
                        return 1, '数据缺失-其他同名数据'
            else:
                if song_name == spoken_name and has_matched_singer:
                    return 1, '排序模型问题'

        return 1, '数据缺失问题'

    def _judge_video_is_problem(
        self,
        el_datas: List[Dict[str, Any]],
        title: str
    ) -> tuple[str, str]:

        is_fix = 0
        for idx, el_data in enumerate(el_datas):
            title_el = self._clean_text(el_data.get('movie', {}).get('title', ''))

            if title_el == title:
                if idx == 0:
                    return 0, '调用成功'
                else:
                    return 1, '排序模型问题'
            else:
                title_matches = self._is_prefix_or_suffix(title, title_el)
                if title_matches:
                    is_fix = 1
                if idx == len(el_datas)-1:
                    if is_fix:
                        return 1, '数据缺失-其他系列数据'
                    else:
                        return 1, '数据缺失问题'

        return 1, '数据缺失问题'


if __name__ == "__main__":
    analyser = AnalyseEntityLinkProblemType()
    analyser.process()

    # python -m recommend.entity_link.analyse.step3_analyse_entitylink_problem_type
