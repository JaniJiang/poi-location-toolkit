import json
import pandas as pd
from loguru import logger
import re
from utils.tool_utils.entitylink_utils import EntityLinkApi

class GetEntityLinkResult:
    """获取EntityLink的结果"""

    def __init__(self):
        self.url = "http://ks-engine-server-inference.ssai-apis-staging.chj.cloud:80/cloud/inner/nlp/kg/knowledge-search-engine/entity-link"
        self.input_file = "data/cloud_share/recommend/struct_display_new/analyse/analyse_metrics/output.tsv"
        self.output_file = "data/cloud_share/recommend/struct_display_new/analyse/analyse_metrics/output_with_entitylink.tsv"
        self.api = EntityLinkApi(self.url)

    @staticmethod
    def extract_spoken(block_json_str):
        try:
            m = re.search(r'"spoken"\s*:\s*"([^"]*)"', block_json_str.replace('""', '"'), re.DOTALL)
            return m.group(1) if m else ""
        except Exception as e:
            logger.error(f"Parse block failed: {e}, src={block_json_str[:80]+'...'}")
            return ""

    @staticmethod
    def extract_title(block_json_str):
        try:
            s = block_json_str.replace('""', '"')
            m = re.search(r'"title"\s*:\s*"([^"]*)"', s, re.DOTALL)
            if m:
                title = m.group(1)
                return f"《{title}》" if title else ""
            else:
                return ""
        except Exception as e:
            logger.error(f"Extract title failed: {e}, src={block_json_str[:80]+'...'}")
            return ""

    
    
    def process(self):
            df = pd.read_csv(self.input_file, sep='\t', dtype=str, keep_default_na=False)
            output_rows = []
            for idx, row in df.iterrows():
                cat = row["category"].strip()
                block = row.get('block', '')

                if cat == '音乐':
                    query = self.extract_spoken(block)
                    link_type = "LT_MUSIC"
                elif cat == '影视':
                    query = self.extract_title(block)
                    link_type = "LT_Movie"
                else:
                    continue

                if not query:
                    logger.warning(f"No valid query for idx={idx}, category={cat}")
                    continue

                request_body = EntityLinkApi.call_entity_link(query, link_type)
                response_json = self.api.post(request_body)

                output_row = row.to_dict()
                output_row['entitylink_response'] = json.dumps(response_json, ensure_ascii=False, indent=2)
                print(f"已处理 idx={idx}, category={cat}, query={query}")
                output_rows.append(output_row)

            out_df = pd.DataFrame(output_rows)
            out_df.to_csv(self.output_file, sep='\t', index=False)
            print(f"结果已保存：{self.output_file}")

if __name__ == "__main__":
    obj = GetEntityLinkResult()
    obj.process()


# python -m recommend.entity_link.analyse.step2_get_entitylink_result