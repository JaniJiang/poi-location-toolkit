import ast
import json
import collections
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, udf, when
from pyspark.sql.types import StringType, ArrayType, MapType, StructType, StructField
from pyspark.sql import functions as F

app_package_name = [
    'cn.cmvideo.car.play',
    'com.lixiang.car.x.tencentvideo',
    'com.youku.carauto',
    'com.lixiang.car.x.video',
    'com.bilibili.bilithings',
    'com.duoduo.child.storyhd',
    'com.mgtv.auto'
]

# 定义视频信息的结构类型
video_info_schema = StructType([
    StructField("title", StringType(), True),
    StructField("category", StringType(), True),
    StructField("app", StringType(), True),
    StructField("label", ArrayType(StringType()), True),
    StructField("area", ArrayType(StringType()), True),
    StructField("actors", ArrayType(StringType()), True),
    StructField("vip_type", StringType(), True),
    # StructField("click_dt", StringType(), True)
])

def get_click_video(vin, data_json, event_key, click_dt, meta_map, month_exposure_map):
    if event_key == 'X_Feed_001_0026':
        return None
    try:
        data = ast.literal_eval(data_json)
    except Exception:
        return None
    
    if data.get('app_package_name') in app_package_name and data.get('strategy_id') == 'feed_scheme':
        video_name = data.get('card_name', '')
        video_id = data.get('card_id', '')
        
        # 检查是否在过去30天内曝光过
        if month_exposure_map is not None and vin in month_exposure_map and video_id not in month_exposure_map[vin]:
            return None
            
        if video_id and meta_map is not None and video_id in meta_map:
            meta = meta_map[video_id]
            actors = []
            try:
                actors_info = meta.get('actors')
                if isinstance(actors_info, str):
                    actors_info = json.loads(actors_info)
                if isinstance(actors_info, list):
                    for item in actors_info:
                        actor_name = item.get('name', '')
                        if actor_name:
                            actors.append(actor_name)
            except Exception:
                pass
                
            label = []
            try:
                label_str = meta.get('label', '')
                if label_str:
                    label = ast.literal_eval(label_str) if isinstance(label_str, str) else label_str
            except Exception:
                pass
                
            area = []
            try:
                area_str = meta.get('area', '')
                if area_str:
                    area = ast.literal_eval(area_str) if isinstance(area_str, str) else area_str
            except Exception:
                pass
                
            return {
                'title': video_name or '',
                'category': meta.get('category', ''),
                'app': meta.get('app_source', ''),
                'label': label,
                'area': area,
                'actors': actors,
                'vip_type': meta.get('vip_type', '')
                # 'click_dt': click_dt or ''
            }
    return None

def get_exposure_video_list(data_json, event_key, meta_map=None):
    if event_key == 'X_Feed_001_0003':
        return []
    try:
        data = ast.literal_eval(data_json)
    except Exception:
        return []
        
    result = []
    package_list = data.get("package_list", [])
    
    for item in package_list:
        if item.get('app_package_name') in app_package_name and item.get('feed_card_type') in ('2', 2):
            video_name = item.get('card_name', '')
            video_id = item.get('card_id', '')
            
            if video_id and meta_map is not None and video_id in meta_map:
                meta = meta_map[video_id]
                actors = []
                try:
                    actors_info = meta.get('actors')
                    if isinstance(actors_info, str):
                        actors_info = json.loads(actors_info)
                    if isinstance(actors_info, list):
                        for aitem in actors_info:
                            actor_name = aitem.get('name', '')
                            if actor_name:
                                actors.append(actor_name)
                except Exception:
                    pass
                    
                label = []
                try:
                    label_str = meta.get('label', '')
                    if label_str:
                        label = ast.literal_eval(label_str) if isinstance(label_str, str) else label_str
                except Exception:
                    pass
                    
                area = []
                try:
                    area_str = meta.get('area', '')
                    if area_str:
                        area = ast.literal_eval(area_str) if isinstance(area_str, str) else area_str
                except Exception:
                    pass
                    
                info = {
                    'title': video_name or '',
                    'category': meta.get('category', ''),
                    'app': meta.get('app_source', ''),
                    'label': label,
                    'area': area,
                    'actors': actors,
                    'vip_type': meta.get('vip_type', '')
                    # 'click_dt': ''  # 曝光没有点击时间
                }
                result.append(info)
                
    return result

def collect_month_exposure_videos(spark, feed_table, app_package_name, dt, vin_list):
    from datetime import datetime, timedelta

    dt_fmt = "%Y-%m-%d"
    dt_end = datetime.strptime(dt, dt_fmt)
    dt_list = [(dt_end - timedelta(days=i)).strftime(dt_fmt) for i in range(30)]
    dt_list_str = "','".join(dt_list)
    vin_str = ",".join([f"'{v}'" for v in vin_list])
    
    sql = f"""
        SELECT vin, data_json, event_key
        FROM {feed_table}
        WHERE dt in ('{dt_list_str}')
        AND event_key = 'X_Feed_001_0026'
        AND vin IN ({vin_str})
        AND get_json_object(data_json, '$.feed_mode') = 'CHILD_MODE'
    """
    df = spark.sql(sql)
    vin2exp = collections.defaultdict(set)
    
    for row in df.collect():
        try:
            data = ast.literal_eval(row['data_json'])
            for item in data.get("package_list", []):
                if item.get('app_package_name') in app_package_name and item.get('card_id', '') and item.get('feed_card_type') in ('2', 2):
                    vin2exp[row['vin']].add(item['card_id'])
        except Exception:
            pass
            
    return {k: list(v) for k, v in vin2exp.items()}

def enrich_search_click_text(show_list_str, click_text, click_dt, meta_map):
    try:
        show_list = ast.literal_eval(show_list_str) if show_list_str else []
    except Exception:
        show_list = []
        
    for video_info in show_list:
        if isinstance(video_info, dict) and 'notice_title' in video_info and video_info['notice_title'] == click_text:
            click_video_id = video_info.get('album_id')
            if click_video_id and click_video_id in meta_map:
                meta = meta_map[click_video_id]
                actors = []
                try:
                    actors_info = meta.get('actors')
                    if isinstance(actors_info, str):
                        actors_info = json.loads(actors_info)
                    if isinstance(actors_info, list):
                        for aitem in actors_info:
                            actor_name = aitem.get('name', '')
                            if actor_name:
                                actors.append(actor_name)
                except Exception:
                    pass
                    
                label = []
                try:
                    label_str = meta.get('label', '')
                    if label_str:
                        label = ast.literal_eval(label_str) if isinstance(label_str, str) else label_str
                except Exception:
                    pass
                    
                area = []
                try:
                    area_str = meta.get('area', '')
                    if area_str:
                        area = ast.literal_eval(area_str) if isinstance(area_str, str) else area_str
                except Exception:
                    pass
                    
                return {
                    'title': click_text or '',
                    'category': meta.get('category', ''),
                    'app': meta.get('app_source', ''),
                    'label': label,
                    'area': area,
                    'actors': actors,
                    'vip_type': meta.get('vip_type', '')
                }
    return None

if __name__ == '__main__':
    print('+++ 开始处理数据 +++')
    spark = SparkSession.builder.getOrCreate()
    spark.sparkContext.setLogLevel("INFO")
    dt = spark.conf.get("spark.app.args", None)
    if not dt:
        raise ValueError("请检查 spark.app.args (dt参数)，不能为空！")
    print(f"处理日期: {dt}")
    
    # ================== 1. 元数据处理 ==================
    sqlString_meta = f"""
        SELECT
            li_video_id,
            app_video_id,
            CASE
                WHEN app_source = 'com.lixiang.crs.plays.iqiyi' THEN '爱奇艺'
                WHEN app_source = 'com.lixiang.crs.plays.tencentvideo' THEN '腾讯视频'
                WHEN app_source = 'com.lixiang.crs.plays.mango' THEN '芒果tv'
                WHEN app_source = 'com.lixiang.crs.plays.youku' THEN '优酷视频'
                WHEN app_source = 'com.lixiang.crs.plays.bilibili' THEN 'bilibili'
                ELSE app_source
            END AS app_source,
            category_name AS category,
            label,
            area,
            actors,
            CASE
                WHEN vip_type = '1' OR vip_type = 1 THEN 'vip'
                ELSE '免费'
            END AS vip_type
        FROM crs_dw.dw_crs_tp_media_collection
        WHERE dt = '{dt}'
        and app_source in (
            'com.lixiang.crs.plays.iqiyi',
            'com.lixiang.crs.plays.tencentvideo',
            'com.lixiang.crs.plays.mango',
            'com.lixiang.crs.plays.youku',
            'com.lixiang.crs.plays.bilibili'
        )
    """
    df_meta = spark.sql(sqlString_meta)
    print('元数据:')
    df_meta.show(truncate=False)
    
    meta_map = {row['app_video_id']: {k: row[k] for k in row.asDict() if k != 'app_video_id'} for row in df_meta.collect()}
    meta_map_bc = spark.sparkContext.broadcast(meta_map)

    # ================== 2. feed数据处理 ==================
    feed_table = "dw.dwd_vehicle_track_feed_di"

    # vin_list用于month_exposure查询
    VIN_LIST = [
        'HLX32B143S1106292', 'HLX33B122S1431138', 'LW433B124P1001444',
        'HLX33B126S1730583', 'HLX32B148R1355178', 'HLX33B126R1606999',
        'HLX33B123S1734073', 'HLX33B126S1432888', 'HLX33B126S1438674',
        'HLX33B121S1734427', 'HLX33B123S1431844', 'HLX33B129S1430634',
        'HLX33B129R0767014', 'LW433B122P1056166', 'HLX33B129S1431170',
        'HLX32B145R1501097', 'LW433B127P1622483', 'HLX33B121S1432278',
        'HLX33B127S1731483', 'HLX33B123S1734591', 'HLX33B127S1725716',
        'HLX32B14XR1428308', 'HLX33B120S1431204', 'HLX32B146S1115391',
        'HLX33B128S0460438', 'HLX33B125S1430730', 'HLX32B148S1061169',
        'LW433B124P1657188', 'HLX33B126P1773490', 'LW433B125P1609988',
        'HLX33B123S1431259', 'HLX33B125R0097039', 'HLX33B121S0461687',
        'HLX32B144S1125238', 'HLX33B121S1432328', 'HLX32B140S1060422',
        'HLX32B142S1060096', 'LW433B125P1081319', 'HLX32B145S1060979',
        'HLX33B120S1431316', 'LW433B125P1600661', 'HLX33B12XS1430724',
        'HLX33B122S1752158', 'HLX32B140S1069282', 'HLX33B125S1431196',
        'HLX33B12XS1431288', 'HLX33B126S1431501', 'HLX33B127S1731483',
        'HLX32B144S1061234', 'LW433B12XP1075113', 'LW433B126P1109743',
        'HLX33B120S1432000', 'HLX32B146R1483077', 'HLX33B12XS1431498',
        'HLX33B121S1734380', 'HLX33B123S1432976', 'HLX33B123S0405962',
        'LW433B123P1673009', 'HLX33B123S1431536', 'HLX33B121S1427906',
        'HLX33B124S1442951', 'HLX33B125R1629321', 'HLX33B122S1430636',
        'HLX33B122P0731761', 'HLX33B126S1427920', 'HLX32B141R1374803',
        'HLX33B125S1730851', 'HLX32B146S1060831', 'HLX33B126S1430963',
        'HLX33B12XS1733650', 'HLX32B142R1499180', 'HLX33B122S1431074',
        'HLX33B123S1429169', 'HLX33B12XR0105751', 'HLX33B121S1431728',
        'HLX32B146S1008020', 'LW433B126P1664269'
    ]

    # 查询最近一个月曝光列表
    month_exposure_map = collect_month_exposure_videos(
        spark, feed_table, app_package_name, dt, VIN_LIST
    )
    month_exposure_map_bc = spark.sparkContext.broadcast(month_exposure_map)

    # feed数据查询
    sql_feed = f"""
        SELECT vin, event_key, data_json, busi_time, dt
        FROM {feed_table}
        WHERE dt='{dt}'
          AND event_key in ('X_Feed_001_0003', 'X_Feed_001_0026')
          AND vin in ({','.join([f"'{v}'" for v in VIN_LIST])})
          AND get_json_object(data_json, '$.feed_mode') = 'CHILD_MODE'
    """
    df_feed = spark.sql(sql_feed)

    # UDF定义 - 修正类型定义
    @udf(video_info_schema)
    def get_click_video_udf(vin, data_json, event_key, busi_time):
        return get_click_video(vin, data_json, event_key, busi_time, meta_map_bc.value, month_exposure_map_bc.value)

    @udf(ArrayType(video_info_schema))
    def get_exposure_video_list_udf(data_json, event_key):
        return get_exposure_video_list(data_json, event_key, meta_map_bc.value)

    # 处理feed数据
    df_feed = df_feed.withColumn(
        'feed_click_video',
        get_click_video_udf(col('vin'), col('data_json'), col('event_key'), col('busi_time'))
    ).withColumn(
        'feed_rec_video_list',
        get_exposure_video_list_udf(col('data_json'), col('event_key'))
    )

    # 聚合数据
    df_feed = df_feed.groupBy('vin', 'dt').agg(
        F.array_distinct(F.flatten(F.collect_list('feed_rec_video_list'))).alias('feed_rec_video_list'),
        F.filter(F.collect_list('feed_click_video'), lambda x: x.isNotNull()).alias('feed_click_video_list')
    )

    df_feed = df_feed.select(
        'vin',
        F.to_json('feed_rec_video_list').alias('feed_rec_video_list'),
        F.to_json('feed_click_video_list').alias('feed_click_video_list'),
        'dt'
    )
    print('Feed数据:')
    df_feed.show(truncate=False)

    # ================== 3. search数据处理 ==================
    sql_search = f"""
        SELECT vin, show_list, click_text, request_time, dt
        FROM ssai_ods.media_search_join_v3_df
        WHERE dt='{dt}'
          AND domain = 'media'
          AND click_text IS NOT NULL
          AND vin in ({','.join([f"'{v}'" for v in VIN_LIST])})
    """
    df_search = spark.sql(sql_search)

    @udf(video_info_schema)
    def enrich_search_click_udf(show_list, click_text, request_time):
        return enrich_search_click_text(show_list, click_text, request_time, meta_map_bc.value)

    df_search = df_search.withColumn(
        'search_click_video',
        enrich_search_click_udf(col('show_list'), col('click_text'), col('request_time'))
    )

    df_search = df_search.groupBy('vin', 'dt').agg(
        F.filter(F.collect_list('search_click_video'), lambda x: x.isNotNull()).alias('search_click_video_list')
    )

    df_search = df_search.select(
        'vin',
        'dt',
        F.to_json('search_click_video_list').alias('search_click_video_list')
    )
    print('Search数据:')
    df_search.show(truncate=False)

    # ================== 4. Join并写表 ==================
    final_table_name = 'user_video_table'
    df_res = df_feed.join(df_search, on=['vin', 'dt'], how='left')
    df_res = df_res.select(
        'vin',
        'feed_rec_video_list',
        'feed_click_video_list',
        'search_click_video_list',
        'dt'
    )
    print('最终结果:')
    df_res.show(truncate=False)
    
    df_res.createOrReplaceTempView(final_table_name)

    sqlT = f"""
        INSERT OVERWRITE TABLE ssai_ods.feed_user_perference_table_child_v4 PARTITION(dt='{dt}')
        SELECT 
            vin,
            feed_rec_video_list,
            feed_click_video_list,
            search_click_video_list
        FROM {final_table_name}
    """
    spark.sql(sqlT)
    spark.stop()
    print('+++ 结果已输出 +++')