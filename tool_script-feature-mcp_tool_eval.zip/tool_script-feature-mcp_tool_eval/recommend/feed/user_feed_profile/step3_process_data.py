import os
import re
import ast
import json
import pandas as pd
from tqdm import tqdm
from datetime import datetime, timedelta


class ProcessData:
    def __init__(self, input_path=None, output_path=None):
        self.input_path = input_path or "/mnt/volumes/ss-spaceai-lx-my/zhaojiufeng/data/data_cloud/feed/label_data_child/v4"
        self.output_path = output_path or "/mnt/volumes/ss-spaceai-lx-my/zhaojiufeng/data/data_cloud/feed/label_data_child/v4"

    def dict_to_str(self, d):
        result = []
        for key in d:
            value = d[key]
            if isinstance(value, list):
                # 把元素转字符串后，逗号拼接
                value_str = '[' + ','.join(str(v) for v in value) + ']'
            else:
                value_str = str(value)
            result.append(f"{key}={value_str}")
        return ', '.join(result)


    def load_before_week_data(self, today_str, week_str, vin):
        today = datetime.strptime(today_str, '%Y-%m-%d')
        if week_str == '第四周':
            begin = 0
            end = 7
        elif week_str == '第三周':
            begin = 7
            end = 14
        elif week_str == '第二周':
            begin = 14
            end = 21
        elif week_str == '第一周':
            begin = 21
            end = 28
        else:
            print('erro week_str')
            return []

        date_list = [
            (today - timedelta(days=i)).strftime('%Y%m%d')
            for i in range(begin, end)
        ]
        date_list.sort()

        valid_files = {f"{date}.csv" for date in date_list}
        feed_res, search_res = [], []

        for filename in os.listdir(self.input_path):
            if filename in valid_files:
                file_path = os.path.join(self.input_path, filename)
                try:
                    df = pd.read_csv(file_path, sep=',')
                    for idx, row in df.iterrows():
                        if row['vin'] != vin:
                            continue
                        try:
                            feed_click_str = row.get(
                                'feed_click_video_list', '[]')
                            search_click_str = row.get(
                                'search_click_video_list', '[]')
                            feed_click_list = []
                            if pd.notna(feed_click_str) and feed_click_str not in [
                                    '', None]:
                                feed_click_list = json.loads(feed_click_str)
                            search_click_list = []
                            if pd.notna(search_click_str) and search_click_str not in [
                                    '', None]:
                                search_click_list = json.loads(
                                    search_click_str)
                            feed_res.extend(feed_click_list)
                            search_res.extend(search_click_list)
                        except Exception as e:
                            print(f"Parse error: {e}, row: {row}")
                            continue
                except Exception as e:
                    print(f"Error reading file {filename}: {e}")
                    continue
        # 结构输出（两种起播方式 + 各自播放列表）
        feed_res = [self.dict_to_str(item) for item in feed_res]
        search_res = [self.dict_to_str(item) for item in search_res]

        click_res = {
            "feed屏播放列表": list(set(feed_res)),
            "视频搜索播放列表": list(set(search_res))
        }
        return click_res

    def process(self, today_str, rec_file_path=None):
        today = datetime.strptime(today_str, '%Y-%m-%d')

        if rec_file_path is None:
            rec_filename = f"{today.strftime('%Y%m%d')}.csv"
            rec_file_path = os.path.join(self.input_path, rec_filename)

        df = pd.read_csv(rec_file_path, sep=',')

        result = []
        for idx, row in tqdm(df.iterrows(), total=len(df),
                             desc="Data Processing"):
            vin = row.get('vin')
            if not vin:
                continue
            # 获取推荐视频列表
            feed_rec_video_list = row.get('feed_rec_video_list', '[]')
            try:
                if pd.notna(feed_rec_video_list) and feed_rec_video_list not in [
                        '', None]:
                    feed_rec_video_list = json.loads(feed_rec_video_list)
                    feed_rec_video_list = [self.dict_to_str(item) for item in feed_rec_video_list]
                else:
                    feed_rec_video_list = []
            except Exception as e:
                print(f"Error parsing feed_rec_video_list: {e}")
                feed_rec_video_list = []
            # 获取各周的点击历史
            first_week_list = self.load_before_week_data(today_str, '第一周', vin)
            second_week_list = self.load_before_week_data(
                today_str, '第二周', vin)
            third_week_list = self.load_before_week_data(today_str, '第三周', vin)
            fourth_week_list = self.load_before_week_data(
                today_str, '第四周', vin)
            user_click_history_list = {
                '第一周': first_week_list,
                '第二周': second_week_list,
                '第三周': third_week_list,
                '第四周': fourth_week_list
            }

            result.append({
                'vin': vin,
                'dt': today_str,
                'feed_rec_video_list': feed_rec_video_list,
                'user_click_history_list': user_click_history_list
            })

        return result

    def save_result(self, result, output_file=None):
        if not result:
            print("No data to save")
            return

        if output_file is None:
            output_file = os.path.join(
                self.output_path,
                f"label_data_{datetime.now().strftime('%Y%m%d')}_v3.json")

        os.makedirs(os.path.dirname(output_file), exist_ok=True)

        try:
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(result, f, ensure_ascii=False, indent=2)
            print(f"Result saved to {output_file}")
        except Exception as e:
            print(f"Error saving result: {e}")


if __name__ == '__main__':
    today_str = '2025-11-06'
    process_data = ProcessData()
    result = process_data.process(today_str)

    if result:
        print(f"Processed {len(result)} records")
        process_data.save_result(result)
    else:
        print("No data processed")

    # python -m recommend.feed.user_feed_profile.step3_label_data
