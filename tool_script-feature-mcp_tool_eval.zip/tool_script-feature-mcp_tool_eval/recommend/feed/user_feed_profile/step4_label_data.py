import json
import pandas as pd
from tqdm import tqdm
from utils.llm_utils.serverless_function import request_llm


class LabelData:
    def __init__(self, input_path=None, output_path=None):
        self.input_path = input_path or "data/cloud_share/feed/label_data/v4/label_data_20251107_v3.json"
        self.output_path = output_path or "data/cloud_share/feed/label_data/v4/label_data_llm_result_20251031_v2.csv"
        self.prompt_template = (
            "你是一名影视调研专家，你要根据用户过去几周的观看历史，评估用户整体的兴趣偏好。\n"
            "最近几周内，用户的观看历史如下：\n{user_click_history_list}\n"
            "我们给用户推荐的影视资源列表如下：\n{feed_rec_video_list}\n"
            "请你先评估用户整体的兴趣偏好，然后判断我们推荐的影视资源是否符合用户兴趣，如果不合适，请说明该用户当前更适合推荐哪些类型的影视资源。"
            "以下因素将不被考虑：影片类型是否是 vip 类型"
        )
        # self.user_pro = (
        #     "请严格按照以下JSON格式输出：\n"
        #     """{{
        #     }}"""
        #     # "用户整体偏好：xxx\n"
        #     # "推荐影视资源与用户整体偏好的契合度：xxx\n"
        #     # "期望推荐的资源类型：xxx（可以包括但不限于语言、影视类型如电影/动漫/综艺/电视剧，类别如科幻/喜剧等）\n"
        #     "输出期望：\n "
        #     "- 用户整体偏好: 可以是挖掘用户喜欢的电影类型、喜欢的导演、喜欢的明星、喜欢的语言等，如无明显特征请勿强硬套入关键词\n"
        #     "- 推荐影视资源与用户整体偏好的契合度：\n"
        #     "- 期望推荐的资源类型：可以不局限于类型，少量的进行探索\n"
        #     "- 以上所以字段仅筛选出关键词，以几个关键词展示"
        # )

        self.user_pro = """请严格按照以下JSON格式输出：
        {{
            "user_interests": ["xxx", "xxx", ...],
            "fit_": "xxx",
            "like": ["xxx", "xxx", ...]
        }}
        
        输出期望：
        - 用户整体偏好: 可以是挖掘用户喜欢的电影类型、喜欢的导演、喜欢的明星、喜欢的语言等，如无明显特征请勿强硬套入关键词
        - 推荐影视资源与用户整体偏好的契合度：判断是否推荐是否契合，有低、中、高选项
        - 期望推荐的资源类型：可以不局限于类型，少量的进行探索
        - 以上所以字段仅筛选出关键词，以几个关键词展示"""

    def LLM_label(self, user_click_history_list,
                  feed_rec_video_list, model="claude-3_5-sonnet"):
        instruction = self.prompt_template.format(
            user_click_history_list=user_click_history_list,
            feed_rec_video_list=feed_rec_video_list
        )
        try:
            _, response_data = request_llm(
                [instruction, self.user_pro], model="gpt-4o")
            res = response_data['choices'][0]['message']['content']
            return res
        except Exception as e:
            return f'Error: {e}'

    def parse_label(self, response):
        import re
        json_match = re.search(r'```json\s*(.*?)\s*```', response, re.DOTALL)
        if json_match:
            json_str = json_match.group(1)
            data = json.loads(json_str)
            return json.dumps(data, ensure_ascii=False, indent=2)
        else:
            json_str = response
            return json_str

    def process(self):
        with open(self.input_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        llm_label_result = []
        for item in tqdm(data, desc="LLM Label"):
            feed_rec_video_list = item.get('feed_rec_video_list', [])
            if isinstance(feed_rec_video_list, str):
                try:
                    feed_rec_video_list = json.loads(feed_rec_video_list)
                except Exception:
                    feed_rec_video_list = []
            user_click_history_list = item.get('user_click_history_list', {})
            if isinstance(user_click_history_list, str):
                try:
                    user_click_history_list = json.loads(
                        user_click_history_list)
                except Exception:
                    user_click_history_list = {}
            llm_label = self.LLM_label(
                user_click_history_list, feed_rec_video_list)
            print(llm_label)
            llm_label = self.parse_label(llm_label)
            llm_label_result.append({
                'vin': item.get('vin', ""),
                'dt': item.get('dt', ""),
                'feed_rec_video_list': json.dumps(feed_rec_video_list, ensure_ascii=False, indent=2),
                'user_click_history_list': json.dumps(user_click_history_list, ensure_ascii=False, indent=2),
                'user_interests': llm_label
            })

        # with open(self.output_path.replace('csv', 'json'), 'w', encoding='utf-8') as f:
        #     for obj in llm_label_result:
        #         f.write(json.dumps(obj, ensure_ascii=False) + '\n')
        df_llm_result = pd.DataFrame(llm_label_result)
        df_llm_result.to_csv(
            self.output_path,
            index=False,
            encoding="utf-8-sig",
            sep="\t"
        )
        print(f"保存到 {self.output_path}")
        return llm_label_result


if __name__ == '__main__':
    label = LabelData()
    label.process()
    # python -m recommend.feed.user_feed_profile.step4_label_data
