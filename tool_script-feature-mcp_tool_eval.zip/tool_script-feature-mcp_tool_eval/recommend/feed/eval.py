import requests
import json
import pandas as pd
from tqdm import tqdm
from datetime import datetime, timedelta
from utils.search_utils.es_client import ElasticSearchClient

addr_mapping = {
    "testtwo": "http://ssai-media-bot-lids-testtwo.ssai-apis-staging.chj.cloud/media/video/feed",
    "bj_prod": "http://ssai-media-bot-lids.ssai-apis.chj.cloud/media/video/feed",
    "sz_prod": "http://ssai-media-bot-lids.ssai-apis.cnsu01.chj.cloud/media/video/feed",
    "local": "http://localhost:16386/media/video/feed",
}


def send_post(env):
    body = {
        "requestId": "test_requestId1sbb2",
        "vin": "test_vins",
        "needNum": 1000,
        "category": "ALL",
        # "needLruCache": False,
        "order": 0,
        # "categoryRatio": None,
        "appRatio": [
            {"name": "zebra", "ratio": 0.0},
            {"name": "voicechat", "ratio": 0.0},
            {"name": "miguvideo", "ratio": 0.0},
            {"name": "ximalaya", "ratio": 0.0},
            {"name": "bilibili", "ratio": 0.0},
            {"name": "thunder", "ratio": 0.0},
            {"name": "iqiyi", "ratio": 0.5},
            {"name": "qqmusic", "ratio": 0.0},
            {"name": "mango", "ratio": 0.0},
            {"name": "tencentvideo", "ratio": 0.5},
            {"name": "netease", "ratio": 0.0},
            {"name": "youku", "ratio": 0.0},
            {"name": "springfestival", "ratio": 0.0},
            {"name": "kugou", "ratio": 0.0},
            {"name": "demonstration", "ratio": 0.0},
            {"name": "kg", "ratio": 0.0},
            {"name": "huanxi", "ratio": 0.0}
        ],
        "apps": [
            {"name": "iqiyi", "isVersionValid": True, "privacy": True},
            # {"name": "tencentvideo", "isVersionValid": True, "privacy": True},
            {"name": "youku", "isVersionValid": True, "privacy": True},
            {"name": "qqmiusic", "isVersionValid": True, "privacy": True},
            {"name": "bilibili", "isVersionValid": True, "privacy": True},
            {"name": "mango", "isVersionValid": True, "privacy": True},
            {"name": "thunder", "isVersionValid": True, "privacy": True},
            {"name": "kugou", "isVersionValid": True, "privacy": True},
            {"name": "netease", "isVersionValid": True, "privacy": True},
            {"name": "qqmusic", "isVersionValid": True, "privacy": True},
            {"name": "zebra", "isVersionValid": True, "privacy": True},
            {"name": "ximalaya", "isVersionValid": True, "privacy": True}
        ],
        "recommendParam": {
            "isFee": False,
            "prePlay": False
        },
        "filterParam":{
            "area": None,
            "language": None,
            "year": None,
            "isFee": None,
            "isDolbyVision": None
        }
    }
    try:
        response = requests.post(addr_mapping[env], json=body, timeout=10)
        response.raise_for_status()
        result = response.json()
        feed_result = result["data"]
        return feed_result
    except Exception as e:
        print("请求出错：", e)
        return []


def get_ES_results(es_env, feed_result, save_path):
    ES_results = []
    headers = {"Content-Type": "application/json"}
    for data in tqdm(feed_result):
        app_source = data['appSource'].split('.')[-1]
        videoId = data['videoId']
        es_query = {
            "size": 100,
            "query": {
                "nested": {
                    "path": "where_look",
                    "query": {
                        "bool": {
                            "must": [
                                {"term": {"where_look.video_id": videoId}}
                            ]
                        }
                    }
                }
            }
        }

        if "prod" in es_env:
            cluster_name = "meta_prod"
            INDEX = f"ssai_tv_meta_{(datetime.now() - timedelta(days=1)).strftime('%Y%m%d')}"
            es_client = ElasticSearchClient(cluster_name)
        else:
            cluster_name = "meta_testtwo"
            INDEX = "test_env_ssai_tv_meta_20250629"
            es_client = ElasticSearchClient(cluster_name)
        resp = es_client.search(es_query, INDEX, False)
        hits = resp.get('hits', {}).get('hits', [])
        for hit in hits:
            rank = []
            for source in hit['_source']['where_look']:
                rank.append({
                    'rank': source['rank'],
                    'source': source['source'],
                })
            ES_results.append(
                {
                    "title": hit['_source']['title'],
                    "appSource": app_source,
                    "publit_time": hit['_source']["publish_time"],
                    "hot": hit['_source']["hot"],
                    "score": hit['_source']["score"],
                    "rank": json.dumps(rank, ensure_ascii=False, indent=2)
                }
            )
    if len(ES_results) > 0:
        df = pd.DataFrame(ES_results)
        df.to_csv(save_path, sep="\t", index=False)
    return ES_results


if __name__ == "__main__":
    env = "bj_prod"  # local, testtwo, bj_prod, sz_prod
    feed_result = send_post(env)
    save_path = f"/data/cloud_share/feed/feed_result_{env}.tsv"
    get_ES_results(env, feed_result, save_path)
    # python -m recommend.feed.eval
