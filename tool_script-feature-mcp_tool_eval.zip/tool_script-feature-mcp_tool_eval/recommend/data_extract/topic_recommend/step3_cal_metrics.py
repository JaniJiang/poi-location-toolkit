import pandas as pd
from tqdm import tqdm
from datetime import datetime, timedelta
from joblib import Parallel, delayed
from utils.time_utils import get_last_week


def process_statics_daily(week_start, i, tabel_dir, week_str):
    date = week_start + timedelta(days=i)
    date_str = date.strftime("%Y-%m-%d")
    # 读取数据
    # vin_table = f"{tabel_dir}/{week_str}.vin/{date_str}.jsonl"
    # session_table = f"{tabel_dir}/{week_str}.session/{date_str}.jsonl"
    vin_session_table = f"{tabel_dir}/{week_str}.vin_session/{date_str}.jsonl"
    # df_vin = pd.read_json(vin_table, orient="records", lines=True)
    # df_session = pd.read_json(session_table, orient="records", lines=True)
    df_vin_session = pd.read_json(vin_session_table, orient="records", lines=True)
    # 指标计算
    total_count = df_vin_session["rounds"].sum()
    show_count = df_vin_session["show_count"].sum()
    click_count = df_vin_session["click_count"].sum()
    show_rate = show_count / total_count
    click_rate = click_count / show_count
    # avg_rounds_session = df_session["rounds"].mean()
    # avg_rounds_vin = df_vin["rounds"].mean()
    avg_rounds_vin_session = df_vin_session["rounds"].mean()
    statics_daily = {
        "日期": date_str,
        "对话总量": total_count,
        "曝光量": show_count,
        "点击量": click_count,
        "曝光率": round(show_rate.item(), 4),
        "点击率": round(click_rate.item(), 4),
        # "平均对话轮次-session维度": round(avg_rounds_session.item(), 2),
        # "平均对话轮次-vin维度": round(avg_rounds_vin.item(), 2),
        "平均对话轮次-session维度(修复)": round(avg_rounds_vin_session.item(), 2),
    }
    return statics_daily


if __name__ == "__main__":
    # 获取上周日期
    # last_week_start, week_str = get_last_week()
    last_week_start, week_str = datetime.strptime("2025-05-12", "%Y-%m-%d"), "20250512-20250518"

    # 统计天级指标
    tabel_dir = "data/cloud_share/recommend/log_group/topic_recommend"
    statics_list = Parallel(n_jobs=7, prefer="processes")(
        delayed(process_statics_daily)(last_week_start, i, tabel_dir, week_str)
        for i in tqdm(range(0, 7, 1), total=7)
    )

    # 保存指标计算结果
    statics_df = pd.DataFrame(statics_list)
    statics_df.sort_values(by="日期", inplace=True)
    statics_df.to_csv(f"{tabel_dir}/{week_str}.statics.tsv", sep="\t", index=False)

# python -m recommend.data_extract.topic_recommend.step3_cal_metrics
