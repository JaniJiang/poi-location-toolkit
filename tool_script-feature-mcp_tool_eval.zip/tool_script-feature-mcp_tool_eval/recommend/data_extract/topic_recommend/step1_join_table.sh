#!/bin/bash
# join 融合表 和 话题推荐用户行为点击表
# bash utils/tool_utils/update_adt_tool.sh
# bash recommend/data_extract/topic_recommend/step1_join_table.sh

start_date="2025-05-26"
end_date=$(date -d "$start_date + 6 days" '+%Y-%m-%d')

start_mmdd=$(date -d "$start_date" '+%Y%m%d')
end_mmdd=$(date -d "$end_date" '+%Y%m%d')
folder_name="${start_mmdd}-${end_mmdd}"
mkdir -p "data/cloud_share/recommend/log_join/topic_recommend/$folder_name"

for i in {0..6}; do
    dt=$(date -d "$start_date + $i day" '+%Y-%m-%d')
    echo "Processing ${dt}"
    data/cloud_share/tool/adt --token d67cc581ad631e063f1e88cf42400a28 ark2csv --csv-file "data/cloud_share/recommend/log_join/topic_recommend/$folder_name/$dt.csv" --sql-string "
    SELECT
        t1.vin,
        t1.new_session_id,
        t1.record_id,
        t1.domain,
        json_extract_scalar(t1.content, '$.APINAME') AS api_name,
        json_extract_scalar(t1.content, '$.CATEGORY') AS category,
        json_extract_scalar(t1.content, '$.MEDIATYPE') AS media_type,
        json_extract_scalar(t2.data_json, '$.face_screen') AS face_screen,
        t1.query,
        t1.show_text_list as show_text_list,
        t1.show_text_click as click_text,
        t2.data_json AS show_info,
        t3.data_json AS click_info,
        t1.output,
        t1.model_13b_output,
        t1.dt,
        t1.request_time
    FROM dwd_vechile_merge_prod_di t1
    LEFT JOIN (
        SELECT
            record_id,
            data_json
        FROM dwd_vehicle_track_vehvoice_record_di
        WHERE dt = '$dt'
            AND event_key = 'vehvoice_002_0107'
            AND track_id IS NOT NULL
    ) t2 ON t1.record_id = t2.record_id
    LEFT JOIN (
        SELECT
            record_id,
            data_json
        FROM dwd_vehicle_track_vehvoice_record_di
        WHERE dt = '$dt'
            AND event_key = 'vehvoice_002_0108'
            AND track_id IS NOT NULL
    ) t3 ON t1.record_id = t3.record_id
    WHERE t1.dt = '$dt'
        AND t1.domain IN ('gpt_chat', 'gpt_autoqa', 'in_car_assistant', 'taskmaster')
        AND t1.query != '' AND t1.query IS NOT NULL
        AND t1.record_id != '' AND t1.record_id IS NOT NULL
        AND t1.vehicle_category = '1'
        AND t1.ota_version > '5'"
done
