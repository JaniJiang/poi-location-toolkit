import json
import math
import pandas as pd
from tqdm import tqdm
from datetime import timedelta
from joblib import Parallel, delayed


def process_group_daily(join_table_folder, group_table_folder, week_start, i, group_field_name, n_jobs=10):
    date = week_start + timedelta(days=i)
    date_str = date.strftime("%Y-%m-%d")
    # 读取数据
    input_df = pd.read_csv(f"{join_table_folder}/{date_str}.csv")
    grouped = input_df.sort_values(by="request_time").groupby(group_field_name)
    # 并发方式处理数据
    result_list = Parallel(n_jobs=n_jobs, prefer="threads")(
        delayed(process_group)(group_field_name, group_field_value, group)
        for group_field_value, group in tqdm(grouped, total=len(grouped), desc=date_str)
    )
    # # 非并发方式处理数据
    # result_list = []
    # for group_field_value, group in tqdm(grouped, total=len(grouped), desc=date_str):
    #     result_list.append(process_group(group_field_name, group_field_value, group))
    # 保存结果
    result_list = [item for item in result_list if len(item) > 0]
    output_df = pd.DataFrame(result_list)
    output_df.to_json(f"{group_table_folder}/{date_str}.jsonl", orient="records", lines=True, force_ascii=False)


def process_group(group_field_name, group_field_value, group, skip_check=False):
    message_origin_list = group.to_dict(orient="records")
    show_count = 0
    click_count = 0
    message_format_list = []
    uniq_key_dict = {}
    for msg_dict in message_origin_list:
        if skip_check is False:
            # 格式化对话数据（处理空值等）
            formated_msg_dict = format_msg_dict(msg_dict)
            # 检查异常数据
            if check_exception(formated_msg_dict) is True:
                continue
            # 数据去重
            uniq_key = gen_uniq_key(formated_msg_dict)
            if uniq_key in uniq_key_dict:
                continue
            uniq_key_dict[uniq_key] = True
        else:
            formated_msg_dict = msg_dict
        # 输出对话列表
        message_format_list.append(formated_msg_dict)
        # 统计曝光点击
        is_show = 1 if len(formated_msg_dict["show_text_list"]) > 0 else 0
        is_click = 1 if formated_msg_dict["click_text"] != "" else 0
        show_count += is_show
        click_count += is_click
    if len(message_format_list) == 0:
        return {}
    return {
        group_field_name: group_field_value,
        "rounds": len(message_format_list),
        "is_show": 1 if show_count > 0 else 0,
        "is_click": 1 if click_count > 0 else 0,
        "show_count": show_count,
        "click_count": click_count,
        "message_list": message_format_list,
    }


def process_dup_group(group_field_name, group_field_value, group):
    message_origin_list = group.to_dict(orient="records")
    # 获取去重key
    uniq_key_list = []
    for msg_dict in message_origin_list:
        # 格式化对话数据（处理空值等）
        formated_msg_dict = format_msg_dict(msg_dict)
        # 检查异常数据
        if check_exception(formated_msg_dict) is True:
            continue
        # 生成去重key
        uniq_key = gen_uniq_key(formated_msg_dict)
        uniq_key_list.append(uniq_key)
    dedup_uniq_key_list = list(set([uniq_key for uniq_key in uniq_key_list if uniq_key_list.count(uniq_key) > 1]))
    # 输出重复数据
    show_count = 0
    click_count = 0
    message_format_list = []
    for msg_dict in message_origin_list:
        # 格式化对话数据（处理空值等）
        formated_msg_dict = format_msg_dict(msg_dict)
        # 检查异常数据
        if check_exception(formated_msg_dict) is True:
            continue
        # 输出重复对话列表
        uniq_key = gen_uniq_key(formated_msg_dict)
        if uniq_key not in dedup_uniq_key_list:
            continue
        message_format_list.append(formated_msg_dict)
        # 统计曝光点击
        is_show = 1 if len(formated_msg_dict["show_text_list"]) > 0 else 0
        is_click = 1 if formated_msg_dict["click_text"] != "" else 0
        show_count += is_show
        click_count += is_click
    if len(message_format_list) == 0:
        return {}
    return {
        group_field_name: group_field_value,
        "rounds": len(message_format_list),
        "is_show": 1 if show_count > 0 else 0,
        "is_click": 1 if click_count > 0 else 0,
        "show_count": show_count,
        "click_count": click_count,
        "message_list": message_format_list,
    }


def format_msg_dict(msg_dict):
    for field_name in ["api_name", "category", "media_type", "click_text", "output", "model_13b_output"]:
        msg_dict[field_name] = format_str_field(msg_dict[field_name])
    for field_name in ["show_text_list"]:
        msg_dict[field_name] = format_list_field(msg_dict[field_name])
    for field_name in ["show_info", "click_info"]:
        msg_dict[field_name] = format_dict_field(msg_dict[field_name])
    return msg_dict


def format_str_field(value):
    if isinstance(value, float) and math.isnan(value):
        return ""
    return value.strip()


def format_list_field(value):
    if isinstance(value, float) and math.isnan(value):
        return []
    if type(value) is str:
        return json.loads(value)
    return value


def format_dict_field(value):
    if isinstance(value, float) and math.isnan(value):
        return {}
    if type(value) is str:
        return json.loads(value)
    return value


def check_exception(msg_dict):
    # 检查曝光异常
    show_text_list_a = msg_dict["show_text_list"]
    show_text_list_b = msg_dict["show_info"].get("voice_value", {}).get("show_text", [])
    if show_text_list_a != show_text_list_b:
        return True
    # 检查点击异常
    click_text_a = msg_dict["click_text"]
    click_text_b = msg_dict["click_info"].get("voice_value", {}).get("show_text", "")
    if click_text_a != click_text_b:
        return True
    return False


def gen_uniq_key(msg_dict):
    uniq_key = "|".join([
        str(msg_dict["vin"]),
        str(msg_dict["new_session_id"]),
        str(msg_dict["query"]),
        json.dumps(msg_dict["show_text_list"], ensure_ascii=False),
        str(msg_dict["click_text"]),
        str(msg_dict["request_time"])
    ])
    return uniq_key


def clean_messages(message_list):
    new_message_list = []
    need_api_name_list = []
    for msg_dict in message_list:
        new_msg_dict = {
            "new_session_id": msg_dict["new_session_id"],
            "record_id": msg_dict["record_id"],
            "domain": msg_dict["domain"],
            "api_name": msg_dict["api_name"],
            "category": msg_dict["category"] if msg_dict["api_name"] != "MEDIASearch" else msg_dict["media_type"],
            "face_screen": msg_dict["face_screen"],
            "query": msg_dict["query"],
            "show_text_list": msg_dict["show_text_list"],
            "click_text": msg_dict["click_text"],
            "output": msg_dict["output"],
            "request_time": msg_dict["request_time"],
        }
        new_message_list.append(new_msg_dict)
        if msg_dict["api_name"] in ["QASearch", "AUTOSearch"]:
            need_api_name_list.append(msg_dict["api_name"])
    new_message_str = json.dumps(new_message_list, ensure_ascii=False, indent=4)
    need_api_name_num = len(need_api_name_list)
    return new_message_str, need_api_name_num


def get_vin_from_session_id(session_id):
    parts = session_id.split("_")
    if len(parts) >= 2:
        return parts[1]
    else:
        return ""
