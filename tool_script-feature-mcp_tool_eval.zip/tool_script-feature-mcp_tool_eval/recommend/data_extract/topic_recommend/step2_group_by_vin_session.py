import os
from tqdm import tqdm
from datetime import datetime
from joblib import Parallel, delayed
from utils.time_utils import get_last_week
from recommend.data_extract.topic_recommend.utils import *


def is_similar(current_msg_dict, last_msg_dict) -> bool:
    current_query = current_msg_dict["query"]
    last_click_text = last_msg_dict["click_text"]
    if current_query == last_click_text:
        return True
    # TODO: 考虑文本相似度(即命中率概念)
    return False


def process_vin_session(vin, group):
    uniq_key_dict = {}
    new_session_id_tmp_list = []
    message_tmp_list = []
    vin_session_message_list = []
    group = group.sort_values("request_time")
    message_origin_list = group.to_dict(orient="records")
    for msg_dict in message_origin_list:
        # 格式化对话数据（处理空值等）
        formated_msg_dict = format_msg_dict(msg_dict)
        # 检查异常数据
        if check_exception(formated_msg_dict) is True:
            continue
        # 数据去重
        uniq_key = gen_uniq_key(formated_msg_dict)
        if uniq_key in uniq_key_dict:
            continue
        uniq_key_dict[uniq_key] = True
        # session判断
        new_session_id = formated_msg_dict["new_session_id"]
        if len(new_session_id_tmp_list) == 0 or new_session_id in new_session_id_tmp_list:  # 同一个session
            new_session_id_tmp_list.append(new_session_id)
            message_tmp_list.append(formated_msg_dict)
            continue
        if is_similar(formated_msg_dict, message_tmp_list[-1]) is True:  # 不同session，可以拼接
            new_session_id_tmp_list.append(new_session_id)
            message_tmp_list.append(formated_msg_dict)
            continue
        vin_session_message_list.append((new_session_id_tmp_list, message_tmp_list))
        new_session_id_tmp_list = [new_session_id]
        message_tmp_list = [formated_msg_dict]
    if len(message_tmp_list) > 0:
        vin_session_message_list.append((new_session_id_tmp_list, message_tmp_list))
    # 合并
    group_list = []
    for new_session_id_list, message_list in vin_session_message_list:
        merge_session_id = "_".join(sorted(list(set(new_session_id_list))))
        group_dict = process_group("merge_session_id", merge_session_id, pd.DataFrame(message_list), skip_check=True)
        group_list.append(group_dict)
    group_df = pd.DataFrame(group_list)
    return group_df


def process_vin_session_daily(input_folder, output_folder, week_start, i, n_jobs=20):
    date = week_start + timedelta(days=i)
    date_str = date.strftime("%Y-%m-%d")
    # 1. 读数据并按照vin做group
    df = pd.read_csv(f"{input_folder}/{date_str}.csv")
    vin_grouped = df.sort_values("request_time").groupby("vin")
    # 2. 处理每个vin下面的session
    group_df_list = Parallel(n_jobs=n_jobs, prefer="processes")(
        delayed(process_vin_session)(vin, group)
        for vin, group in tqdm(vin_grouped, total=len(vin_grouped), desc=f"process_vin_session[{date_str}]")
    )
    # 合并数据并排序
    output_df = pd.DataFrame(columns=["merge_session_id", "rounds",
                                      "is_show", "is_click", "show_count", "click_count", "message_list"])
    if group_df_list:
        output_df = pd.concat([output_df] + group_df_list, ignore_index=True)
    output_df.to_json(f"{output_folder}/{date_str}.jsonl", orient="records", lines=True, force_ascii=False)


if __name__ == "__main__":
    # 获取上周日期
    # last_week_start, week_str = get_last_week()
    last_week_start, week_str = datetime.strptime("2025-05-26", "%Y-%m-%d"), "20250526-20250601"

    join_table_folder = f"data/cloud_share/recommend/log_join/topic_recommend/{week_str}"
    group_table_folder = f"data/cloud_share/recommend/log_group/topic_recommend/{week_str}.vin_session"
    os.makedirs(group_table_folder, exist_ok=True)
    Parallel(n_jobs=7, prefer="processes")(
        delayed(process_vin_session_daily)(join_table_folder, group_table_folder, last_week_start, i)
        for i in tqdm(range(0, 7, 1), total=7, desc="process_daily")
    )

# python -m recommend.data_extract.topic_recommend.step2_group_by_vin_session
# nohup python -m recommend.data_extract.topic_recommend.step2_group_by_vin_session > log/recommend/data_extract/topic_recommend/step2_group_by_vin_session.log 2>&1 &
# ps aux|grep 'joblib.externals.loky.backend.popen_loky_posix'|awk -F" " '{print $2}'|xargs kill -9
