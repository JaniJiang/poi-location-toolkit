import os
from tqdm import tqdm
from datetime import datetime
from joblib import Parallel, delayed
from utils.time_utils import get_last_week
from recommend.data_extract.topic_recommend.utils import *

if __name__ == "__main__":
    # 获取上周日期
    last_week_start, week_str = get_last_week()
    # last_week_start, week_str = datetime.strptime("2025-04-07", "%Y-%m-%d"), "20250407-20250413"

    join_table_folder = f"data/cloud_share/recommend/log_join/topic_recommend/{week_str}"
    group_table_folder = f"data/cloud_share/recommend/log_group/topic_recommend/{week_str}.vin"
    os.makedirs(group_table_folder, exist_ok=True)
    Parallel(n_jobs=7, prefer="processes")(
        delayed(process_group_daily)(join_table_folder, group_table_folder, last_week_start, i, "vin")
        for i in tqdm(range(0, 7, 1), total=7)
    )

# python -m recommend.data_extract.topic_recommend.step2_group_by_vin
# nohup python -m recommend.data_extract.topic_recommend.step2_group_by_vin > log/recommend/data_extract/topic_recommend/step2_group_by_vin.log 2>&1 &
# ps aux|grep 'joblib.externals.loky.backend.popen_loky_posix'|awk -F" " '{print $2}'|xargs kill -9
