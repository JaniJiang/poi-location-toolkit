## 话题推荐:用户行为表
dwd_vehicle_track_vehvoice_record_di

## 话题推荐:云端日志表
暂无


## 结构化+富媒体推荐:用户行为表
通过飞书邮件下载后上传到/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_origin/struct/track_table

## 结构化+富媒体推荐:云端日志表
通过飞书邮件下载后上传到/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_origin/struct/cloud_table

## 下载后解压
使用/mnt/pfs-guan-ssai/nlu/zhaojiufeng/tool_script/data_extract/step2_unzip_file.sh


## 热点话题
暂无