from pyspark.sql import SparkSession
from pyspark.sql.functions import col, from_json, expr, rand
from pyspark.sql.types import StructType, StructField, StringType
import pandas as pd

# 初始化 SparkSession
spark = SparkSession.builder \
    .appName("Slot Sampling") \
    .config("spark.sql.parquet.enableVectorizedReader", "false") \
    .config("spark.driver.memory", "16g") \
    .config("spark.executor.memory", "16g") \
    .getOrCreate()

# 1. 读取 parquet 并过滤 has_show == True
parquet_path = "/lpai/volumes/ss-sai-lx-my/xuzhou1/data_share/recommend/log_join/struct/2025-04-13/"
df = spark.read.parquet(parquet_path).filter(col("has_show") == True)

# 2. 解析 slot_li 中的 JSON（假设 slot_li 是一个字符串列表，取第一个元素）
slot_schema = StructType([
    StructField("APINAME", StringType(), True),
    StructField("CATEGORY", StringType(), True),
    StructField("QUERY", StringType(), True),
    StructField("TAG", StringType(), True)
])

df_parsed = df.withColumn("slot_parsed", from_json(col("slot_li")[0], slot_schema))
df_clean = df_parsed.filter(col("slot_parsed").isNotNull())

# 3. 提取 APINAME 和 CATEGORY 字段
df_extracted = df_clean.withColumn("APINAME", col("slot_parsed.APINAME")) \
                       .withColumn("CATEGORY", col("slot_parsed.CATEGORY"))
# 采样逻辑在后面写上
# 额外采样 "CATEGORY"="人设" 且 "APINAME"="CHARASearch" 的 100 条数据
filtered_df = df_extracted.filter(
    (col("APINAME") == "meituansearch")
)

# 使用随机采样，获取最多 100 条数据
sampled_filtered_df = filtered_df.orderBy(rand())

# 转换为 Pandas 并保存为 Excel
filtered_pd = sampled_filtered_df.toPandas()
filtered_pd.to_excel("sampled_CHARASearch_meituansearch.xlsx", index=False)

# 4. 统计 APINAME 和 CATEGORY 的数量和比例
total_count = df_extracted.count()

category_stats = df_extracted.groupBy("CATEGORY").count().withColumn("ratio", expr(f"round(count / {total_count}, 4)"))
apiname_stats = df_extracted.groupBy("APINAME").count().withColumn("ratio", expr(f"round(count / {total_count}, 4)"))

print("CATEGORY 分布：")
category_stats.orderBy("count", ascending=False).show(truncate=False)

print("APINAME 分布：")
apiname_stats.orderBy("count", ascending=False).show(truncate=False)

# 5. 按照 CATEGORY 的比例采样 1000 条原始数据
# 添加随机数列用于分层采样
df_with_rand = df_extracted.withColumn("rand_val", rand())

# 加载统计数据到 driver 端以做采样比例控制
category_dist = category_stats.collect()

# 计算每类采样数（按比例分配）
category_sample_counts = {
    row['CATEGORY']: int(row['ratio'] * 1000) for row in category_dist
}

# 避免因比例误差导致总量不准（可调节）
remaining = 1000 - sum(category_sample_counts.values())
if remaining > 0:
    # 补齐最大类别
    max_cat = max(category_sample_counts, key=category_sample_counts.get)
    category_sample_counts[max_cat] += remaining

# 分组采样拼接结果
sampled_dfs = []
for cat, n in category_sample_counts.items():
    if n > 0:
        sampled_dfs.append(
            df_extracted.filter(col("CATEGORY") == cat).orderBy(rand()).limit(n)
        )

sampled_df = sampled_dfs[0]
for sdf in sampled_dfs[1:]:
    sampled_df = sampled_df.union(sdf)

# 6. 保存 1000 条原始数据为 Excel（toPandas）
sampled_pd = sampled_df.toPandas()
sampled_pd.to_excel("sampled_by_category_proportion.xlsx", index=False)

# Done
spark.stop()

# python -m recommend.data_extract.struct_display.step4_expourse_data
