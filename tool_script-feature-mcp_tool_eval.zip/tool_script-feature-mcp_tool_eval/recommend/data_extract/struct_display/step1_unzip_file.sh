#!/bin/bash

## 目前只能通过数智平台获取数据
## step1: 开发中心 - 新建 - 输入以下sql代码(按需改dt)
## step2: 资源配置、邮件配置 详情参考 https://li.feishu.cn/docx/BUKxdMI0PoaGLZxtuNgcYbetn2g
## step3: 任务成功后 数据会发送到飞书邮箱
## step4: 下载 - 传到开发机 /mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_origin
## step5: 解压step2_unzip_struct_file.sh

# select v.record_id as record_id, v.vin as vin, v.dt as dt, v.busi_time as busi_time, v.data_json as data_json, 
# v.has_recommend as has_recommend,
# v.recommend_type as recommend_type,
# h.record_id is not NULL AS has_show, 
# s.record_id is not NULL AS has_click
# from
#   (
#     select
#       dt,
#       vin,
#       busi_time,
#       get_json_object(data_json, '$.voice_value.recommend_type') as recommend_type,
#       get_json_object(data_json, '$.voice_value.has_recommend') as has_recommend,
#       data_json,
#       record_id
#     from
#       dw.dwd_vehicle_track_event_record_vehvoice_di
#     where
#       dt BETWEEN '2025-03-31' and '2025-04-06'
#       and event_key IN ('vehvoice_002_0112')
#   ) v
#   LEFT OUTER join (
#     select
#       dt,
#       vin,
#       busi_time,
#       record_id
#     from
#       dw.dwd_vehicle_track_event_record_vehvoice_di
#     where
#       dt BETWEEN '2025-03-31' and '2025-04-06'
#       and event_key IN ('vehvoice_002_0137')
#   ) h on v.record_id = h.record_id
#   LEFT OUTER join (
#     select
#       dt,
#       vin,
#       busi_time,
#       record_id
#     from
#       dw.dwd_vehicle_track_event_record_vehvoice_di
#     where
#       dt BETWEEN '2025-03-31' and '2025-04-06'
#       and event_key IN ('vehvoice_002_0138')
#   ) s on v.record_id = s.record_id
#   join (
#     select
#       dt,
#       vin
#     from
#       dm.dm_vom_basic
#     where
#       dt BETWEEN '2025-03-31' and '2025-04-06'
#       and is_user_vehicle = 1
#   ) bsc on v.dt = bsc.dt
#   and v.vin = bsc.vin


# 替换以下字段
week_str="20250407-20250413" # 上周的日期
DIR="/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_origin/struct/cloud_table/$week_str" # 要遍历的目录
PASSWORD="73u1q9" # 解压缩时需要使用的密码

total_count=1
found_zip=false
for zip_file in "$DIR"/*.zip
do
    if [ -f "$zip_file" ]; then
        found_zip=true
    
        csv_file="${week_str}_${total_count}.csv"
        echo "生成文件名: $csv_file"
        
        # 解压缩文件
        echo "正在解压: $zip_file"
        unzip -p -P "$PASSWORD" "$zip_file" > "$DIR/$csv_file"
        
        total_count=$((total_count + 1))
    fi
done

if [ "$found_zip" = false ]; then
    echo "目录中没有.zip文件"
else
    echo "所有文件解压完成！"
fi
