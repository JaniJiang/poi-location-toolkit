from datetime import datetime, timedelta
from pyspark.sql import SparkSession
from pyspark.sql.functions import col

if __name__ == '__main__':
    today = datetime.now()
    last_week_start = today - timedelta(days=today.weekday() + 7)
    last_week_end = last_week_start + timedelta(days=6)
    last_week_start_str = last_week_start.strftime("%Y%m%d")
    last_week_end_str = last_week_end.strftime("%Y%m%d")
    week_str = f"{last_week_start_str}-{last_week_end_str}"

    # 计算结构化富媒体推荐的曝光、点击率
    # recommend_type = 2 视频推荐
    # recommend_type = 3 音乐推荐
    # recommend_type = 4 新闻推荐
    # recommend_type = 5 体育推荐
    # recommend_type = 6 小红书推荐
    # 总曝光率： df['has_show'].notnull.sum() / len(df)
    # 总点击率： df['has_click].notnull.sum() / df['has_show'].notnull.sum()

    spark = SparkSession.builder \
        .appName("Calculate Rates") \
        .getOrCreate()

    struct_joined_table_folder = f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_join/struct/{week_str}/"
    count = 0
    total_exposure_rate = 0
    total_click_rate = 0
    for i in range(0, 7, 1):
        date = last_week_start + timedelta(days=i)
        date_str = date.strftime("%Y-%m-%d")
        struct_joined_table_file = struct_joined_table_folder + f'{date_str}'
        try:
            spark_df = spark.read.parquet(struct_joined_table_file)
            filtered_df = spark_df.filter(spark_df.recommend_type.isin(2, 3, 4, 5, 6))
            recommend_type_counts = filtered_df.groupBy("recommend_type").count()
            recommend_type_counts.show()
            # 曝光
            show_count = filtered_df.filter(col('has_show') == True).count()
            exposure_rate = show_count / filtered_df.count() if filtered_df.count() != 0 else 0
            total_exposure_rate += exposure_rate
            # 点击
            click_count = filtered_df.filter((col('has_click') == True) & (col('has_show') == True)).count()
            click_rate = click_count / show_count if show_count != 0 else 0
            total_click_rate += click_rate
            count += 1

            print(f"{date_str}曝光率: {exposure_rate}")
            print(f"{date_str}点击率: {click_rate}")
        except Exception as e:
            print(f"error:{e}")

    print(f"富媒体推荐-总曝光率: {round(total_exposure_rate / count, 4)}")
    print(f"富媒体推荐-总点击率: {round(total_click_rate / count, 4)}")

    # python -m recommend.data_extract.struct_display.step3_get_statics
