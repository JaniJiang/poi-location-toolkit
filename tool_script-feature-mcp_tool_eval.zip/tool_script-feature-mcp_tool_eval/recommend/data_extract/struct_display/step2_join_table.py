import os
from tqdm import tqdm
from datetime import datetime, timedelta
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, lit, to_date

# def join_three_table(dt, merge_table_bos_path, cloud_split_by_dt_path, track_split_by_dt_path):
#     print(f"join_three_table start: {dt}")
#     try:
#         # 读取融合表数据
#         merge_df = spark.read.format("hudi").load(merge_table_bos_path + f"{dt}/") \
#             .select("query", "domain", "slot_li", "request_time", "record_id") \
#             .filter(col("domain").isin(["gpt_chat", "gpt_autoqa"]))

#         cloud_path = f"{cloud_split_by_dt_path}/dt={dt}"
#         track_path = f"{track_split_by_dt_path}/dt={dt}"

#         # 检查目录是否存在
#         if os.path.exists(cloud_path) and os.path.exists(track_path):
#             cloud_df = spark.read.json(cloud_path)
#             track_df = spark.read.json(track_path).withColumn("service_type", lit("结构化+富媒体推荐"))

#             if cloud_df and track_df:
#                 # 去重字段
#                 cloud_df = cloud_df.drop("dt", "recommend_type", "vin")
#                 # 连接数据
#                 joined_df = track_df.join(cloud_df, on="record_id", how="left") \
#                                      .join(merge_df, on="record_id", how="left")

#                 print(f"总行数: {joined_df.count()}")
#                 filter_df(dt, joined_df)

#                 # 保存为 Parquet
#                 output_path = f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_join/struct/{dt}/"
#                 joined_df.write.mode("overwrite").parquet(output_path)
#                 return joined_df
#         else:
#             print(f"路径不存在: {cloud_path} 或 {track_path}")
#             return None
#     except Exception as e:
#         print(f"[ERROR] join_three_table failed for dt={dt}, error: {e}")
#         return None
#     finally:
#         print(f"join_three_table finish: {dt}")


# def filter_df(dt, df):
#     try:
#         # 筛选并抽样
#         filtered_df = df.filter(col("service_type") == "结构化+富媒体推荐")
#         sampled_df = filtered_df.sample(False, 1000.0 / filtered_df.count(), seed=42)

#         # 转为 pandas 并写入 CSV，防止乱码
#         pandas_df = sampled_df.toPandas()
#         csv_path = f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_join/struct/sample_joined_table_{dt}.csv"
#         pandas_df.to_csv(csv_path, encoding="utf-8-sig", index=False)
#         print(f"CSV写入完成: {csv_path}")
#     except Exception as e:
#         print(f"[ERROR] filter_df failed for dt={dt}, error: {e}")


def merge_split_tables_by_date(parent_path, output_path):
    print(f"merge_split_tables_by_date start")

    dt_to_dfs = {}  # key: dt, value: list of DataFrames

    # 遍历所有 split 子目录
    for sub_dir in os.listdir(parent_path):
        sub_path = os.path.join(parent_path, sub_dir)
        if not os.path.isdir(sub_path) or not sub_dir.startswith("20250407-20250413.split."):
            continue

        # 遍历子目录下的所有 dt 分区目录
        for dt_folder in os.listdir(sub_path):
            if not dt_folder.startswith("dt="):
                continue
            dt_value = dt_folder.replace("dt=", "")
            full_dt_path = os.path.join(sub_path, dt_folder)

            try:
                df = spark.read.json(full_dt_path)
                if dt_value not in dt_to_dfs:
                    dt_to_dfs[dt_value] = [df]
                else:
                    dt_to_dfs[dt_value].append(df)
            except Exception as e:
                print(f"Error reading {full_dt_path}: {e}")

    # 写入合并后的输出
    for dt_value, df_list in dt_to_dfs.items():
        print(f"Merging dt={dt_value} with {len(df_list)} parts")
        combined_df = df_list[0]
        for other_df in df_list[1:]:
            combined_df = combined_df.unionByName(other_df)

        combined_df.write.mode("overwrite").json(os.path.join(output_path, f"dt={dt_value}"))

    print("merge_split_tables_by_date finish")


def split_table(input_path, output_path, data_type):
    # cloud_folder_path = f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_origin/struct/cloud_table/{week_str}"
    # cloud_split_by_dt_path = f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_origin/struct/cloud_table/{week_str}.split"
    # cloud_folder_path, cloud_split_by_dt_path, "cloud"
    print(f"split_table start: {data_type}")
    if os.path.exists(input_path):
        for idx, file in enumerate(os.listdir(input_path)):
            if file.endswith(".csv"):
                file_path = os.path.join(input_path, file)
                input_df = spark.read.csv(file_path, header=True, inferSchema=True)
                input_df = input_df.withColumn("dt_valid", to_date(col("dt"), "yyyy-MM-dd")) \
                    .filter(col("dt_valid").isNotNull()) \
                    .drop("dt") \
                    .withColumnRenamed("dt_valid", "dt")
                if data_type == "cloud":
                    output_df = input_df.select("record_id", "raw_query", "content_text",
                                                "query_ner_list", "answer_ner_list", "title",
                                                "subtitle", "summary", "keyword", "travel_position",
                                                "recommend_type", "image_search_query",
                                                "image_search_request", "image_search_response",
                                                "ks_result", "media_result", "request", "response",
                                                "dt")
                elif data_type == "track":
                    output_df = input_df.select("record_id", "has_recommend", "has_show", "has_click", "dt")
                # output_df = input_df.select("record_id", "recommend_type", "content_style", "dt")
                # TODO: 校验dt是否合法日期
                # input_df = input_df.withColumn("dt_valid", to_date(col("dt"), "yyyy-MM-dd"))
                # output_df = input_df.filter(col("dt_valid").isNotNull()) \
                #                     .select("record_id", "recommend_type", "content_style", "dt_valid") \
                #                     .withColumnRenamed("dt_valid", "dt")
                # 每个子文件单独拆分和保存，解决合并多个df的OOM问题
                current_output_path = f"{output_path}.{idx}"
                print(f"data_type: {data_type}")
                output_df.write.partitionBy("dt").mode("overwrite").format("json").save(current_output_path)
        # 合并文件
        merge_split_tables_by_date(
            # r"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_origin/struct/cloud_table/",
            os.path.dirname(input_path.rstrip('/')),
            input_path + ".split")
    else:
        print(f'not exist {input_path}')
    print(f"split_table finish: {data_type}")


# def join_three_table(dt, merge_table_bos_path, cloud_split_by_dt_path, track_split_by_dt_path):
#     print("join_three_table start")
#     # 读取融合表数据
#     merge_df = spark.read.format("hudi").load(merge_table_bos_path + f"{dt}/") \
#         .select("query", "domain", "slot_li", "request_time", "record_id") \
#         .filter(col("domain").isin(["gpt_chat", "gpt_autoqa"]))
#     # 检查目录是否存在
#     if os.path.exists(f"{cloud_split_by_dt_path}/dt={dt}") and os.path.exists(f"{track_split_by_dt_path}/dt={dt}"):
#         cloud_df = spark.read.format("json").load(f"{cloud_split_by_dt_path}/dt={dt}")
#         track_df = spark.read.format("json").load(f"{track_split_by_dt_path}/dt={dt}")
#         track_df = track_df.withColumn("service_type", lit("结构化+富媒体推荐"))
#         if cloud_df and track_df:
#             # 去重
#             cloud_df = cloud_df.drop('dt', 'recommend_type', 'vin')
#             # 拼接
#             first_join_df = track_df.join(cloud_df, on='record_id', how='left')
#             joined_df = first_join_df.join(merge_df, on='record_id', how='left')
#             print(f"总行数: {joined_df.count()}")
#             filter_df(dt, joined_df)
#             # 保存
#             output_path = f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_join/struct/{dt}/"
#             joined_df.write.parquet(output_path)
#             return joined_df
#     else:
#         print(f'{dt} file not exist')
#         return None
#     print("join_three_table finish")


# def filter_df(dt, df):
#     # 筛选并随机抽取1000条符合条件的数据
#     filtered_df = df.filter(col("service_type") == "结构化+富媒体推荐")
#     sampled_df = filtered_df.sample(False, 1000.0 / filtered_df.count(), seed=42)  # 通过设定随机种子保证重现性
#     # 将Spark DataFrame转换为Pandas DataFrame
#     pandas_df = sampled_df.toPandas()
#     # 保存为Excel文件
#     excel_output_path = f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_join/struct/sample_joined_table_{dt}.csv"
#     pandas_df.to_csv(excel_output_path)
def join_three_table(dt, merge_table_bos_path, cloud_split_by_dt_path, track_split_by_dt_path):
    print(f"join_three_table start: {dt}")
    try:
        # 读取融合表数据
        merge_df = spark.read.format("hudi").load(merge_table_bos_path + f"{dt}/") \
            .select("query", "domain", "slot_li", "request_time", "record_id") \
            .filter(col("domain").isin(["gpt_chat", "gpt_autoqa"]))

        cloud_path = f"{cloud_split_by_dt_path}/dt={dt}"
        track_path = f"{track_split_by_dt_path}/dt={dt}"

        # 检查目录是否存在
        if os.path.exists(cloud_path) and os.path.exists(track_path):
            cloud_df = spark.read.json(cloud_path)
            track_df = spark.read.json(track_path).withColumn("service_type", lit("结构化+富媒体推荐"))

            if cloud_df and track_df:
                # 去重字段
                cloud_df = cloud_df.drop("dt", "vin")
                # 连接数据
                joined_df = track_df.join(cloud_df, on="record_id", how="left") \
                    .join(merge_df, on="record_id", how="left")

                print(f"总行数: {joined_df.count()}")
                filter_df(dt, joined_df)

                # 保存为 Parquet
                output_path = f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_join/struct/{dt}/"
                joined_df.write.mode("overwrite").parquet(output_path)
                return joined_df
        else:
            print(f"路径不存在: {cloud_path} 或 {track_path}")
            return None
    except Exception as e:
        print(f"[ERROR] join_three_table failed for dt={dt}, error: {e}")
        return None
    finally:
        print(f"join_three_table finish: {dt}")


def filter_df(dt, df):
    try:
        # 筛选并抽样
        filtered_df = df.filter(col("service_type") == "结构化+富媒体推荐")
        sampled_df = filtered_df.sample(False, 1000.0 / filtered_df.count(), seed=42)

        # 转为 pandas 并写入 CSV，防止乱码
        pandas_df = sampled_df.toPandas()
        csv_path = f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_join/struct/sample_joined_table_{dt}.csv"
        pandas_df.to_csv(csv_path, encoding="utf-8-sig", index=False)
        print(f"CSV写入完成: {csv_path}")
    except Exception as e:
        print(f"[ERROR] filter_df failed for dt={dt}, error: {e}")


if __name__ == '__main__':
    # 初始化 SparkSession
    # spark = SparkSession.builder \
    #     .appName("CSV Aggregation") \
    #     .getOrCreate()
    spark = SparkSession \
        .builder \
        .appName("step4_get_struct_recommend_join_table") \
        .config("spark.jars.packages", "org.apache.hudi:hudi-spark3.3-bundle_2.12:0.14.1") \
        .config("spark.driver.memory", "300g") \
        .config("spark.driver.maxResultSize", "300g") \
        .config("spark.driver.memoryOverhead", "30g") \
        .config("spark.executor.instances", "30") \
        .config("spark.executor.memory", "16g") \
        .config("spark.executor.memoryOverhead", "8g") \
        .config("spark.sql.shuffle.partitions", "100") \
        .config("spark.default.parallelism", "100") \
        .config("spark.sql.execution.arrow.pyspark.enabled", "true") \
        .getOrCreate()

    # # 获取上周日期
    # today = datetime.now()
    # last_week_start = today - timedelta(days=today.weekday() + 7)
    # last_week_end = last_week_start + timedelta(days=6)
    # last_week_start_str = last_week_start.strftime("%Y%m%d")
    # last_week_end_str = last_week_end.strftime("%Y%m%d")
    # week_str = f"{last_week_start_str}-{last_week_end_str}"
    # tset
    week_str = "20250407-20250413"
    last_week_start = datetime.strptime("2025-04-07", "%Y-%m-%d")
    print(last_week_start)
    # 按天划分数据
    cloud_folder_path = f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_origin/struct/cloud_table/{week_str}"
    track_folder_path = f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_origin/struct/track_table/{week_str}"
    cloud_split_by_dt_path = f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_origin/struct/cloud_table/{week_str}.split"
    track_split_by_dt_path = f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_origin/struct/track_table/{week_str}.split"
    split_table(cloud_folder_path, cloud_split_by_dt_path, "cloud")
    split_table(track_folder_path, track_split_by_dt_path, "track")
    # 拼接数据
    merge_table_bos_path = f"bos://spaceai-internal/ark/prod_env/ark_data/dwd_vechile_merge_prod_di/"
    for i in tqdm(range(0, 7, 1)):
        date = last_week_start + timedelta(days=i)
        date_str = date.strftime("%Y-%m-%d")
        print(date_str)
        join_three_table(date_str, merge_table_bos_path, cloud_split_by_dt_path, track_split_by_dt_path)
    spark.stop()

# cd recommend/data_extract/struct_display && /opt/spark/bin/spark-submit step2_join_table.py
# python -m recommend.data_extract.struct_display.step2_join_table
# recommend/data_extract/struct_display/step2_join_table.py
