from pyspark.sql import SparkSession
from pyspark.sql.functions import col, sum as spark_sum, countDistinct, lit
from functools import reduce

# 初始化 SparkSession
spark = SparkSession.builder.appName("DailyUserBehaviorStats").getOrCreate()

# 父目录路径和日期列表
base_path = "/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_join/struct"
date_folders = ["2025-04-07", "2025-04-08", "2025-04-09", "2025-04-10", "2025-04-11", "2025-04-12", "2025-04-13"]

# 存储所有日期的结果
exposure_result_list = []
ctr_result_list = []

# 单日期处理函数


def process_one_day(day):
    path = f"{base_path}/{day}"
    df = spark.read.parquet(path).withColumn("date", lit(day))

    # 仅保留 recommend_type 为 2/3/9
    df = df.filter(col("recommend_type").isin("2", "3", "9"))

    # 曝光统计：用户 × 日期 × 类型
    exposure_df = df.filter(col("has_show") == 1) \
        .groupBy("vin", "date", "recommend_type") \
        .agg(spark_sum("has_show").alias("exposure_count"))

    # 点击率：每天总用户数
    total_user_df = df.select("vin", "date").dropDuplicates() \
        .groupBy("date").agg(countDistinct("vin").alias("total_users"))

    # 每天点击用户数（按类型）
    click_user_df = df.filter(col("has_click") == 1) \
        .select("vin", "date", "recommend_type").dropDuplicates() \
        .groupBy("date", "recommend_type") \
        .agg(countDistinct("vin").alias("click_users"))

    # 计算点击率
    ctr_df = click_user_df.join(total_user_df, on="date", how="left") \
        .withColumn("click_rate", col("click_users") / col("total_users"))

    return exposure_df, ctr_df


# 主循环，按天处理并汇总
for day in date_folders:
    exposure_df, ctr_df = process_one_day(day)
    exposure_result_list.append(exposure_df)
    ctr_result_list.append(ctr_df)

# 合并所有天数的结果
exposure_all = reduce(lambda a, b: a.unionByName(b), exposure_result_list)
ctr_all = reduce(lambda a, b: a.unionByName(b), ctr_result_list)

# 查看结果
exposure_all.show()
ctr_all.show()

# python -m recommend.data_extract.struct_display.exposure_hit_rate
