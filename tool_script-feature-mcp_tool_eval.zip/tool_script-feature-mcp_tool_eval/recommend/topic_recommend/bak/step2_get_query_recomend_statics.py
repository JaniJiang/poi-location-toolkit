import pandas as pd
from datetime import datetime, timedelta
from tqdm import tqdm
import json
import csv
from typing import List
import ast
from sentence_transformers import SentenceTransformer
from transformers import AutoTokenizer
import os
import torch
import random
import numpy as np
from transformers import AutoModel, AutoTokenizer
from serverless_function import request_llm

def replace_nan(value, replacement):
    return replacement if pd.isna(value) else value

def get_df_groupby_session_static(df, date_str):
    df_groupby_session = df.sort_values(by=['new_session_id', 'request_time'])
    df_groupby_session = df_groupby_session.groupby('new_session_id').apply(
        lambda group: pd.Series({
            'round_num': len(group),
            'query_list': list(group['query'])
        })
    ).reset_index()
    df_groupby_session = df_groupby_session[['new_session_id', 'round_num', 'query_list']]
    print(f"{date_str}单个对话次数:{df_groupby_session['round_num'].sum()}")
    print(f"{date_str}对话数:{len(df_groupby_session)}")
    print(f"{date_str}平均对话轮次——vin: {df_groupby_session['round_num'].sum() / len(df_groupby_session)}") 


def get_similarity(user_under_query: str, current_query_list: List[str]) -> bool:
    model = SentenceTransformer("/mnt/pfs-guan-ssai/nlu/zhaojiufeng/model/beg-m3", device="cuda:1")
    embeddings_1 = model.encode([user_under_query], batch_size=12, max_length=8192)
    embeddings_2 = model.encode(current_query_list, batch_size=12, max_length=8192)
    similarity = embeddings_1 @ embeddings_2.T
    similarity = similarity.flatten() 
    # return similarity.tolist()
    for sim in similarity.tolist():
        if sim > 0.9:
            return 1
    else:
        return 0

def add_simility(df):
    sorted_df = df.sort_values(['vin', 'request_time']).reset_index(drop=True)
    sorted_df["next_query"] = ""
    sorted_df["similarity"] = 0
    for i in tqdm(range(len(sorted_df)), desc="data_processing"):
        current_vin = sorted_df.iloc[i]["vin"]
        
        if i + 1 < len(sorted_df) and sorted_df.iloc[i + 1]["vin"] == current_vin:
            sorted_df.at[i, "next_query"] = sorted_df.iloc[i + 1]["query"]
        else:
            sorted_df.at[i, "next_query"] = "FINAL"

        if pd.isnull(sorted_df.at[i, "show_text_list"]) or sorted_df.at[i, "next_query"] == "FINAL":
            sorted_df.at[i, "similarity"] = 0

        else:
            sorted_df.at[i, "similarity"] = get_similarity(
                sorted_df.iloc[i]["next_query"], ast.literal_eval(sorted_df.iloc[i]["show_text_list"]))
    # print(sorted_df.loc[:10, ['query', 'next_query', 'similarity']])
    return sorted_df

def load_active_users():
    file_path = "/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/tmp/active_user_table.csv"
    df = pd.read_csv(file_path)
    data_dict = df.set_index('vin')['occurrence_count'].to_dict()
    active_users = [vin for vin, count in data_dict.items() if count >= 20]
    # negative_user = [vin for vin, count in data_dict.items() if count < 20]
    return active_users

def get_base_static(df):
    taskmaster_df = df[df['domain'] == 'taskmaster']
    taskmaster_click_ratio = taskmaster_df['show_text_click'].notnull().sum() / taskmaster_df['show_text_list'].notnull().sum()

    in_car_assistant_df = df[df['domain'] == 'in_car_assistant']
    in_car_assistant_click_ratio = in_car_assistant_df['show_text_click'].notnull().sum() / in_car_assistant_df['show_text_list'].notnull().sum()

    gpt_autoqa_df = df[df['domain'] == 'gpt_autoqa']
    gpt_autoqa_click_ratio = gpt_autoqa_df['show_text_click'].notnull().sum() / gpt_autoqa_df['show_text_list'].notnull().sum()

    gpt_chat_df = df[df['domain'] == 'gpt_chat']
    gpt_chat_cick_ratio = gpt_chat_df['show_text_click'].notnull().sum() / gpt_chat_df['show_text_list'].notnull().sum()

    print(f"taskmaster点击率:{taskmaster_click_ratio}\nin_car_assistant点击率:{in_car_assistant_click_ratio}\ngpt_autoqa点击率{gpt_autoqa_click_ratio}\ngpt_chat点击率{gpt_chat_cick_ratio}")
    print('\n\n')
    null_apiname_df = df[df['APINAME'].isnull() | (df['APINAME'] == '')]
    null_apiname_click_retio = null_apiname_df['show_text_click'].notnull().sum() / null_apiname_df['show_text_list'].notnull().sum()

    QASearch_df = df[df['APINAME'] == 'QASearch']
    QASearch_click_ratio = QASearch_df['show_text_click'].notnull().sum() / QASearch_df['show_text_list'].notnull().sum()

    AUTOSearch_df = df[df['APINAME'] == 'AUTOSearch']
    AUTOSearch_click_ratio = AUTOSearch_df['show_text_click'].notnull().sum() / AUTOSearch_df['show_text_list'].notnull().sum()

    MEDIASearch_df = df[df['APINAME'] == 'MEDIASearch']
    MEDIASearch_click_ratio = MEDIASearch_df['show_text_click'].notnull().sum() / MEDIASearch_df['show_text_list'].notnull().sum()

    CHARASearch_df =  df[df['APINAME'] == 'CHARASearch']
    CHARASearch_click_ratio = CHARASearch_df['show_text_click'].notnull().sum() / CHARASearch_df['show_text_list'].notnull().sum()

    MathQA_df = df[df['APINAME'] == 'MathQA']
    MathQA_click_ratio = MathQA_df['show_text_click'].notnull().sum() / MathQA_df['show_text_list'].notnull().sum()

    print(f"APINAME为空点击率:{null_apiname_click_retio}\nQASearch点击率:{QASearch_click_ratio}\nAUTOSearch点击率:{AUTOSearch_click_ratio}\nMEDIASearch点击率:{MEDIASearch_click_ratio}\nCHARASearch点击率:{CHARASearch_click_ratio}\nMathQA点击率:{MathQA_click_ratio}")

    return taskmaster_click_ratio, in_car_assistant_click_ratio, gpt_autoqa_click_ratio, gpt_chat_cick_ratio


def add_more_statics(dialogue_infos):
    taskmaster_count = 0
    in_car_assistant_count = 0
    AUTOSearch_count = 0
    LLM_no_RAG_count = 0
    MEDIASearch_count = 0
    QASearch_count = 0
    other_count = 0
    for info in dialogue_infos:
        try:
            if info['domain'] == 'taskmaster':
                taskmaster_count += 1
            elif info['domain'] == 'in_car_assistant':
                in_car_assistant_count += 1
            elif info['domain'] == 'gpt_autoqa':
                AUTOSearch_count += 1
            elif info['domain'] == 'gpt_chat':
                if len(info['APINAME']) == 0:
                    LLM_no_RAG_count += 1
                elif info['APINAME'] == 'MEDIASearch':
                    MEDIASearch_count += 1
                elif info['APINAME'] == 'QASearch':
                    QASearch_count += 1
                else:
                    other_count += 1
        except:
            print(info)
    return taskmaster_count, in_car_assistant_count, LLM_no_RAG_count, AUTOSearch_count, MEDIASearch_count, QASearch_count, other_count

def groupby_session(df):
    sorted_df = df.sort_values(by=['new_session_id', 'request_time']).reset_index(drop=True)
    for i in tqdm(range(len(sorted_df)), desc="data_processing"):
        new_session_id = sorted_df.iloc[i]["new_session_id"]
        
        if i + 1 < len(sorted_df) and sorted_df.iloc[i + 1]["new_session_id"] == new_session_id:
            sorted_df.at[i, "next_query"] = sorted_df.iloc[i + 1]["query"]
        else:
            sorted_df.at[i, "next_query"] = "FINAL"
    
    sorted_df['session_info'] = sorted_df.apply(lambda row: {
        "face_screen": replace_nan(row['face_screen'].replace('"', ''), ""),
        "domain": replace_nan(row['domain'], ""),
        "new_session_id": row['new_session_id'],
        "CATEGORY": replace_nan(str(row['CATEGORY']).replace('"', ''), "").replace("nan", ""),
        "APINAME": replace_nan(str(row['APINAME']).replace('"', ''), "").replace("nan", ""),
        "query": row['query'],
        "output": replace_nan(row['output'], ""),
        "next_query": row['next_query'],
        "has_exposure": 1 if replace_nan(row['show_text_list'], 0) else 0,
        "show_text_list": [] if pd.isna(row['show_text_list']) else ast.literal_eval(row['show_text_list']),
        "has_click": 1 if replace_nan(row['has_click'], 0) else 0,
        "show_text_click": replace_nan(row['show_text_click'], ""),
        "request_time": row['request_time']
    }, axis=1)

    groupby_session_df = sorted_df.groupby('new_session_id').apply(
        lambda group: pd.Series({
            'vin': group['vin'].iloc[0],
            'round_num': len(group),
            'is_exposure': int(group['has_exposure'].max()),
            'is_click': int(group['has_click'].max()),
            'is_hit': int(group['has_click'].max()),
            'session_list': list(group['session_info'])
        })
    ).reset_index()
    groupby_session_df['session_list'] = groupby_session_df['session_list'].apply(lambda x: json.dumps(x, ensure_ascii=False, indent=4))
    filter_df = groupby_session_df[(groupby_session_df['is_exposure'] == 1) & (groupby_session_df['is_click'] == 0)]
    sample_df = filter_df.sample(n=1000, random_state=42) 
    for index, row in tqdm(sample_df.iterrows(), desc='data analysing'):
        # print(row['session_list'])
        prompt = f"""
        你是一名话题推荐业务的问题分析师，需要分析为什么用户没有点击推荐的话题。请结合用户的实际对话内容，包括“query（用户提问）”、“output（系统回答）”、“next_query（用户后续提问）”、“show_text_list（推荐的话题列表）”等信息，分析本次推荐的话题存在哪些不足，可能导致用户没有点击。

        **用户多轮会话信息如下：**
        {row['session_list']}

        **任务说明：**
        请根据上述信息，从用户需求和推荐话题内容的匹配度等角度，分析可能导致用户未点击推荐话题的原因。请列举2条，输出格式如下：
        1. 原因xxx
        2. 原因xxx
        """
        try:
            payload, response_data = request_llm(prompt, model='gpt-4o', n=1, temperature=0)
            # print(json.dumps({"payload": payload, "response": response_data}, ensure_ascii=False))
            output = response_data["choices"][0]["message"]["content"]
        except Exception as e:
            output = "Exception"
            print(e)
        sample_df.at[i, 'session_list'] = output
    sample_df.to_csv(f'/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_group/query_recommend/analy/{date_str}_groupby_session.csv')


if __name__ == '__main__':
    today = datetime.now()
    last_week_start = today - timedelta(days=today.weekday() + 7)
    last_week_end = last_week_start + timedelta(days=6)
    last_week_start_str = last_week_start.strftime("%Y%m%d")
    last_week_end_str = last_week_end.strftime("%Y%m%d")
    week_str = f"{last_week_start_str}-{last_week_end_str}"
    folder_path = f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_join/query_recommend/{week_str}/"
    activate_users = load_active_users()
    test1_table = {}
    for i in tqdm(range(0, 7, 1)):
        date = last_week_start + timedelta(days=i)
        date_str = date.strftime("%Y-%m-%d")
        join_table_file = folder_path + f"{date_str}.csv"
        # if date_str == '2025-04-10':
        df = pd.read_csv(join_table_file)
        groupby_session(df)
        # df['unique_text'] = df.apply(lambda row: row['vin'] + row['query'] + str(row['show_text_list']) + row['show_text_click'] + row['request_time'])
        df['unique_text'] = df.apply(
            lambda row: str(row['vin']) + '|' + str(row['query']) + '|' + 
                        json.dumps(row['show_text_list'], ensure_ascii=False) + '|' + 
                        str(row['show_text_click']) + '|' + str(row['request_time']),
            axis=1
        )
        df.drop_duplicates(subset='unique_text', keep='first', inplace=True)
        df['APINAME'] = df['APINAME'].apply(lambda col: replace_nan(str(col).replace('"', ''), "").replace("nan", ""))
        get_base_static(df)


        df['dialogue_info'] = df.apply(lambda row: {
            "face_screen": replace_nan(row['face_screen'].replace('"', ''), ""),
            "domain": replace_nan(row['domain'], ""),
            "new_session_id": row['new_session_id'],
            "CATEGORY": replace_nan(str(row['CATEGORY']).replace('"', ''), "").replace("nan", ""),
            "APINAME": replace_nan(str(row['APINAME']).replace('"', ''), "").replace("nan", ""),
            "query": row['query'],
            "output": replace_nan(row['output'], ""),
            "has_exposure": 1 if replace_nan(row['show_text_list'], 0) else 0,
            "show_text_list": [] if pd.isna(row['show_text_list']) else ast.literal_eval(row['show_text_list']),
            # "exposure_info": replace_nan(row['exposure_info'], {}),
            "has_click": 1 if replace_nan(row['has_click'], 0) else 0,
            "show_text_click": replace_nan(row['show_text_click'], ""),
            # "click_info": replace_nan(row['click_info'], {}),
            "request_time": row['request_time']
        }, axis=1)

        sorted_df = df.sort_values(by=['vin', 'request_time']).reset_index(drop=True)
        groupby_vin_df = sorted_df.groupby('vin').apply(
            lambda group: pd.Series({
                'round_num': len(group),
                'is_exposure': int(group['has_exposure'].max()),
                'is_click': int(group['has_click'].max()),
                'is_hit': int(group['has_click'].max()),
                'dialogue_list': list(group['dialogue_info']),
                '任务大师': add_more_statics(list(group['dialogue_info']))[0],
                '服务专家': add_more_statics(list(group['dialogue_info']))[1],
                '大模型非RAG': add_more_statics(list(group['dialogue_info']))[2], 
                '大模型-RAG-AUTOSearch': add_more_statics(list(group['dialogue_info']))[3],
                '大模型-RAG-MEDIASearch': add_more_statics(list(group['dialogue_info']))[4],
                '大模型-RAG-QASearch': add_more_statics(list(group['dialogue_info']))[5],
                '大模型-RAG-其他': add_more_statics(list(group['dialogue_info']))[6]
            })
        ).reset_index()
        groupby_vin_df['is_activate_user'] = groupby_vin_df['vin'].isin(activate_users).astype(int)
        groupby_vin_df = groupby_vin_df[['vin', 'is_activate_user', 'round_num', 'is_exposure', 'is_click', 'is_hit', 'dialogue_list', '任务大师', '服务专家', '大模型非RAG', '大模型-RAG-AUTOSearch', '大模型-RAG-MEDIASearch', '大模型-RAG-QASearch', '大模型-RAG-其他']]
        groupby_vin_df['dialogue_list'] = groupby_vin_df['dialogue_list'].apply(lambda x: json.dumps(x, ensure_ascii=False, indent=4))
        df_no_exposure = groupby_vin_df[groupby_vin_df['is_exposure'] == 0]
        df_exposure = groupby_vin_df[groupby_vin_df['is_exposure'] == 1]

        sample_no_exposure_df = df_no_exposure.sample(n=1000, random_state=42) 
        sample_exposure_df = df_exposure.sample(n=1000, random_state=42) 
        # print(f"{date_str}test1-group1-平均对话轮次-vin维度: {sample_no_exposure_df['round_num'].sum() / len(sample_no_exposure_df)}")
        # print(f"{date_str}test1-group2-平均对话轮次-vin维度: {sample_exposure_df['round_num'].sum() / len(sample_exposure_df)}")
        # # print(f"{date_str}test1-group1-活跃用户占比: {len(sample_no_exposure_df[sample_no_exposure_df['round_num'] >= 3]) / len(sample_no_exposure_df)}")
        # # print(f"{date_str}test1-group2-活跃用户占比: {len(sample_exposure_df[sample_exposure_df['round_num'] >= 3]) / len(sample_exposure_df)}")

        # print(f"{date_str}test1-group1-活跃用户占比: {len(sample_no_exposure_df[sample_no_exposure_df['is_activate_user'] == 1]) / len(sample_no_exposure_df)}")
        # print(f"{date_str}test1-group2-活跃用户占比: {len(sample_exposure_df[sample_exposure_df['is_activate_user'] == 1]) / len(sample_exposure_df)}")
        combined_df1 = pd.concat([sample_no_exposure_df, sample_exposure_df], ignore_index=True)
        combined_df1.to_csv(f'/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_group/query_recommend/{week_str}/{date_str}_test1.csv')

        
        df_hit = groupby_vin_df[groupby_vin_df['is_hit'] == 1]
        sampled_hit_df = df_hit.sample(n=1000, random_state=42) 
        df_no_hit = df_exposure[df_exposure['is_hit'] == 0]
        sampled_no_hit_df = df_no_hit.sample(n=1000, random_state=42) 
        # print(f"{date_str}test2-group1-平均对话轮次-vin维度: {sampled_no_hit_df['round_num'].sum() / len(sampled_no_hit_df)}")
        # print(f"{date_str}test2-group2-平均对话轮次-vin维度: {sampled_hit_df['round_num'].sum() / len(sampled_hit_df)}")
        # # print(f"{date_str}test2-group1-活跃用户占比: {len(sampled_no_hit_df[sampled_no_hit_df['round_num'] >= 3]) / len(sampled_no_hit_df)}")
        # # print(f"{date_str}test2-group2-活跃用户占比: {len(sampled_hit_df[sampled_hit_df['round_num'] >= 3]) / len(sampled_hit_df)}")

        # print(f"{date_str}test2-group1-活跃用户占比: {len(sampled_no_hit_df[sampled_no_hit_df['is_activate_user'] == 1]) / len(sampled_no_hit_df)}")
        # print(f"{date_str}test2-group2-活跃用户占比: {len(sampled_hit_df[sampled_hit_df['is_activate_user'] == 1]) / len(sampled_hit_df)}")
        combined_df2 = pd.concat([sampled_hit_df, sampled_no_hit_df], ignore_index=True)
        combined_df2.to_csv(f'/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_group/query_recommend/{week_str}/{date_str}_test2.csv')
        