import os
from tqdm import tqdm
from collections import defaultdict
from datetime import datetime
from joblib import Parallel, delayed
from utils.time_utils import get_last_week
from utils.domain_utils import get_real_domain
from recommend.data_extract.topic_recommend.utils import *


def process_row(row):
    """优化后的单行处理，直接生成领域统计"""
    domain_stats = defaultdict(lambda: {"all": 0, "show": 0, "click": 0})
    for msg_dict in row.message_list:
        domain = get_real_domain(msg_dict)
        is_show = int(len(msg_dict["show_text_list"]) > 0)
        is_click = int(msg_dict["click_text"] != "")
        domain_stats[domain]["all"] += 1
        domain_stats[domain]["show"] += is_show
        domain_stats[domain]["click"] += is_click
    return {k: dict(v) for k, v in domain_stats.items()}


def merge_results(result_list):
    """直接合并领域统计并计算指标"""
    merged = defaultdict(lambda: {"all": 0, "show": 0, "click": 0})
    # 单阶段合并
    for result in result_list:
        for domain, stats in result.items():
            merged[domain]["all"] += stats["all"]
            merged[domain]["show"] += stats["show"]
            merged[domain]["click"] += stats["click"]
    # 计算领域指标
    domain_stats = {}
    for domain in merged:
        all_count = merged[domain]["all"]
        show_count = merged[domain]["show"]
        click_count = merged[domain]["click"]
        show_rate = show_count / all_count if all_count else 0
        click_rate = click_count / show_count if show_count else 0
        domain_stats[domain] = {
            "all": all_count,
            "show": show_count,
            "click": click_count,
            "show_rate": round(show_rate, 4),
            "click_rate": round(click_rate, 4),
        }
    # 计算总体指标
    total_all = sum(s["all"] for s in merged.values())
    total_show = sum(s["show"] for s in merged.values())
    total_click = sum(s["click"] for s in merged.values())
    domain_stats["totals"] = {
        "all": total_all,
        "show": total_show,
        "click": total_click,
        "show_rate": round(total_show / total_all, 4) if total_all else 0,
        "click_rate": round(total_click / total_show, 4) if total_show else 0,
    }
    return domain_stats


def process_vin_session_daily(input_dir, output_dir, week_start, i, n_jobs=20):
    def save_as_table(data, output_path, sep=","):
        df = pd.DataFrame.from_dict(data, orient="index")
        df.index.name = "domain"
        df.reset_index(inplace=True)
        df.to_csv(output_path, sep=sep, index=False, float_format="%.4f")

    date = week_start + timedelta(days=i)
    date_str = date.strftime("%Y-%m-%d")
    df = pd.read_json(f"{input_dir}/{date_str}.jsonl", orient="records", lines=True)
    results = Parallel(n_jobs=n_jobs, prefer="processes")(
        delayed(process_row)(row)
        for _, row in tqdm(df.iterrows(), total=len(df), desc=f"process_row[{date_str}]")
    )
    domain_stats = merge_results(results)
    save_as_table(domain_stats, f"{output_dir}/{date_str}.tsv", sep="\t")


if __name__ == "__main__":
    # 获取上周日期
    # last_week_start, week_str = get_last_week()
    last_week_start, week_str = datetime.strptime("2025-04-07", "%Y-%m-%d"), "20250407-20250413"

    input_dir = f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_group/topic_recommend/{week_str}.vin_session"
    output_dir = f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_group/topic_recommend/{week_str}.vin_session.domain_analyse"
    os.makedirs(output_dir, exist_ok=True)
    Parallel(n_jobs=1, prefer="processes")(
        delayed(process_vin_session_daily)(input_dir, output_dir, last_week_start, i)
        for i in tqdm(range(0, 1, 1), total=1, desc="process_daily")
    )

# python -m recommend.topic_recommend.data_distribution.domain_analyse
