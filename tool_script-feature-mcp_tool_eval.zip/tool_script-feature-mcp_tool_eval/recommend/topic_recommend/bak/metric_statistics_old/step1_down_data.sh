#!/bin/bash

## 从 融合表 和 用户行为表 拿一周的数据
start_date="2025-04-21"
end_date=$(date -d "$start_date + 6 days" '+%Y%m%d')
folder_name="${start_date//-/}-$end_date"
mkdir "/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/bak/$folder_name"

for i in {0..6}; do
  dt=$(date -d "$start_date + $i day" '+%Y-%m-%d')
  echo "Processing ${dt}"
    ## 合并全量、曝光、点击数据
    /mnt/pfs-guan-ssai/nlu/zhaojiufeng/adt --token d67cc581ad631e063f1e88cf42400a28 ark2csv --csv-file "/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/bak/$folder_name/$dt.csv" --sql-string "
    SELECT 
        distinct t1.query,
        t1.domain,
        t1.vin,
        t1.record_id,
        t1.new_session_id,
        -- t1.query_type,
        -- t1.recommend_json,
        t1.continuous_dialogue,
        t1.multiple_dialogue,
        t1.request_time,
        t1.show_text_list,
        t1.show_text_click,
        t1.output,
        t2.data_json AS exposure_data,
        t3.data_json AS click_data,
        t1.request_time
    FROM dwd_vechile_merge_prod_di t1
    LEFT JOIN (
        SELECT 
            record_id,
            data_json
        FROM dwd_vehicle_track_vehvoice_record_di 
        WHERE dt = '$dt' 
            AND event_key = 'vehvoice_002_0107' 
            AND track_id IS NOT NULL
    ) t2 ON t1.record_id = t2.record_id
    LEFT JOIN (
        SELECT 
            record_id,
            data_json
        FROM dwd_vehicle_track_vehvoice_record_di 
        WHERE dt = '$dt' 
            AND event_key = 'vehvoice_002_0108' 
            AND track_id IS NOT NULL
    ) t3 ON t1.record_id = t3.record_id
    WHERE t1.dt = '$dt' 
        AND t1.domain IN ('gpt_chat', 'gpt_autoqa', 'in_car_assistant', 'taskmaster')"
done


# # --- step1: 获取线上数据 ---

# ## 全量数据
# /mnt/pfs-guan-ssai/nlu/zhaojiufeng/adt --token d67cc581ad631e063f1e88cf42400a28 ark2csv --csv-file "/mnt/pfs-guan-ssai/nlu/zhaojiufeng/query_recommend/result/online_table/20250224.csv" --sql-string "
# SELECT 
#     query, 
#     domain, 
#     record_id,
#     session_id
# FROM dwd_vechile_merge_prod_di 
# WHERE dt = '2025-02-24'
#      and domain IN ('gpt_chat', 'gpt_autoqa', 'in_car_assistant', 'taskmaster') "

# ## 曝光表
# /mnt/pfs-guan-ssai/nlu/zhaojiufeng/adt --token d67cc581ad631e063f1e88cf42400a28 ark2csv --csv-file "/mnt/pfs-guan-ssai/nlu/zhaojiufeng/query_recommend/result/exposure_table/sqllab_曝光事件埋点_20250224.csv" --sql-string "
# SELECT 
#     dt, 
#     record_id, 
#     data_json 
# FROM dwd_vehicle_track_vehvoice_record_di 
# WHERE dt = '2025-02-24' 
#     and event_key = 'vehvoice_002_0107' and track_id is not null"

# ## 点击表
# /mnt/pfs-guan-ssai/nlu/zhaojiufeng/adt --token d67cc581ad631e063f1e88cf42400a28 ark2csv --csv-file "/mnt/pfs-guan-ssai/nlu/zhaojiufeng/query_recommend/result/click_table/sqllab_点击事件埋点_20250224.csv" --sql-string "
# SELECT 
#     dt, 
#     record_id, 
#     data_json 
# FROM dwd_vehicle_track_vehvoice_record_di 
# WHERE dt = '2025-02-24' 
#     and event_key = 'vehvoice_002_0108' and track_id is not null"
