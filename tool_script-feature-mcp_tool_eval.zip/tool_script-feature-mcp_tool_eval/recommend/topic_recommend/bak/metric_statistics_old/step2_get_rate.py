# 计算话题推荐曝光、点击率

import pandas as pd
from datetime import datetime, timedelta
from tqdm import tqdm


def computer_exposure_and_click_rate(df):
    exposure_num = df['show_text_list'].notna().sum()
    click_num = df['show_text_click'].notna().sum()
    # print(exposure_num)
    # print(click_num)
    return exposure_num / len(df), click_num / exposure_num


count = 0
total_exposure_rate = 0
total_click_rate = 0

# start_data 为起始时间（周一）
start_date = datetime.strptime("2025-04-21", '%Y-%m-%d')
end_date = start_date + timedelta(days=6)
start_date_str = start_date.strftime('%Y%m%d')
end_date_str = end_date.strftime('%Y%m%d')
folder_name = f"{start_date_str}-{end_date_str}"

for i in tqdm(range(0, 7, 1)):
    date_time = start_date + timedelta(days=i)
    date_time_str = date_time.strftime('%Y-%m-%d')
    try:
        df = pd.read_csv(f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/bak/{folder_name}/{date_time_str}.csv")
        # print(date_time_str)
        exposure_rate, click_rate = computer_exposure_and_click_rate(df)
        total_exposure_rate += exposure_rate
        total_click_rate += click_rate
        count += 1
    except Exception as e:
        print(f"error:{e}")
print(count)

avg_exposure_rate = round(total_exposure_rate / count, 4)
avg_click_rate = round(total_click_rate / count, 4)
print("曝光率:", avg_exposure_rate)
print("点击率:", avg_click_rate)
