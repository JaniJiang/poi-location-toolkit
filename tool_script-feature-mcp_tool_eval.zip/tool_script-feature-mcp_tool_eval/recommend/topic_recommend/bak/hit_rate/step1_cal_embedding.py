import ast
import os
import argparse
from tqdm import tqdm
import pandas as pd
import numpy as np
from typing import List
from utils.nlp_utils.embedding_local import load_model_to_local


def get_similarity(user_under_query: str, current_query_list: List[str], model) -> bool:
    embeddings_1 = model.encode([user_under_query], batch_size=12, max_length=8192)
    embeddings_2 = model.encode(current_query_list, batch_size=12, max_length=8192)
    similarity = embeddings_1 @ embeddings_2.T
    similarity = similarity.flatten()  # 转换为形状 (N,)
    return similarity.tolist()


def main(file, gpu, w):
    df = pd.read_csv(file,  encoding="utf-8")
    # 找到所有 show_text_list 为空的行的索引
    indexes_to_drop = df[df['show_text_list'].isnull() | (df['show_text_list'] == '')].index
    # 删除这些行
    df.drop(indexes_to_drop, inplace=True)
    # 重置索引
    df.reset_index(drop=True, inplace=True)

    df["request_time"] = pd.to_datetime(df["request_time"])

    # 全局排序（推荐）
    sorted_df = df.sort_values(['vin', 'request_time']).reset_index(drop=True)
    sorted_df_len = len(sorted_df)

    # 加入新的字段
    sorted_df["next_query"] = ""
    sorted_df["similarity"] = ""

    model = load_model_to_local(gpu, use_onnx=False)
    print("加载模型完成!")

    for i in tqdm(range(sorted_df_len), desc="data_processing"):
        current_vin = sorted_df.iloc[i]["vin"]

        # 检查是否为最后一行，避免 IndexError
        if i + 1 < sorted_df_len and sorted_df.iloc[i + 1]["vin"] == current_vin:
            sorted_df.at[i, "next_query"] = sorted_df.iloc[i + 1]["query"]
        else:
            sorted_df.at[i, "next_query"] = "FINAL"
        try:
            if pd.isnull(sorted_df.at[i, "show_text_list"]) or sorted_df.at[i, "next_query"] == "FINAL":
                sorted_df.at[i, "similarity"] = np.nan
            else:
                # 计算相似性分数
                sorted_df.at[i, "similarity"] = get_similarity(
                    sorted_df.iloc[i]["next_query"], ast.literal_eval(sorted_df.iloc[i]["show_text_list"]), model)
        except Exception as e:
            sorted_df.at[i, "similarity"] = np.nan
            continue
            
        # 测试数据
        # if i == 200:
            # break

    sorted_df.to_csv(f'data/local/recommend/topic_recommend/hit_rate/W{w}/process_data_{os.path.basename(os.path.basename(file))}', index=False)
    # 测试数据
    # sorted_df[:200].to_csv(f'data/local/recommend/topic_recommend/hit_rate/W{w}/process_data_{os.path.basename(os.path.basename(file))}', index=False)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('-f', '--file', type=str, required=True, help='file_name')
    parser.add_argument('-g', '--gpu', type=int, required=True, help='gpu')
    parser.add_argument('-w', '--week', type=str, required=True, help='num_weeks')
    args = parser.parse_args()
    main(args.file, args.gpu, args.week)
