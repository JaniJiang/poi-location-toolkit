#!/bin/bash
#  bash recommend/topic_recommend/hit_rate/start.sh

# data_base_dir="/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend"
# # date_range="20250310-20250316"
# date_range="20250317-20250323"

data_base_dir="/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/bak"

# 检查基础目录是否存在
if [ ! -d "$data_base_dir" ]; then
    echo "错误：基础目录不存在 $data_base_dir"
    exit 1
fi

# 获取所有可用日期目录
mapfile -t date_dirs < <(find "$data_base_dir" -mindepth 1 -maxdepth 1 -type d -exec basename {} \; | sort -n)

# 检查是否有可用目录
if [ ${#date_dirs[@]} -eq 0 ]; then
    echo "错误：没有找到可用的日期目录"
    exit 1
fi

# 创建交互式菜单
echo "可用日期目录列表："
for i in "${!date_dirs[@]}"; do
    printf "%2d) %s\n" $((i+1)) "${date_dirs[$i]}"
done

# 用户选择处理
while true; do
    read -p "请选择目录编号 (1-${#date_dirs[@]}, 回车自动选最新): " choice
    
    # 处理空输入（自动选择最新）
    if [ -z "$choice" ]; then
        date_range="${date_dirs[-1]}"
        echo "自动选择最新目录: $date_range"
        break
    fi

    # 验证输入有效性
    if [[ ! "$choice" =~ ^[0-9]+$ ]]; then
        echo "错误：请输入数字！"
        continue
    elif (( choice < 1 || choice > ${#date_dirs[@]} )); then
        echo "错误：编号范围 1-${#date_dirs[@]}！"
        continue
    else
        date_range="${date_dirs[$((choice-1))]}"
        break
    fi
done

current_dir="$data_base_dir/$date_range"

# 验证最终目录
if [ ! -d "$current_dir" ]; then
    echo "错误：最终目录不存在 $current_dir"
    exit 1
fi

echo "已选择目录: $current_dir"


current_dir="$data_base_dir/$date_range"

counter=1
gpu_arr=(0 0 1 3 6 7 7)
for file in "$current_dir"/*; do
    if [ -f "$file" ]; then
        filename=$(basename "$file" .csv)
        echo "文件路径: $file"
        echo "文件名称: $filename"
        echo "文件索引: $counter"
        target_week=$(date -d  $filename +%V)
        echo "$filename 是第 W$target_week 周"

        gpu_index=$(( (counter-1) % ${#gpu_arr[@]} ))
        gpu_id=${gpu_arr[$gpu_index]}

        # 创建周日志目录
        log_dir="log/recommend/topic_recommend/hit_rate/W$target_week"
        mkdir -p "$log_dir"
        data_dir="data/local/recommend/topic_recommend/hit_rate/W$target_week"
        mkdir -p "$data_dir"

        nohup python -m recommend.topic_recommend.hit_rate.step1_cal_embedding --file $file --gpu $gpu_id --week $target_week > log/recommend/topic_recommend/hit_rate/W$target_week/step1_cal_embedding_$filename.log 2>&1 &
        ((counter++))
    fi
done
