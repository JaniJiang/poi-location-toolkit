import pandas as pd
import os
import ast

import warnings
warnings.filterwarnings("ignore", category=pd.errors.DtypeWarning)

file_root = "recommend/topic_recommend/HIT_RATE/new_data"
file_list = os.listdir(file_root)

marking_num = 10000
for file_path in file_list:
    df = pd.read_csv(os.path.join(file_root, file_path), encoding="utf-8")
    # 随机
    shuffled_df = df.sample(frac=1).reset_index(drop=True)

    df_len = len(shuffled_df)

    # 创建一个列表来存储合适的行
    filtered_rows = []  

    count = 0 
    for i in range(df_len):
        if shuffled_df.iloc[i]["next_query"] == "FINAL":
            continue
        
        try:
            # 拆分 similarity 字段
            similarity = shuffled_df.iloc[i]["similarity"]
            similarity = ast.literal_eval(similarity)
        
            # 获取 similarity1 和 similarity2
            if len(similarity) == 2:
                row_data = {
                    "Query": shuffled_df.iloc[i]["query"],
                    "请求时间": shuffled_df.iloc[i]["request_time"],    
                    "展现话题列表": shuffled_df.iloc[i]["show_text_list"],
                    "点击话题": shuffled_df.iloc[i]["show_text_click"],
                    "下一轮Query": shuffled_df.iloc[i]["next_query"],
                    "话题1相似度": similarity[0],
                    "话题2相似度": similarity[1]
                }
                filtered_rows.append(row_data)
            elif len(similarity) == 1:  # 处理长度为 1 的情况
                row_data = {
                    "Query": shuffled_df.iloc[i]["query"],
                    "请求时间": shuffled_df.iloc[i]["request_time"],
                    "展现话题列表": shuffled_df.iloc[i]["show_text_list"],
                    "点击话题": shuffled_df.iloc[i]["show_text_click"],
                    "下一轮Query": shuffled_df.iloc[i]["next_query"],
                    "话题1相似度": similarity[0],
                    "话题2相似度": None  # 如果没有第二个相似度就填 None
                }
                filtered_rows.append(row_data)
            
            count += 1
            # 达到指定的行数后停止
            if count >= marking_num:
                break

        except Exception as e:
            continue


    # 创建一个新的 DataFrame 来保存选择的行
    result_df = pd.DataFrame(filtered_rows)

    # 将结果保存到 CSV 文件
    result_df.to_csv(f'recommend/topic_recommend/HIT_RATE/marking_data/{file_path[-14:-4]}.csv', index=False)

    print(f"已保存 {count} 行到 '{file_path[-14:-4]}.csv' 文件。")


# python -m recommend.topic_recommend.HIT_RATE.marking_data










