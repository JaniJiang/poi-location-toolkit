#!/bin/bash
#  bash recommend/topic_recommend/hit_rate/step2_get_hit_rate_by_week.sh

# 交互式获取周数输入
while true; do
    read -p "请输入需要处理的周数 (1-53): " week
    
    # 验证输入有效性
    if [[ ! "$week" =~ ^[0-9]+$ ]]; then
        echo "错误：必须输入数字！"
        continue
    elif (( week < 1 || week > 53 )); then
        echo "错误：周数范围 1-53！"
        continue
    else
        break
    fi
done

# 打印执行命令（调试用）
echo "正在处理第 ${week} 周数据..."

# 执行Python程序
python -m recommend.topic_recommend.hit_rate.step2_cal_hit_rate --week $week