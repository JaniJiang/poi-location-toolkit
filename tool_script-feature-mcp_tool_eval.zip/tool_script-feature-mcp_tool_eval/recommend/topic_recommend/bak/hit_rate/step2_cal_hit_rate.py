import os
import pandas as pd
import numpy as np
import csv
import argparse

import warnings
warnings.filterwarnings("ignore", category=pd.errors.DtypeWarning)

def main():

    parser = argparse.ArgumentParser()
    parser.add_argument("-w","--week",type=str)
    args = parser.parse_args()

    # 处理好文件的存放位置
    SIMILARITY_PROCESS_DATA = f"data/local/recommend/topic_recommend/hit_rate/W{args.week}"
    print(SIMILARITY_PROCESS_DATA)
    # 阈值
    SIMILARITY_THRESHOLD= 0.9

    
    data_file_path_list = os.listdir(SIMILARITY_PROCESS_DATA)
    print(data_file_path_list)
    all_len = 0
    all_hit = 0
    all_click = 0


    rate_list_with_hit_click = []
    rate_list_with_click = []
    rate_list_with_hit = []
    
    num_list_with_hit_click = []
    num_list_with_click = []
    num_list_with_hit = []

    for data_file_path in data_file_path_list:

        with open(os.path.join(SIMILARITY_PROCESS_DATA, data_file_path), "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            
            len_reader = 0
            count_click = 0 
            count_hit = 0 
            for row in reader:
                len_reader += 1
                if row["show_text_click"]:
                    count_click += 1
                else:
                    if not row["similarity"]:
                        continue
                    similarity = eval(row["similarity"])

                    if isinstance(similarity, list):
                        for x in similarity:
                            if x >= SIMILARITY_THRESHOLD:
                                count_hit += 1
                                break
                        continue
                    
                    if isinstance(similarity, float):
                        if x >= SIMILARITY_THRESHOLD:
                            count_hit += 1
                            continue

            print(f"{data_file_path}, click_nums: {count_click}, hit_nums: {count_hit}, click_rate: {(count_click / len_reader):.2%}, hit_rate: {(count_hit/len_reader):.2%}, all_hit_rate: {((count_click + count_hit) / len_reader):.2%}")

            all_len += len_reader
            all_hit += count_hit
            all_click += count_click

            num_list_with_hit_click.append(count_click + count_hit)
            num_list_with_click.append(count_click)
            num_list_with_hit.append(count_hit)

            rate_list_with_hit.append(count_hit/len_reader)
            rate_list_with_click.append(count_click/len_reader)
            rate_list_with_hit_click.append((count_click + count_hit) / len_reader)

    print("统计完成！！！")
    print(f"这周的数据数量是：{all_len}")
    print(f"这周的点击数量是：{all_click}")
    print(f"这周的命中数量是：{all_hit}")
    print(f"平均点击率是{(sum(rate_list_with_click) / len(rate_list_with_click)):.2%}")
    print(f"平均命中率是{(sum(rate_list_with_hit) / len(rate_list_with_hit)):.2%}")
    print(f"平均总命中率是{(sum(rate_list_with_hit_click) / len(rate_list_with_hit_click)):.2%}")


if __name__ == "__main__":
    main()

# python -m recommend.topic_recommend.hit_rate.step2_cal_hit_rate


# 点击率代码
# for data_file_path in data_file_path_list:
#     click = 0
#     print(os.path.join(SIMILARITY_PROCESS_DATA, data_file_path))
#     real_file_path = os.path.join(SIMILARITY_PROCESS_DATA, data_file_path)

#     with open(real_file_path, "r", encoding="utf-8") as f:
#         reader = csv.DictReader(f)
#         len_reader = 0
#         count = 0 
#         for row in reader:
#             len_reader += 1
#             if row["show_text_click"]:
#                 count += 1
        
#         print(f"{real_file_path}, {count}, {len_reader}, {(count / len_reader):.4%}")