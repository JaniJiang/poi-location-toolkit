import pandas as pd
from tqdm import tqdm
from recommend.data_extract.topic_recommend.utils import *


def calculate_avg_metrics(data_list, return_type="float"):
    result = round(sum(data_list) / len(data_list), 2)
    if return_type == "float":
        return result
    return str(result)


def get_active_data():
    input_path = "data/cloud_share/recommend/value_argument/choose_data_by_vin_session.csv"
    input_df = pd.read_csv(input_path)
    return input_df


def get_all_data():
    input_path = "data/cloud_share/recommend/log_group/topic_recommend/20250407-20250413.vin_session/2025-04-07.jsonl"
    input_df = pd.read_json(input_path, orient="records", lines=True)
    input_df["vin"] = input_df["merge_session_id"].apply(get_vin_from_session_id)
    input_df["message_list"], input_df["need_api"] = zip(*input_df["message_list"].apply(clean_messages))
    input_df = input_df[input_df["need_api"] > 0]
    return input_df


if __name__ == "__main__":
    mode = "all"  # active | all
    if mode == "active":
        output_path = "data/cloud_share/recommend/value_argument/calculate_metrics.active.csv"
        input_df = get_active_data()
    else:
        output_path = "data/cloud_share/recommend/value_argument/calculate_metrics.all.csv"
        input_df = get_all_data()
    vin_grouped = input_df.groupby("vin")
    all_rounds_rate_list = []
    show_rounds_rate_list = []
    not_show_rounds_rate_list = []
    click_rounds_rate_list = []
    not_click_rounds_rate_list = []
    for vin, group_df in tqdm(vin_grouped, total=len(vin_grouped)):
        session_list = group_df.to_dict(orient="records")
        all_rounds_list = []
        show_rounds_list = []
        not_show_rounds_list = []
        click_rounds_list = []
        not_click_rounds_list = []
        for session in session_list:
            rounds = session["rounds"]
            all_rounds_list.append(rounds)
            if session["show_count"] > 0:
                show_rounds_list.append(rounds)
                if session["click_count"] > 0:
                    click_rounds_list.append(rounds)
                else:
                    not_click_rounds_list.append(rounds)
            else:
                not_show_rounds_list.append(rounds)
        # 单个vin的指标
        if len(all_rounds_list) > 0:
            all_rounds_rate_list.append(calculate_avg_metrics(all_rounds_list))
        if len(show_rounds_list) > 0:
            show_rounds_rate_list.append(calculate_avg_metrics(show_rounds_list))
        if len(not_show_rounds_list) > 0:
            not_show_rounds_rate_list.append(calculate_avg_metrics(not_show_rounds_list))
        if len(click_rounds_list) > 0:
            click_rounds_rate_list.append(calculate_avg_metrics(click_rounds_list))
        if len(not_click_rounds_list) > 0:
            not_click_rounds_rate_list.append(calculate_avg_metrics(not_click_rounds_list))
    # 所有vin的平均指标
    with open(output_path, "w") as f:
        f.write("all" + "\t" + calculate_avg_metrics(all_rounds_rate_list, "str") + "\n")
        f.write("show" + "\t" + calculate_avg_metrics(show_rounds_rate_list, "str") + "\n")
        f.write("not_show" + "\t" + calculate_avg_metrics(not_show_rounds_rate_list, "str") + "\n")
        f.write("click" + "\t" + calculate_avg_metrics(click_rounds_rate_list, "str") + "\n")
        f.write("not_click" + "\t" + calculate_avg_metrics(not_click_rounds_rate_list, "str") + "\n")

# python -m recommend.topic_recommend.value_argument.step4_calculate_metrics
