import os
import pandas as pd
from tqdm import tqdm
from joblib import Parallel, delayed
from recommend.data_extract.topic_recommend.utils import *


def process_session_daily(group_data_dir, day_file_name, active_vin_list):
    day_file_path = f"{group_data_dir}/{day_file_name}"
    df = pd.read_json(day_file_path, orient="records", lines=True)
    df["vin"] = df["new_session_id"].apply(get_vin_from_session_id)
    df_choose = df[df["vin"].isin(active_vin_list)].copy()
    df_choose["dt"] = day_file_name.rstrip(".jsonl")
    df_choose["message_list"], df_choose["need_api"] = zip(*df_choose["message_list"].apply(clean_messages))
    df_choose = df_choose[df_choose["need_api"] > 0]
    return df_choose


if __name__ == "__main__":
    group_data_dir = "data/cloud_share/recommend/log_group/topic_recommend/20250407-20250413.session"
    active_user_path = "data/cloud_share/recommend/value_argument/choose_active_user_2025-04-07_2025-04-13.shuf.csv"
    output_path = "data/cloud_share/recommend/value_argument/choose_data_by_session.csv"
    # 获取活跃vin列表
    active_user_df = pd.read_csv(active_user_path, header=None, names=["vin", "count"])
    active_vin_list = active_user_df["vin"].to_list()
    # 抽取分组数据
    day_file_name_list = sorted(os.listdir(group_data_dir))
    df_list = Parallel(n_jobs=7, prefer="processes")(
        delayed(process_session_daily)(group_data_dir, day_file_name, active_vin_list)
        for day_file_name in tqdm(day_file_name_list, total=len(day_file_name_list))
    )
    # 合并数据并排序
    df_merge = pd.DataFrame(columns=["new_session_id", "rounds", "is_show", "is_click", "show_count", "click_count",
                                     "message_list", "dt", "vin", "need_api"])
    if df_list:
        df_merge = pd.concat([df_merge] + df_list, ignore_index=True)
    df_merge.sort_values(by=["new_session_id", "dt"], inplace=True)
    # 保存结果
    df_merge.to_csv(output_path, index=False)
    # df_merge.to_csv(output_path, sep="\t", index=False)

# python -m recommend.topic_recommend.value_argument.step3_choose_data_by_session
