#!/bin/bash
# bash recommend/topic_recommend/value_argument/step2_choose_active_user.sh

start_dt="2025-04-28"
end_dt=$(date -d "$start_dt + 6 days" '+%Y-%m-%d')

data_dir="data/cloud_share/recommend/value_argument"
input_path="$data_dir/extract_active_user_${start_dt}_${end_dt}.csv"
output_need_path="$data_dir/choose_active_user_${start_dt}_${end_dt}.csv"
output_shuf_path="$data_dir/choose_active_user_${start_dt}_${end_dt}.shuf.csv"

cat $input_path | awk -F"," '$2>=5 {print $0}' > $output_need_path
shuf -n1000 $output_need_path > $output_shuf_path
