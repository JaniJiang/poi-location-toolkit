#!/bin/bash
# bash recommend/topic_recommend/value_argument/step1_extract_active_user.sh

start_dt="2025-04-28"
end_dt=$(date -d "$start_dt + 6 days" '+%Y-%m-%d')

data/cloud_share/tool/adt --token d67cc581ad631e063f1e88cf42400a28 ark2csv --csv-file "data/cloud_share/recommend/value_argument/extract_active_user_${start_dt}_${end_dt}.csv" --sql-string "
SELECT vin, COUNT(DISTINCT dt) AS occurrence_count
FROM (
    SELECT DISTINCT vin, dt
    FROM dwd_vechile_merge_prod_di
    WHERE dt BETWEEN '$start_dt' AND '$end_dt'
    AND domain IN ('gpt_chat', 'gpt_autoqa', 'in_car_assistant')
) AS unique_entries
GROUP BY vin"
