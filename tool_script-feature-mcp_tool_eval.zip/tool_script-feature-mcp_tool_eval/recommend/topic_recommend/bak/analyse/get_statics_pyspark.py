from pyspark.sql import SparkSession
from pyspark.sql.functions import col, when, count, mean, expr, lit, rand, row_number
from pyspark.sql.window import Window
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType
from pyspark.ml.feature import CountVectorizer
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import HashingTF, IDF
from pyspark.ml.feature import Tokenizer
from pyspark.ml.linalg import DenseVector
from pyspark.ml.stat import Summarizer
import numpy as np

# 初始化 SparkSession
spark = SparkSession.builder \
    .appName("QueryRecommendAnalysis") \
    .getOrCreate()

# 定义余弦相似度函数
def cosine_similarity_between_strings(str1, str2):
    tokenizer = Tokenizer(inputCol="text", outputCol="words")
    hashingTF = HashingTF(inputCol="words", outputCol="rawFeatures", numFeatures=20)
    idf = IDF(inputCol="rawFeatures", outputCol="features")
    
    # 创建 DataFrame
    data = spark.createDataFrame([(str1,), (str2,)], ["text"])
    wordsData = tokenizer.transform(data)
    featurizedData = hashingTF.transform(wordsData)
    idfModel = idf.fit(featurizedData)
    rescaledData = idfModel.transform(featurizedData)
    
    # 获取特征向量
    features = rescaledData.select("features").collect()
    vec1 = features[0][0].toArray()
    vec2 = features[1][0].toArray()
    
    # 计算余弦相似度
    dot_product = np.dot(vec1, vec2)
    norm1 = np.linalg.norm(vec1)
    norm2 = np.linalg.norm(vec2)
    similarity = dot_product / (norm1 * norm2)
    return similarity

# 定义按会话分组的函数
def split_by_session(df, column_str, num):
    return df.filter(col(column_str) == num)

# 主程序
if __name__ == '__main__':
    statics = []
    no_recommend_statics = []
    recommend_no_click_statics = []
    recommend_click_statics = []
    statics_base_exposure = []
    statics_base_click = []
    statics_base_mingzhong = []

    for i in range(18, 25):
        raw_table_path = f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/query_recommend/result/raw_table/table_202502{i}.csv"
        df = spark.read.csv(raw_table_path, header=True, inferSchema=True)

        # 添加列
        window = Window.partitionBy("new_session_id")
        df = df.withColumn("round_nums", count("new_session_id").over(window))
        df = df.withColumn("round_idx", row_number().over(window.orderBy("new_session_id")))
        df = df.withColumn("is_click", when(col("show_text_click").isNotNull(), 1).otherwise(0))
        df = df.withColumn("is_exposure", when(col("show_text_list").isNotNull(), 1).otherwise(0))

        # 整体指标
        exposure_count = df.filter(col("is_exposure") == 1).count()
        click_count = df.filter(col("is_click") == 1).count()
        avg_session = df.select("round_nums").distinct().agg(mean("round_nums")).collect()[0][0]

        merged_data_path = f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/query_recommend/result/vin_table/table_202502{i}.csv"
        merged_df = spark.read.csv(merged_data_path, header=True, inferSchema=True)
        avg_vin = merged_df.agg(mean("dialogue_nums")).collect()[0][0]

        statics.append({
            "日期": f"202502{i}",
            "曝光率": f"{exposure_count/df.count():.2%}",
            "点击率": f"{click_count/exposure_count:.2%}",
            "对话轮次平均值-session维度": round(avg_session, 2),
            "对话轮次平均值-vin维度": round(avg_vin, 2)
        })

        # 无话题曝光的指标
        no_recommend_df_session = split_by_session(df, "is_exposure", 0)
        no_recommend_avg_session = no_recommend_df_session.select("round_nums").distinct().agg(mean("round_nums")).collect()[0][0]

        no_recommend_merged_df = merged_df.filter(col("is_exposure") == 0)
        no_recommend_avg_vin = no_recommend_merged_df.agg(mean("dialogue_nums")).collect()[0][0]

        no_recommend_statics.append({
            "日期": f"202502{i}",
            "对话轮次平均值-session维度": round(no_recommend_avg_session, 2),
            "对话轮次平均值-vin维度": round(no_recommend_avg_vin, 2)
        })

        # 有话题曝光但未点击的指标
        recommend_df_session = split_by_session(df, "is_exposure", 1)
        recommend_no_click_df_session = split_by_session(recommend_df_session, "is_click", 0)
        recommend_no_click_avg_session = recommend_no_click_df_session.select("round_nums").distinct().agg(mean("round_nums")).collect()[0][0]

        recommend_merged_df = merged_df.filter(col("is_exposure") == 1)
        recommend_no_click_merged_df = recommend_merged_df.filter(col("is_click") == 0)
        recommend_no_click_avg_vin = recommend_no_click_merged_df.agg(mean("dialogue_nums")).collect()[0][0]

        recommend_no_click_statics.append({
            "日期": f"202502{i}",
            "对话轮次平均值-session维度": round(recommend_no_click_avg_session, 2),
            "对话轮次平均值-vin维度": round(recommend_no_click_avg_vin, 2)
        })

        # 有话题曝光且点击的指标
        recommend_click_df_session = split_by_session(recommend_df_session, "is_click", 1)
        recommend_click_avg_session = recommend_click_df_session.select("round_nums").distinct().agg(mean("round_nums")).collect()[0][0]

        recommend_click_merged_df = recommend_merged_df.filter(col("is_click") == 1)
        recommend_click_avg_vin = recommend_click_merged_df.agg(mean("dialogue_nums")).collect()[0][0]

        recommend_click_statics.append({
            "日期": f"202502{i}",
            "对话轮次平均值-session维度": round(recommend_click_avg_session, 2),
            "对话轮次平均值-vin维度": round(recommend_click_avg_vin, 2)
        })

        # 对比分析-基于曝光
        no_recommend_merged_df_sample = no_recommend_merged_df.sample(False, 0.1, seed=42)
        no_recommend_sample_avg_vin = no_recommend_merged_df_sample.agg(mean("dialogue_nums")).collect()[0][0]

        recommend_merged_df_sample = recommend_merged_df.sample(False, 0.1, seed=42)
        recommend_sample_avg_vin = recommend_merged_df_sample.agg(mean("dialogue_nums")).collect()[0][0]

        statics_base_exposure.append({
            "日期": f"202502{i}",
            "group1-平均对话轮次-vin维度": round(no_recommend_sample_avg_vin, 2),
            "group2-平均对话轮次-vin维度": round(recommend_sample_avg_vin, 2)
        })

        # 对比分析-基于点击
        recommend_no_click_merged_df_sample = recommend_no_click_merged_df.sample(False, 0.1, seed=42)
        recommend_no_click_sample_avg_vin = recommend_no_click_merged_df_sample.agg(mean("dialogue_nums")).collect()[0][0]

        recommend_click_merged_df_sample = recommend_click_merged_df.sample(False, 0.1, seed=42)
        recommend_click_sample_avg_vin = recommend_click_merged_df_sample.agg(mean("dialogue_nums")).collect()[0][0]

        statics_base_click.append({
            "日期": f"202502{i}",
            "group1-平均对话轮次-vin维度": round(recommend_no_click_sample_avg_vin, 2),
            "group2-平均对话轮次-vin维度": round(recommend_click_sample_avg_vin, 2)
        })

        # # 对比分析-基于命中（点击+相似）
        # recommend_merged_df = merged_df.filter(col("is_exposure") == 1)
        # for row in recommend_merged_df.collect():
        #     flag = 0
        #     if row['is_click'] == 1:
        #         flag = 1
        #     else:
        #         session_list = eval(row['session_list'].replace('nan', '[]'))
        #         for session in session_list:
        #             query_list = []
        #             text_list = []
        #             for data in session:
        #                 query_list.append(data['query'])
        #                 if data['show_text_list']:
        #                     text_list.extend(data['show_text_list'])
        #             for text in text_list:
        #                 for query in query_list:
        #                     if cosine_similarity_between_strings(text, query) > 0.9:
        #                         flag += 1
        #     if flag > 0:
        #         recommend_merged_df = recommend_merged_df.withColumn("is_click", when(col("new_session_id") == row['new_session_id'], 1).otherwise(col("is_click")))

        # df_click = recommend_merged_df.filter(col("is_click") == 1)
        # df_exposure = recommend_merged_df.filter(col("is_click") == 0)
        # _exposure_avg_vin = df_exposure.agg(mean("dialogue_nums")).collect()[0][0]
        # _click_avg_vin = df_click.agg(mean("dialogue_nums")).collect()[0][0]

        # statics_base_mingzhong.append({
        #     "日期": f"202502{i}",
        #     "group1-平均对话轮次-vin维度": round(_exposure_avg_vin, 2),
        #     "group2-平均对话轮次-vin维度": round(_click_avg_vin, 2)
        # })

    # 保存结果
    static_df = spark.createDataFrame(statics)
    static_df.write.mode("overwrite").csv("/mnt/pfs-guan-ssai/nlu/zhaojiufeng/query_recommend/result/static_table/20250218-20250224_static_pyspark.csv")

    # no_recommend_df = spark.createDataFrame(no_recommend_statics)
    # no_recommend_df.write.mode("overwrite").csv("/mnt/pfs-guan-ssai/nlu/zhaojiufeng/query_recommend/result/static_table/20250218-20250224_no_recommend_statics.csv")

    # recommend_no_click_df = spark.createDataFrame(recommend_no_click_statics)
    # recommend_no_click_df.write.mode("overwrite").csv("/mnt/pfs-guan-ssai/nlu/zhaojiufeng/query_recommend/result/static_table/20250218-20250224_recommend_no_click_statics.csv")

    # recommend_click_df = spark.createDataFrame(recommend_click_statics)
    # recommend_click_df.write.mode("overwrite").csv("/mnt/pfs-guan-ssai/nlu/zhaojiufeng/query_recommend/result/static_table/20250218-20250224_recommend_click_statics.csv")

    # base_exposure_df = spark.createDataFrame(statics_base_exposure)
    # base_exposure_df.write.mode("overwrite").csv("/mnt/pfs-guan-ssai/nlu/zhaojiufeng/query_recommend/result/static_table/20250218-20250224_statics_base_exposure.csv")

    # base_click_df = spark.createDataFrame(statics_base_click)
    # base_click_df.write.mode("overwrite").csv("/mnt/pfs-guan-ssai/nlu/zhaojiufeng/query_recommend/result/static_table/20250218-20250224_statics_base_click.csv")

    # base_mingzhong_df = spark.createDataFrame(statics_base_mingzhong)
    # base_mingzhong_df.write.mode("overwrite").csv("/mnt/pfs-guan-ssai/nlu/zhaojiufeng/query_recommend/result/static_table/20250218-20250224_statics_base_mingzhong.csv")

    spark.stop()