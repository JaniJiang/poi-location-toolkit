import json


if __name__ == "__main__":
    input_path = "/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_group/query_recommend/20250407-20250413.session/2025-04-07.jsonl"
    with open(input_path, "r") as f:
        for line in f:
            line = line.strip()
            if line == "":
                continue
            line_dict = json.loads(line)
            new_session_id = line_dict["new_session_id"]
            message_list = line_dict["message_list"]
            for message in message_list:
                # print(message["show_info"].get("voice_value", {}).get("guide_type", ""))
                # show
                show_text_list_a = message["show_text_list"]
                show_text_list_b = message["show_info"].get("voice_value", {}).get("show_text", [])
                if show_text_list_a != show_text_list_b:
                    print("\t".join([new_session_id, "show", str(show_text_list_a), str(show_text_list_b)]))
                # click
                click_text_a = message["click_text"]
                click_text_b = message["click_info"].get("voice_value", {}).get("show_text", "")
                if click_text_a != click_text_b:
                    print("\t".join([new_session_id, "click", str(click_text_a), str(click_text_b)]))


# python recommend/topic_recommend/analyse/log_diff.py
# cat 2025-04-07.jsonl | jq -r '.show_count' | awk -F" " '{sum+=$1} END {print sum}'
# cat 2025-04-07.jsonl | jq -r '.click_count' | awk -F" " '{sum+=$1} END {print sum}'
# cat 2025-04-07.jsonl | jq -r '.rounds' | awk -F" " '{sum+=$1} END {print sum}'
