# --- step3: 获取各项指标 ---

import pandas as pd
import numpy as np
from tqdm import tqdm
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def cosine_similarity_between_strings(str1, str2):
    # 将字符串转换为词频向量
    vectorizer = CountVectorizer().fit([str1, str2])
    vectors = vectorizer.transform([str1, str2]).toarray()
    
    # 计算余弦相似度
    similarity = cosine_similarity([vectors[0]], [vectors[1]])[0][0]
    return similarity

def split_by_session(df, column_str, num):
    grouped = df.groupby('new_session_id')
    data_list = []
    for id, group in grouped:
        if (group[column_str] == num).any():
            data_list.append(group)
        else:
            continue
    return pd.concat(data_list)
    

if __name__ == '__main__':
    statics = []
    no_recommend_statics = []
    recommend_no_click_statics = []
    recommend_click_statics = []
    statics_base_exposure = []
    statics_base_click = []
    statics_base_mingzhong = []
    for i in range(18, 25, 1):
        raw_table = f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/query_recommend/result/raw_table/table_202502{i}.csv"
        df = pd.read_csv(raw_table)
        df['round_nums'] = df.groupby('new_session_id')['new_session_id'].transform('size')  # 每个id的总行数
        df['round_idx'] = df.groupby('new_session_id').cumcount()
        df['is_click'] = np.where(df['show_text_click'].notna(), 1, 0)
        df['is_exposure'] = np.where(df['show_text_list'].notna(), 1, 0)
        df = df[['domain', 'vin', 'new_session_id', 'round_nums', 'round_idx', 'query', 'output', 'is_exposure', 'show_text_list', 'is_click', 'show_text_click']]
        

        # --- 整体指标 ---
        exposure_count = (df['is_exposure'] == 1).sum()
        click_count = (df['is_click'] == 1).sum()
        avg_session = df.drop_duplicates('new_session_id')['round_nums'].mean()
        # median = df.drop_duplicates('new_session_id')['round_nums'].median()
        
        merged_data_path = f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/query_recommend/result/vin_table/table_202502{i}.csv"
        merged_df = pd.read_csv(merged_data_path)
        avg_vin = merged_df['dialogue_nums'].mean()
        statics.append({
            "日期": f"202502{i}",
            "曝光率": f"{exposure_count/len(df):.2%}",
            "点击率": f"{click_count/exposure_count:.2%}",
            "对话轮次平均值-session维度": round(avg_session, 2),
            "对话轮次平均值-vin维度": round(avg_vin, 2)
        })


        # --- 无话题曝光的指标 ---
        no_recommend_df_session = split_by_session(df, 'is_exposure', 0)
        no_recommend_avg_session = no_recommend_df_session.drop_duplicates('new_session_id')['round_nums'].mean()

        no_recommend_merged_df = merged_df[merged_df['is_exposure'] == 0]
        no_recommend_avg_vin = no_recommend_merged_df['dialogue_nums'].mean()
        no_recommend_statics.append({
            "日期": f"202502{i}",
            "对话轮次平均值-session维度": round(no_recommend_avg_session, 2),
            "对话轮次平均值-vin维度": round(no_recommend_avg_vin, 2)
        })


        # --- 有话题曝光但未点击的指标 ---
        recommend_df_session = split_by_session(df, 'is_exposure', 1)
        recommend_no_click_df_session = split_by_session(recommend_df_session, 'is_click', 0)
        recommend_no_click_avg_session = recommend_no_click_df_session.drop_duplicates('new_session_id')['round_nums'].mean()

        recommend_merged_df = merged_df[merged_df['is_exposure'] == 1]
        recommend_no_click_merged_df = recommend_merged_df[recommend_merged_df['is_click'] == 0]
        recommend_no_click_avg_vin = recommend_no_click_merged_df['dialogue_nums'].mean()
        recommend_no_click_statics.append({
            "日期": f"202502{i}",
            "对话轮次平均值-session维度": round(recommend_no_click_avg_session, 2),
            "对话轮次平均值-vin维度": round(recommend_no_click_avg_vin, 2)
        })


        # --- 有话题曝光且点击的指标 ---
        recommend_click_df_session = split_by_session(recommend_df_session, 'is_click', 1)
        recommend_click_avg_session = recommend_click_df_session.drop_duplicates('new_session_id')['round_nums'].mean()

        recommend_click_merged_df = recommend_merged_df[recommend_merged_df['is_click'] == 1]
        recommend_click_avg_vin = recommend_click_merged_df['dialogue_nums'].mean()
        recommend_click_statics.append({
            "日期": f"202502{i}",
            "对话轮次平均值-session维度": round(recommend_click_avg_session, 2),
            "对话轮次平均值-vin维度": round(recommend_click_avg_vin, 2)
        })

        # --- 对比分析-基于曝光 ---
        # 将全量用户划分到两个group：group1接触不到话题推荐（无曝光），group2能接触到话题推荐（有曝光）。从每个group中分别随机1w个vin，计算平均对话轮次：
        no_recommend_merged_df_sample = no_recommend_merged_df.sample(n=10000, random_state=42)
        no_recommend_sample_avg_vin = no_recommend_merged_df_sample['dialogue_nums'].mean()

        recommend_merged_df_sample = recommend_merged_df.sample(n=10000, random_state=42)
        recommend_sample_avg_vin = recommend_merged_df_sample['dialogue_nums'].mean()

        statics_base_exposure.append({
            "日期": f"202502{i}",
            "group1-平均对话轮次-vin维度": round(no_recommend_sample_avg_vin, 2),
            "group2-平均对话轮次-vin维度": round(recommend_sample_avg_vin, 2)
        })

        # --- 对比分析-基于点击 ---
        # 将能够接触到话题推荐的用户划分到两个用户group：group1有曝光无点击，group2有曝光有点击。从每个group中分别随机1k个vin，计算平均对话轮次：
        recommend_no_click_merged_df_sample = recommend_no_click_merged_df.sample(n=2000, random_state=42)
        recommend_no_click_sample_avg_vin = recommend_no_click_merged_df_sample['dialogue_nums'].mean()

        recommend_click_merged_df_sample = recommend_click_merged_df.sample(n=2000, random_state=42)
        recommend_click_sample_avg_vin = recommend_click_merged_df_sample['dialogue_nums'].mean()

        statics_base_click.append({
            "日期": f"202502{i}",
            "group1-平均对话轮次-vin维度": round(recommend_no_click_sample_avg_vin, 2),
            "group2-平均对话轮次-vin维度": round(recommend_click_sample_avg_vin, 2)
        })


        # --- 对比分析-基于命中（点击+相似） ---
        # group1有曝光无命中，group2有曝光有命中
        # 曝光表recommend_merged_df,相似度大于0.9或有点击的作为点击表，否则为曝光表
        recommend_merged_df = merged_df[merged_df['is_exposure'] == 1]
        for index, row in recommend_merged_df.iterrows():
            falg = 0
            if row['is_click'] == '1' or row['is_click'] == 1:
                falg = 1
            else:
                session_list = eval(row['session_list'].replace('nan', '[]'))
                for session in session_list:
                    query_list = []
                    text_list = []
                    for data in session:
                        query_list.append(data['query'])
                        if data['show_text_list']:
                            text_list.extend(data['show_text_list'])
                    for text in text_list:
                        for query in query_list:
                            if cosine_similarity_between_strings(text, query) > 0.9:
                                falg += 1
            if falg > 0:
                recommend_merged_df.at[index, 'is_click'] = 1  # 修改原始数据

        df_click = recommend_merged_df[recommend_merged_df['is_click'] == 1]
        df_exposure = recommend_merged_df[recommend_merged_df['is_click'] == 0]
        _exposure_avg_vin = df_exposure['dialogue_nums'].mean()
        _click_avg_vin = df_click['dialogue_nums'].mean()

        statics_base_mingzhong.append({
            "日期": f"202502{i}",
            "group1-平均对话轮次-vin维度": round(_exposure_avg_vin, 2),
            "group2-平均对话轮次-vin维度": round(_click_avg_vin, 2)
        })

        # print(statics_base_mingzhong)
    static_df = pd.DataFrame(statics)
    static_df.to_excel(f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/query_recommend/result/static_table/20250218-20250224_static.xlsx")
    no_recommend_df = pd.DataFrame(no_recommend_statics)
    no_recommend_df.to_excel(f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/query_recommend/result/static_table/20250218-20250224_no_recommend_statics.xlsx")   
    recommend_no_click_df = pd.DataFrame(recommend_no_click_statics)
    recommend_no_click_df.to_excel(f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/query_recommend/result/static_table/20250218-20250224_recommend_no_click_statics.xlsx")   
    recommend_click_df = pd.DataFrame(recommend_click_statics)
    recommend_click_df.to_excel(f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/query_recommend/result/static_table/20250218-20250224_recommend_click_statics.xlsx")   
    base_exposure_df = pd.DataFrame(statics_base_exposure)
    base_exposure_df.to_excel(f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/query_recommend/result/static_table/20250218-20250224_statics_base_exposure.xlsx")   
    base_click_df = pd.DataFrame(statics_base_click)
    base_click_df.to_excel(f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/query_recommend/result/static_table/20250218-20250224_statics_base_click.xlsx")   
    base_mingzhong_df = pd.DataFrame(statics_base_mingzhong)
    base_mingzhong_df.to_excel(f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/query_recommend/result/static_table/20250218-20250224_statics_base_mingzhong.xlsx")   
