import json
import pandas as pd
from tqdm import tqdm
from loguru import logger
from collections import Counter


class ExposureAnalyse:

    def __init__(self):
        self.date = "2025-04-10"
        self.input_path = f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_group/query_recommend/20250407-20250413/{self.date}.csv"
        self.output_path = f"data/cloud/recommend/topic_recommend/analyse/exposure_analyse/{self.date}"
        self.field_name_list = ["face_screen", "domain", "APINAME", "CATEGORY"]

    def process(self):
        logger.info("读取输入数据")
        input_df = pd.read_csv(self.input_path)
        logger.info("逐行处理数据")
        self.total_group_dict = {}
        self.show_group_dict = {}
        self.notshow_group_dict = {}
        for _, sample_row in tqdm(input_df.iterrows(), total=len(input_df)):
            # is_exposure: 是否曝光
            # is_click: 是否点击
            # dialogue_list: 对话历史
            is_exposure = sample_row["is_exposure"]
            for item in json.loads(sample_row["dialogue_list"]):
                for field_name in self.field_name_list:
                    field_value = item.get(field_name, "").strip('"')
                    # 整体
                    if field_name not in self.total_group_dict:
                        self.total_group_dict[field_name] = []
                    self.total_group_dict[field_name].append(field_value)
                    if is_exposure == 1:  # 有曝光
                        if field_name not in self.show_group_dict:
                            self.show_group_dict[field_name] = []
                        self.show_group_dict[field_name].append(field_value)
                    else:  # 无曝光
                        if field_name not in self.notshow_group_dict:
                            self.notshow_group_dict[field_name] = []
                        self.notshow_group_dict[field_name].append(field_value)
        logger.info("统计基础字段分布")
        for field_name in self.field_name_list:
            self.count_frequency("total", field_name, self.total_group_dict.get(field_name, []))
            self.count_frequency("show", field_name, self.show_group_dict.get(field_name, []))
            self.count_frequency("notshow", field_name, self.notshow_group_dict.get(field_name, []))

    def count_frequency(self, data_type, field_name, data_list):
        counter = Counter(data_list)
        sorted_items = sorted(counter.items(), key=lambda x: x[1], reverse=True)
        with open(f"{self.output_path}.{data_type}.{field_name}.tsv", "w") as f:
            f.write("\t".join(["取值", "数据量"]) + "\n")
            for sorted_item in sorted_items:
                f.write("\t".join([str(x) for x in sorted_item]) + "\n")


if __name__ == "__main__":
    obj = ExposureAnalyse()
    obj.process()

# python -m recommend.topic_recommend.analyse.exposure_analyse
