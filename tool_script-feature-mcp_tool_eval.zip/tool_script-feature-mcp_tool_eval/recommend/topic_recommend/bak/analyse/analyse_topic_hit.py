import pandas as pd
from tqdm import tqdm
from utils.metrics_utils.common_metrics_utils import cal_metrics
from utils.search_utils.rule_match import calculate_common_ratios_set


class AnalyseTopicHit:

    def __init__(self):
        data_dir = "data/cloud_share/recommend/topic_recommend/analyse/analyse_topic_hit"
        self.input_path = f"{data_dir}/input.tsv"
        self.output_path = f"{data_dir}/output"

    def process(self):
        df = pd.read_csv(self.input_path, sep="\t")
        tqdm.pandas()
        df[["ratio1", "ratio2"]] = df.progress_apply(self.process_row, axis=1)
        cal_metrics(df, self.output_path, "话题1相似度", "话题1人工标注", 0.01, 0.85, 1.0)
        cal_metrics(df, self.output_path, "ratio1", "话题1人工标注", 0.1)
        cal_metrics(df, self.output_path, "ratio2", "话题1人工标注", 0.1)

    def process_row(self, row):
        show_topic = row["展现话题1"]
        next_query = row["下一轮Query"]
        ratio1, ratio2 = calculate_common_ratios_set(show_topic, next_query)
        return pd.Series([ratio1, ratio2])


if __name__ == "__main__":
    obj = AnalyseTopicHit()
    obj.process()

# python -m recommend.topic_recommend.analyse.analyse_topic_hit
