# --- step2: 根据vin划分数据 ---


import pandas as pd
import numpy as np
from tqdm import tqdm
import json

for i in tqdm(range(18, 25, 1)):
    merged_table = f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/query_recommend/result/raw_table/table_202502{i}.csv"
    df = pd.read_csv(merged_table)
    df['round_nums'] = df.groupby('new_session_id')['new_session_id'].transform('size')  # 每个id的总行数
    df['round_idx'] = df.groupby('new_session_id').cumcount()
    df['is_click'] = np.where(df['show_text_click'].notna(), 1, 0)
    df['is_exposure'] = np.where(df['show_text_list'].notna(), 1, 0)
    res_df = df[['domain', 'vin', 'new_session_id', 'round_nums', 'round_idx', 'query', 'output', 'is_exposure', 'show_text_list', 'is_click', 'show_text_click']]
    # 写入
    res_df.to_csv(f'/mnt/pfs-guan-ssai/nlu/zhaojiufeng/query_recommend/result/res_202502{i}.csv')
    # 将vin相同的数据拼接起来,
    vin_grouped = res_df.groupby('vin')
    res_data = []
    for vin, group in vin_grouped:
        data_list = []
        if (group['is_exposure'] == 1).any():
            is_exposure = 1
        else:
            is_exposure = 0
        
        if (group['is_click'] == 1).any():
            is_click = 1
        else:
            is_click = 0

        session_grouped = group.groupby('new_session_id')
        session_list = []
        dialogue_nums = 0
        for session_id, group2 in session_grouped:
            session_data = []
            dialogue_nums += len(group2)
            group2["show_text_list"] = group2["show_text_list"].apply(lambda x: x if isinstance(x, list) else [])
            group2['show_text_click'] = group2['show_text_click'].apply(lambda x: x if isinstance(x, list) else [])
            group2['output'] = group2['output'].apply(lambda x: x if isinstance(x, (str, list)) and len(x) > 0 else "")
            for index, row in group2.iterrows():
                session_data.append({
                    'query': row['query'],
                    'output': row['output'],
                    'show_text_list': row['show_text_list'],
                    'show_text_click': row['show_text_click']
                })
            session_list.append(session_data)
            
        res_data.append({
            'vin': vin,
            'is_exposure': is_exposure,
            'is_click': is_click,
            'session_nums': len(session_list), 
            'dialogue_nums': dialogue_nums,
            'session_list': json.dumps(session_list,ensure_ascii=False)
        })
        # print('res_data:')
        # print(res_data)

    res_data_df = pd.DataFrame(res_data)
    res_data_df.to_csv(f"/mnt/pfs-guan-ssai/nlu/zhaojiufeng/query_recommend/result/vin_table/table_202502{i}.csv")