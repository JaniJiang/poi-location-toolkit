import json
import pandas as pd
from loguru import logger
from tqdm import tqdm


class ClickAnalyse:
    def __init__(self):
        self.date = "2025-04-10"
        self.work_dir = "data/cloud/recommend/topic_recommend/analyse/click_analyse"
        self.input_path = f"{self.work_dir}/{self.date}/input.tsv"
        self.output_path = f"{self.work_dir}/{self.date}/output.tsv"

    def process(self):
        logger.info("读取输入数据")
        input_df = pd.read_csv(self.input_path,  sep="\t")
        logger.info("逐行处理数据")
        result_list = []
        for _, row in tqdm(input_df.iterrows(), total=len(input_df)):
            try:
                exist_line_dict = {}
                for item in json.loads(row["dialogue_list"]):
                    result = [
                        row["vin"],
                        row["is_activate_user"],
                        item["face_screen"],
                        item["query"],
                        item["domain"],
                        item["APINAME"],
                        item["CATEGORY"],
                        item["has_exposure"],
                        item["has_click"],
                        item["show_text_list"],
                        item["show_text_click"],
                    ]
                    line = "\t".join([str(x) for x in result])
                    if line not in exist_line_dict:
                        result_list.append(line)
                        exist_line_dict[line] = True
            except Exception as e:
                logger.warning(f"process vin[{row['vin']}] failed: str({e})")
        logger.info("保存处理结果")
        with open(self.output_path, "w") as f:
            for line in result_list:
                f.write(line + "\n")


if __name__ == "__main__":
    obj = ClickAnalyse()
    obj.process()

# python -m recommend.topic_recommend.analyse.click_analyse
