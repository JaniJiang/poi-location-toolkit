DATA_DIR = "data/cloud_share/recommend/topic/llm_query2topic"
