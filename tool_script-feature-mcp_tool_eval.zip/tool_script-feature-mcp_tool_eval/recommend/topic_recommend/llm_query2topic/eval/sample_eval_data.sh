#!/bin/bash

# 定义输入文件路径和输出文件路径
INPUT_FILE="data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_online_data/step3_generate_topics_data/20250101-20250612.jsonl"
OUTPUT_FILE="data/cloud_share/recommend/topic_recommendation/llm_query2topic/eval/eval_input_v2_sample.tsv"
TOP_PV_COUNT=50
RAND_SAMPLE_COUNT=50

# 输出表头
echo -e "query\tpv\tllm_ner\trealated_knowledge\trecommendation_topics" > ${OUTPUT_FILE}

# 预处理 JSON 数据，确保没有多余的转义符
PREPROCESSED_FILE=$(mktemp) # 临时文件存放中间结果
jq -c 'select(.recommendation_topics != "REJECT")' ${INPUT_FILE} > ${PREPROCESSED_FILE}

# 第一步：top_pv采样
jq -c -s "sort_by(.pv) | reverse | .[:${TOP_PV_COUNT}]" ${PREPROCESSED_FILE} \
    | jq -r '.[] | [.query, (.pv|tostring), (.llm_ner|tostring), (.realated_knowledge|tostring), (.recommendation_topics|tostring)] | @tsv' \
    >> ${OUTPUT_FILE}

# 第二步：随机采样（过滤掉 top_pv 中已选的 query）
jq -r '.query' ${OUTPUT_FILE} > top_pv_queries.txt

grep -F -v -f top_pv_queries.txt ${PREPROCESSED_FILE} \
    | shuf -n ${RAND_SAMPLE_COUNT} \
    | jq -r '[.query, (.pv|tostring), (.llm_ner|tostring), (.realated_knowledge|tostring), (.recommendation_topics|tostring)] | @tsv' \
    >> ${OUTPUT_FILE}

# 删除临时文件
rm -f ${PREPROCESSED_FILE} top_pv_queries.txt

echo "自测集采样完成！ top_v采样 ${TOP_PV_COUNT} 条； rand采样 ${RAND_SAMPLE_COUNT} 条"