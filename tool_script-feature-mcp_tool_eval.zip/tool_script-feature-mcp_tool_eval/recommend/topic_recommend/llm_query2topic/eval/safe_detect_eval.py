import pandas as pd
import json


def save_data_as_tsv(data_path, save_path):
    data = []
    with open(data_path, 'r', encoding='utf-8') as rf:
        for line in rf.readlines():
            line = json.loads(line)
            data.append(line)
    df = pd.DataFrame(data)
    df.to_csv(save_path, sep="\t", index=False)


if __name__ == "__main__":
    safe_data_path = "data_share/recommend/topic_recommendation/llm_query2topic/build_online_data/step5_safe_detect_data/20250101-20250612_safe.jsonl"
    unsafe_data_path = "data_share/recommend/topic_recommendation/llm_query2topic/build_online_data/step5_safe_detect_data/20250101-20250612_unsafe.jsonl"
    unsafe_save_path = "data_share/recommend/topic_recommendation/llm_query2topic/build_online_data/step5_safe_detect_data/20250101-20250612_unsafe.tsv"
    safe_save_path = "data_share/recommend/topic_recommendation/llm_query2topic/build_online_data/step5_safe_detect_data/20250101-20250612_safe.tsv"
    save_data_as_tsv(safe_data_path, safe_save_path)
    # python -m recommend.topic_recommend.llm_query2topic.eval.safe_detect_eval
