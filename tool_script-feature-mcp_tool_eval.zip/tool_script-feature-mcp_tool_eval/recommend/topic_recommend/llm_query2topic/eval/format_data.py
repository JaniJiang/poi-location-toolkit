import pandas as pd
import time
import hashlib
import json


def generate_index_id(query):
    salt = str(time.time_ns())  # 纳秒时间戳，或用其他唯一值
    source = (query.lower() + salt).encode('utf-8')
    index_id = hashlib.md5(source).hexdigest()[:16]  # 截取前16位
    return index_id


def mix_output_show_list(tsv_path, raw_path, output_path):
    from pyspark.sql import SparkSession
    from pyspark.sql.functions import monotonically_increasing_id

    spark = SparkSession.builder \
        .appName("Mix Output Show List") \
        .config("spark.driver.memory", "16g") \
        .config("spark.executor.memory", "16g") \
        .config("spark.driver.maxResultSize", "2g") \
        .getOrCreate()
    df_tsv = spark.read.option("header", True).option("sep", "\t").csv(tsv_path) \
        .withColumn("row_index", monotonically_increasing_id())
    df_raw = spark.read.option("header", True) \
        .option("multiLine", True) \
        .option("quote", '"') \
        .csv(raw_path)
    columns_to_keep = ['query', 'api_name', 'ans', 'category', 'show_text_list']
    df_raw_filtered = df_raw.select(*[c for c in columns_to_keep if c in df_raw.columns])
    df_raw_dedup = df_raw_filtered.dropDuplicates(["query"])
    df_joined = df_tsv.join(df_raw_dedup, on="query", how="left") \
        .orderBy("row_index")  # 恢复顺序
    df_joined.drop("row_index").toPandas().to_csv(output_path, sep="\t", index=False)

    print("✅ 合并完成，顺序已保留，结果已写入：", output_path)

# def mix_output_show_list(tsv_path, raw_path, out_put):
#     import pandas as pd
#     from pyspark.sql import SparkSession
#     from pyspark.sql.functions import col, explode, length, when

#     spark = SparkSession.builder \
#         .appName("StrictSampleFlagMarker") \
#         .config("spark.driver.memory", "16g") \
#         .config("spark.executor.memory", "16g") \
#         .config("spark.driver.maxResultSize", "2g") \
#         .getOrCreate()

#     df_spark_pd = spark.read.csv(raw_path).toPandas()
#     df_tsv = pd.read_csv(tsv_path, sep="\t")
#     df_merged = pd.merge(df_tsv, df_spark_pd, on="query", how="left")
#     df_merged.to_csv(out_put, sep="\t", index=False)
#     print("✅ 合并完成，Spark 的 output 已作为 answer 字段合入 TSV 文件中。")


# def mix_output_show_list(tsv_path, raw_path, out_put):
    # import pandas as pd
    # from pyspark.sql import SparkSession
    # from pyspark.sql.functions import col, explode, length, when

    # spark = SparkSession.builder \
    #     .appName("StrictSampleFlagMarker") \
    #     .config("spark.driver.memory", "16g") \
    #     .config("spark.executor.memory", "16g") \
    #     .config("spark.driver.maxResultSize", "2g") \
    #     .getOrCreate()

    # df = spark.read.csv(raw_path)
    # df = df.withColumn("message", explode(col("message_list")))

    # df = df.select(
    #     col("message.query").alias("query"),
    #     col("message.answer").alias("answer"),
    #     col("message.show_text_list").alias("show_text_list")

    # ).filter(col("answer").isNotNull())

    # # 标记哪些行的信息更完整
    # df = df.withColumn("score",
    #                    when((col("answer").isNotNull()) & (length(col("answer")) > 0), 1).otherwise(0) +
    #                    when((col("show_text_list").isNotNull()), 1).otherwise(0))

    # # 优先保留 score 高的记录（信息更完整的）
    # df = df.dropna(subset=["query"]) \
    #        .orderBy(col("score").desc()) \
    #        .dropDuplicates(["query"]) \
    #        .drop("score")  # 最后去掉辅助列

    # df_spark_pd = df.toPandas()
    # df_tsv = pd.read_csv(tsv_path, sep="\t")
    # # df_spark_pd = df.dropna(subset=["query"]).dropDuplicates(["query"]).toPandas()
    # # df_tsv = pd.read_csv(tsv_path, sep="\t")

    # df_merged = pd.merge(df_tsv, df_spark_pd, on="query", how="left", suffixes=("", "_from_spark"))

    # # answer 替换
    # if "answer_from_spark" in df_merged.columns:
    #     df_merged["answer"] = df_merged["answer_from_spark"].combine_first(df_merged["answer"])
    #     df_merged.drop(columns=["answer_from_spark"], inplace=True)

    # # show_text_list 替换
    # if "show_text_list_from_spark" in df_merged.columns:
    #     df_merged["show_text_list"] = df_merged["show_text_list_from_spark"].combine_first(
    #         df_merged.get("show_text_list"))
    #     df_merged.drop(columns=["show_text_list_from_spark"], inplace=True)

    # df_merged.to_csv(out_put, sep="\t", index=False)

    # print("✅ 合并完成，Spark 的 output 已作为 answer 字段合入 TSV 文件中。")


def eval_build_data():
    df = pd.read_csv("recommend/topic_recommend/llm_query2topic/eval/eval.tsv", sep="\t")
    df_len = len(df)
    data = []
    topic_choice = ["generalization", "attractiveness"]

    for idx in range(df_len):
        line = df.iloc[idx]
        query = line["query"]
        topic_dict = eval(line["recommendation_topics"])
        merged_list = []
        for key in topic_choice:
            if key in topic_dict and isinstance(topic_dict[key], list):
                merged_list.extend(topic_dict[key])

        base_data = {
            "id": generate_index_id(query=query),
            "query": query,
            "domain": "common",
            "topic_list": merged_list
        }
        data.append(base_data)

    with open("data/cloud_share/recommend/topic_recommendation/llm_query2topic/eval/eval.jsonl", "w", encoding="utf-8") as f:
        for item in data:
            f.write(json.dumps(item, ensure_ascii=False) + "\n")


def search_query_info(raw_path, query_list):
    from pyspark.sql import SparkSession
    from pyspark.sql.functions import col, explode

    # 初始化 Spark
    spark = SparkSession.builder \
        .appName("QueryListSearcher") \
        .getOrCreate()

    # 读取 JSON 数据
    df = spark.read.json(raw_path)

    # 展开 message_list
    df = df.withColumn("message", explode(col("message_list")))

    # 选择字段
    df = df.select(
        col("message.query").alias("query"),
        col("message.output").alias("answer"),
        col("message.show_text_list").alias("show_text_list")
    )

    # 过滤 query 在列表中的记录
    result_df = df.filter(col("query").isin(query_list))

    # 显示结果（全部展开）
    result_df.orderBy("query").show(truncate=False, n=1000)


if __name__ == "__main__":
    tsv_path = "data/cloud_share/recommend/topic_recommendation/llm_query2topic/eval/eval_input_v2_sample.tsv"
    raw_path = "data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_online_data/step1_extract_query/2025010-20250612-1/20250101-20250612_*.csv"
    out_put = "data/cloud_share/recommend/topic_recommendation/llm_query2topic/eval/eval_output_mix_ans_v2.tsv"
    mix_output_show_list(tsv_path, raw_path, out_put)
    # query_list = [
    #     "鹿晗为何删掉了宣传关晓彤新剧的微博",
    #     "SpaceX要求台湾供应商外移会影响供应链合作吗?",
    #     "瑞典央行为何首次在十年后将利率下调50个基点",
    #     "小伙如何发现疑似抗寒榴莲树并获得农科院感谢",
    #     "湖南怀化女发型师晓华如何在短时间内爆火",
    #     "公积金贷款利率有可能会下调吗"]
    # search_query_info(raw_path, query_list)
    # python -m recommend.topic_recommend.llm_query2topic.eval.format_data
