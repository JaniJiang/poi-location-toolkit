import pandas as pd
from tqdm import tqdm
from recommend.topic_recommend.utils.topic_recommend_client import *


def eval_offline_test(eval_data, eval_ouput_data):
    env = "local"  # local | dev | testtwo
    client = TopicRecommendClient(env)
    df = pd.read_csv(eval_data, sep="\t")
    df_len = len(df)
    # df["client_topic_list"] = None
    for idx in tqdm(range((df_len)), desc="Evaling ..."):
        try:
            line = df.iloc[idx]
            query = line["query"]
            answer = line.get("answer", "")
            if answer == "":
                continue
            domain = "gpt_chat"
            category = line['category']
            api_name = line['api_name']
            vin = ""
            response = client.process(query, answer, domain, category, api_name, vin)
            topic_list = response.to_dict().get("topic_list", [])
            df.at[idx, "client_topic_list"] = json.dumps(topic_list, ensure_ascii=False)
        except Exception as e:
            df.at[idx, "client_topic_list"] = "error"
            continue
    df.to_csv(eval_ouput_data, sep="\t", index=False)


if __name__ == "__main__":
    eval_data = r"data/cloud_share/recommend/topic_recommendation/llm_query2topic/eval/eval_output_mix_ans.tsv"
    eval_ouput_data = r"data/cloud_share/recommend/topic_recommendation/llm_query2topic/eval/eval_output_cilent.tsv"
    eval_offline_test(eval_data, eval_ouput_data)
    # python -m recommend.topic_recommend.llm_query2topic.eval.eval

    # 采样指令
    # 随机采样
    # (
    #     echo -e "query\tpv\tllm_ner\trealated_knowledge\trecommendation_topics"
    #     jq -c 'select(.recommendation_topics != "REJECT")' data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_online_data/step3_generate_topics_data/20250101-20250612.jsonl \
    #     | shuf -n 100 \
    #     | jq -r '[.query, (.pv|@json), (.llm_ner|@json), (.realated_knowledge|@json), (.recommendation_topics|@json)] | @tsv'
    # ) > data/cloud_share/recommend/topic_recommendation/llm_query2topic/eval/eval_input_v2.tsv
    # top_pv采样
    # 运行 bash recommend/topic_recommend/llm_query2topic/eval/sample_eval_data.sh
