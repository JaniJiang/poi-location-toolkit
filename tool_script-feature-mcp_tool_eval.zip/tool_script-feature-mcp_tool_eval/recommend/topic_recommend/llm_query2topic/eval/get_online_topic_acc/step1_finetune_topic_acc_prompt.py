import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import pandas as pd
from tqdm import tqdm

from utils.llm_utils.serverless_function import request_llm

# origin prompt
# prompt_template = """
# 有一个推荐系统对于输入的问题和回复内容出了一个推荐话题，推荐话题可以是关于问题的扩展、回复内容的延伸。你现在是一个优秀的标注人员，来判断推荐话题是否是合适的。
# 当存在以下情况的时候，应标为不合适：
# 1. 如果推荐话题能在问题或者回复内容里可以找到，就为错。
# 2. 没有逻辑性关系的推荐话题，比如：二手车的电池和充电桩有关系吗？
# 3. 预测类的推荐话题，比如：马斯克的下一个创新是什么？
# 4. 无法改变的事实，比如：如何提高鹰的视力。
# 5. 除了理想汽车的其他品牌车辆细节信息，例如：es8多长
# 6. 推荐关于”理想one“这款车型的信息
# 7. 推荐话题句子不通顺，句子不全，中英文混乱
# 根据上述要求，请你判断下面这个case是否是合适的，请选择：A. 合适；B. 不合适。请说明理由
# 问题是：{query}
# 回复内容是：{answer}
# 推荐话题是：{doc}
# """

prompt_template = """有一个推荐系统对于输入的问题和回复内容出了一个推荐话题，推荐话题可以是关于问题的扩展、回复内容的延伸。你现在是一个优秀的标注人员，来判断推荐话题是否是合适的。
当存在以下情况的时候，应标为不合适：
1. 只要无明显的逻辑错误就不算错，连贯行为应该不是错误的，例如：说到博物馆，就会提到参观。但其中有很多相关的逻辑性关系是很难发现的, 例如一说到武则天我们就会想到狄仁杰。
2. 推荐的话题不应该是不符合现实生活的，比如：钢铁侠的战衣制作成本，钢铁侠的战衣在现实生活中是不存在的不能用价格衡量。
3. 当推荐的topic与query毫无关联时，判定为显著错误。例如，query为 “瑞典央行为何首次在十年后将利率下调 50 个基点”，而topic为 “瑞典电信业的未来”“诺贝尔奖得主的经济背景”，query核心围绕经济问题，推荐话题却偏离主题，属于显著错误。
4. 预测类的推荐话题，比如：马斯克的下一个创新是什么？
5. 无法改变的事实，比如：如何提高鹰的视力。
6. 除了理想汽车的其他品牌车辆细节信息，例如：es8多长。
7. 推荐关于”理想one“这款车型的信息。
8. 推荐话题的不通顺，句子本身是个病句，不符合逻辑，句子不全，中英文混乱，例如：世界地区社会特点如何？。
正确的：
1. 话题可具有泛化性，例如：溧阳市有哪些五星级酒店？可以给用户推荐：溧阳市的历史文化有哪些？，并不一定沿着酒店推荐
2. 推荐的话题若涉及query相关的人物、事物或能够吸引用户点击，即具备吸引能力。以query“熊出没” 为例，topic如 “熊大熊二的性格特点是什么”“光头强的日常工作是什么”，聚焦于 “熊出没” 中的人物，可视为具有吸引力的优质话题。
根据上述要求，请你判断下面这个case是否是合适的，请选择：A. 合适；B. 不合适。请说明理由
问题是：{query}
回复内容是：{answer}
推荐话题是：{doc}"""


user_pro = """请严格以以下JSON回复，非Markdown格式：
{
    "ans": "A" or "B" // 代表着合适与不合适
    "reason": "给出理由说明"
}
"""


def get_response(system_pro: str, user_pro: str, model="gpt-4o"):
    try:
        _, response_data = request_llm([system_pro, user_pro], model=model)
        res = response_data['choices'][0]['message']['content']
        res = eval(res)
        return res
    except Exception as e:
        return "error"


def process_row(idx, df, max_retries=3):
    try:
        data = df.iloc[idx]
        query = data["query"]
        gold_ans = data["answer"]
        topic_list = eval(data["推荐query list"])
        topic_num = len(topic_list)
        right_num = 0
        query_accuracies = [None, None]
        topic_accuracies = [None, None]  # 新增：每个topic的准确度
        questions = [None, None]         # 新增：每个topic的问题记录

        # 获取真实标签
        try:
            label1 = data["label1"]
            label2 = data["label2"]
        except KeyError:
            label1 = None
            label2 = None

        for i, topic in enumerate(topic_list[:2]):
            system_pro = prompt_template.format(query=query, answer=gold_ans, doc=topic)

            # 添加重试机制
            for attempt in range(max_retries):
                try:
                    res = get_response(system_pro, user_pro)
                    # 检查响应是否有效
                    if res != "error" and res.get("ans") in ["A", "B"]:
                        break
                except Exception as e:
                    print(f"Attempt {attempt+1} failed for index {idx}, topic {i}: {str(e)}")
                    res = "error"

                # 重试间隔
                if attempt < max_retries - 1:
                    time.sleep(1)  # 等待1秒后重试

            # 处理最终结果
            pred = None
            if res == "error" or res.get("ans") not in ["A", "B"]:
                query_accuracies[i] = None
            else:
                if res["ans"] == "A":
                    right_num += 1
                    query_accuracies[i] = 1
                    pred = 1
                else:
                    query_accuracies[i] = 0
                    pred = 0

            # 计算准确度
            if i == 0:
                gold = label1
            else:
                gold = label2

            # 准确度计算逻辑
            if pred is None and gold is None:
                topic_accuracies[i] = None
            elif pred is None or gold is None:
                topic_accuracies[i] = -1
            elif pred == gold:
                topic_accuracies[i] = 1
            else:
                questions[i] = res
                topic_accuracies[i] = 0

        return idx, topic_num, right_num, query_accuracies, topic_accuracies, questions
    except Exception as e:
        print(f"Row {idx} processing failed: {str(e)}")
        print(df.iloc[idx])
        return idx, 0, 0, [None, None], [None, None], [None, None]


def run(data_path, output_path, max_workers=5, max_retries=3):
    df = pd.read_csv(data_path, sep="\t")
    len_df = len(df)
    total_topic_num = 0
    total_right_num = 0

    # 新增列
    df["pred1"] = None
    df["pred2"] = None
    df["acc1"] = None
    df["acc2"] = None
    df["问题1"] = None
    df["问题2"] = None

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = []
        for idx in range(len_df):
            futures.append(executor.submit(process_row, idx, df, max_retries))

        for future in tqdm(as_completed(futures), total=len_df, desc="Processing"):
            row_idx, topic_num, right_num, query_accuracies, topic_accuracies, questions = future.result()
            total_topic_num += topic_num
            total_right_num += right_num

            # 更新结果
            df.at[row_idx, "pred1"] = query_accuracies[0]
            df.at[row_idx, "pred2"] = query_accuracies[1]
            df.at[row_idx, "acc1"] = topic_accuracies[0]
            df.at[row_idx, "acc2"] = topic_accuracies[1]
            df.at[row_idx, "问题1"] = questions[0]
            df.at[row_idx, "问题2"] = questions[1]

    print(f"Total topic number: {total_topic_num}")
    print(f"Total right number: {total_right_num}")
    print(f"ACC = {(total_right_num / total_topic_num):.2%}")

    # 计算整体准确率
    valid_acc1 = df["acc1"].dropna()
    valid_acc2 = df["acc2"].dropna()

    valid_acc = pd.concat([valid_acc1, valid_acc2])
    valid_acc = valid_acc[valid_acc != -1]  # 排除一个有值一个空的情况

    if len(valid_acc) > 0:
        overall_accuracy = (valid_acc == 1).mean()
        print(f"Overall Accuracy = {overall_accuracy:.2%}")
    else:
        print("No valid accuracy data available")

    df.to_csv(output_path, sep="\t", index=False)
    print("fininsh")


if __name__ == "__main__":
    row_path = r"data/cloud_share/recommend/topic_recommendation/llm_query2topic/eval/test_old_our_prompt.tsv"
    output_path = r"data/cloud_share/recommend/topic_recommendation/llm_query2topic/eval/test_old_our_prompt_label.tsv"
    run(row_path, output_path)
    # python -m recommend.topic_recommend.llm_query2topic.eval.get_online_topic_acc.step1_finetune_topic_acc_prompt
