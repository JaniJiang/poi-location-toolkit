import requests
import logging
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *

system_template = """有一个推荐系统对于输入的问题和回复内容出了一个推荐话题，推荐话题可以是关于问题的扩展、回复内容的延伸。你现在是一个优秀的标注人员，来判断推荐话题是否是合适的。

## 当存在以下情况的时候，应标为不合适：
1. 只要无明显的逻辑错误就不算错，连贯行为应该不是错误的，例如：说到博物馆，就会提到参观。但其中有很多相关的逻辑性关系是很难发现的, 例如一说到武则天我们就会想到狄仁杰。
2. 推荐的话题不应该是不符合现实生活的，比如：钢铁侠的战衣制作成本，钢铁侠的战衣在现实生活中是不存在的不能用价格衡量。
3. 当推荐的topic与query毫无关联时，判定为显著错误。例如，query为 “瑞典央行为何首次在十年后将利率下调 50 个基点”，而topic为 “瑞典电信业的未来”“诺贝尔奖得主的经济背景”，query核心围绕经济问题，推荐话题却偏离主题，属于显著错误。
4. 预测类的推荐话题，比如：马斯克的下一个创新是什么？
5. 无法改变的事实，比如：如何提高鹰的视力。
6. 除了理想汽车的其他品牌车辆细节信息，例如：es8多长。
7. 推荐关于”理想one“这款车型的信息。
8. 推荐话题的不通顺，句子本身是个病句，不符合逻辑，句子不全，中英文混乱，例如：世界地区社会特点如何？。

## 以下情况可标注为合适：
1. 话题可具有泛化性，例如：溧阳市有哪些五星级酒店？可以给用户推荐：溧阳市的历史文化有哪些？，并不一定沿着酒店推荐
2. 推荐的话题若涉及query相关的人物、事物或能够吸引用户点击，即具备吸引能力。以query“熊出没” 为例，topic如 “熊大熊二的性格特点是什么”“光头强的日常工作是什么”，聚焦于 “熊出没” 中的人物，可视为具有吸引力的优质话题。

## 输出要求
根据上述要求，请你判断下面这个case是否是合适的，请选择：A. 合适；B. 不合适。请说明理由
问题是：{query}
回复内容是：{answer}
推荐话题是：{doc}"""

user_template = """请严格以以下JSON回复，非Markdown格式：
{
    "ans": "A" or "B" // 代表着合适与不合适
    "reason": "给出理由说明"
}"""

DEFAULT_SYSTEM_PROMPT = "You are a helpful assistant."
MODEL_URLS = {
    'gpt-4o': "https://xuzhou1-tool-llm.ontest.fc.chj.cloud/gpt-4o",
    'claude-3_5-sonnet': "https://xuzhou1-tool-llm.ontest.fc.chj.cloud/claude-3_5-sonnet",
    'deepseek-v3': "https://xuzhou1-tool-llm.ontest.fc.chj.cloud/deepseek-v3",
    'deepseek-r1': "https://xuzhou1-tool-llm.ontest.fc.chj.cloud/deepseek-r1",
    'deepseek-r1-distill-qwen-32b': "https://xuzhou1-tool-llm.ontest.fc.chj.cloud/deepseek-r1-distill-qwen-32b",
}

select_sql = """WITH parsed AS (
  -- 原有的parsed CTE保持不变
  SELECT
    EXPLODE(from_json(
      message_list,
      'array<struct<
      new_session_id:string,
      record_id:string,
      domain:string,
      api_name:string,
      category:string,
      media_type:string,
      face_screen:string,
      query:string,
      show_text_list:array<string>,
      click_text:string,
      output:string,
      request_time:string,
      is_hit:int
      >>'
      )) AS message
  FROM {table}
  WHERE dt BETWEEN '{dt}' AND '{last_dt}' AND type = 'hit'
),
random_sample AS (
  SELECT
    message.query,
    message.output AS ans,
    message.show_text_list
  FROM parsed
  WHERE 
    message.query IS NOT NULL AND 
    message.query != '' AND
    message.api_name = 'QASearch' AND
    message.category IN (
      '其他问答', '人物', '城市', '健康', '生物', '公司', '景点', '城市景点推荐',
      '音乐', '世界之最', '出游美食', '影视', '文学', '地理', '地理通用', '国家',
      '历史', '教育', '法律', '房产', '旅游', '人工智能', '交通出行',
      '活动', '城市活动推荐'
    )
  ORDER BY RAND()  -- 随机排序
  LIMIT 200        -- 取前200条
)

-- 输出随机样本
SELECT * FROM random_sample;"""

# -------------------------------------------


def request_llm(history, model='gpt-4o', n=1, temperature=1, max_tokens=4096, show_payload=False):
    if not history:
        return {'error': '传入的history为空！'}
    if not history[0]:
        history[0] = DEFAULT_SYSTEM_PROMPT

    messages = [{"role": ["assistant", "user"][i % 2], "content": message} for i, message in enumerate(history)]
    messages[0]['role'] = 'system'

    url = MODEL_URLS.get(model)
    if url is None:
        print("当前仅支持以下模型：", ", ".join(MODEL_URLS.keys()))
        raise ValueError(f"此模型尚未支持：{model}")

    if model in ['deepseek-r1', 'deepseek-r1-distill-qwen-32b'] and n != 1:
        print(f"【警告】deepseek-r1模型的n只能设置为1，当前为{n}，已自动改为1")
        n = 1

    headers = {'Content-Type': 'application/json'}
    payload = {
        "messages": messages,
        "n": n,
        "temperature": temperature,
        "max_tokens": max_tokens
    }
    if show_payload:
        print(payload)

    try:
        response = requests.request("POST", url, headers=headers, json=payload, timeout=120)
        response_data = response.json()
        if response.status_code != 200:
            print(f"请求失败，状态码为{response.status_code}，response为\n{response.text}")
    except Exception as e:
        logging.debug("【request_llm】response结构化出现错误。")
        logging.debug(response.text)
        logging.debug('API调用异常：{}'.format(e))
        logging.debug(f"payload is {payload}")
        response_data = {"error": "API调用异常。"}
        logging.debug("-" * 327)
    return payload, response_data


def get_response(system_pro: str, user_pro: str, model="gpt-4o"):
    try:
        _, response_data = request_llm([system_pro, user_pro], model=model)
        res = response_data['choices'][0]['message']['content']
        res = eval(res)
        return res
    except Exception as e:
        return "error"


def get_acc(df, retry_max=5):
    total_num = 0
    right_num = 0
    df_len = len(df)
    for idx in range(df_len):
        data = df.iloc[idx]
        query = data.get("query", '')
        ans = data.get("ans", '')
        show_text_list = []
        try:
            show_text_list = eval(data.get("show_text_list", []))
        except Exception as e:
            print(1, e)
            continue
        total_num += len(show_text_list)
        for tpoic in show_text_list:
            try:
                system_message = system_template.format(query=query, answer=ans, doc=tpoic)
                response = None
                for attempt in range(retry_max):
                    try:
                        response = get_response(system_message, user_template)
                        if response.get('ans', '') in ['A', 'B']:
                            break  # 有效响应则跳出重试循环
                    except Exception as e:
                        print(2, e)
                        continue  # 重试直至达到最大次数
                if response and response.get('ans', '') == 'A':
                    right_num += 1
            except Exception as e:
                print(3, e)
                continue
    return right_num / total_num if total_num > 0 else 0, right_num, total_num


def get_topic_acc(spark, input_table, dt):
    """使用Spark处理单日数据"""
    # 1. 从Hive表读取数据
    from datetime import datetime, timedelta
    sunday = datetime.strptime(dt, "%Y-%m-%d")
    monday = sunday + timedelta(days=-6)  # 周日减去6天 = 本周一
    monday = monday.strftime('%Y-%m-%d')
    query = select_sql.format(table=input_table, dt=monday, last_dt=dt)
    df = spark.sql(query)
    if df.count() == 0:
        print(f"No data found for date {dt}")
        return
    df = df.toPandas()
    # 2. 计算准确率
    acc, right_num, total_num = get_acc(df)
    # 3. 打印所有统计指标
    print("##"*20)
    print(f"ACC: {acc}")
    print(f"right_num: {right_num}")
    print(f"total_num: {total_num}")
    print("##"*20)


def main():
    """主函数"""
    # 创建SparkSession
    spark = SparkSession.builder \
        .appName("ProcessVinSession") \
        .enableHiveSupport() \
        .getOrCreate()
    # 从环境变量获取日期
    dt = spark.sparkContext.getConf().get("spark.app.args.dt")
    if not dt:
        raise ValueError("Environment variable 'DT' is not set. Please set DT=yyyy-MM-dd")
    print(f"Processing data for date: {dt}")
    # 参数配置
    input_table = "ssai_ods.topic_recommend_group_v2_df"  # 输入Hive表
    try:
        get_topic_acc(spark, input_table, dt)
        print("Processing completed successfully")
    except Exception as e:
        print(f"Error during processing: {str(e)}")
        raise
    finally:
        spark.stop()


if __name__ == "__main__":
    main()
