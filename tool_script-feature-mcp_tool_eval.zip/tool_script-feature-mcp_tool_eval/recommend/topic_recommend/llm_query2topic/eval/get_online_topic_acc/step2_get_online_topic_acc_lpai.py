import os
import os.path
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta
from typing import Iterator

import pandas as pd
from datagrid import get_client
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, explode, from_json, rand, size
from pyspark.sql.types import *
from tqdm import tqdm

from utils.llm_utils.serverless_function import request_llm
from recommend.topic_recommend.llm_query2topic.meta import *

system_template = """有一个推荐系统对于输入的问题和回复内容出了一个推荐话题，推荐话题可以是关于问题的扩展、回复内容的延伸。你现在是一个优秀的标注人员，来判断推荐话题是否是合适的。

## 当存在以下情况的时候，应标为不合适：
1. 只要无明显的逻辑错误就不算错，连贯行为应该不是错误的，例如：说到博物馆，就会提到参观。但其中有很多相关的逻辑性关系是很难发现的, 例如一说到武则天我们就会想到狄仁杰。
2. 推荐的话题不应该是不符合现实生活的，比如：钢铁侠的战衣制作成本，钢铁侠的战衣在现实生活中是不存在的不能用价格衡量。
3. 当推荐的topic与query毫无关联时，判定为显著错误。例如，query为 “瑞典央行为何首次在十年后将利率下调 50 个基点”，而topic为 “瑞典电信业的未来”“诺贝尔奖得主的经济背景”，query核心围绕经济问题，推荐话题却偏离主题，属于显著错误。
4. 预测类的推荐话题，比如：马斯克的下一个创新是什么？
5. 无法改变的事实，比如：如何提高鹰的视力。
6. 除了理想汽车的其他品牌车辆细节信息，例如：es8多长。
7. 推荐关于”理想one“这款车型的信息。
8. 推荐话题的不通顺，句子本身是个病句，不符合逻辑，句子不全，中英文混乱，例如：世界地区社会特点如何？。

## 以下情况可标注为合适：
1. 话题可具有泛化性，例如：溧阳市有哪些五星级酒店？可以给用户推荐：溧阳市的历史文化有哪些？，并不一定沿着酒店推荐
2. 推荐的话题若涉及query相关的人物、事物或能够吸引用户点击，即具备吸引能力。以query“熊出没” 为例，topic如 “熊大熊二的性格特点是什么”“光头强的日常工作是什么”，聚焦于 “熊出没” 中的人物，可视为具有吸引力的优质话题。

## 输出要求
根据上述要求，请你判断下面这个case是否是合适的，请选择：A. 合适；B. 不合适。请说明理由
问题是：{query}
回复内容是：{answer}
推荐话题是：{doc}"""

user_template = """请严格以以下JSON回复，非Markdown格式：
{
    "ans": "A" or "B" // 代表着合适与不合适
    "reason": "给出理由说明"
}"""


def write_iterator_to_csv(iterator: Iterator[pd.DataFrame], file_path: str):
    # 检查文件是否存在，以确定是否需要写入表头
    file_exists = False
    try:
        with open(file_path, 'r', newline='', encoding='utf-8') as file:
            if file.read(1):  # 如果能读取到至少一个字符，说明文件存在且非空
                file_exists = True
    except FileNotFoundError:
        pass

    # 写入数据
    for df in iterator:
        # 如果文件不存在或者这是第一个 DataFrame，则包含表头
        mode = 'a' if file_exists else 'w'
        header = not file_exists

        # 将 DataFrame 写入 CSV 文件
        df.to_csv(file_path, mode=mode, index=False, header=header)

        # 写入完成后，将文件存在标志设置为 True
        file_exists = True


def load_dip_dataset(client, datasetcode: str, version: str):
    datagrid_cache_dir = "/lpai/volumes/ss-sai-bd-ga/songyanmei/sym/output2"
    ite = client.load_dataset_cached_local_iterator(
        dataset_id=f"{datasetcode}",
        version_id=f"{version}",
        cache_dir=datagrid_cache_dir,
        filter_expression=None, batch_size=10000, verbose=True, progress=True)
    count = 0
    import pandas as pd
    dataframes = []
    for it in ite:
        if False:
            print(it)
            break
        dataframes.append(it)
        # (row,_)  = it.shape
        # count += row
    # print(f"total rows has been loaded is : {count}")
    # 合并所有 DataFrame
    merged_df = pd.concat(dataframes, ignore_index=True)
    # 删除dip数据集内置的列
    # '__rowid', '__objects','__rowschema','__rowimporttime' 是dip数据集的内置列，业务方使用的时候可以手动过滤下
    merged_df = merged_df.drop(columns=['__rowid', '__objects', '__rowschema', '__rowimporttime'])
    print(merged_df.shape)
    print(merged_df)


def get_dates_from_week_string(week_str):
    year, week = week_str.split("-W")
    year = int(year)
    week = int(week)
    first_day_of_year = datetime(year, 1, 1)
    first_week_start_date = first_day_of_year - timedelta(days=first_day_of_year.weekday())
    target_week_start_date = first_week_start_date + timedelta(weeks=week - 1)
    return [(target_week_start_date + timedelta(days=i)).date().isoformat() for i in range(7)]


def get_response(system_pro: str, user_pro: str, model="gpt-4o"):
    try:
        _, response_data = request_llm([system_pro, user_pro], model=model)
        res = response_data['choices'][0]['message']['content']
        res = eval(res)
        return res
    except Exception as e:
        return "error"


def _eval_row(row, retry_max=5):
    query = row.get("query", '')
    ans = row.get("output", '')
    show_text_list = row.get("show_text_list", []) or []

    right = 0
    total = len(show_text_list)
    labels = []

    for topic in show_text_list:
        if topic == "更多百科小知识":
            right += 1
            labels.append("1")
        system_message = system_template.format(query=query, answer=ans, doc=topic)
        # 带重试的 API 调用
        response = None
        for _ in range(retry_max):
            try:
                resp = get_response(system_message, user_template)
                # 只认 A / B 的回复
                if resp.get("ans", '') in ['A', 'B']:
                    response = resp
                    break
            except Exception:
                continue

        if response and response.get("ans", '') == 'A':
            right += 1
            labels.append("1")
        else:
            labels.append("0")
    row["labels"] = labels

    return right, total, row


def get_acc(df_data, save_sample_data_path, retry_max=5, max_workers=5):
    right_sum = 0
    total_sum = 0
    row_list = []

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {
            pool.submit(_eval_row, row, retry_max): idx
            for idx, row in df_data.iterrows()
        }
        for fut in tqdm(as_completed(futures), total=len(futures), desc="Running"):
            try:
                right, total, row = fut.result()
                right_sum += right
                total_sum += total
                row_list.append(row)
            except Exception as e:
                continue
    acc = right_sum / total_sum if total_sum > 0 else 0
    df_label = pd.DataFrame(row_list)
    df_label.to_csv(save_sample_data_path, sep="\t", index=False)
    return acc, right_sum, total_sum


def process(week_dir):
    spark = (SparkSession.builder
             .appName("merge_and_sample")
             .getOrCreate())
    csv_dir = os.path.join(week_dir, "*.csv")
    save_sample_data_path = os.path.join(week_dir, "smaple.tsv")
    df_raw = (spark.read
              .option("header", True)
              .option("multiLine", True)
              .option("escape", '"')
              .csv(csv_dir))
    msg_schema = ArrayType(StructType([
        StructField("query", StringType()),
        StructField("output", StringType()),
        StructField("show_text_list", ArrayType(StringType()))
    ]))
    df_parsed = (df_raw
                 .withColumn("msg_arr", from_json(col("message_list"), msg_schema))
                 .select(explode("msg_arr").alias("msg")))
    df_filtered = df_parsed.filter(size(col("msg.show_text_list")) > 0)
    df_trimmed = df_filtered.select(
        col("msg.query").alias("query"),
        col("msg.output").alias("output"),
        col("msg.show_text_list").alias("show_text_list")
    )
    df_sampled = df_trimmed.orderBy(rand()).limit(200)
    pdf = df_sampled.toPandas()
    spark.stop()
    return get_acc(pdf, save_sample_data_path)


if __name__ == "__main__":
    W_week = ["2025-W45"]
    os.environ['dip.env'] = 'prod'
    os.environ['dip.x-dip-spacecode'] = 'sai-dp'
    os.environ['dip_refresh_token'] = 'BJ:3NZKSSjCqcW67q0RjzN'
    os.environ['dip.x-chj-gwtoken'] = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJud01DajhpZm9FMEFTZVFrVkF5V2dBUThQVHpldmJMaSJ9.BS9D24qhhIW-96wecYvgLCWicOvIeym-IeWk6xDf3pQ'

    temp_root = "data/temp"
    excel_path = f"{DATA_DIR}/eval/get_online_topic_acc/话题推荐周准确率.xlsx"
    if not os.path.exists(excel_path):
        res_df = pd.DataFrame(columns=["time", "acc", "right_sum", "total_sum"])
        res_df.to_excel(excel_path, index=False)

    print(os.environ['dip.env'], os.environ['dip.x-dip-spacecode'], os.environ['dip_refresh_token'])
    client = get_client(env=os.environ['dip.env'], space_code=os.environ['dip.x-dip-spacecode'],
                        refresh_token=os.environ['dip_refresh_token'], x_chj_gwtoken=os.environ['dip.x-chj-gwtoken'])
    # database = "ssai_ods"
    # table = "topic_recommend_group_v2_df"
    # partition_spec = "dt=2025-05-28"
    # cache_dir = 'data/temp'
    # datagrid_cache_dir = "data/temp"

    metric_list = []
    for w_week in W_week:
        date_list = get_dates_from_week_string(w_week)
        cache_dir = os.path.join(temp_root, "cache")
        week_dir = os.path.join(temp_root, w_week)
        if not os.path.exists(week_dir):
            os.makedirs(week_dir)

        for dt in date_list:
            try:
                path = f"jfs://jfs-public/data_sai_dp/ssai_ods/topic_recommend_group_v2_df/dt={dt}/type=hit"
                save_data_path = os.path.join(week_dir, f"{dt}.csv")
                if os.path.exists(save_data_path):
                    continue
                ite = client.load_data_cache_local_iterator(
                    path=path,
                    cache_dir=cache_dir,
                    filter_expression=None, batch_size=10000, verbose=False, progress=True)
                dataframes = []
                for it in ite:
                    dataframes.append(it)
                merged_df = pd.concat(dataframes, ignore_index=True)
                merged_df.to_csv(save_data_path, index=False)
                print(f"文件已成功保存至: {save_data_path}")
            except Exception as e:
                continue

        print("finish load to the local")

        acc, right_sum, total_sum = process(week_dir)
        print(acc, right_sum, total_sum)
        metric_list.append({
            "time": w_week,
            "acc": acc,
            "right_sum": right_sum,
            "total_sum": total_sum
        })

        subprocess.run("clear")

        try:
            res_df = pd.DataFrame(metric_list)
            with pd.ExcelWriter(excel_path, engine='openpyxl', mode='a', if_sheet_exists='replace') as writer:
                res_df.to_excel(writer, index=False)
                print(f"指标已成功保存至： {excel_path}  文件")
        except Exception as e:
            print(f"保存 Excel 文件时出错: {e}")

    # if False:
    #     import subprocess

    #     # 删除cache 文件和 temp文件
    #     for w_week in W_week:
    #         del_path = os.path.join(temp_root, w_week)
    #         subprocess.run(f"rm -rf {del_path}")

    # # 删除cache
    # if False:
    #     for root, dirs, files in os.walk(cache_dir):
    #         for file in files:
    #             file_path = os.path.join(root, file)
    #             try:
    #                 os.remove(file_path)
    #             except Exception as e:
    #                 print(f"删除失败: {file_path}, 原因: {e}")

    # if True:
    #     df_iterator = client.load_table_in_iterator(database=database, table=table, partition_spec=partition_spec,
    #                                                 filter_expression=None, batch_size=10000, verbose=True,
    #                                                 progress=True)
    #     dataframes = []
    #     # write_iterator_to_csv(df_iterator,"/lpai/volumes/ss-sai-bd-ga/songyanmei/sym/output2")
    #     for df in df_iterator:
    #         dataframes.append(df)
    #     merged_df = pd.concat(dataframes, ignore_index=True)
    #     merged_df.to_csv('data/temp/aa.csv', index=False)

    # filter_expression = "select * where create__time_ts>'2023-10-19 16:00:00'"
    # filter_expression = "select * where dt >'2025-6-2 16:00:00'"
    # it = client.load_table_in_iterator(database=database, table=table, partition_spec=partition_spec,
    #                                    filter_expression=filter_expression, verbose=True, progress=True)
    # for item in it:
    #     print(item)

    # python -m recommend.topic_recommend.llm_query2topic.eval.get_online_topic_acc.step2_get_online_topic_acc_lpai
