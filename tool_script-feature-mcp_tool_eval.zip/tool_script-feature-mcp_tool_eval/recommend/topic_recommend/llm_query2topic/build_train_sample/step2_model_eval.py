import json
import time
import hashlib
import requests
import threading
import traceback
import pandas as pd
from tqdm import tqdm
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from utils.nlp_utils.ner_tool import request_ner
from recommend.topic_recommend.llm_query2topic.eval.get_online_topic_acc.step2_get_online_topic_acc_lpai import *
from recommend.topic_recommend.llm_query2topic.build_train_sample.template import *


lock = threading.Lock()
progress_lock = threading.Lock()
progress_bar = None  # 全局 tqdm 进度条对象

config = {
    "tr-v3-full-qwen3-8b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/tr-v3-full-qwen3-8b-d231-lhczxz/v1/chat/completions",
    "tr-v3-lora-qwen3-8b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/tr-v3-lora-qwen3-8b-595f-iosblc/v1/chat/completions",
    "tr-v4-lora-qwen3-8b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/tr-v4-lora-qwen3-8b-e3e8-tgbfww/v1/chat/completions",
    "tr-v4-lora-qwen3-32b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/tr-v4-lora-qwen3-32b-0fa7-faeyur/v1/chat/completions",
    "tr-v4-dpo-qwen3-32b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/tr-v4-dpo-qwen3-32b-91ef-asjuzb/v1/chat/completions",
    "tr-v4-lora-qwen3-32b-think": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/tr-v4-lora-qwen3-32b-think-dfe5-swiljv/v1/chat/completions",

}
headers = {"Content-Type": "application/json"}
# model_list = ["tr-v3-full-qwen3-8b", "tr-v3-lora-qwen3-8b", ""]


class Eval_Model():

    def __init__(self, model=None):
        self.model = model
        assert model in config, f"不支持{self.model}, 仅支持一下模型:\n{config.keys()}"

    @staticmethod
    def chat_with_lpai_LLM(query, model, url) -> str:
        instruction = instruction_template.format(user_query=query)
        payload = {
            "model": model,
            # "temperature": 1,
            # "n": 1,
            # "max_tokens": 1000,
            "messages": [{"role": "user", "content": instruction}],
            "stream": False
        }
        res = requests.post(url, json=payload, headers=headers)
        return json.loads(res.text)["choices"][0]["message"]["content"]

    @staticmethod
    def get_nlu_ner(query) -> list:
        try:
            ner_tuple = request_ner(query, need_parse=False, need_group=False)
            return ner_tuple
            # if tag != "rule":
            #     most_pro = ner_tuple[0][0]
            #     return [f'{most_pro["norm"] +"@"+ most_pro["tag"]}', f'{most_pro["norm"]}']
            # else:
            #     most_pro = ner_tuple[1][0]

        except Exception as e:
            return []

    @staticmethod
    def generate_index_id(query):
        salt = str(time.time_ns())  # 纳秒时间戳，或用其他唯一值
        source = (query.lower() + salt).encode('utf-8')
        index_id = hashlib.md5(source).hexdigest()[:16]  # 截取前16位
        return index_id

    @staticmethod
    def process_row_and_write(data, save_path, model, url):
        global progress_bar
        query = data["query"]
        # record_id = data["record_id"]
        # domain = data["domain"]
        # api_name = data["api_name"]
        # category = data["category"]
        # show_text_list = data["show_text_list"]

        try:
            res = Eval_Model.chat_with_lpai_LLM(query=query, model=model, url=url)
            dict_res = eval(res)
            # realated_knowledge = dict_res.get("realated_knowledge", "")
            # llm_ner = dict_res.get("llm_ner", "")
            ner = Eval_Model.get_nlu_ner(query=query)
            flag = dict_res.get("flag", "")
            if flag == "ACCEPT":
                recommendation_topics = dict_res.get("recommendation_topics", "")
                recommendation_topics_flat = [item for sublist in recommendation_topics.values() for item in sublist]
                es_data = {
                    "id": Eval_Model.generate_index_id(query=query),
                    "query": query,
                    "entity": ner,
                    "domain": "common",
                    "topic_list": recommendation_topics_flat
                }
            else:
                es_data = {
                    "id": Eval_Model.generate_index_id(query=query),
                    "query": query,
                    "entity": ner,
                    "domain": "common",
                    "topic_list": "REJECT"
                }
        except Exception as e:
            print(e)
            return

        with lock:
            with open(save_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(es_data, ensure_ascii=False) + "\n")

        with progress_lock:
            progress_bar.update(1)

    def build_database_data(self, data_path: str, save_path: str, max_workers=5):
        global progress_bar
        df = pd.read_excel(data_path)
        open(save_path, 'w').close()

        progress_bar = tqdm(total=len(df), desc="Processing")

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            for i in range(len(df)):
                executor.submit(Eval_Model.process_row_and_write, df.iloc[i],
                                save_path, model=self.model, url=config[self.model])

        progress_bar.close()

    def eval_online_data(self, online_data: str, online_data_eval_path: str):
        lock = threading.Lock()
        # 读入所有行（假设不是超大文件）
        with open(online_data, "r", encoding="utf-8") as f:
            lines = [json.loads(line) for line in f]

        def process_line(line):
            query = line["query"]
            try:
                res = Eval_Model.chat_with_lpai_LLM(
                    query=query,
                    model=self.model,
                    url=config[self.model]
                )
                dict_res = eval(res)  # ⚠️你已验证安全

                line.update({
                    "llm_ner": dict_res["ner"],
                    "realated_knowledge": dict_res["realated_knowledge"],
                    "recommendation_topics": dict_res["recommendation_topics"]
                    if dict_res["flag"] == "ACCEPT" else "REJECT"
                })

                # 写入文件时加锁
                with lock:
                    with open(online_data_eval_path, "a", encoding="utf-8") as f_out:
                        f_out.write(json.dumps(line, ensure_ascii=False) + "\n")

            except Exception as e:
                print(f"处理 query 出错: {query}\n错误: {e}")

        # 启用线程池 + 进度条
        with ThreadPoolExecutor(max_workers=64) as executor:
            futures = [executor.submit(process_line, line) for line in lines]

            for _ in tqdm(as_completed(futures), total=len(futures), desc="Processing"):
                pass

    def eval_base_data(self, row_data_path, max_retries=3):
        row_data_path = Path(row_data_path)
        save_llm_path = row_data_path.with_stem(row_data_path.stem + f"_{self.model}")
        save_llm_path = Path(save_llm_path)
        save_label_path = save_llm_path.with_stem(save_llm_path.stem + f"_label")

        # 请求LLM---------------------------------------
        df = pd.read_csv(row_data_path, sep='\t')

        def process_row(row):
            query = row["query"]
            retries = 0
            while retries < max_retries:
                try:
                    res = Eval_Model.chat_with_lpai_LLM(
                        query=query,
                        model=self.model,
                        url=config[self.model]
                    )
                    if "dpo" or "think" in self.model:
                        start_index = res.find("{")
                        end_index = res.rfind("}") + 1
                        json_data = res[start_index:end_index]
                        dict_res = json.loads(json_data)
                    else:
                        dict_res = json.loads(res)
                    recommendation = dict_res.get("recommendation_topics", {})
                    topic_list = (
                        recommendation.get("topic_transition", []) +
                        recommendation.get("generalization", []) +
                        recommendation.get("attractiveness", [])
                    )
                    realated_knowledge = dict_res["realated_knowledge"]
                    row["related_knowledge"] = json.dumps(realated_knowledge, ensure_ascii=False, indent=2)
                    row["topic_list"] = json.dumps(topic_list, ensure_ascii=False, indent=2)
                    row["topic_list_num"] = len(topic_list)

                    return row

                except Exception as e:
                    retries += 1
                    raw_line = locals().get('line', '<无法获取原始行>')
                    print('='*60)
                    print(f'原始内容: {raw_line!r}')
                    print(f'异常类型: {type(e).__name__}')
                    print(f'异常信息: {e}')
                    print('--- traceback ---')
                    traceback.print_exc()
                    print('='*60)
                    # print(f"Query失败: {query}, 第 {retries} 次重试, 错误: {e}")
                    time.sleep(1)  # 稍作等待，防止频率过快

                # 超过重试次数，记录空值
                print(f"Query失败: {query}，已达最大重试次数，跳过")
                row["related_knowledge"] = []
                row["topic_list"] = []
                row["topic_list_num"] = 0
                return row
        results = []
        with ThreadPoolExecutor(max_workers=20) as executor:
            futures = [executor.submit(process_row, row) for _, row in df.iterrows()]
            for future in tqdm(as_completed(futures), total=len(futures), desc="Processing"):
                results.append(future.result())

        result_df = pd.DataFrame(results)
        result_df.to_csv(save_llm_path, sep='\t', index=False, encoding='utf-8')

        print(f"LLM处理完成，结果保存至： {save_llm_path}")
        print("请稍等，马上打标签！")
        # 准确率标签---------------------------------------
        result_df["topic_list_correct"] = result_df["topic_list_correct"].astype(object)

        def process_row(idx, data):
            try:
                query = data["query"]
                ans = data["answer"]
                topic_list = eval(data["topic_list"])
                topic_list_correct = []
                for topic in topic_list:
                    system_message = system_template.format(query=query, answer=ans, doc=topic)
                    response = None
                    for _ in range(max_retries):
                        try:
                            resp = get_response(system_message, user_template)
                            if resp.get("ans", '') in ['A', 'B']:
                                response = resp
                                break
                        except Exception:
                            continue
                    if response and response.get("ans", '') == 'A':
                        topic_list_correct.append(1)
                    else:
                        topic_list_correct.append(0)
                return idx, topic_list_correct
            except Exception as e:
                return idx, []

        results = []
        # 使用线程池并行处理
        with ThreadPoolExecutor(max_workers=5) as executor:
            futures = [executor.submit(process_row, idx, row) for idx, row in result_df.iterrows()]

            for future in tqdm(as_completed(futures), total=len(futures), desc="Processing"):
                idx, topic_list_correct = future.result()
                result_df.at[idx, "topic_list_correct"] = json.dumps(topic_list_correct, ensure_ascii=False, indent=2)
                result_df.at[idx, "topic_list_correct_num"] = sum(topic_list_correct)

        # 保存结果
        result_df.to_csv(save_label_path, sep='\t', index=False, encoding='utf-8')
        print(f"Label处理完成，结果保存至： {save_label_path}")

    def eval_rj_data(self, row_data_path, max_retries=3):
        row_data_path = Path(row_data_path)
        save_rj_path = row_data_path.with_stem(row_data_path.stem + f"_{self.model}")

        df = pd.read_csv(row_data_path, sep='\t')

        def process_row(row):
            query = row["query"]
            retries = 0
            while retries < max_retries:
                try:
                    res = Eval_Model.chat_with_lpai_LLM(
                        query=query,
                        model=self.model,
                        url=config[self.model]
                    )
                    if "dpo" or "think" in self.model:
                        start_index = res.find("{")
                        end_index = res.rfind("}") + 1
                        json_data = res[start_index:end_index]
                        dict_res = json.loads(json_data)
                    else:
                        dict_res = json.loads(res)
                    flag = dict_res.get("flag", None)
                    if flag == "REJECT":
                        row["predict"] = 1
                    else:
                        row["predict"] = 0
                    return row

                except Exception as e:
                    retries += 1
                    raw_line = locals().get('line', '<无法获取原始行>')
                    print('='*60)
                    print(f'原始内容: {raw_line!r}')
                    print(f'异常类型: {type(e).__name__}')
                    print(f'异常信息: {e}')
                    print('--- traceback ---')
                    traceback.print_exc()
                    print('='*60)
                    # print(f"Query失败: {query}, 第 {retries} 次重试, 错误: {e}")
                    time.sleep(1)  # 稍作等待，防止频率过快

                # 超过重试次数，记录空值
                print(f"Query失败: {query}，已达最大重试次数，跳过")
                row["predict"] = 0
                return row

        results = []
        with ThreadPoolExecutor(max_workers=20) as executor:
            futures = [executor.submit(process_row, row) for _, row in df.iterrows()]
            for future in tqdm(as_completed(futures), total=len(futures), desc="Processing"):
                results.append(future.result())

        result_df = pd.DataFrame(results)
        result_df.to_csv(save_rj_path, sep='\t', index=False, encoding='utf-8')
        print(f"模型拒识能力测评已经完成，结果输出至： {save_rj_path} ")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description='模型评估脚本')
    parser.add_argument('--model', type=str, required=True,
                        help='指定要使用的模型名称，例如：tr-v3-lora-qwen3-8b')
    args = parser.parse_args()
    DATA_ROOT = "data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_train_sample"
    data_path = f"{DATA_ROOT}/train_data/row_eval_data.xlsx"
    save_path = f"{DATA_ROOT}/train_data/eval_data_full.jsonl"
    eval_model = Eval_Model(model=args.model)
    # eval_model.build_database_data(data_path, save_path, max_workers=10)
    # eval_model.eval_online_data("data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_train_sample/step2_model_eval/eval-20250526-20250601.jsonl",
    #                             "data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_train_sample/step2_model_eval/eval-20250526-20250601-dpo.jsonl")
    eval_base_data = f"{DATA_ROOT}/step2_model_eval/model_eval_base_1.tsv"
    rj_base_data = f"{DATA_ROOT}/step2_model_eval/model_reject_eval_base_1.tsv"
    eval_model.eval_base_data(eval_base_data)
    # eval_model.eval_rj_data(rj_base_data)

    # python -m recommend.topic_recommend.llm_query2topic.build_train_sample.step2_model_eval --model
