import json
from typing import List
from recommend.topic_recommend.llm_query2topic.build_train_sample.template import *
from recommend.topic_recommend.llm_query2topic.meta import *

# demo data
# {
#     "instruction": "你是一个话题推荐专家，请根据用户问题，从以下三个能力维度各推荐三个相关话题：\n1. 话题转移能力（Topic Transition）: 与原话题相关且可自然转移的话题\n2. 泛化能力（Generalization）: 从原话题泛化出的上层或宽泛话题\n3. 吸引力能力（Attractiveness）: 更吸引人、更具传播性的相关话题\n\n你可以将任务拆解为以下三个步骤：\nStep 1: 识别问题中的实体（NER），抽取出关键名词短语。\nStep 2: 对这些实体进行知识联想（Knowledge Expansion），列出与其紧密相关的概念。\nStep 3: 思考一下用户的query是否有生成推荐话题的价值且query中应该包含实体；具有一定的信息量；没有歧义（包括人名歧义等）；不应该包含涉及政治敏感、低俗、暴力、负面或其他不当内容。如果满足以上生成条件则继续生成推荐话题，如果不满足请主动拒绝生成推荐话题。\nStep 4: 根据实体和扩展知识，生成推荐话题，分别对应三种能力。\n\n请仅以如下 JSON 格式输出（注意字段名拼写）：\n{\n    \"ner\":[...],  // 从 user 的问题中提取出的实体\n    \"realated_knowledge\":[...],  // 每个实体对应的相关知识词\n    \"flag\": ACCEPT or REJECT,  // 是否生成推荐话题\n    \"recommendation_topics\":{   // 根据三个能力生成的推荐话题\n        \"topic_transition\":[...],  // 与原话题相关且可自然转移的话题\n        \"generalization\":[...],    // 从原话题泛化出的上层或宽泛话题\n        \"attractiveness\":[...]     // 更吸引人、更具传播性的相关话题\n    }\n}\n\n用户问题：\n有一首歌那个里边儿会提到一个说走吧说干巴巴的老爷们儿那是什么歌\n",
#     "input": "",
#     "output": "{\n    \"ner\": \"[\\\"歌\\\", \\\"说走吧\\\", \\\"干巴巴的老爷们儿\\\"]\",\n    \"realated_knowledge\": \"[\\\"《老男孩》\\\", \\\"筷子兄弟\\\", \\\"肖央\\\", \\\"王太利\\\", \\\"电影《老男孩》\\\", \\\"《小苹果》\\\"]\",\n    \"flag\": \"ACCEPT\",\n    \"recommendation_topics\": {\n        \"topic_transition\": [\n            \"肖央最火的电影有哪些\",\n            \"筷子兄弟的经典歌曲\",\n            \"《小苹果》背后的故事\"\n        ],\n        \"generalization\": [\n            \"说走吧的歌曲是哪首\",\n            \"歌词中出现老爷们的歌\",\n            \"哪些歌有说走吧\"\n        ],\n        \"attractiveness\": [\n            \"筷子兄弟的成名之路\",\n            \"《老男孩》与梦想的故事\",\n            \"王太利和肖央的合作缘由\"\n        ]\n    }\n}"
# }


class Expand:
    def __init__(self, models: List[str]):
        self.expand_dataset = []
        self.model = models
        self.model_method_map = {
            "play": self.expand_play,
            "recitation": self.expand_recitation,
            "who_win": self.expand_who_win,
            "the_most": self.expand_the_word_most,
            "three_words": self.expand_three_words
        }

    def dataset_append(self, query, ner, realated_knowledge):
        dict_topic = {
            "ner": ner,
            "realated_knowledge": realated_knowledge,
            "flag": "REJECT",
        }
        base_dict = {
            "instruction": instruction_template.format(user_query=query),
            "input": "",
            "output": json.dumps(dict_topic, ensure_ascii=False, indent=4)
        }
        self.expand_dataset.append(base_dict)

    def expand_play(self):
        # 前缀词
        for prefix in expand_play_prefix:
            # 动画片
            for play in expand_play_list:
                query = prefix + play
                ner = [play]
                realated_knowledge = expand_play_related_list[play]
                self.dataset_append(query, ner, realated_knowledge)

        print(f"本次扩充{len(expand_play_prefix) * len(expand_play_list)}条“播放”拒绝数据！")

    def expand_recitation(self):
        # prefix
        for prefix in expand_recitatio_prefix:
            # 唐诗三百首
            for poem in expand_recitation_list:
                query = prefix + poem["title"]
                ner = [poem["title"]]
                realated_knowledge = [poem["author"]]
                self.dataset_append(query, ner, realated_knowledge)

        print(f"本次扩充{len(expand_recitatio_prefix) * len(expand_recitation_list)}条“朗诵”拒绝数据！")

    # 你和xxx谁厉害
    def expand_who_win(self):
        for ai in expand_who_win_list:
            query = f"你和{ai}更厉害"
            ner = [ai]
            realated_knowledge = [x for x in expand_who_win_list if x != ai]
            self.dataset_append(query, ner, realated_knowledge)
        print(f"本次扩充{len(expand_who_win_list)}条“谁比谁强”拒绝数据！")

    # 三个字
    def expand_three_words(self):
        for word in expand_three_words_list:
            query = f"三个{word['singular']}字读什么"
            ner = []
            realated_knowledge = [word["triple"]]
            self.dataset_append(query, ner, realated_knowledge)
        print(f"本次扩充{len(expand_three_words_list)}条“三个xx字读什么”拒绝数据！")

    # 世界之最
    def expand_the_word_most(self):
        for most in expand_the_word_most_list:
            query = f"世界上最{most['superlative']}的{most['category']}是什么"
            ner = [f"世界上最{most['superlative']}"]
            realated_knowledge = [most["name"]]
            self.dataset_append(query, ner, realated_knowledge)
        print(f"本次扩充{len(expand_the_word_most_list)}条“世界之最”拒绝数据！")

    def generate(self, save_data_path):
        for model in self.model:
            if model in self.model_method_map:
                self.model_method_map[model]()
            else:
                print(f"警告：未找到扩充类型 '{model}' 对应的扩充方法，已跳过")

        # saving
        Expand.save_data(self.expand_dataset, save_data_path)
        print(f"总共保存{len(self)}条数据至{save_data_path}")

    @staticmethod
    def save_data(data, save_path):
        with open(save_path, "w") as w_f:
            json.dump(data, w_f, indent=2, ensure_ascii=False)

    def merged_data(self, row_data, new_data):
        with open(row_data, 'r', encoding='utf-8') as f:
            existing_data = json.load(f)
        existing_data.extend(self.expand_dataset)
        with open(new_data, 'w', encoding='utf-8') as f:
            json.dump(existing_data, f, ensure_ascii=False, indent=4)
        print(f"扩充数据集已经写入{new_data}文件中！")

    def __len__(self):
        return len(self.expand_dataset)

    def __getitem__(self, idx):
        return self.expand_dataset[idx]


if __name__ == "__main__":
    model_list = ["play", "recitation", "who_win", "the_most", "three_words"]
    save_data_path = f"{DATA_DIR}/build_train_sample/train_data/topic_recommendation_instruction_v3_expand.json"
    row_dataset_path = f"{DATA_DIR}/build_train_sample/train_data/topic_recommendation_instruction_v3.json"
    new_dataset_path = f"{DATA_DIR}/build_train_sample/train_data/topic_recommendation_instruction_v3_rj.json"
    ex = Expand(model_list)
    ex.generate(save_data_path)
    ex.merged_data(row_dataset_path, new_dataset_path)

    # python -m recommend.topic_recommend.llm_query2topic.build_train_sample.step1_expand_dataset
