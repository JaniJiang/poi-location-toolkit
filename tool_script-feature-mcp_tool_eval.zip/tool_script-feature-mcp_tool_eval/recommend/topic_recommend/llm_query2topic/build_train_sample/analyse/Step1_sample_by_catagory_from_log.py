import pandas as pd
import ast
import os


def extract_first_field(val, field):
    try:
        parsed = ast.literal_eval(val) if isinstance(val, str) else val
        if isinstance(parsed, list) and len(parsed) > 0 and isinstance(parsed[0], dict):
            return parsed[0].get(field)
    except Exception:
        return None


def extract_ouput(val):
    try:
        parsed = ast.literal_eval(val) if isinstance(val, str) else val
        if isinstance(parsed, list) and len(parsed) > 0 and isinstance(parsed[0], dict):
            output_list = [session.get("output", "") for session in parsed]
            if len(output_list) == 1:
                return output_list[0]
            else:
                return ("\n" + "-" * 15 + "\n").join(output_list)
    except Exception:
        return None


def extract_merged(val):
    merged_queries = []
    nested_show_texts = []
    try:
        parsed = ast.literal_eval(val) if isinstance(val, str) else val
        if isinstance(parsed, list):
            for msg in parsed:
                if isinstance(msg, dict):
                    merged_queries.append(msg.get("query"))
                    stl = msg.get("show_text_list")
                    nested_show_texts.append(stl if isinstance(stl, list) else [])
    except Exception:
        pass
    return pd.Series({
        "merged_queries": merged_queries,
        "merged_show_text_list": nested_show_texts
    })


def expand_show_text_list(merged_show_text_list):
    try:
        if isinstance(merged_show_text_list, str):
            merged_show_text_list = ast.literal_eval(merged_show_text_list)
        if not isinstance(merged_show_text_list, list):
            return ""

        segments = []
        for topic_list in merged_show_text_list:
            if isinstance(topic_list, list):
                segments.append("\n".join(str(t) for t in topic_list if t))
        return ("\n" + "-" * 15 + "\n").join(segments) if segments else ""
    except Exception:
        return ""


def stratified_sample(df, api_name, sample_size, field="category_from_msg"):
    sub_df = df[df["api_name"] == api_name]
    dist = sub_df[field].value_counts(normalize=True)
    sampled = sub_df.groupby(field, group_keys=False).apply(
        lambda x: x.sample(n=int(round(sample_size * dist[x.name])), random_state=400)
    )
    return sampled


def main():
    # ===== 文件路径 =====
    file_path = "data/recommend/topic_recommend/log_data/曝光点击数据分析-vin_session(4.28-5.4).xlsx"
    output_slim = "data/recommend/topic_recommend/log_data/分层采样结果_精简字段_(4.28-5.4).xlsx"
    output_full = "data/recommend/topic_recommend/log_data/分层采样结果_完整信息_(4.28-5.4).xlsx"

    # ===== 读取文件 =====
    df = pd.read_excel(file_path, engine="openpyxl")

    # ===== 筛选show的case =====
    df = df[df["is_show"].astype("int") == 1]

    # ===== 提取字段 =====
    df["api_name"] = df["message_list"].apply(lambda x: extract_first_field(x, "api_name"))
    df["category_from_msg"] = df["message_list"].apply(lambda x: extract_first_field(x, "category"))
    df["output"] = df["message_list"].apply(extract_ouput)

    df_extra = df["message_list"].apply(extract_merged)
    df["merged_queries"] = df_extra["merged_queries"]
    df["merged_show_text_list"] = df_extra["merged_show_text_list"]
    df["expand_show_text_list"] = df["merged_show_text_list"].apply(expand_show_text_list)

    # ===== 添加 row_id 并筛选有效数据 =====
    df["row_id"] = df.index
    df_valid = df.dropna(subset=["api_name", "category_from_msg"])

    # ===== 分层采样 =====
    qa_sampled = stratified_sample(df_valid, "QASearch", 30)
    auto_sampled = stratified_sample(df_valid, "AUTOSearch", 20)
    sampled_df = pd.concat([qa_sampled, auto_sampled]).reset_index(drop=True)

    # ===== 精简字段表 =====
    sampled_slim = df.loc[sampled_df["row_id"], [
        "api_name", "category_from_msg", "merged_queries",
        "output", "merged_show_text_list", "expand_show_text_list"
    ]]

    # ===== 保存结果 =====
    os.makedirs(os.path.dirname(output_slim), exist_ok=True)
    sampled_slim.to_excel(output_slim, index=False)
    sampled_df.to_excel(output_full, index=False)

    print("✅ 分层采样完成，结果已保存：")
    print(f"  ➤ 精简版：{output_slim}")
    print(f"  ➤ 完整版：{output_full}")


if __name__ == "__main__":
    main()
    # python -m recommend.topic_recommend.train_LLM.Step1_sample_by_catagory_from_log
