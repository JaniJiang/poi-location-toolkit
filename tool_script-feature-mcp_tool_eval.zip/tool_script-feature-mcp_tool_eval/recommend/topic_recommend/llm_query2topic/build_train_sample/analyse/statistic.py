import os
import json
import pandas as pd
from tqdm import tqdm
from collections import Counter


def get_produce_source(data_path: os.path) -> None:
    counter = Counter()
    with open(data_path, "r") as f:
        for row in f:
            data = json.loads(row)
            counter[data["produce_source"]] += 1
    for source, count in counter.most_common():
        print(f"{source}: {count}")
    # 大模型生成: 6834
    # 人工撰写: 1028


def divide_two_source(data_path: os.path) -> None:
    save_path_big_model_source = r"data/recommend/topic_recommend/train_data/save_path_big_model_source.jsonl"
    save_path_manual_source = r"data/recommend/topic_recommend/train_data/save_path_manual_source.jsonl"

    with open(data_path, "r", encoding="utf-8") as infile, \
            open(save_path_big_model_source, "a", encoding="utf-8") as big_model_outfile, \
            open(save_path_manual_source, "a", encoding="utf-8") as manual_outfile:
        for row in infile:
            data = json.loads(row)
            if data["produce_source"] == "大模型生成":
                big_model_outfile.write(json.dumps(data, ensure_ascii=False) + "\n")
            elif data["produce_source"] == "人工撰写":
                manual_outfile.write(json.dumps(data, ensure_ascii=False) + "\n")
            else:
                continue


def get_catagory_rate(data_path: str):
    df = pd.read_excel(data_path)
    df_len = len(df)
    counter = Counter()
    nums = 0
    for i in tqdm(range(df_len), desc="processing"):
        row = df.iloc[i]
        try:
            message_list = eval(row["message_list"])
            for message in message_list:
                counter[message["category"]] += 1
                nums += 1
        except Exception as e:
            continue

    for source, count in counter.most_common():
        print(f"{source}: {count}")


if __name__ == "__main__":
    # data_path = r"data/recommend/topic_recommend/train_data/singleconv_querylist_single_turn_20231129.jsonl"
    # get_produce_source(data_path=data_path)
    # divide_two_source(data_path)

    data_path = "data/recommend/topic_recommend/log_data/曝光点击数据分析-vin_session(4.28-5.4).xlsx"
    get_catagory_rate(data_path=data_path)

    # python -m recommend.topic_recommend.train_LLM.statistic
