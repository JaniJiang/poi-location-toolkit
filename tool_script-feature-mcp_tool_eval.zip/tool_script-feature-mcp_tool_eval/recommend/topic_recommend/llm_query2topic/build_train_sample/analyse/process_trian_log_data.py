import os
import json
import random
import numpy as np
import pandas as pd
from tqdm import tqdm
from recommend.topic_recommend.train_LLM.template import *
from utils.llm_utils.serverless_function import request_llm


class process_trian_data:
    def __init__(self, data_path, sample_path, label_path, all_sample_num=50):
        self.data_path = data_path
        self.sample_path = sample_path
        self.label_path = label_path
        self.model_list = ['gpt-4o', 'claude-3_5-sonnet', "deepseek-v3", 'deepseek-r1']
        self.all_sample_num = all_sample_num
        self.template_class = 4
        self.rate_list = [0] * self.template_class
        self.data_len = None

    def cal_template_rate(self):
        template_1_num, template_2_num, template_3_num, template_4_num = 0, 0, 0, 0
        total = 0
        with open(self.data_path, 'r') as f:
            for line in f:
                json_obj = json.loads(line.strip())
                prompt = json_obj['messages'][0]['content'][0]
                total += 1
                if template_1 in prompt:
                    template_1_num += 1
                elif template_2 in prompt:
                    template_2_num += 1
                elif template_3 in prompt:
                    template_3_num += 1
                elif template_4 in prompt:
                    template_4_num += 1
                else:
                    print(f"未匹配模板的 prompt: {prompt}")
                    exit()
        self.data_len = total
        self.rate_list = [template_1_num / total, template_2_num /
                          total, template_3_num / total, template_4_num / total]
        print(f"总训练数量：{total}")
        print(f"template_1, 数量：{template_1_num}, 占比：{template_1_num / total:.2%}")
        print(f"template_2, 数量：{template_2_num}, 占比：{template_2_num / total:.2%}")
        print(f"template_3, 数量：{template_3_num}, 占比：{template_3_num / total:.2%}")
        print(f"template_4, 数量：{template_4_num}, 占比：{template_4_num / total:.2%}")

    def samlpe_data(self):
        if self.data_len == None:
            self.cal_template_rate()
        sample_num_class = self.allocate_sample_counts(self.rate_list, self.all_sample_num)
        print(f"分配数量：{sample_num_class}, all sample_num: {sum(sample_num_class)}")
        template_buckets = [[] for _ in range(self.template_class)]
        # Step 1: 分类收集
        with open(self.data_path, 'r') as f:
            for line in f:
                json_obj = json.loads(line.strip())
                prompt = json_obj['messages'][0]['content'][0]
                if template_1 in prompt:
                    template_buckets[0].append(json_obj)
                elif template_2 in prompt:
                    template_buckets[1].append(json_obj)
                elif template_3 in prompt:
                    template_buckets[2].append(json_obj)
                elif template_4 in prompt:
                    template_buckets[3].append(json_obj)

        # Step 2: 随机采样
        sampled_data = []
        for i in range(self.template_class):
            pool = template_buckets[i]
            num_to_sample = sample_num_class[i]
            if len(pool) >= num_to_sample:
                sampled = random.sample(pool, num_to_sample)
            else:
                sampled = pool  # 如果不够就全取
            sampled_data.extend(sampled)

        # Step 3: 可选 — 保存结果
        with open(self.sample_path, "w", encoding='utf-8') as fw:
            for item in sampled_data:
                fw.write(json.dumps(item, ensure_ascii=False) + "\n")

        print(f"已完成采样，总数：{len(sampled_data)}，保存为 sampled_output.jsonl")
        return sampled_data

    def label_for_sample_data(self):
        if not os.path.exists(self.sample_path):
            raise Exception("未找到采样数据，请先运行 sample_data() 方法")

        with open(self.sample_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()

        labeled_data = []
        for line in tqdm(lines, desc="标注中"):
            json_obj = json.loads(line.strip())
            prompt = json_obj['messages'][0]['content'][0]
            base_data = {
                "训练数据": prompt,
                "训练数据回答": json_obj['messages'][-1]['content'][0],
            }
            replay = {}
            for model in self.model_list:
                try:
                    _, response_data = request_llm(["", prompt], model=model)
                    replay[model] = response_data['choices'][0]['message']['content']
                except Exception as e:
                    replay[model] = "None"
                    print(f"model:{model}, error:{e}")
                    continue
            labeled_data.append({**base_data, **replay})
        df = pd.DataFrame(labeled_data)
        df.to_excel(self.label_path, index=False)
        print(f"已保存标注数据到 {self.label_path}")

    @staticmethod
    def allocate_sample_counts(rate_list, total_samples):
        raw_counts = [int(r * total_samples) for r in rate_list]
        shortfall = total_samples - sum(raw_counts)
        residuals = [(r * total_samples) - raw for r, raw in zip(rate_list, raw_counts)]
        for idx in np.argsort(residuals)[::-1][:shortfall]:
            raw_counts[idx] += 1
        return raw_counts


class process_log_data:
    # 确保logdata是线上已经采样好的数据
    def __init__(self, data_path, save_path):
        self.data_path = data_path
        self.save_path = save_path
        self.model_list = ['gpt-4o', 'claude-3_5-sonnet', "deepseek-v3", 'deepseek-r1']

    def run(self):
        df = pd.read_excel(self.data_path, engine="openpyxl")
        df_len = len(df)

        df["expand_show_text_list"] = df["merged_show_text_list"].apply(process_log_data.expand_show_text_list)
        for idx in tqdm(df.index, desc="标注中"):
            row = df.loc[idx]
            for model in self.model_list:
                response = self.get_response(row["merged_queries"], model)
                df.at[idx, model] = response

        print(f"{df_len}条数据标注完成！")
        df.to_excel(self.save_path, index=False)

    @staticmethod
    def expand_show_text_list(merged_show_text_list):
        try:
            merged_show_text_list = eval(merged_show_text_list)
            if not isinstance(merged_show_text_list, list):
                return ""
            segments = ["\n".join(topic_list) for topic_list in merged_show_text_list]
            if len(segments) == 1:
                return segments[0]
            else:
                return ("\n" + "-" * 15 + "\n").join(segments)
        except Exception as e:
            print(e)
            return None

    @staticmethod
    def build_prompt(templete, **kwargs):
        return templete.format(**kwargs)

    @staticmethod
    def get_response(merged_queries, model):
        try:
            merged_queries = eval(merged_queries)
            response_join_list = []
            for query in merged_queries:
                try:
                    _, response_data = request_llm([process_log_data.build_prompt(
                        template_log_system, query=query), template_log_user], model=model)
                    response_join_list.append(response_data['choices'][0]['message']['content'].strip())
                except Exception as e:
                    print(e)
                    response_join_list.append("None")
            return ("\n" + "-" * 15 + "\n").join(response_join_list)
        except Exception as e:
            print(e)
            return None


if __name__ == '__main__':
    # data_path = r"data/local/recommend/topic_recommend/LLM/singleconv_querylist_single_turn_20231129.jsonl"
    # sample_path = r"data/local/recommend/topic_recommend/LLM/sample_data.jsonl"
    # label_path = r"data/local/recommend/topic_recommend/LLM/label_data.xlsx"
    # # process_trian_data(data_path, sample_path, label_path).samlpe_data()
    # process_trian_data(data_path, sample_path, label_path).label_for_sample_data()

    data_path = r"data/recommend/topic_recommend/log_data/修正_分层采样结果_精简字段_(4.28-5.4).xlsx"
    save_path = r"data/recommend/topic_recommend/log_data/sample_log_other_model_request_4_28-5_4.xlsx"
    process_log_data(data_path, save_path).run()
    # python -m recommend.topic_recommend.train_LLM.process_trian_log_data
