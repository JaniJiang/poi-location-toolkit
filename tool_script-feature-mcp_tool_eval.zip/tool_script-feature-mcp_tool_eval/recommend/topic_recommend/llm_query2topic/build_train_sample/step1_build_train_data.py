import os
import re
import time
import json
import orjson
import threading
import pandas as pd
from tqdm import tqdm
from queue import Queue
from threading import Lock
from typing import List, Dict
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, explode
from utils.nlp_utils.ner_tool import request_ner
from utils.llm_utils.serverless_function import request_llm
from concurrent.futures import ThreadPoolExecutor, as_completed
from recommend.topic_recommend.llm_query2topic.build_train_sample.template import *
from recommend.topic_recommend.llm_query2topic.build_train_sample.step2_model_eval import Eval_Model


class Statistic_Tools:
    def __init__(self):
        ...

    ability_list = ["ability1", "ability2", "ability3"]
    black_list = ["早间", "人设", "价值观", "", "汽车", "一般涉政", "理想舆情"]
    white_list = ["其他问答", "人物", "城市", "健康", "生物", "公司", "景点", "城市景点推荐", "音乐", "世界之最", "出游美食",
                  "影视", "文学", "地理", "地理通用", "国家", "历史", "教育", "法律", "房产", "旅游", "人工智能", "交通出行", "活动", "城市活动推荐"]
    query_white_list = ["闯红灯扣几分", "闯红灯扣多少分", "闯红灯扣几分？", "嫖娼犯法吗", "强奸判几年", "欠多少钱可以起诉", "牛怎么叫"]
    reject_think = "敏感、不健康、你认识xx、xx叫什么、xx是谁、xx总统是谁、xx首相是谁、哪里有xxx等一些不好生成、敏感、不健康的内容"

    @staticmethod
    def find_json(text):
        pattern = re.compile(r'{.*?}', re.DOTALL)
        matches = pattern.findall(text)
        json_objects = []
        for match in matches:
            try:
                json_objects.append(json.loads(match))
            except:
                continue
        return json_objects

    @staticmethod
    def find_related_entities(query, catagory, max_query_ner=3, max_entity=6, model="gpt-4o"):
        try:
            _, response_data = request_llm([get_ner_entities_sys, get_ner_entities_user.format(
                query=query, require=catagory_require_mp[catagory] if catagory in catagory_require_mp else catagory_require_mp["其他问答"], max_query_ner=max_query_ner, max_entity=max_entity)], model=model)
            response = response_data['choices'][0]['message']['content']
            response = Statistic_Tools.find_json(response)[0]
            return response["ner"], response["entities"]
        except Exception as e:
            return [], []

    @staticmethod
    def get_response(system_pro: str, user_pro: str, type: str = "get_ability", model="deepseek-r1"):
        try:
            _, response_data = request_llm([system_pro, user_pro], model=model)
            ans = response_data['choices'][0]['message']['content']
            ans = eval(ans)
            return [int(ans[ability]) for ability in Statistic_Tools.ability_list] if type == "get_ability" else f"话题转移能力：{ans['first_group_topics']}\n话题泛化能力：{ans['second_group_topics']}\n话题吸引力：{ans['third_group_topics']}"
        except Exception as e:
            return "error"

    @staticmethod
    def clear_console(wait_time=5):
        print("即将清理控制台，请稍候...")
        time.sleep(wait_time)  # 等待 1 秒，让用户看到提示
        os.system('cls' if os.name == 'nt' else 'clear')

    @staticmethod
    def get_nlu_ner(query):
        try:
            ner_model_result, _ = request_ner(query, need_parse=True, need_group=False)
            return_ner_list = list({i["norm"] for i in ner_model_result})
            return return_ner_list
        except Exception as e:
            return []

    @staticmethod
    def jsonl2tsv(data_path, save_path):
        import json
        import pandas as pd
        formated_list = []
        # 读取 jsonl 文件
        with open(data_path, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    d = json.loads(line)
                    formated_d = {}
                    for k, v in d.items():
                        if not isinstance(v, str):
                            formated_d[k] = json.dumps(v, ensure_ascii=False)
                        else:
                            formated_d[k] = v
                    formated_list.append(formated_d)
                except json.JSONDecodeError:
                    continue  # 跳过错误行

        # 转换为 DataFrame 并保存为 tsv
        df = pd.DataFrame(formated_list)
        df.to_csv(save_path, sep="\t", header=True, index=False)

    @staticmethod
    def parse_recommendation_topics(recommendation_topics: str):
        recommendation_topics_list = recommendation_topics.split("\n")
        ans = []
        for i in recommendation_topics_list:
            ans.append(eval(i.split("：")[1]))
        return ans[0], ans[1], ans[2]

    @staticmethod
    def get_low_query(bacth_query_str) -> List:
        _, response_data = request_llm([strip_low_qeury_sys_template.format(
            uer_query_str=bacth_query_str), "请认真思考问题，并严格按照要求返回！"], model="gpt-4o")
        ans = response_data['choices'][0]['message']['content']
        # 提取JSON部分
        m = re.search(r'\{[\s\S]*?\}', ans)
        if not m:
            raise ValueError("No JSON block found in the given text.")

        return json.loads(m.group(0))["lower_query_list"]

    @staticmethod
    def process_batch_low_query(batch_data: List[Dict]):
        bacth_query_str = "、".join([data["query"] for data in batch_data])
        low_query_black = Statistic_Tools.get_low_query(bacth_query_str)
        low_query_list = []
        high_query_list = []
        for data in batch_data:
            if data["query"] in low_query_black:
                low_query_list.append(data)
            else:
                high_query_list.append(data)
        return low_query_list,  high_query_list

    @staticmethod
    def regex_query(query):
        strip_punctuation = ["?", "？"]
        if query[-1] in strip_punctuation:
            return query[:-1]
        return query


class Producter():
    def __init__(self, row_data_path: str = None,
                 save_sampled_data_path: str = None,
                 sample_config: dict = None,
                 save_label_data_path: str = None,
                 max_workers: int = 5,
                 save_label_data_have_ner_path=None,
                 save_label_data_no_ner_path=None,
                 save_label_data_low_query_path=None,
                 save_label_data_high_query_path=None,
                 clean_train_data_path=None,
                 save_instruction_dataset_path=None,
                 model_name=None,
                 cloud_train_model_path=None):
        # 采样需要变量
        self.row_data_path = row_data_path
        self.save_sampled_data_path = save_sampled_data_path
        self.sample_config = {"total_top_pv": 5000,
                              "per_category_top": 200,
                              "total_rand_samples": 5000} if sample_config == None else sample_config
        # 生成标签需要变量
        self.save_label_data_path = save_label_data_path
        self.max_workers = max_workers

        # 去除ner的path
        self.save_label_data_have_ner_path = save_label_data_have_ner_path
        self.save_label_data_no_ner_path = save_label_data_no_ner_path

        self.save_label_data_low_query_path = save_label_data_low_query_path
        self.save_label_data_high_query_path = save_label_data_high_query_path

        # 数据集->指令集path
        self.clean_train_data_path = clean_train_data_path
        self.save_instruction_dataset_path = save_instruction_dataset_path

        # 构建训练配置
        self.model_name = model_name
        self.cloud_train_model_path = cloud_train_model_path
        self.datasets_name = ...
        self.datasets_path = ...
        self.datasets_config = {
            "topic_recommendation_instruction_v2": {
                "file_name": "cloud_share/recommend/topic_recommendation/train_data/topic_recommendation_instruction_v2.json",
                "columns": {
                    "prompt": "instruction",
                    "response": "output"
                }
            }
        }
        self.train_cofig = ...

    def sampling_data(self):
        total_top_pv = self.sample_config["total_top_pv"]
        per_category_top = self.sample_config["per_category_top"]
        total_rand_samples = self.sample_config["total_rand_samples"]
        spark = SparkSession.builder \
            .appName("StrictSampleFlagMarker") \
            .config("spark.driver.memory", "16g") \
            .config("spark.executor.memory", "16g") \
            .getOrCreate()

        # 获取所有子目录路径
        # subdirs = [
        #     os.path.join(self.row_data_path, d)
        #     for d in os.listdir(self.row_data_path)
        #     if os.path.isdir(os.path.join(self.row_data_path, d)) and d.endswith("vin_session")
        # ]

        # 1、用 Spark 读取所有子目录数据
        df = spark.read.json(self.row_data_path)
        print(f"🚀 原始记录数: {df.count()}")
        df = df.withColumn("message", explode(col("message_list")))
        print(f"🚀 展开后记录数: {df.count()}")

        df = df.select(
            col("message.api_name").alias("api_name"),
            col("message.category").alias("category"),
            col("message.query").alias("query"),
            col("message.show_text_list").alias("show_text_list"),
            col("message.output").alias("ans")
        )

        df = df.filter(
            (col("api_name") == "QASearch") &
            (col("query").isNotNull()) & (col("query") != "") &
            # 使用白名单
            (col("category").isin(Statistic_Tools.white_list))
            # 使用黑名单
            # (~col("category").isin(exclude_categories))
        ).drop("api_name")

        # 转 Pandas
        data = df.toPandas()
        print(f"✅ 清洗后记录数: {len(data)}")

        # 计算 PV
        data["pv"] = data.groupby(["category", "query"])["query"].transform("count")

        # 保证 category-query 唯一（方便后续）
        data = data.sort_values("pv", ascending=False).drop_duplicates(subset=["category", "query"])

        used_queries = set()
        sampled_data = []

        # 2. Top-pv 全局
        top_pv_global = data[~data["query"].isin(used_queries)]
        top_pv_global = top_pv_global.sort_values("pv", ascending=False).head(total_top_pv)
        top_pv_global["is_sample"] = True
        top_pv_global["sample_type"] = "top_pv_global"
        used_queries.update(top_pv_global["query"])
        sampled_data.append(top_pv_global)
        print(f"✅ 采样 top_pv_global：{len(top_pv_global)} 条")

        # 3. 每类 Top200（pv > 2）
        top_cat_rows = []
        for cat in data["category"].unique():
            cat_df = data[(data["category"] == cat) &
                          (~data["query"].isin(used_queries)) &
                          (data["pv"] > 2)]
            top_cat = cat_df.sort_values("pv", ascending=False).head(per_category_top)
            top_cat["is_sample"] = True
            top_cat["sample_type"] = "top_per_category"
            used_queries.update(top_cat["query"])
            top_cat_rows.append(top_cat)
            print(f"✅ 类别 '{cat}'：top200 中采样 {len(top_cat)} 条")

        top_cat_data = pd.concat(top_cat_rows)
        sampled_data.append(top_cat_data)

        # 4. 随机采样
        remaining = data[~data["query"].isin(used_queries)]
        rand_sample = remaining.sample(n=min(total_rand_samples, len(remaining)), random_state=42)
        rand_sample["is_sample"] = True
        rand_sample["sample_type"] = "random"
        sampled_data.append(rand_sample)
        print(f"✅ 随机采样：{len(rand_sample)} 条")

        # 5. 合并全部采样数据
        final_data = pd.concat(sampled_data)
        print(f"\n📊 最终样本总数：{len(final_data)}（应为约 {total_top_pv + total_rand_samples + len(top_cat_data)}）")
        print(final_data["sample_type"].value_counts(dropna=False))

        # 6. 保存 JSONL
        print(f"\n💾 正在保存为 JSONL 文件： {self.save_sampled_data_path}")
        final_data.to_json(self.save_sampled_data_path, orient="records", lines=True, force_ascii=False)
        print("✅ 采样数据保存成功！")

    def generate_new_topic_multithread(self):
        assert os.path.exists(self.save_sampled_data_path), "在采样数据前，请先采样！"

        with open(self.save_sampled_data_path, "r", encoding="utf-8") as f:
            raw_data = [json.loads(line) for line in f]
        df = pd.DataFrame(raw_data)
        df_len = len(df)

        write_lock = Lock()  # 文件写入锁，防止多个线程同时写文件

        def process_row(i):
            data = df.iloc[i].astype(object).to_dict()
            catagory = data["category"]
            query = data["query"]
            try:
                ner, entities = Statistic_Tools.find_related_entities(query=query, catagory=catagory)
                topic_list = Statistic_Tools.get_response(
                    generate_template_sys.format(few_shot=label_shot, cot_task=cot_task),
                    generate_template_user.format(query=query, ner=ner, expand=entities if entities else "None"), type="generate", model="gpt-4o")
                if topic_list == "error":
                    return None

                result = {
                    **data,
                    "ner": ner,
                    "entities": entities,
                    "gen_topic_list": topic_list
                }

                # 实时写入 JSONL（带锁）
                with write_lock:
                    with open(self.save_label_data_path, "a", encoding="utf-8") as f:
                        f.write(orjson.dumps(result, option=orjson.OPT_APPEND_NEWLINE |
                                orjson.OPT_NON_STR_KEYS).decode("utf-8"))

                return result
            except Exception as e:
                return None

        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {executor.submit(process_row, i): i for i in range(df_len)}

            for future in tqdm(as_completed(futures), total=df_len, desc="Multithread labeling"):
                future.result()  # 实际写入已经在每个线程内部完成

        print(f"✅ 文件已实时写入 JSONL 至 {self.save_label_data_path}")

    def strip_no_ner(self):
        assert os.path.exists(self.save_label_data_path), "去除ner为空前，请先打标签！"
        with open(self.save_label_data_path, 'r', encoding='utf-8') as infile, \
                open(self.save_label_data_have_ner_path, 'w', encoding='utf-8') as outfile_have, \
                open(self.save_label_data_no_ner_path, 'w', encoding='utf-8') as outfile_no:
            total_lines = sum(1 for _ in open(self.save_label_data_path, 'r', encoding='utf-8'))
            for line in tqdm(infile, total=total_lines, desc="Processing lines"):
                try:
                    data = json.loads(line)
                    if data["category"] == "车牌查询":
                        continue
                    final_data = {
                        "catagory": data["category"],
                        "query": data["query"],
                        "pv": data["pv"],
                        "sample_type": data["sample_type"],
                        "show_text_list": data["show_text_list"],
                        "nlu_ner": None,
                        "llm_ner": data["ner"],
                        "llm_entities": data["entities"],
                        "llm_topics": data["gen_topic_list"]
                    }
                    # 白名单必须写回have中
                    if data["query"] in Statistic_Tools.query_white_list:
                        if data["ner"] == []:
                            ner_list = Statistic_Tools.get_nlu_ner(query=data["query"])
                        final_data["nlu_ner"] = ner_list
                        json.dump(final_data, outfile_have, ensure_ascii=False)
                        outfile_have.write('\n')
                        continue

                    if data["ner"] == []:
                        ner_list = Statistic_Tools.get_nlu_ner(query=data["query"])
                        if ner_list == []:
                            # nlu无ner写回no中
                            final_data["ner_list"] = ner_list
                            json.dump(final_data, outfile_no, ensure_ascii=False)
                            outfile_no.write('\n')
                            continue
                        else:
                            # nlu 获得ner写回have中
                            final_data["ner_list"] = ner_list
                            json.dump(final_data, outfile_have, ensure_ascii=False)
                            outfile_have.write('\n')
                            continue
                    else:
                        # 有llm_ner写回have中
                        final_data["nlu_ner"] = []
                        json.dump(final_data, outfile_have, ensure_ascii=False)
                        outfile_have.write('\n')

                except json.JSONDecodeError:
                    continue

    # def process_dpo_dataset(self, label_data_path, outpath_dpo_path):
    #     model = 'tr-v4-lora-qwen3-32b'
    #     url = 'https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/tr-v4-lora-qwen3-32b-0fa7-faeyur/v1/chat/completions'

    #     dataset = []

    #     with open(label_data_path, "r", encoding='utf-8') as f:
    #         lines = f.readlines()

    #     for line in tqdm(lines, desc="Processing DPO Dataset"):
    #         line = json.loads(line)
    #         query = Statistic_Tools.regex_query(line["query"])
    #         ner = line["llm_ner"] if line["llm_ner"] != "[]" else line["nlu_ner"]
    #         related_knowledge = line["llm_entities"]

    #         try:
    #             res = eval(Eval_Model.chat_with_lpai_LLM(query, model, url))
    #             flag = res.get("falg")  # 原代码拼写应为 flag
    #         except Exception as e:
    #             print(f"LLM调用失败，query: {query}, 错误: {e}")
    #             continue

    #         if flag == "ACCEPT":
    #             topic_transition, generalization, attractiveness = Statistic_Tools.parse_recommendation_topics(
    #                 line["llm_topics"]
    #             )
    #             chosen_dict_topic = {
    #                 "ner": ner,
    #                 "realated_knowledge": related_knowledge,
    #                 "flag": "ACCEPT",
    #                 "recommendation_topics": topic_transition + generalization + attractiveness
    #             }
    #         else:
    #             chosen_dict_topic = {
    #                 "ner": ner,
    #                 "realated_knowledge": related_knowledge,
    #                 "flag": "REJECT"
    #             }

    #         reject_dict_topic = {
    #             "ner": ner,
    #             "realated_knowledge": related_knowledge,
    #             "flag": "ACCEPT",
    #             "recommendation_topics": line.get("show_text_list", [])
    #         }

    #         dataset.append({
    #             "instruction": instruction_template.format(user_query=query),
    #             "input": "",
    #             "chosen": json.dumps(chosen_dict_topic, ensure_ascii=False, indent=4),
    #             "rejected": json.dumps(reject_dict_topic, ensure_ascii=False, indent=4)
    #         })

    #     with open(outpath_dpo_path, "w", encoding="utf-8") as w_f:
    #         json.dump(dataset, w_f, indent=2, ensure_ascii=False)

    #     print(f"DPO数据集已保存至：{outpath_dpo_path}")

    def process_single_line(self, line, model, url):
        try:
            line = json.loads(line)
            query = Statistic_Tools.regex_query(line["query"])
            ner = line["llm_ner"] if line["llm_ner"] != "[]" else line["nlu_ner"]
            related_knowledge = line["llm_entities"]

            res = eval(Eval_Model.chat_with_lpai_LLM(query, model, url))
            flag = res.get("falg", "REJECT")  # 默认给REJECT，防止空

            if flag == "ACCEPT":
                topic_transition, generalization, attractiveness = Statistic_Tools.parse_recommendation_topics(
                    line["llm_topics"]
                )
                chosen_dict_topic = {
                    "ner": ner,
                    "realated_knowledge": related_knowledge,
                    "flag": "ACCEPT",
                    "recommendation_topics": topic_transition + generalization + attractiveness
                }
            else:
                chosen_dict_topic = {
                    "ner": ner,
                    "realated_knowledge": related_knowledge,
                    "flag": "REJECT"
                }

            reject_dict_topic = {
                "ner": ner,
                "realated_knowledge": related_knowledge,
                "flag": "ACCEPT",
                "recommendation_topics": line.get("show_text_list", [])
            }

            result = {
                "instruction": instruction_template.format(user_query=query),
                "input": "",
                "chosen": json.dumps(chosen_dict_topic, ensure_ascii=False, indent=4),
                "rejected": json.dumps(reject_dict_topic, ensure_ascii=False, indent=4)
            }
            return result
        except Exception as e:
            print(f"处理失败，原因：{e}")
            return None

    def process_dpo_dataset(self, label_data_path, outpath_dpo_path, max_workers=48):
        model = 'tr-v4-lora-qwen3-32b'
        url = 'https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/tr-v4-lora-qwen3-32b-0fa7-faeyur/v1/chat/completions'

        dataset = []
        with open(label_data_path, "r", encoding='utf-8') as f:
            lines = f.readlines()

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {executor.submit(self.process_single_line, line, model, url): line for line in lines}

            for future in tqdm(as_completed(futures), total=len(futures), desc="Processing DPO Dataset"):
                result = future.result()
                if result:
                    dataset.append(result)

        with open(outpath_dpo_path, "w", encoding="utf-8") as w_f:
            json.dump(dataset, w_f, indent=2, ensure_ascii=False)

        print(f"DPO数据集已保存至：{outpath_dpo_path}")

    def label_data2instruction_dataset(self, think=False):
        # 标签数据 -> 指令集
        dataset = []
        df = pd.read_excel(self.clean_train_data_path)
        len_df = len(df)
        for idx in tqdm(range(len_df), desc="处理中。。。"):
            line = df.iloc[idx]
            flag = line["标注"]
            query = Statistic_Tools.regex_query(line["query"])
            ner = line["llm_ner"] if line["llm_ner"] != "[]" else line["nlu_ner"]
            realated_knowledge = line["llm_entities"]
            if flag == 0.5:
                continue
            elif flag == 0:
                dict_topic = {
                    "ner": ner,
                    "realated_knowledge": realated_knowledge,
                    "flag": "REJECT",
                    # "thinking": f"这个query包含有{Statistic_Tools.reject_think}，不需要生成话题，返回REJECT",
                }
                think = f"<think>用户的问题不符合回答要求，因予以拒绝！</think>\n"
            elif flag == 1:
                recommendation_topics = line["llm_topics"]
                try:
                    topic_transition, generalization, attractiveness = Statistic_Tools.parse_recommendation_topics(
                        recommendation_topics)
                    dict_topic = {
                        # "thinking": f"这个query中包含{ner}实体，满足生成话题的要求，所以生成如下话题",
                        "ner": ner,
                        "realated_knowledge": realated_knowledge,
                        "flag": "ACCEPT",
                        "recommendation_topics": {"topic_transition": topic_transition,
                                                  "generalization": generalization,
                                                  "attractiveness": attractiveness}
                    }
                    think = f"<think>通过用户问题：{query}，可以联想到相关知识:{realated_knowledge}，最后有以下回复：</think>\n"
                except Exception as e:
                    continue
            else:
                continue
            dataset.append({
                "instruction": instruction_template.format(user_query=query),
                "input": "",
                "output": think + json.dumps(dict_topic, ensure_ascii=False, indent=4)})

        with open(self.save_instruction_dataset_path, "w") as w_f:
            json.dump(dataset, w_f, indent=2, ensure_ascii=False)

        print(f"✅ {self.save_instruction_dataset_path}数据集构建完成，共写入 {len(dataset)} 条样本。")

    def strip_low_query(self, batch_num=20, max_workers=5):
        low_query_lock = threading.Lock()
        high_query_lock = threading.Lock()
        progress_queue = Queue()

        def process_and_write_batch(batch_data):
            low_query, high_query = Statistic_Tools.process_batch_low_query(batch_data)

            if low_query:
                with low_query_lock, open(self.save_label_data_low_query_path, "a", encoding="utf-8") as low_out:
                    for item in low_query:
                        low_out.write(json.dumps(item, ensure_ascii=False) + "\n")

            if high_query:
                with high_query_lock, open(self.save_label_data_high_query_path, "a", encoding="utf-8") as high_out:
                    for item in high_query:
                        high_out.write(json.dumps(item, ensure_ascii=False) + "\n")

            # 用于主线程更新进度条
            progress_queue.put(len(batch_data))

        # 清空旧文件内容
        open(self.save_label_data_low_query_path, "w", encoding="utf-8").close()
        open(self.save_label_data_high_query_path, "w", encoding="utf-8").close()

        batch_data = []
        futures = []

        with open(self.save_label_data_have_ner_path, "r", encoding="utf-8") as f:
            total_lines = sum(1 for _ in f)

        with open(self.save_label_data_have_ner_path, "r", encoding="utf-8") as f, \
                ThreadPoolExecutor(max_workers=max_workers) as executor, \
                tqdm(total=total_lines, desc="Processing lines", ncols=100) as pbar:

            for line in f:
                line = line.strip()
                if not line:
                    continue
                data = json.loads(line)
                batch_data.append(data)

                if len(batch_data) == batch_num:
                    future = executor.submit(process_and_write_batch, batch_data.copy())
                    futures.append(future)
                    batch_data.clear()

            if batch_data:
                future = executor.submit(process_and_write_batch, batch_data)
                futures.append(future)

            # 实时更新进度条
            completed = 0
            while completed < len(futures):
                processed = progress_queue.get()  # 等待线程通知已处理条数
                pbar.update(processed)
                completed += 1

    def build_train_env(self):
        ...

    def pipeline(self, sample_data: bool = True,
                 generate_new_topic_multithread: bool = True,
                 strip_no_ner: bool = True,
                 label_data2instruction_dataset: bool = True):
        # “处理数据 + 标签 + 训练” 管道
        def step(desc: str, func):
            print(f"\n🚀 正在执行步骤：{desc}")
            func()
            Statistic_Tools.clear_console()
        # TODO 完成条件assert
        if sample_data:
            step("采样数据", self.sampling_data)
        if generate_new_topic_multithread:
            step("生成新 topic（多线程）", self.generate_new_topic_multithread)
        if strip_no_ner:
            step("去除没有 NER 的样本", self.strip_no_ner)
        if label_data2instruction_dataset:
            step("生成指令微调格式数据", self.label_data2instruction_dataset)
        # TODO 构建训练配置


if __name__ == "__main__":
    # 标准通道命名
    # producter = Producter(row_data_path="data/cloud_share/recommend/log_group/topic_recommend/",
    #                       save_sampled_data_path="data/cloud_share/recommend/topic_recommendation/train_data/all_row_data_marked_v4.jsonl",
    #                       save_label_data_path="data/cloud_share/recommend/topic_recommendation/train_data/label_train_data_v3.jsonl",
    #                       save_label_data_have_ner_path="data/cloud_share/recommend/topic_recommendation/train_data/label_train_data_v3_have_ner.jsonl",
    #                       save_label_data_no_ner_path="data/cloud_share/recommend/topic_recommendation/train_data/label_train_data_v3_no_ner.jsonl",
    #                       clean_train_data_path="data/cloud_share/recommend/topic_recommendation/train_data/clean_train_data.xlsx",
    #                       save_label_data_low_query_path='data/cloud_share/recommend/topic_recommendation/train_data/label_train_data_v3_low_query.jsonl',
    #                       save_label_data_high_query_path='data/cloud_share/recommend/topic_recommendation/train_data/label_train_data_v3_high_query.jsonl',
    #                       save_instruction_dataset_path="data/cloud_share/recommend/topic_recommendation/train_data/topic_recommendation_instruction_v3.json",
    #                       )
    producter = Producter(row_data_path="data/cloud_share/recommend/log_group/topic_recommend/20250526-20250601.vin_session",
                          save_sampled_data_path="data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_train_sample/train_data/eval-20250526-20250601_have_show_ans.jsonl",
                          save_label_data_path="data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_train_sample/train_data/label_train_data_v4.jsonl",
                          save_label_data_have_ner_path="data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_train_sample/train_data/label_train_data_v4_have_ner.jsonl",
                          save_label_data_no_ner_path="data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_train_sample/train_data/label_train_data_v4_no_ner.jsonl",
                          clean_train_data_path="data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_train_sample/train_data/clean_train_data.xlsx",
                          save_label_data_low_query_path='data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_train_sample/train_data/label_train_data_v3_low_query.jsonl',
                          save_label_data_high_query_path='data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_train_sample/train_data/label_train_data_v3_high_query.jsonl',
                          save_instruction_dataset_path="data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_train_sample/train_data/topic_recommendation_instruction_v4_think.json",
                          )
    producter.sampling_data()
    # producter.generate_new_topic_multithread()
    # producter.strip_no_ner()
    # producter.process_dpo_dataset(
    #     "data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_train_sample/train_data/label_train_data_v4_have_ner.jsonl",
    #     "data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_train_sample/train_data/topic_recommendation_instruction_v4_dpo.json")
    # producter.label_data2instruction_dataset()
    # producter.pipeline()
    # producter.strip_low_query()
    # producter.label_data2instruction_dataset()
    # Statistic_Tools.jsonl2tsv("data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_online_data/step3_generate_topics_data/20250101-20250612.jsonl",
    #                           "data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_online_data/step3_generate_topics_data/20250101-20250612.tsv")
    # str1 = "哪吒汽车破产了吗、中国的四大发明是什么、驴怎么叫、搜索小米、汕头有什么好吃的、芬太尼是什么东西、远古的鱼有多大？"
    # str2 = "落枕了怎么办、介绍一下赵欣彤、牙疼怎么办、怎么说、介绍一下张韶涵、介绍一下华山、孙中山是谁、世界上最大的国家是哪个国家"
    # str3 = "石家庄有什么好玩儿的、你知道哪吒吗、红绿灯是谁发明的、大唐不夜城、康定海拔多少、怎么清洗玻璃、雪豹怎么叫、谢霆锋多少岁"
    # Statistic_Tools.get_low_query(str1)
    # python -m recommend.topic_recommend.llm_query2topic.build_train_sample.step1_build_train_data

    # 文件体系
    # 1.row_data: 来自于线上采样的数据
    # 2.sampled_data：对线上数据进行catagory_pv、top_pv、random采样
    # 3.have_ner：对上一步的数据清除ner为空的数据
    # 4.high_ner: 对上一步的数据清除query低质的数据


def str_to_list(raw_str: str) -> List[str]:
    raw_str = raw_str.strip()
    return raw_str.split("\n")


def eval_tool(data_path: str, save_path: str) -> None:
    df = pd.read_excel("data/recommend/topic_recommend/train_data/分层采样结果_精简字段_(4.28-5.4).xlsx")
    df_len = len(df)
    df["tag_label_LLM"] = None
    correct, total = 0, 0

    for idx in tqdm(range(df_len), desc="processing"):
        data = df.iloc[idx]
        user_query = data["Query"]
        list_ans = []
        # 判断理想、豆包、Kimi、文心的能力
        for i in ["推荐话题", "豆包推荐项", "kimi推荐项", "文心推荐项"]:
            ability = str_to_list(data[i])
            # DONE 每个回答的能力评估最后融入最后一行
            prompt_sys = evalue_template.format(
                user_query=user_query,
                ablity1_topic=ability,
                ablity2_topic=ability,
                ablity3_topic=ability
            )
            ans = Statistic_Tools.get_response(prompt_sys, "请你严格按照上面json格式回复，请注意你只需要回复json（非Markdown格式）")
            list_ans.append(ans)
        df.at[idx, "tag_label_LLM"] = list_ans
        # 示例 "list_ans" [[0,0,0],[0,0,1],[0,0,1],[0,0,1]]
        # ✅ 在这里同步计算准确率
        real_label = get_real_label(data)
        correct_temp, total_temp = calculate_accuracy(real_label, list_ans)
        correct += correct_temp
        total += total_temp

    # 保存结果
    df.to_excel(save_path)
    print(f"Accuracy: {correct / total:.4f}")


def get_real_label(row):
    # 评价维度列名
    metrics = ["话题转移能力", "话题泛化能力", "话题吸引力"]
    # 模型名按顺序排列
    models = ["理想", "豆包", "Kimi", "文心"]

    # 初始化统计矩阵（4 模型 × 3 维度）
    stat_matrix = [[0] * len(metrics) for _ in range(len(models))]

    for metric_idx, col in enumerate(metrics):
        entries = row[col].split(",")

        for model_idx, model_name in enumerate(models):
            if model_name in entries:
                stat_matrix[model_idx][metric_idx] = 1

    return stat_matrix


def calculate_accuracy(real_label: List[List[int]], evaluate_label: List[List[int]]) -> List[int]:
    # TODO 计算指标
    if len(real_label) != len(evaluate_label):
        return 0, 0
    correct = 0
    total = 0
    for true_seq, pred_seq in zip(real_label, evaluate_label):
        if not isinstance(pred_seq, list):
            continue
        min_len = min(len(true_seq), len(pred_seq))
        for i in range(min_len - 1):
            if true_seq[i] == pred_seq[i]:
                correct += 1
        total += (len(true_seq) - 1)   # 真实标签决定总标签数
    print(real_label)
    print(evaluate_label)
    print(correct)
    print(total)
    return correct, total
