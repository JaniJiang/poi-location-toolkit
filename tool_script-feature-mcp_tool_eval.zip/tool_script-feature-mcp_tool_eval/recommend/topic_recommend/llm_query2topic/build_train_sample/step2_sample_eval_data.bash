# 配置
INPUT_FILE="data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_train_sample/train_data/eval-20250526-20250601_have_show_ans.jsonl"
OUTPUT_FILE="data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_train_sample/train_data/eval-20250526-20250601_have_show_ans_sample.tsv"
TOP_PV_COUNT=50
RAND_SAMPLE_COUNT=50

# 输出表头
echo -e "query\tpv\tcategory\tshow_text_list\tans\tis_sample\tsample_type" > ${OUTPUT_FILE}

# 创建临时中间文件
TMP_ALL=$(mktemp)
TMP_TOP=$(mktemp)
TMP_TOP_QUERIES=$(mktemp)
TMP_RANDOM=$(mktemp)

# Step 1: 预处理，过滤掉 ans 为 null 或空字符串
jq -c 'select(.ans != null and .ans != "")' ${INPUT_FILE} > ${TMP_ALL}

# Step 2: Top PV 排序采样
jq -s "sort_by(.pv) | reverse | .[:${TOP_PV_COUNT}]" ${TMP_ALL} > ${TMP_TOP}
jq -r '.[] | [.query, (.pv|tostring), .category, (.show_text_list|tostring), (.ans|tostring), (.is_sample|tostring), (.sample_type|tostring)] | @tsv' ${TMP_TOP} >> ${OUTPUT_FILE}

# Step 3: 提取已用 query
jq -r '.[] | .query' ${TMP_TOP} > ${TMP_TOP_QUERIES}

# Step 4: 随机采样剩余 query（已排除 ans 为空的情况）
grep -F -v -f ${TMP_TOP_QUERIES} ${TMP_ALL} | shuf -n ${RAND_SAMPLE_COUNT} > ${TMP_RANDOM}
jq -r '[.query, (.pv|tostring), .category, (.show_text_list|tostring), (.ans|tostring), (.is_sample|tostring), (.sample_type|tostring)] | @tsv' ${TMP_RANDOM} >> ${OUTPUT_FILE}

# 清理
rm -f ${TMP_ALL} ${TMP_TOP} ${TMP_TOP_QUERIES} ${TMP_RANDOM}

echo "✅ 完成（跳过空 ans）：TopPV=${TOP_PV_COUNT}，Random=${RAND_SAMPLE_COUNT}，输出文件： ${OUTPUT_FILE}"