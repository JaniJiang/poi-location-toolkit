from functools import partial
import multiprocessing as mp
from tqdm import tqdm
from pathlib import Path
from loguru import logger
import json
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from recommend.topic_recommend.llm_query2topic.build_train_sample.step2_model_eval import Eval_Model

# TODO 关注线上黑名单
black_list = {
    "version": "v1.3.2",
    "queryRegex": "llama|Llama|LLAMA|打开.{0,6}安全气囊|座椅弹射|再见[^\\w\\s]*$|^哦.{0,2}好的|你好啊[^\\w\\s]*$|退下[^\\w\\s]*$|退下吧[^\\w\\s]*$|^好的|谢谢|(L|l)[0-9]呢|^理想(L9|l9).{0,2}后排中间|我想买车|购车建议|解答.{0,2}数学|还剩多少钱|^.{0,4}$|讲个笑话|定制.+海报|出.*数学题|做一首|作一首|[A-Za-z\\s]+.{0,4}意思|消防车的股票|策划.+文案|讲一个|你.+CEO|讲个故事|MEGA|mega|Mega|理想one|理想ONE|理想One|计算一下|等于多少|等于几|猜谜语|变成英文|翻译|讲.+故事|(写|生成)一(个|篇|首)|(生成|写).+(作文|文章|信|说明文|论文|小说|文字|文案|诗|短文|范文|情书|稿子|总结)|理想汽车|理想.*(差别|不同|差异|销量|比|优惠|贵|更|分别|区别)|[一二三四五六七八九十百千万亿\\d]+\\s*[+\\-*/加减乘除]\\s*[一二三四五六七八九十百千万亿\\d]+|服务专家|调音大师|绘画大师|^你|自己|理想同学|李想|马东辉|李铁|谢炎|邹良军|范皓宇|勾晓菲|郎咸朋|沈亚楠|理想.*(事故|下.+车|质疑|停产|领导者|声誉|老板|成立|上市|前身|办公地址|使命|愿景|价值观|组织使命|行为准则|目标市场|三大主张|驱动力|产品规划|创始人团队|董事长|创始人|首席技术官|CTO|CEO|CFO|首席财务官|首席执行官|首席营销官|总裁|副总裁|总经理|老板|经营范围|品牌slogan|股票代码|注册地|法定代表人|总资产|市值|所属行业|是否上市|注册资金|简介|公司类型|公司口号|年营业额|员工数量|发展史|评价|业务|融资|获奖情况|规模|文化|业务范围|营业额|净利率|常州工厂)",
    "answerRegex": "llama|Llama|LLAMA|能否给出更具体|你有什么问题或话题想讨论|需要(依赖|更多|一些).{0,2}上下文|我会根据您提供|有什么特定的上下文|我未能找到|请提供我所要帮助的主题|没有关于具体地点的描述|你可以给我一个具体的问题|您的问题似乎是|(你|您).{0,6}一个模糊的话题|能再提供一些具体信息|(你|您)提供的句子有一些随意的拼接|如果(您|你)提到的是其他内容|这个问题很模糊|我似乎误解|我需要更多信息|(你|您)的问题.{0,5}(难以|不).{0,2}理解|请详细告诉我|出.{0,2}了.{0,4}(差错|故障)|您提供的上下文不太明确|我都愿意倾听|你接下来想做|你想从哪一点开始|我可以.{0,4}告诉你|你有.{0,4}这方面的问题吗|不知道您是想知道|我能更好地为您提供信息|我(都会|才能|将|会|很|可以)(能|帮助|乐意|尽|提供|为|给出).{0,6}(帮助|回答|解答)|问题.{0,5}不.{0,3}完整|我这里暂时找不到|请提供您的位置|如果有任何具体|还没告诉我|有任何其他问题|你也可以详细询问|这个我也没看过|我发现了问题|你请尽情地问我|你想要的是|有什么我可以|提供更(多信息|精确|准确)|我(非常|很)抱歉|有什么.+和我说|(你|您)如果.{0,3}(更多|明确|需要|问题)|你是想让我不再说话|玩个文字游戏挺好玩的|(您|你|请).{0,3}提供.{0,2}(一个|更|具体|详细)|(您|你)需要.{0,4}明确|你说错了|(你|您|请).{0,4}(补充|说明)|如果(你|您).{0,3}(更多|明确|需要|问题)|请随时向我|请描述(您|你)的需求或疑惑|请(您|你)告诉我|我的认知存在误差|暂时无法|我需要知道|^嘿，小朋友|如果(你|您)需要|(你|您)(能|能否)提供(更多|具体).+(吗|？)|(需要|如果).{0,4}提供(更|具体)|^(很遗憾|很抱歉|对不起|不好意思)|我.{0,2}不.{0,2}确定|引发.{0,2}(安全|不适当).*后果|还想了解什么|有需要就找我|^.{0,10}$|如果(你|您).{0,6}详细|请检查问题|随时为您提供其他|我会.{0,2}陪伴|可能.{0,3}是.{0,3}不同|没有明确.{0,2}答案|意义尚不清晰|请问.{0,2}有.+(吗|？)|取决于具体的语境|您还有.*问题吗？|我相信这不是|你需要.+吗？|告诉我更多|随时告诉我|请告诉我|可以告诉我|请您.{0,4}说明|要其他帮助吗|为你提供相关的信息|可以聊聊吗？|^$|^(没有|对不起|抱歉|非常抱歉)|稍后我.+等|请告诉我你的问题|执行成功|执行失败|暂无.{0,4}信息|没有.{0,4}相匹配的内容|我.{0,2}不.{0,2}(清楚|明白|了解|知道|具有|理解)|超出了我.{0,6}范围|不太明白|换个话题|我没想好|没太想好|在学习|未配备|没有配备|没配备|未配置|没有配置|没配置|未搭载|没有搭载|没搭载|获取失败|难到我|等我学习|没找到|没有找到|跳转失败|打开失败|执行失败|不能处理|无法评论|无法评价|我.{0,4}无法|我.{0,4}不能|我不支持|我.{0,4}没有|很难回答|无法.{0,6}回答|我.{0,4}不会|没有.{0,6}信息|没有.*消息|无法提供|没有配备|不支持.{0,6}功能|不具有.{0,6}功能",
    "domainSet": ["chat", "other", "navigation"],
    "apiNameSet": ["CHARASearch", "Silentwait", "Reject"],
    "sourceDomainSet": ["autotype.lixiang.com", "manual_official_info.lixiang.com", "lixiang.com/news", "manual_official_info.qa.lixiang.com", "manual_add_by_case.lixiang.com", "brand_book", "lixiang.com"],
    "tagSet": [],
    "topicRegex": "理想ONE|理想one|理想One|^你|^您|吸引你|异同|理想同学|不同之处|有哪些不同|不同点"
}
config = {
    "tr-v3-full-qwen3-8b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/tr-v3-full-qwen3-8b-d231-lhczxz/v1/chat/completions",
    "tr-v3-lora-qwen3-8b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/tr-v3-lora-qwen3-8b-595f-njfzdu/v1/chat/completions"
}
headers = {"Content-Type": "application/json"}
model_list = ["tr-v3-full-qwen3-8b", "tr-v3-lora-qwen3-8b"]

file_lock = threading.Lock()
pbar_lock = threading.Lock()


def process_line_and_write(line, model, output_path, pbar):
    try:
        query = line.get("query", "")
        res = Eval_Model.chat_with_lpai_LLM(query, model=model, url=config[model])
        dict_res = eval(res)

        if dict_res.get("flag") == "ACCEPT":
            line.update({
                "llm_ner": dict_res.get("ner"),
                "realated_knowledge": dict_res.get("realated_knowledge"),
                "recommendation_topics": dict_res.get("recommendation_topics")
            })
        else:
            line.update({
                "llm_ner": dict_res.get("ner"),
                "realated_knowledge": dict_res.get("realated_knowledge"),
                "recommendation_topics": "REJECT"
            })

        # 安全写入文件
        with file_lock:
            with open(output_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(line, ensure_ascii=False) + "\n")

    except Exception as e:
        logger.warning(f"process_line_and_write: {json.dumps(line, ensure_ascii=False)}")
        # print(f"[❌ 处理失败] query: {line.get('query', '')}，错误: {e}")
    finally:
        # 安全更新进度条
        with pbar_lock:
            pbar.update(1)


def generate_topics(step2_data_path, step3_data_path, model, max_workers=64):
    lines = []
    with open(step2_data_path, "r", encoding="utf-8") as f:
        for line in f:
            try:
                lines.append(json.loads(line))
            except json.JSONDecodeError as e:
                print(f"[⚠️ JSON解析失败] {e}")
                continue

    total = len(lines)
    # Path(step3_data_path).write_text("", encoding="utf-8")  # 清空输出

    print(f"🚀 开始多线程处理，共 {total} 条，线程数: {max_workers}")
    with tqdm(total=total, desc="💡 处理进度") as pbar:
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            for line in lines:
                executor.submit(process_line_and_write, line, model, step3_data_path, pbar)

    print(f"✅ 所有数据处理完毕，输出文件: {step3_data_path}")


def add_loss_data(log_path, loss_data_path, step3_data_path, model):
    import os
    import time

    if not os.path.exist(loss_data_path):
        shell_sentence = f'''grep "process_line_and_write" {log_path} | awk -F"process_line_and_write: " '{{print $2}}' > {loss_data_path}'''
        os.system(shell_sentence)
    result = os.popen(f"wc -l {loss_data_path}").read()
    line_count = int(result.strip().split()[0])
    print(f"本次共计「{line_count}」条数据待修复。")

    hard_erro = []
    with open(loss_data_path, "r", encoding="utf-8") as f:
        for raw_line in tqdm(f, total=line_count, desc="修复中"):
            line = json.loads(raw_line)
            count = 0
            while True:
                count += 1
                if count > 5:
                    hard_erro.append(line)
                    break
                try:
                    query = line.get("query", "")
                    res = Eval_Model.chat_with_lpai_LLM(query, model=model, url=config[model])
                    dict_res = eval(res)

                    if dict_res.get("flag") == "ACCEPT":
                        line.update({
                            "llm_ner": dict_res.get("ner"),
                            "realated_knowledge": dict_res.get("realated_knowledge"),
                            "recommendation_topics": dict_res.get("recommendation_topics")
                        })
                    else:
                        line.update({
                            "llm_ner": dict_res.get("ner"),
                            "realated_knowledge": dict_res.get("realated_knowledge"),
                            "recommendation_topics": "REJECT"
                        })
                    # 写入结果
                    with open(step3_data_path, "a", encoding="utf-8") as out_f:
                        out_f.write(json.dumps(line, ensure_ascii=False) + "\n")
                    break  # 成功就跳出 retry 循环
                except Exception as e:
                    print(f'处理失败，query: {line.get("query", "无query")}，错误：{e}')
                    time.sleep(1)  # 防止无限速请求


if __name__ == "__main__":
    step2_data_path = r"data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_online_data/step2_clean_data/20250101-20250612.jsonl"
    step3_data_path = r"data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_online_data/step3_generate_topics_data/20250101-20250612.jsonl"
    model = "tr-v3-lora-qwen3-8b"
    generate_topics(step2_data_path, step3_data_path, model)

    # 注 启动完“generate_topics”才能启动add_loss_data， log_path 是nohup输出管道的文件
    # loss_data_path = r"log/recommend/topic_recommend/llm_query2topic/build_online_data/step3_generate_topic/generate_topic.query.jsonl"
    # log_path = r"log/recommend/topic_recommend/llm_query2topic/build_online_data/step3_generate_topic/generate_topic.log"
    # add_loss_data(log_path, loss_data_path, step3_data_path, model)
    # ["tr-v3-full-qwen3-8b", "tr-v3-lora-qwen3-8b"]
    # python -m recommend.topic_recommend.llm_query2topic.build_online_data.step3_generate_topic
    # nohup python -m recommend.topic_recommend.llm_query2topic.build_online_data.step3_generate_topic > data/temp/generate_topic.log 2>&1 &
