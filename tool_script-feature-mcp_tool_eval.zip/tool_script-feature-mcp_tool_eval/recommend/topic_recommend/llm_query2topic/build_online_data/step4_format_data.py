import time
from tqdm import tqdm
import json
import hashlib
# 需要什么样的格式

topic_choice = ["generalization", "attractiveness"]


def generate_index_id(query):
    salt = str(time.time_ns())  # 纳秒时间戳，或用其他唯一值
    source = (query.lower() + salt).encode('utf-8')
    index_id = hashlib.md5(source).hexdigest()[:16]  # 截取前16位
    return index_id


def format_data(step3, step4):

    # 预先统计行数用于进度条总长度
    with open(step3, "r", encoding="utf-8") as f:
        total_lines = sum(1 for _ in f)

    with open(step3, "r", encoding="utf-8") as fin, open(step4, "w", encoding="utf-8") as fout:
        for line in tqdm(fin, total=total_lines, desc="⏳ 正在处理"):
            line = json.loads(line)
            # print(line)
            if line["recommendation_topics"] == "REJECT":
                continue

            try:
                query = line["query"]
                topic_dict = line["recommendation_topics"]
                merged_list = []
                for key in topic_choice:
                    if key in topic_dict and isinstance(topic_dict[key], list):
                        merged_list.extend(topic_dict[key])

                base_data = {
                    "id": generate_index_id(query=query),
                    "query": query,
                    "domain": "common",
                    "topic_list": merged_list
                }

                fout.write(json.dumps(base_data, ensure_ascii=False) + "\n")
            except Exception as e:
                print(f"have {e}")
                continue


if __name__ == "__main__":
    clean_data_path = r"data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_online_data/step3_generate_topics_data/20250101-20250612.jsonl"
    format_data_path = r"data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_online_data/step4_format_data/20250101-20250612.jsonl"
    format_data(clean_data_path, format_data_path)
    # python -m recommend.topic_recommend.llm_query2topic.build_online_data.step4_format_data
