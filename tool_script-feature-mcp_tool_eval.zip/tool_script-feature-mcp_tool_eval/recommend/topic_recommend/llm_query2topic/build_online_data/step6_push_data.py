from datetime import datetime
from loguru import logger
from utils.file_utils import read_jsonl_file
from utils.search_utils.es_client import ElasticSearchClient
from recommend.topic_recommend.llm_query2topic.meta import *


class PushData:

    def __init__(self, env, index_name, refresh_index=False):
        self.index_name = index_name
        self.refresh_index = refresh_index
        # input data
        # self.input_path = f"{DATA_DIR}/eval/eval_build_data.jsonl"
        self.input_path = f"{DATA_DIR}/build_online_data/step5_safe_detect_data/20250101-20250612_safe.jsonl"
        # init es client
        cluster_name = "recommend_prod" if env in [
            "prod"] else "recommend_testtwo"
        self.es_client = ElasticSearchClient(cluster_name)
        self.mapping = {
            "properties": {
                "id": {"type": "keyword"},
                "query": {"type": "keyword"},
                "domain": {"type": "keyword"},
                "topic_list": {"type": "keyword"},
            }
        }

    def process(self):
        # create index
        code = self.es_client.check_and_create_index(
            self.index_name, self.refresh_index, self.mapping)
        if code is False:
            logger.error(
                f"[PushData] check_and_create_index {self.index_name} failed")
            return False
        logger.info(
            f"[PushData] check_and_create_index {self.index_name} success")
        # read data
        data_list = read_jsonl_file(self.input_path)
        # load data
        success, failed = self.es_client.load_data(self.index_name, data_list)
        logger.info(
            f"[PushData] {success} documents loaded successfully, {failed} documents failed to load.")
        return True


if __name__ == "__main__":
    env = "testtwo"
    # index_name = "recommend_20250612_test"  # eval data
    current_time = datetime.now().strftime("%Y%m%d")
    index_name = f"recommend_{current_time}_test"  # official data
    refresh_index = True
    obj = PushData(env, index_name, refresh_index)
    obj.process()

# python -m recommend.topic_recommend.llm_query2topic.build_online_data.step6_push_data
