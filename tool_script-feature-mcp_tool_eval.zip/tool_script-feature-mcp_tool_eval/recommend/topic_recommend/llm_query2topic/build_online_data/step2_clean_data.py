from pyspark import SparkConf
from recommend.topic_recommend.llm_query2topic.build_train_sample.step1_build_train_data import Statistic_Tools
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, length, udf, sum as F_sum
from pyspark.sql.types import StringType

MAX_QUERY_LEN = 25

sample_config = {"total_top_pv": 5000,
                 "per_category_top": 200,
                 "total_rand_samples": 5000}


def clean_data(row_data_path, save_cleaned_data_path):
    conf = SparkConf() \
        .set("spark.executor.memory", "16g") \
        .set("spark.driver.memory", "16g") \
        # .set("spark.sql.shuffle.partitions", "200")  # 控制聚合时的 task 数

    spark = SparkSession.builder \
        .appName("CleanDataWithPvSum") \
        .config(conf=conf) \
        .getOrCreate()

    print(f"📥 正在加载 CSV 文件: {row_data_path}")
    df = spark.read.option("header", True).csv(row_data_path)
    print(f"✅ 加载数据记录数: {df.count()}")

    # 类型转换
    df = df.withColumn("pv", col("pv").cast("int"))

    # 过滤条件
    df = df.filter(
        # (col("api_name") == "QASearch") &
        (length(col("query")) <= MAX_QUERY_LEN) &
        (col("query").isNotNull()) & (col("query") != "") &
        (col("category").isin(Statistic_Tools.white_list))
    ).drop("api_name")

    # 归一化
    regex_query_udf = udf(Statistic_Tools.regex_query, StringType())
    df = df.withColumn("query", regex_query_udf(col("query")))

    print(f"✅ 清洗后记录数: {df.count()}")

    # 累加 pv：按 query 分组求和
    df_aggregated = df.groupBy("query").agg(F_sum("pv").alias("pv")).orderBy("pv", ascending=False)

    print(f"✅ 聚合后记录数: {df_aggregated.count()}")

    # 保存为 JSONL，只保留 query 和 pv 字段
    print(f"\n💾 正在保存为 JSONL 文件: {save_cleaned_data_path}")
    df_aggregated.toPandas().to_json(save_cleaned_data_path, orient="records", lines=True, force_ascii=False)
    print("✅ 清洗数据保存成功！")


if __name__ == "__main__":
    row_data_path = r"data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_online_data/step1_extract_query/20250101-20250612/20250101-20250612*.csv"
    save_sampled_data_path = r"data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_online_data/step2_clean_data/20250101-20250612.jsonl"
    clean_data(row_data_path, save_sampled_data_path)

    # python -m recommend.topic_recommend.llm_query2topic.build_online_data.step2_clean_data
