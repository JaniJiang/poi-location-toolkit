from pyspark.sql import SparkSession
from pyspark.sql.functions import col, count, sum as _sum, when


def analyse(step1_path):
    # 启动 Spark 会话
    spark = SparkSession.builder.appName("CategoryQueryStats").getOrCreate()

    # 设置 CSV 文件路径（请根据实际修改）
    input_path = step1_path

    # 读取 CSV 文件（假设列包含: category, query, pv）
    df = spark.read.option("header", "true").option("inferSchema", "true").csv(input_path)

    # 将 pv 转为整数类型，确保可以参与数值运算
    df = df.withColumn("pv", col("pv").cast("int"))

    # 添加是否为高频 query（pv > 1 的情况）
    df = df.withColumn("is_high_freq", when(col("pv") > 1, 1).otherwise(0))

    # 添加高频 query 的 PV 值列，仅保留 pv > 1 的值
    df = df.withColumn("high_freq_pv", when(col("pv") > 1, col("pv")).otherwise(0))

    # 分组统计每个 category 的指标
    result = df.groupBy("category").agg(
        count("query").alias("query_count"),                 # 查询总数
        _sum("is_high_freq").alias("high_freq_query_count"),  # 高频 query 数量
        _sum("pv").alias("total_pv"),                        # 所有 PV 总和
        _sum("high_freq_pv").alias("high_freq_pv")           # 高频 query 的 PV 总和
    )

    # 打印输出结果
    # result.show(truncate=False)
    result.toPandas().to_csv("data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_online_data/analyse/analyse_catagory_pv.tsv", sep="\t")


if __name__ == "__main__":
    step1_path = r"data/cloud_share/recommend/topic_recommendation/tr_group_hive/20250501-20250601/20250501-20250601*.csv"
    analyse(step1_path)

    # python -m recommend.topic_recommend.llm_query2topic.build_online_data.analyse.analyse_catagory_pv
