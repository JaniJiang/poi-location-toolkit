-- TODO: 解析message_list
-- TODO: 预期输出格式：query api_name category pv
WITH parsed AS (
  SELECT
    from_json(
      message_list,
      'array<struct<
        new_session_id:string,
        record_id:string,
        domain:string,
        api_name:string,
        category:string,
        media_type:string,
        face_screen:string,
        query:string,
        show_text_list:array<string>,
        click_text:string,
        output:string,
        request_time:string
      >>'
    ) AS message_array
  FROM ssai_ods.topic_recommend_group_df
  WHERE dt = '2025-06-04' AND  '2025-06-06' -- ✅ 日期限制
),

exploded AS (
  SELECT EXPLODE(message_array) AS message FROM parsed
),

flattened AS (
  SELECT
    message.api_name AS api_name,
    message.category AS category,
    message.query AS query
  FROM exploded
)

SELECT
  api_name,
  category,
  query,
  COUNT(*) AS pv
FROM flattened
GROUP BY api_name, category, query
ORDER BY pv DESC;