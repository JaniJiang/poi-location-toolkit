ROOT_PATH = "recommend/topic_recommend/llm_query2topic/build_online_data"
DATA_ROOT_PATH = "data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_online_data"
