import time
import json
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor, as_completed
from recommend.topic_recommend.utils.safe_detection_client import *

client = SafeDetectClient()


def detect_topic(detect_topic):
    msg_id = 'jiaojinda756'
    record_id = ''
    try:
        response = client.process(msg_id, record_id, detect_topic)
        if isinstance(response, dict) and response.get("status") == "SDS_SAFE":
            return (detect_topic, True)
        else:
            return (detect_topic, False)
    except Exception as e:
        print(f"topic:{detect_topic}。\tsafe detect error: {e}")
        return (detect_topic, False)


def safe_detect(step4, step5_safe, step5_unsafe, max_workers=8):
    cnt = 0
    with open(step4, "r", encoding="utf-8") as rf, \
            open(step5_safe, "w", encoding="utf-8") as wf1, \
            open(step5_unsafe, "w", encoding="utf-8") as wf2, \
            ThreadPoolExecutor(max_workers=max_workers) as executor:
        for line in tqdm(rf, desc="安全检测"):
            cnt += 1
            line = json.loads(line)
            if not (isinstance(line, dict) and line.get("topic_list")):
                continue

            detect_topics = list(line["topic_list"])
            future_to_topic = {
                executor.submit(
                    detect_topic,
                    topic): topic for topic in detect_topics}
            safe_topics = []
            unsafe_topics = []
            for future in as_completed(future_to_topic):
                detect_topic_text, is_safe = future.result()
                if is_safe:
                    safe_topics.append(detect_topic_text)
                else:
                    unsafe_topics.append(detect_topic_text)

            if safe_topics:
                to_save = dict(line)
                to_save["topic_list"] = safe_topics
                wf1.write(json.dumps(to_save, ensure_ascii=False) + "\n")
            if unsafe_topics:
                to_save2 = dict(line)
                to_save2["topic_list"] = unsafe_topics
                wf2.write(json.dumps(to_save2, ensure_ascii=False) + "\n")

            # if cnt > 100:
            #     break


if __name__ == "__main__":
    input_file = r"/mnt/volumes/ss-sai-lx-my/xuzhou1/code/tool_script/data/cloud_share/recommend/topic_recommendation/llm_query2topic/build_online_data/step5_safe_detect_data/20250101-20250612.jsonl"
    safe_output_file = r"/mnt/volumes/ss-sai-lx-my/xuzhou1/data_share/recommend/topic_recommendation/llm_query2topic/build_online_data/step5_safe_detect_data/20250101-20250612_safe.jsonl"
    unsafe_output_file = r"/mnt/volumes/ss-sai-lx-my/xuzhou1/data_share/recommend/topic_recommendation/llm_query2topic/build_online_data/step5_safe_detect_data/20250101-20250612_unsafe.jsonl"
    safe_detect(
        input_file,
        safe_output_file,
        unsafe_output_file,
        max_workers=16)
    # python -m
    # recommend.topic_recommend.llm_query2topic.build_online_data.step5_safe_detectV2
