WITH parsed AS (
  SELECT
    vin, 
    from_json(
      message_list,
      'array<struct<
        new_session_id:string,
        record_id:string,
        domain:string,
        api_name:string,
        category:string,
        media_type:string,
        face_screen:string,
        query:string,
        show_text_list:array<string>,
        click_text:string,
        output:string,
        request_time:string
      >>'
    ) AS message_array
  FROM ssai_ods.topic_recommend_group_df
  WHERE dt BETWEEN '2025-05-16' AND '2025-06-16'
),

exploded AS (
  SELECT
    vin,
    EXPLODE(message_array) AS message
  FROM parsed
),

flattened AS (
  SELECT
    vin,
    message.api_name AS api_name,
    message.category AS category,
    message.query AS query
  FROM exploded
),

filtered AS (
  SELECT *
  FROM flattened
  WHERE
    api_name = 'QASearch'
    AND query IS NOT NULL AND query != ''
    AND category IN (
      '其他问答', '人物', '城市', '健康', '生物', '公司', '景点', '城市景点推荐',
      '音乐', '世界之最', '出游美食', '影视', '文学', '地理', '地理通用', '国家',
      '历史', '教育', '法律', '房产', '旅游', '人工智能', '交通出行',
      '活动', '城市活动推荐'
    )
),

vin_pool AS (
  SELECT
    vin,
    COUNT(*) AS total_interactions
  FROM filtered
  GROUP BY vin
  ORDER BY total_interactions DESC
  LIMIT 10000
)

SELECT vin
FROM (
    SELECT vin, rand() AS rnd
    FROM vin_pool
) t
ORDER BY rnd
LIMIT 2000
;