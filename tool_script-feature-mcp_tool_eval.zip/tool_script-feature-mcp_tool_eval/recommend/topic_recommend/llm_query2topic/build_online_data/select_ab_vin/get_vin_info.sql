SELECT
  vin,
  SUM(rounds) AS rounds,
  MAX(is_show) AS is_show,
  MAX(is_click) AS is_click,
  SUM(show_count) AS show_count,
  SUM(click_count) AS click_count
FROM
  ssai_ods.topic_recommend_group_df
WHERE
  dt BETWEEN '2025-05-11' AND '2025-06-11'
GROUP BY
  vin