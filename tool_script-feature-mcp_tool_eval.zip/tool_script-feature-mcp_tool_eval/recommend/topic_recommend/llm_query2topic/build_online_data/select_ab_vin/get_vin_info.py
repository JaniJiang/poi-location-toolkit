import os
import pandas as pd
import matplotlib.pyplot as plt
from pyspark.sql import SparkSession
from recommend.topic_recommend.llm_query2topic.build_online_data.meta import *


def get_vin_info(vin_info_path, only_vin_path, save_path):
    spark = SparkSession.builder.appName("MergeAndFilterVINs").getOrCreate()
    print(f"{only_vin_path} 开始抽取信息")
    vin_df = spark.read.option("header", True).csv(only_vin_path).select("vin").dropna().dropDuplicates()
    merged_df = spark.read.option("header", True).csv(vin_info_path)
    result_df = merged_df.join(vin_df, on="vin", how="inner")
    pdf = result_df.toPandas()
    int_columns = ["rounds", "is_show", "is_click", "show_count", "click_count"]
    for col in int_columns:
        pdf[col] = pdf[col].astype(float).fillna(0).astype(int)
    print(f"{save_path} 已经保存！")
    pdf.to_csv(save_path, index=False)
    spark.stop()


def show_statitic(csv_path):
    # 1. 读取数据：替换为实际文件路径
    df = pd.read_csv(csv_path)
    numeric_cols = ['rounds', 'is_show', 'is_click', 'show_count', 'click_count']
    stats = df[numeric_cols].agg(['min', 'max', 'mean', 'median', 'std', 'sum'])
    print(f"Descriptive statistics {os.path.basename(csv_path)}:\n", stats)


if __name__ == "__main__":
    root_path = f"{DATA_ROOT_PATH}/select_ab_vin/get_vin_info"
    # vin_info_path = f"{root_path}/20250316-20250616_*.csv"
    # only_vin_path = f"{root_path}/download_ab_vin_b.csv"
    save_path = f"{root_path}/info_ab_vin_a.csv"

    # get_vin_info(vin_info_path, only_vin_path, save_path)
    show_statitic(save_path)


# python -m recommend.topic_recommend.llm_query2topic.build_online_data.select_ab_vin.get_vin_info
