import grpc
import numpy as np
from loguru import logger
from google.protobuf import empty_pb2
from utils.rpc.py.grpc_service_pb2 import (
    InferTensorContents,
    ModelInferRequest,
    ModelInferResponse
)
from utils.rpc.py.grpc_service_pb2_grpc import GRPCInferenceServiceStub


class TopicVectorClient:

    def __init__(self, address="nlu-testone-tritonserver.inference:1981"):
        # 创建gRPC通道（增加重试策略）
        self.channel = grpc.insecure_channel(
            address,
            options=[
                ('grpc.max_receive_message_length', 100 * 1024 * 1024),
                ('grpc.max_send_message_length', 100 * 1024 * 1024)
            ]
        )
        self.stub = GRPCInferenceServiceStub(self.channel)

    def process(self):
        msg_id = "demo"
        text_list = ["你好", "你好啊"]
        self.get_vector(msg_id, text_list)

    def get_vector(self, msg_id, text_list):
        # 构建输入张量内容
        infer_tensor_contents = InferTensorContents()
        for text in text_list:
            infer_tensor_contents.bytes_contents.append(text.encode("utf-8"))
        print("infer_tensor_contents:", infer_tensor_contents)
        # 构建请求
        model_infer_request = ModelInferRequest(
            model_name="semantic-embedder-ensemble",
            model_version="1",
            id=msg_id,
            inputs=[
                ModelInferRequest.InferInputTensor(
                    name="query",
                    datatype="BYTES",
                    shape=[len(text_list), 1],
                    contents=infer_tensor_contents
                )
            ]
        )
        print("model_infer_request:", model_infer_request)
        # 发送请求（增加错误处理）
        try:
            response = self.stub.ModelInfer(model_infer_request)
            print(response)
        except grpc.RpcError as e:
            logger.warning(f"gRPC error ({e.code()}): {e.details()}")
            raise


if __name__ == "__main__":
    cli = TopicVectorClient()
    cli.process()

# python -m recommend.topic_recommend.utils.topic_vector_client
