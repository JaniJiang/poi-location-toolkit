import grpc
import json
from google.protobuf import json_format
import utils.rpc.py.nlu_engine_pb2_grpc as nlu_engine_pb2_grpc
import utils.rpc.py.nlu_engine_pb2 as nlu_engine_pb2
import utils.rpc.py.safedetect_pb2_grpc as safedetect_pb2_grpc
import utils.rpc.py.safedetect_pb2 as safedetect_pb2
from utils.rpc.consts import *
from utils.rpc.request_text_config import *
from utils.rpc.model.SafeDetectionModel import *
from utils.rpc.model.NluRequestV2Model import *


class SafeDetectClient():

    def process(self, msg_id, record_id, detect_topic):
        msg_id = "topic_recommend_" + generate()
        record_id = record_generate()
        nlu_request_config = NluRequestV2(detect_topic)
        nlu_response = self.get_nlu_result(
            nlu_request_config.get_request_recommend_config())
        safe_detection_request_config = SafeDetectRequest(
            msg_id, record_id, detect_topic, [nlu_response])
        safe_detection_response = self.get_safe_detaction_result(
            safe_detection_request_config.get_request_recommend_config())
        return safe_detection_response

    def get_nlu_result(self, request):

        # dev
        # channel = grpc.insecure_channel(
        #     "security-detection-service-dev.ssai-apis-staging.chj.cloud:80")

        # testtwo
        channel = grpc.insecure_channel(
            "security-detection-service-testtwo.ssai-apis-staging.chj.cloud:80"
        )
        stub = nlu_engine_pb2_grpc.NluEngineStub(channel)
        try:
            message = nlu_engine_pb2.NluRequestV2()
            json_format.ParseDict(request, message)
            response = stub.ParseV2(message)
            response_json = json.loads(json_format.MessageToJson(response))
            return response_json
        except grpc.RpcError as e:
            print(
                "stream call err, code: %s, msg: %s" %
                (e.code(), e.details()))
            return "error"
        except StopIteration:
            print("Stream has ended (EOF).")

    def get_safe_detaction_result(self, request):
        channel = grpc.insecure_channel(
            "security-detection-service-dev.ssai-apis-staging.chj.cloud:80")
        stub = safedetect_pb2_grpc.SafeDetectStub(channel)
        try:
            message = safedetect_pb2.SafeDetectRequest()
            json_format.ParseDict(request, message)
            response = stub.Detect(message)
            response_json = json.loads(json_format.MessageToJson(response))
            return response_json
        except grpc.RpcError as e:
            print(
                "stream call err, code: %s, msg: %s" %
                (e.code(), e.details()))
            return "error"
        except StopIteration:
            print("Stream has ended (EOF).")


if __name__ == '__main__':
    client = SafeDetectClient()
    msg_id = 'jiaojinda756'
    record_id = ''
    detect_topic = '我想杀人啦'
    # detect_topic = '为什么有游客会被终身禁止入园熊猫基地'
    response = client.process(msg_id, record_id, detect_topic)
    print(json.dumps(response, ensure_ascii=False))
    if isinstance(response, dict) and response.get("status") == "SDS_SAFE":
        print("safe")
    else:
        print("unsafe")

#  python -m recommend.topic_recommend.utils.safe_detection_client
