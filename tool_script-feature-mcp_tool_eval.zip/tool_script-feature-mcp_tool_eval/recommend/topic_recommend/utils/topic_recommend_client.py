import grpc
import json
from google.protobuf import json_format
import utils.rpc.py.recommended_pb2 as recommended_pb2
import utils.rpc.py.recommended_pb2_grpc as recommended_pb2_grpc
from utils.rpc.consts import *
from utils.rpc.request_text_config import *
from utils.rpc.model.TopicRecommendModel import *


addr_dict = {
    "local": "localhost:50003",
    "dev": "ssai-intelligent-recommendation-dev.ssai-apis-staging.chj.cloud:80",
    "testtwo": 'ssai-intelligent-recommendation-testtwo.ssai-apis-staging.chj.cloud:80',
}


class TopicRecommendClient():

    def __init__(self, env):
        self.addr = addr_dict[env]

    def process(self, query, answer, domain, category, api_name, vin):
        msg_id = "topic_recommend_" + generate()
        context_id = context_generate()
        session_id = session_generate()
        request_config = TopicRecommendRequest(query, answer, domain, category,
                                               api_name, msg_id, session_id, context_id, vin)
        response = self.send_request(request_config.get_request_recommend_config())
        return response

    def send_request(self, request):
        response = self.streaming_recommend(request)
        return self.handle_response(response)

    def streaming_recommend(self, request):
        channel = grpc.insecure_channel(self.addr)
        stub = recommended_pb2_grpc.RecommendedStub(channel)
        try:
            message = recommended_pb2.TopicRecommendedRequest()
            json_format.ParseDict(request, message)
            response = stub.TopicRecommended(message)
            response_json = json.loads(json_format.MessageToJson(response))
            return response_json
        except grpc.RpcError as e:
            print("stream call err, code: %s, msg: %s" % (e.code(), e.details()))
            return "error"
        except StopIteration:
            print("Stream has ended (EOF).")

    def handle_response(self, response):
        topic_list = response.get("topicList", "")
        msg_id = response.get("commonResponse", {}).get("requestInfo", {}).get("msgId", "")
        recommend_response = TopicRecommendResponse()
        recommend_response.set_topic_list(topic_list)
        recommend_response.set_msg_id(msg_id)
        return recommend_response


if __name__ == '__main__':
    env = "local"  # local | dev | testtwo
    client = TopicRecommendClient(env)
    query = "恐龙为什么会灭绝"
    answer = "恐龙的灭绝是一个复杂的过程，科学家们提出了多种理论来解释这一现象。其中，最广为接受的理论是小行星撞击地球。大约在6600万年前，一颗小行星撞击了现在的墨西哥尤卡坦半岛地区，引发了大规模的火山活动、气候变化和生态系统破坏。这些灾难性的事件导致了全球性的环境恶化，食物链受到严重冲击，最终导致恐龙的灭绝。除了小行星撞击理论，还有气候变化、火山活动、疾病传播等多种理论也被提出，但目前小行星撞击说是最为主流的解释。"
    domain = "gpt_chat"
    category = "其他问答"
    api_name = "QASearch"
    vin = ""
    multi_session = ""
    if multi_session not in NONE_LIST:  # 上文不为空
        session_context_list = session_context_multi_rounds(multi_session.strip())
        response = client.process(query, answer, domain, category, api_name, vin)
        print(response)
    else:  # 上文为空
        response = client.process(query, answer, domain, category, api_name, vin)
        print(response)

# python -m recommend.topic_recommend.utils.topic_recommend_client
