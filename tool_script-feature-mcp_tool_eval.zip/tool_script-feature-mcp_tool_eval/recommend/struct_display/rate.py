
raw_name = ["没有问题","空字段","不合理"]
raw_list_dict = {
    "title":[110,33,8],
    "keyword":[104,36,11],
    "query_ner":[47,75,29],
    "answer_ner":[40,55,56]

}

# 计算并打印占比
for key, values in raw_list_dict.items():
    total = sum(values)  # 计算总数
    print(f"{key} :" )
    for i, count in enumerate(values):
        percent = (count / total) * 100  # 计算百分比
        print(f"{i + 1}. {raw_name[i]}占比 {percent:.2f}%")


# python -m recommend.struct_display.rate

# title : 1. 没有问题占比 31.79%
#         2. 空字段占比 60.26%
#         3. 不合理占比 7.95%
# keyword : 1. 没有问题占比 31.79%
#         2. 空字段占比 60.26%
#         3. 不合理占比 7.95%