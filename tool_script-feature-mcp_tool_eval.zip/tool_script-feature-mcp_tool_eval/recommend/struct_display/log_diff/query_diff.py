import pandas as pd


def main():
    input1_path = "data/cloud_share/recommend/struct_display/log_diff/query_diff/input1.tsv"
    input2_path = "data/cloud_share/recommend/struct_display/log_diff/query_diff/input2.tsv"
    input1_df = pd.read_csv(input1_path, sep="\t").fillna("")
    input2_df = pd.read_csv(input2_path, sep="\t").fillna("")
    # 旧日期
    query_dict = {}
    for _, row in input2_df.iterrows():
        query_dict[row["api_query"]] = True
    # 新日期
    for _, row in input1_df.iterrows():
        if row["api_query"] in query_dict:
            continue
        print("\t".join([row["api_query"], row["api_name"], row["category"], row["media_type"]]))


if __name__ == "__main__":
    main()
