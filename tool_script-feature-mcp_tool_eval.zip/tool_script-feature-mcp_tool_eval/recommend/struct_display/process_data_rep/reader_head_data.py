import csv
import os


sample_data_path = "data/local/recommend/struct_display/2025-04-07_11_52_43_1.csv"


with open("data/local/recommend/struct_display/2025-04-07_11_52_43_1.csv", "r", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    for row in reader:
        # print(row)
        print(row.keys())
        break
    # print(row[0])


# python -m recommend.struct_display.process_data_rep.reader_head_data
