from pyspark.sql import SparkSession
from pyspark.sql.functions import col, when, count, sum as spark_sum

# 初始化 SparkSession
spark = SparkSession.builder.appName("RecommendationStats").getOrCreate()

# 示例：读取你的 DataFrame，替换为实际的数据源
# df = spark.read.json("your_data_path.json") 或 parquet/csv/数据库等
df = spark.read.parquet(
    "/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_join/struct/20250331-20250406/2025-04-06/")

# 仅统计 recommend_type 为 2~6 的数据
valid_types = [2, 3, 4, 5, 6]
status_filter = col("recommend_type").isin(valid_types)

# 添加辅助列用于布尔统计（True 为 1，False 为 0）
df_stats = df.withColumn("has_recommend_int", when((col("has_recommend") == True) & status_filter, 1).otherwise(0)) \
             .withColumn("has_show_int", when((col("has_show") == True) & status_filter, 1).otherwise(0)) \
             .withColumn("has_click_int", when((col("has_show") == True) & (col("has_click") == True) & status_filter, 1).otherwise(0))

# 总行数（符合条件的总样本数）
total_count = df.filter(status_filter).count()

# 聚合统计
agg_result = df_stats.agg(
    spark_sum("has_recommend_int").alias("recommend_count"),
    spark_sum("has_show_int").alias("show_count"),
    spark_sum("has_click_int").alias("click_count")
).collect()[0]

# 计算比例
recommend_ratio = agg_result["recommend_count"] / total_count
show_ratio = agg_result["show_count"] / total_count
click_ratio = agg_result["click_count"] / agg_result["show_count"]

# 打印结果
print(f"📌 总数据量: {total_count}")
print(f"✅ 推荐占比 (has_recommend=True): {recommend_ratio:.2%}")
print(f"📢 曝光占比 (has_show=True): {show_ratio:.2%}")
print(f"🖱️ 点击占比 (has_show=True & has_click=True): {click_ratio:.2%}")
