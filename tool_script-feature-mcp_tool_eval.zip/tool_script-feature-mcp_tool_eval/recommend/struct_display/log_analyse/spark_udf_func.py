# udf 函数仓库

def image_list_empty(json_str):
    try:
        dict = eval(json_str)
        if "image_list" in dict and dict["image_list"] is not None:
            return 1
        else:
            return 0
    except:
        return 0


def pro_image_search_query_empty(recommend_type):
    if recommend_type == "TS_NEWS":
        return "新闻不需要image_search_query"

    return "title&query_ner未能击中title"


def have_picture_data(image_search_response):
    try:
        image_search_response = eval(image_search_response)
        if "data" in dict and image_search_response["data"] is not None:
            return 1
        else:
            return 0
    except:
        return 0


def have_picture(image_search_response):
    try:
        image_search_response = eval(image_search_response)
        if "data" in image_search_response and image_search_response["data"] is not None and image_search_response["data"][0]["image_info"] is not None:
            return 1
        else:
            return 0
    except:
        return 0


def which_erro_step(recommend_type, image_search_query, image_search_response):
    if recommend_type == "TS_TRAVEL_SEARCH_":
        if image_search_query is None or image_search_query == "":
            return "没有image_search_query"
        else:
            return "召回失败"
    else:
        try:
            image_search_response = eval(image_search_response)
            if "message" in image_search_response and image_search_response["message"].startswith("image match,"):
                return "内外路召回失败"
            else:
                return "兜底回复"
        except:
            return "无Response"
