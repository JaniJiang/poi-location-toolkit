import os
import ast
import json
import argparse
import pandas as pd
from tqdm import tqdm
from recommend.struct_display.log_analyse.analyse_image_query_with_VLM import Qwen_VLM, get_VLM_response


def is_valid_hit(response_str):
    try:
        data = json.loads(response_str)
        # 确保是有数据的列表，并且第一个元素有 "id" 字段
        return "data" in data and isinstance(data["data"], list) and \
               len(data["data"]) > 0 and "id" in data["data"][0]
    except Exception:
        return False  # 如果不是合法 JSON 或结构不匹配，返回 False


def get_query(row):
    # try:
    #     slot_li_str = row.get("slot_li")
    #     slot_list = ast.literal_eval(slot_li_str)
    #     query = eval(slot_list[0])["QUERY"]
    #     return query
    # except Exception as e:
    #     return row.get("raw_query", "None")

    return row.get("raw_query", "None")


def check_image_validity(row, save_log_path, model, processor, device):
    # TODO:判断图片是否是正确的
    if row["image_search_response"]:
        try:
            data = json.loads(row["image_search_response"])
            img_links = []

            def recursive_extract(obj):
                if isinstance(obj, dict):
                    for key, value in obj.items():
                        if key == "img_link":
                            img_links.append(value)
                        else:
                            recursive_extract(value)
                elif isinstance(obj, list):
                    for item in obj:
                        recursive_extract(item)

            recursive_extract(data)
            if len(img_links) == 0:
                return True
            else:
                url = img_links[0]
                query = get_query(row)
                res = get_VLM_response(
                    model, processor, device, url, oral_prompt.format(user_query=query))
                res = json.loads(res)
                with open(save_log_path, "a", encoding="utf-8") as f:
                    f.write(f"ans: {res['answer']}, reason: {res['reason']}, query: {query}, url: {url}\n")
                if res['answer'] == "是":
                    return True
                elif res['answer'] == "不是":
                    return False
                else:
                    return True
        except Exception as e:
            return True
    else:
        return True


oral_prompt = """
这个图片是否能关于：'{user_query}'，这个问题？可以不用回答问题，仅仅相关即可！
1. 请严格按照以下json格式回复，只需要回复json字符串,不能使用markdown格式返回。
2. 需要注意的是照片里面中包含问题中的任何关键字即可，不必纠结一些小细节。
3. 注意我提供的问题可以不需要回答，只要图片内容是问题中的某小个关键字。
例子1：
问题：火龙果中富含什么维生素
图片：一个火龙果
{{
    "answer": "是"，
    "reason": "图片的内容是关于火龙果的"
}}

例子2：
问题：陶喆的票价档次
图片：图片中包含陶喆的名字和演唱会信息
{{
    "answer": "是"，
    "reason": "图片中的内容是关于陶喆的"
}}

以下是你要回复的json问题：
{{
    "answer": "是" | "不是"
    "reason": "你需要给出的判断理由"
}}

"""


def main(root_path, model_type, device):
    file_list = [f for f in os.listdir(root_path) if f.endswith("pro_hit_result.xlsx")]
    save_path = f"data/local/recommend/struct_display/hit_rate_dig/hit_rate_dig_statistical_data/picture_accuracy_{model_type}.xlsx"
    model, processor = Qwen_VLM(model_path="data/rep/Qwen2.5-VL-7B-Instruct", device=device)
    file_name, total_list, acc = [], [], []
    for file in file_list:
        file_name.append(file)
        df = pd.read_excel(os.path.join(root_path, file))
        save_log_path = f"data/local/recommend/struct_display/hit_rate_dig/picatur_acc_data/picture_accuracy_{model_type}_{file}.txt"
        if model_type == "have_picture":
            df_filtered = df[df["搜图结果是否有图片"] == 1]
        elif model_type == "can_not_hit":
            df_filtered = df[df["image_search_response"].apply(is_valid_hit)]
        true_picture = 0
        total = df_filtered.shape[0]
        total_list.append(total)
        for _, row in tqdm(df_filtered.iterrows(), total=len(df_filtered), desc=f"{file}图像判断中!"):
            try:
                if check_image_validity(row, save_log_path, model, processor, device):
                    true_picture += 1
            except Exception as e:
                print("处理失败:", e)
        # 输出结果
        acc.append((true_picture / total))
        print(f"{file}:模型标注准确率：{(true_picture / total):.2%}")

    result_df = pd.DataFrame({
        "文件": file_name,
        "数量": total_list,
        "图片准确率问题占比": [f"{i:.2%}" for i in acc]
    })
    result_df.to_excel(save_path, index=False)
    print(f"结果已保存至：{save_path}")


if __name__ == "__main__":
    # file = r"data/local/recommend/struct_display/hit_rate_dig/hit_rate_dig_pro_data/sample_joined_table_2025-04-07_pro_hit_result.xlsx"
    file = r"data/local/recommend/struct_display/hit_rate_dig/hit_rate_dig_pro_data"
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=str, choices=["have_picture", "can_not_hit"])
    parser.add_argument("--device", type=str, default="cuda:0")
    args = parser.parse_args()
    main(file, args.model, args.device)
    # nohup python -m recommend.struct_display.log_analyse.step3_llm_label --model have_picture --device cuda:4 > have_picture.log 2>&1 &
    # nohup python -m recommend.struct_display.log_analyse.step3_llm_label --model can_not_hit --device cuda:6 > can_not_hit.log 2>&1 &
