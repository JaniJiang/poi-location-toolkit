from pyspark.sql import SparkSession
from pyspark.sql.functions import col, explode, from_json
from pyspark.sql.types import MapType, StringType

# 打印函数：key: count 格式，便于复制


def print_counts(df, label):
    print(f"\n📌 {label} 统计（格式：值: 次数）")
    for row in df.collect():
        key = row[0] if row[0] is not None else "(null)"
        print(f"{key}: {row[1]}")


# 初始化 Spark
spark = SparkSession.builder.appName("SlotLI_Domain_Stats").getOrCreate()

# 读取 parquet 数据（包含多个日期子目录）
df_raw = spark.read.parquet(
    "/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_join/struct/20250331-20250406/2025-04-*")

# 筛掉空值并展开 slot_li
df_step1 = df_raw.filter(col("slot_li").isNotNull())
df_step2 = df_step1.withColumn("slot_str", explode(col("slot_li")))

# 每个元素是 JSON 字符串，转成 MAP
df_step3 = df_step2.withColumn("slot_map", from_json("slot_str", MapType(StringType(), StringType())))

# 提取字段
df_final = df_step3.select(
    col("slot_map").getItem("APINAME").alias("apiname"),
    col("slot_map").getItem("CATEGORY").alias("category"),
    col("slot_map").getItem("MEDIATYPE").alias("mediatype")
)

# 各字段统计并打印
apiname_df = df_final.groupBy("apiname").count().orderBy("count", ascending=False)
# category_df = df_final.groupBy("category").count().orderBy("count", ascending=False)
mediatype_df = df_final.groupBy("mediatype").count().orderBy("count", ascending=False)

print_counts(apiname_df, "APINAME")
# print_counts(category_df, "CATEGORY")
print_counts(mediatype_df, "MEDIATYPE")

# python -m recommend.struct_display.log_analyse.get_domian
