import pandas as pd
import csv
import os
import numpy as np
import argparse

statistical_save_path = "data/local/temp/statistical.csv"
statistical_heads = ['数据量', 'image_search_query 空占比', 'query_ner_empty 空占比', 'answer_ner_empty 空占比',
                     'title 空占比', 'keyword_empty 空占比', 'query_or_answer_ner 未命中占比', 'query_and_answer_ner 全为空占比']


def which_erro_step(row):
    recommend_type = row['recommend_type']
    image_search_query = row['image_search_query']
    image_search_response = row['image_search_response']

    if recommend_type == "TS_TRAVEL_SEARCH_":
        if str(row['image_search_query']) == "nan":
            return "没有image_search_query"
        else:
            print(row['image_search_query'])
            return "召回失败"
    else:
        try:
            # 尝试解析 image_search_response 为字典
            image_search_response = eval(image_search_response)
            if "message" in image_search_response and image_search_response["message"].startswith("image match,"):
                return "内外路召回失败"
            else:
                return "兜底回复"
        except:
            return "无Response"


def save_statistical(statistical, save_path):
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    # 检查文件是否存在以确定是否需要写入头
    file_exists = os.path.isfile(save_path)
    with open(save_path, 'a', encoding="utf-8") as f:
        writer = csv.writer(f)
        # 在文件不存在时写入头
        if not file_exists:
            writer.writerow(statistical_heads)
        # 写入统计数据
        writer.writerow(statistical)


def get_statistical(df, save_path):
    # 统计各类情况
    total_lines = len(df)  # 总行数
    image_search_query_empty = df['image_search_query'].isnull().sum()
    query_ner_list_empty = (df['query_ner_list'] == '[]').sum()
    answer_ner_list_empty = (df['answer_ner_list'] == '[]').sum()
    title_empty = df['title'].isnull().sum()
    keyword_empty = df['keyword'].isnull().sum()

    query_or_answer_ner_not_empty_and_title_empty = len(df[
        ((df['query_ner_list'] != '[]') | (df['answer_ner_list'] != '[]')) & df['image_search_query'].isnull()
    ])

    query_and_answer_ner_not_empty_and_title_empty = len(df[
        (df['query_ner_list'] == '[]') & (df['answer_ner_list'] == '[]') & df['image_search_query'].isnull()
    ])

    # 计算占比
    statistical = [
        total_lines,  # 数据量
        round((image_search_query_empty / total_lines) * 100, 2),
        round((query_ner_list_empty / total_lines) * 100, 2),
        round((answer_ner_list_empty / total_lines) * 100, 2),
        round((title_empty / total_lines) * 100, 2),
        round((keyword_empty / total_lines) * 100, 2),
        round((query_or_answer_ner_not_empty_and_title_empty / total_lines) * 100, 2),
        round((query_and_answer_ner_not_empty_and_title_empty / total_lines) * 100, 2)
    ]

    save_statistical(statistical, save_path)


def safe_eval(x):
    try:
        # 确保 x 是字符串，再使用 eval
        if isinstance(x, str):
            return eval(x)
        else:
            return None
    except:
        return None


def build_save_path(original_path, catagory, model):
    # 拆解路径和文件名
    dir_path, filename = os.path.split(original_path)

    # 获取文件名前缀和扩展名
    file_prefix, _ = os.path.splitext(filename)

    # 构造新目录路径（替换掉 "hit_rate_dig_raw_data" 为 "hit_rate_dig_pro_data"）
    new_dir = dir_path.replace("hit_rate_dig_raw_data", f"hit_rate_dig_{catagory}_data")

    # 构造新的文件名（加上 _statistical_result 后缀）
    new_filename = f"{file_prefix}_{catagory}_{model}_result{'.xlsx' if catagory == 'pro' else '.csv'}"

    return os.path.join(new_dir, new_filename)


def main(model, root_path):
    # 添加字段：image_list是否为空，image_search_query是否为空，image_search_query为空的原因，是否有搜图结果，搜图结果是否有图片，搜图错误出现在那个步骤
    # 统计指标：'文件名','数据量','image_search_query 空占比','query_ner_empty 空占比','answer_ner_empty 空占比','title 空占比','keyword_empty 空占比','query_or_answer_ner 未命中占比','query_and_answer_ner 全为空占比'
    path_list = os.listdir(root_path)

    for path in path_list:
        full_path = os.path.join(root_path, path)
        if model == "recommend":
            if not path.endswith(".csv"):
                continue
            df = pd.read_csv(full_path, sep=",")
            df = df[df["has_recommend"] == False]
        elif model == "hit":
            if not path.endswith(".csv"):
                continue
            df = pd.read_csv(full_path, sep=",")
            df = df[(df["has_click"] == False) & (df["has_show"] == True)]
        else:
            if not path.endswith(".xlsx"):
                continue
            df = pd.read_excel(full_path)
        # 处理 'image_list是否为空' 列
        # df['image_list是否为空'] = df['image_search_request'].astype(str).apply(
        #     lambda x: 0 if x is None or (safe_eval(x) and safe_eval(x).get("image_list", None) is None) else 1
        # )
        df['image_list是否为空'] = df['image_search_request'].apply(
            lambda x: 0 if pd.isna(x) or (safe_eval(x) and safe_eval(x).get("image_list") is None) else 1
        )
        # 处理 'image_search_query是否为空' 列
        df['image_search_query是否为空'] = df['image_search_query'].isnull().astype(int)
        # 处理 'image_search_query为空的原因' 列
        df['image_search_query为空的原因'] = df.apply(
            lambda row: "无" if pd.notnull(row['image_search_query']) else
                        ("新闻不需要image_search_query" if row['recommend_type'] == "TS_NEWS"
                         else "title&query_ner未能击中title"),
            axis=1
        )
        # 处理 '是否有搜图结果' 列
        df['是否有搜图结果'] = df['image_search_response'].apply(
            lambda x: 1 if safe_eval(x) and "data" in safe_eval(x) and safe_eval(x).get("data") is not None else 0
        )
        # 处理 '搜图结果是否有图片' 列
        # df['搜图结果是否有图片'] = df['image_search_response'].apply(
        #     lambda x: 1 if safe_eval(x) and "data" in safe_eval(x) and safe_eval(x).get(
        #         "data") is not None and safe_eval(x)["data"][0].get("image_info", None) is not None else 0
        # )
        df['搜图结果是否有图片'] = df['image_search_response'].apply(
            lambda x: 1 if (safe_eval(x) and "data" in safe_eval(x) and isinstance(safe_eval(x)["data"], list) and len(safe_eval(x)["data"]) > 0)
            else 0
        )
        df['搜图错误出现在那个步骤'] = df.apply(
            lambda row: "无问题" if row['是否有搜图结果'] == 1 else which_erro_step(row),
            axis=1
        )
        statistical_save_path = build_save_path(full_path, "statistical", model)
        print(statistical_save_path)
        get_statistical(df, statistical_save_path)
        df.to_excel(build_save_path(full_path, "pro", model), index=False)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=str, choices=["recall", "recommend", "hit"], default="recall", help="模式选择")
    parser.add_argument("--file_name", type=str, default="data/local/temp/sample_1000_from_4.3_to_4.9.xlsx")
    args = parser.parse_args()
    main(args.model, args.file_name)

    # python -m recommend.struct_display.log_analyse.step2_rule_label --model recall --file_name data/local/temp/sample_1000_from_4.3_to_4.9.xlsx
    # python -m recommend.struct_display.log_analyse.step2_rule_label --model recommend --file_name data/local/recommend/struct_display/hit_rate_dig/hit_rate_dig_raw_data
    # python -m recommend.struct_display.log_analyse.step2_rule_label --model hit --file_name data/local/recommend/struct_display/hit_rate_dig/hit_rate_dig_raw_data
