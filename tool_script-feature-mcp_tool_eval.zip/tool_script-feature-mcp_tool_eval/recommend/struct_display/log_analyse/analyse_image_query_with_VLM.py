from transformers import Qwen2_5_VLForConditionalGeneration, AutoTokenizer, AutoProcessor
from qwen_vl_utils import process_vision_info


def Qwen_VLM(model_path: str, device: str = "cuda:0", min_pixels=256*28*28, max_pixels=1280*28*28):
    model = Qwen2_5_VLForConditionalGeneration.from_pretrained(
        model_path, torch_dtype="auto", device_map=device
    )
    processor = AutoProcessor.from_pretrained(model_path, min_pixels=min_pixels, max_pixels=max_pixels)

    return model, processor


def get_VLM_response(model, processor, device, url: str, prompt: str) -> str:

    messages = [
        {
            "role": "user",
            "content": [
                {
                    "type": "image",
                    "image": url,
                },
                {"type": "text", "text": prompt},
            ],
        }
    ]
    text = processor.apply_chat_template(
        messages, tokenize=False, add_generation_prompt=True
    )
    image_inputs, video_inputs = process_vision_info(messages)
    inputs = processor(
        text=[text],
        images=image_inputs,
        videos=video_inputs,
        padding=True,
        return_tensors="pt",
    )
    inputs = inputs.to(device)
    # Inference: Generation of the output
    generated_ids = model.generate(**inputs, max_new_tokens=128)
    generated_ids_trimmed = [
        out_ids[len(in_ids):] for in_ids, out_ids in zip(inputs.input_ids, generated_ids)
    ]
    output_text = processor.batch_decode(
        generated_ids_trimmed, skip_special_tokens=True, clean_up_tokenization_spaces=False
    )

    return output_text[0]


if __name__ == "__main__":
    import time
    model, processor = Qwen_VLM("data/rep/Qwen2.5-VL-7B-Instruct", "cuda:0")
    inference_time = time.time()
    print(get_VLM_response(model, processor, "recommend/struct_display/log_analyse/images.jpg", "这是个猫吗？你只用回答是或者不是"))
    print(f"inference time: {time.time() - inference_time:.2f}s")


# python -m recommend.struct_display.log_analyse.analyse_image_query_with_VLM
