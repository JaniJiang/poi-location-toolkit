import os
import re
import json
import argparse
import pandas as pd
from datetime import datetime
from recommend.struct_display.log_analyse.bottom_line_prompt import *
from utils.llm_utils.serverless_function import request_llm


def contains_cosine_score(response_str):
    try:
        data = json.loads(response_str)
        return "all result cosine socre" in data.get("message", "")
    except (json.JSONDecodeError, TypeError):
        return False


def hit_whitelist_func(response_str):
    try:

        data = json.loads(response_str)
        return "img-tag: outerAPIMatch,hit-blackwords" in data.get("message", "")
    except (json.JSONDecodeError, TypeError):
        return False


def query_result_empty_func(response_str):
    try:
        if response_str == "nan":
            return True
        data = json.loads(response_str)
        return data["data"][0] == {}
    except Exception as e:
        return False


def bottom_line_reply_func(row):
    try:
        # if row.get("搜图错误出现在那个步骤") != "兜底回复":
        #     return False
        if not bottom_response(row.get("image_search_response")):
            return False
        request_str = row.get("image_search_request")
        request = json.loads(request_str)
        orig_user_query = request.get("orig_user_query", "")
        model_answer = request.get("model_answer", "")
        bottom_line_prompt_system = bottom_line_prompt_system_template.format(
            question=orig_user_query, answer=model_answer)
        _, reponse = request_llm(history=[bottom_line_prompt_system, bottom_line_prompt_user_template])

        try:
            response_json = json.loads(reponse['choices'][0]['message']['content'])
            print(response_json)
            return response_json.get("answer", "")
        except (json.JSONDecodeError, TypeError):
            return False
    except Exception as e:
        print(e)
        return False


def bottom_response(response_str):
    try:
        data = json.loads(response_str)
        return "hit default answer for keyword" in data.get("message", "")
    except (json.JSONDecodeError, TypeError):
        return False


def have_api(ks_list):
    try:
        data = json.loads(ks_list)
        if len(data) == 0:
            return False
        return True
    except (json.JSONDecodeError, TypeError):
        return False


def pro_bottom_line_reply(df):
    ...


def main(file_path, model):
    # DONE：开发
    # 1. 有召回
    # 2. 无召回
    #     1. 查询条件为空
    #     2. 阈值过高
    #     3. 击中白名单
    #     4. 查询结果为空  "data":[{}]
    #     5. 策略误判为兜底
    #     6. 真实大模型兜底
    #     7. 无request
    mdoel_file = {
        "hit": "hit_result.xlsx",
        "recommend": "recommend_result.xlsx"
    }
    model_str = mdoel_file[model]
    file_list = os.listdir(file_path)
    file_list = [f for f in file_list if f.endswith(model_str)]
    len_df = have_recall = no_recall = search_image_issues = api_result_empty = query_condition_empty = \
        high_threshold = hit_whitelist = query_result_empty = interl_error = \
        bottom_line_reply_true = bottom_line_reply_false = 0
    for file_name in file_list:
        df = pd.read_excel(os.path.join(file_path, file_name))
        len_df += len(df)
        have_recall += df[df['搜图结果是否有图片'].astype(str) == "1"].shape[0]
        no_recall += df[df['搜图结果是否有图片'].astype(str) == "0"].shape[0]
        search_image_issues += df[(df['搜图结果是否有图片'].astype(str) == "0") &
                                  (df['是否有搜图结果'].astype(str) == "1")].shape[0]

        # search_image_issues = df[(df['搜图结果是否有图片'].astype(str) == "0") &
        #                          (df['是否有搜图结果'].astype(str) == "1")].shape[0]

        api_result_empty += df[(df["ks_result"].apply(have_api)) &
                               (df["image_list是否为空"].astype(str) == "0")].shape[0]

        # 搜图query，image——list为空， 搜图条件为空
        query_condition_empty += df[(df['搜图结果是否有图片'].astype(str) == "0") &
                                    (df['是否有搜图结果'].astype(str) == "0") &
                                    (df['image_list是否为空'].astype(str) == "0") &
                                    (df['image_search_query是否为空'].astype(str) == "1")].shape[0]

        # 搜图query，image——list为空， 搜图条件不为空
        high_threshold += df[(df['搜图结果是否有图片'].astype(str) == "0") &
                             (df['是否有搜图结果'].astype(str) == "0") &
                             ((df['image_list是否为空'].astype(str) == "1") | (df['image_search_query是否为空'].astype(str) == "0")) &
                             (df['image_search_response'].apply(contains_cosine_score))].shape[0]

        hit_whitelist += df[(df['搜图结果是否有图片'].astype(str) == "0") &
                            (df['是否有搜图结果'].astype(str) == "0") &
                            ((df['image_list是否为空'].astype(str) == "1") | (df['image_search_query是否为空'].astype(str) == "0")) &
                            (df["image_search_response"].apply(hit_whitelist_func))].shape[0]

        query_result_empty += df[(df['搜图结果是否有图片'].astype(str) == "0") &
                                 (df['是否有搜图结果'].astype(str) == "1") &
                                 ((df['image_list是否为空'].astype(str) == "1") | (df['image_search_query是否为空'].astype(str) == "0")) &
                                 (df["image_search_response"].astype(str).apply(query_result_empty_func))].shape[0]

        interl_error += df[(df['搜图结果是否有图片'].astype(str) == "0") &
                           (df['是否有搜图结果'].astype(str) == "0") &
                           ((df['image_list是否为空'].astype(str) == "1") | (df['image_search_query是否为空'].astype(str) == "0")) &
                           (df['image_search_request'].isnull())].shape[0]
        print(f"{file_name}:正在请求大模型处理兜底回复判断问题。。。。。。情请耐心等待。。。")
        bottom_line_reply_true_temp = df[(df['搜图结果是否有图片'].astype(str) == "0") &
                                         (df['是否有搜图结果'].astype(str) == "0") &
                                         ((df['image_list是否为空'].astype(str) == "1") | (df['image_search_query是否为空'].astype(str) == "0")) &
                                         (df['image_search_response'].apply(bottom_response)) &
                                         (df.apply(bottom_line_reply_func, axis=1))].shape[0]
        bottom_line_reply_true += bottom_line_reply_true_temp
        bottom_line_reply_false += (df[(df['搜图结果是否有图片'].astype(str) == "0") &
                                       (df['是否有搜图结果'].astype(str) == "0") &
                                       ((df['image_list是否为空'].astype(str) == "1") | (df['image_search_query是否为空'].astype(str) == "0")) &
                                       (df['image_search_response'].apply(bottom_response))].shape[0] - bottom_line_reply_true_temp)

    print(f"len_df: {len_df}")
    print(f"有召回：{have_recall}")
    print(f"无召回：{no_recall}")
    print(f"search_image_issues: {search_image_issues}")
    print(f"query_condition_empty: {query_condition_empty}")
    print(f"high_threshold: {high_threshold}")
    print(f"hit_whitelist: {hit_whitelist}")
    print(f"query_result_empty: {query_result_empty}")
    print(f"bottom_line_reply_true: {bottom_line_reply_true}")
    print(f"bottom_line_reply_false: {bottom_line_reply_false}")
    print(f"interl_error: {interl_error}")
    print("-----"*20)
    print(f"len_df: {len_df}")
    print(f"有召回：{have_recall / len_df:.2%}")
    print(f"无召回：{no_recall / len_df:.2%}")
    print(f"搜索算法问题:{search_image_issues / len_df:.2%}")
    print(f"查询条件为空:{query_condition_empty / len_df:.2%}")
    print(f"阈值过高:{high_threshold / len_df:.2%}")
    print(f"击中白名单:{hit_whitelist / len_df:.2%}")
    print(f"查询结果为空:{query_result_empty / len_df:.2%}")
    print(f"策略误判为兜底:{bottom_line_reply_true / len_df:.2%}")
    print(f"真实大模型兜底:{bottom_line_reply_false / len_df:.2%}")
    print(f"网络问题:{interl_error / len_df:.2%}")
    data = [
        ("总览", "有召回", "--", (have_recall + interl_error) / len_df),
        ("总览", "无召回", "--", (no_recall - interl_error) / len_df),
        ("上游问题", "空apiResults", "--", api_result_empty / len_df),
        ("搜索算法", "QU", "image_list为空，不走InnerMatch；搜图query为空，不走OuterSearch；导致未调用搜图服务（InnerMatch和OuterSearch）",
         query_condition_empty / len_df),
        ("搜索算法", "召回", "image_list不为空，走InnerMatch；InnerMatch匹配到image_list中的无图结果",
         (search_image_issues - query_result_empty) / len_df),
        ("搜索算法", "相关性", "image_list不为空，走InnerMatch；InnerMatch结果为空，answer和image_list相关性低", high_threshold / len_df),
        ("搜索算法", "黑名单干预", "image_list为空，不走InnerMatch，走OuterSearch；OuterSearch命中黑名单", hit_whitelist / len_df),
        ("其他", "兜底回复", "策略误判为兜底", bottom_line_reply_true / len_df),
        ("其他", "兜底回复", "真实大模型兜底", bottom_line_reply_false / len_df),
        ("其他", "请求异常", "--", query_result_empty / len_df),
    ]
    df_result = pd.DataFrame(data, columns=["问题（大类）", "问题（小类）",  "问题描述", "占比"])
    df_result["占比"] = df_result["占比"].apply(lambda x: f"{x:.2%}")
    # 提取日期字符串
    date_str = re.search(r'\d{4}-\d{2}-\d{2}', file_name).group()
    # 转换为周数
    week_num = datetime.strptime(date_str, "%Y-%m-%d").isocalendar().week
    # 构建最终路径
    save_path = os.path.join(os.path.dirname(file_path.rstrip("/")), "hit_rate_dig_statistical_data",
                             f"{week_num}周结构化挖掘统计数据.xlsx")
    df_result.to_excel(save_path, index=False)


if __name__ == '__main__':
    # file_path = "data/local/recommend/temp/数仓4.3-4.9处理数据_1.xlsx"
    argparser = argparse.ArgumentParser()
    argparser.add_argument("--file_path", type=str, default="data/local/recommend/temp/数仓4.3-4.9处理数据_1.xlsx")
    argparser.add_argument("--model", type=str, default="recommend")
    args = argparser.parse_args()
    # temp/数仓4.3-4.9处理数据_1.xlsx
    main(args.file_path, args.model)

    # python -m recommend.struct_display.log_analyse.step2_dig_recall --model recommend --file_path data/local/recommend/struct_display/temp/数仓4.3-4.9处理数据_1.xlsx
    # python -m recommend.struct_display.log_analyse.step2_dig_recall --model recommend --file_path data/local/recommend/struct_display/hit_rate_dig/hit_rate_dig_pro_data/sample_joined_table_2025-04-07_pro_result.xlsx
    # python -m recommend.struct_display.log_analyse.step2_dig_recall --model hit --file_path data/local/recommend/struct_display/hit_rate_dig/hit_rate_dig_pro_data/
