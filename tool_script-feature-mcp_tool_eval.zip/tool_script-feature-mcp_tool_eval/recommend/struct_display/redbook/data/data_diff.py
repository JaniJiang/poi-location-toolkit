import json
from utils.file_utils import read_json_file
from recommend.struct_display.redbook.meta import *


class DataDiff:

    def __init__(self, old_path, new_path):
        self.old_path = old_path
        self.new_path = new_path

    def process(self):
        old_id_list = self.get_id_list(self.old_path)
        new_id_list = self.get_id_list(self.new_path)
        common_count, different_count, old_list_unique_count, new_list_unique_count = self.compare_lists(
            old_id_list, new_id_list)
        print(f"共同元素数量: {common_count}")
        print(f"不同元素数量: {different_count}")
        print(f"删除元素数量: {old_list_unique_count}")
        print(f"新增元素数量: {new_list_unique_count}")

    def get_id_list(self, data_path):
        data_list = read_json_file(data_path)
        id_list = [json.loads(item)["note_id"] for item in data_list]
        return id_list

    def compare_lists(self, list1, list2):
        # 转换为集合计算共同元素（交集）
        set1 = set(list1)
        set2 = set(list2)
        common_elements = set1 & set2
        common_count = len(common_elements)
        # 计算对称差集（两个列表中不同的元素总数）
        different_elements = set1 ^ set2  # 等价于 (set1 - set2) | (set2 - set1)
        different_count = len(different_elements)
        # 计算list1中有但list2中没有的元素（差集：set1 - set2）
        list1_unique = set1 - set2
        list1_unique_count = len(list1_unique)
        # 计算list2中有但list1中没有的元素（差集：set2 - set1）
        list2_unique = set2 - set1
        list2_unique_count = len(list2_unique)
        return common_count, different_count, list1_unique_count, list2_unique_count


if __name__ == "__main__":
    # old_path = f"{DATA_DIR}/data/lxNote20250210.json"
    # new_path = f"{DATA_DIR}/data/lxNote20250303.json"
    # old_path = f"{DATA_DIR}/data/lxNote20250303.json"
    # new_path = f"{DATA_DIR}/data/lxNote20250312.json"
    old_path = f"{DATA_DIR}/data/lxNote20250210.json"
    new_path = f"{DATA_DIR}/data/lxNote20250312.json"
    obj = DataDiff(old_path, new_path)
    obj.process()

# python -m recommend.struct_display.redbook.data.data_diff
