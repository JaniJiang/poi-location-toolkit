# 路径参数
DATA_DIR = "data/cloud/recommend/struct_display/redbook"
# 向量模型参数
DIM = 128  # 768 | 128
BATCH_SIZE = 256
