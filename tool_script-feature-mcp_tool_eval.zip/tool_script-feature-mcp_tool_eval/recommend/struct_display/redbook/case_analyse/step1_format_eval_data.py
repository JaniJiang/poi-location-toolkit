import csv
import json
import pandas as pd
from tqdm import tqdm
from recommend.struct_display.redbook.meta import *


class FormatEvalData:

    def __init__(self):
        self.input_path = f"{DATA_DIR}/case_analyse/V0225-deepseek_结构化测试报告.xlsx"
        self.output_path = f"{DATA_DIR}/case_analyse/step1_format_eval_data.tsv"

    def process(self):
        sheet_df = pd.read_excel(self.input_path, sheet_name="结果集")
        sample_count = sheet_df["query"].count()
        result_list = []
        for _, row in tqdm(sheet_df.iterrows(), total=sample_count, desc="FormatEvalData"):
            if row["业务"] != "出行助手":
                continue
            try:
                response_dict = eval(row["描述response"])
                debug_info = response_dict.get("debugInfo", {})
                image_search_result = response_dict.get("imageDatas", [])
                is_recall = 1 if len(image_search_result) > 0 else 0
                is_redbook_recall = self.is_redbook_recall(image_search_result)
                result_item = {
                    "query": row["query"],
                    "is_recall": is_recall,
                    "is_redbook_recall": is_redbook_recall,
                    "answer": row["ds_answer"],
                    "title": debug_info.get("title", ""),
                    "keyword": debug_info.get("keyword", ""),
                    "query_ner": debug_info.get("query-ner", ""),
                    "answer_ner": debug_info.get("answer-ner", ""),
                    "image_search_query": debug_info.get("image-search-query", ""),
                    "image_search_result": json.dumps(image_search_result, ensure_ascii=False),
                }
                result_list.append(result_item)
            except Exception as e:
                print(e)
        # 保存处理结果
        with open(self.output_path, "w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=result_list[0].keys(), delimiter="\t")
            writer.writeheader()
            writer.writerows(result_list)

    def is_redbook_recall(self, image_search_result):
        is_redbook_recall = 0
        if len(image_search_result) > 0:
            media_resources = image_search_result[0].get("mediaResources", [])
            if len(media_resources) > 0:
                for item in media_resources:
                    if item.get("appName", "") == "小红书":
                        is_redbook_recall = 1
                        break
        return is_redbook_recall


if __name__ == "__main__":
    obj = FormatEvalData()
    obj.process()

# python -m recommend.struct_display.redbook.case_analyse.step1_format_eval_data
