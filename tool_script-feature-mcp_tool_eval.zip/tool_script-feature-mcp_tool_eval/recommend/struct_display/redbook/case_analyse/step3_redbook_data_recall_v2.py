import json
from tqdm import tqdm
from typing import List
from utils.file_utils import read_jsonl_file, read_text_split_file
from utils.nlp_utils.embedding import get_batch_embedding
from utils.search_utils.memory_qdrant import MemoryQdrant
from recommend.struct_display.redbook.meta import *


class RedbookDataRecall:
    """召回小红书的数据"""

    def __init__(self):
        self.query_path = f"{DATA_DIR}/case_analyse/step1_format_eval_data.labeled.tsv"
        self.index_path = f"{DATA_DIR}/case_analyse/step2_redbook_data_build.jsonl"
        self.output_path = f"{DATA_DIR}/case_analyse/step3_redbook_data_recall.jsonl"
        self.recall_num = 5
        self.local_model = True

    def process(self):
        # 读取query数据
        query_data_list = read_text_split_file(self.query_path)
        query_text_list = [x[1] for x in query_data_list]
        # 读取index数据
        text_index = self.build_index(self.index_path)
        # 检索小红书数据
        with open(self.output_path, "w", encoding="utf-8") as f:
            retriever_result = self.do_retriever("qa", text_index, query_text_list)
            for idx, item in enumerate(retriever_result):
                query_data = query_data_list[idx]
                item_format = query_data + [
                    item["has_item"],
                    str(item["score"]),
                    item["payload"].get("title", ""),
                    json.dumps(item["payload"], ensure_ascii=False),
                ]
                f.write("\t".join(item_format) + "\n")

    def build_index(self, index_path):
        print(f"build_index: {index_path}")
        text_index = MemoryQdrant()
        index_list = read_jsonl_file(index_path)
        for point in index_list:
            text_index.add_points([point])
        return text_index

    def do_retriever(self, data_type, text_index: MemoryQdrant, query_text_list: List[str]):
        print(f"do_retriever: {data_type}")
        retriever_result = []
        query_embedding_list = get_batch_embedding(query_text_list, DIM, BATCH_SIZE, self.local_model)
        for query_idx, query in tqdm(enumerate(query_text_list), total=len(query_text_list)):
            # 召回
            query_embedding = query_embedding_list[query_idx]
            item_list = text_index.search(query_embedding, top_k=self.recall_num)
            # 排序
            has_item, matched_item = self.do_rank(query, item_list)
            formated_item = {
                "has_item": has_item,
                "score": float(matched_item["score"]),
                "payload": matched_item["payload"],
            }
            retriever_result.append(formated_item)
        return retriever_result

    def do_rank(self, query, item_list):
        if len(item_list) == 0:
            return "0", {}
        return "1", item_list[0]


if __name__ == "__main__":
    obj = RedbookDataRecall()
    obj.process()

# python -m recommend.struct_display.redbook.case_analyse.step3_redbook_data_recall_v2
# sudo /home/huyangzhao/.conda/envs/tool/bin/python -m recommend.struct_display.redbook.case_analyse.step3_redbook_data_recall_v2
