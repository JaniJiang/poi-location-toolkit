import json
import hashlib
from tqdm import tqdm
from utils.file_utils import read_jsonl_file
from utils.nlp_utils.embedding import get_batch_embedding
from recommend.struct_display.redbook.meta import *


class RedbookDataBuild:
    """构建小红书的索引数据"""

    def __init__(self):
        self.input_path = f"{DATA_DIR}/case_analyse/redbook.jsonl"
        self.output_path = f"{DATA_DIR}/case_analyse/step2_redbook_data_build.jsonl"

    def process(self):
        # 读取数据
        knowledge_list = read_jsonl_file(self.input_path)
        print("knowledge_list len:", len(knowledge_list))
        # 逐条处理knowledge生成索引数据
        with open(self.output_path, "w", encoding="utf-8") as f:
            for i in tqdm(range(0, len(knowledge_list), BATCH_SIZE), desc="index"):
                # 获取Knowledge字段
                batch_question_list = []
                batch_question_id_list = []
                batch_question_dict = {}
                for knowledge_item in knowledge_list[i: (i + BATCH_SIZE)]:
                    question_id = str(knowledge_item.get("id", ""))
                    if question_id == "":
                        continue
                    question_list = [knowledge_item.get("title", "")]
                    if len(question_list) == 0:
                        continue
                    batch_question_list.extend(question_list)
                    batch_question_id_list.extend([question_id] * len(question_list))
                    batch_question_dict[question_id] = knowledge_item
                # 获取索引文本对应的向量
                try:
                    batch_embedding_list = get_batch_embedding(batch_question_list, DIM, BATCH_SIZE)
                except:
                    print("get_batch_embedding failed:", batch_question_dict.keys())
                    continue
                if len(batch_question_list) != len(batch_embedding_list):
                    continue
                # 逐条生成qdrant索引数据
                for i, batch_question in enumerate(batch_question_list):
                    batch_question_id = batch_question_id_list[i]
                    index_id = self.generate_index_id(batch_question_id, batch_question)
                    batch_embedding = batch_embedding_list[i]
                    qdrant_item = {
                        "id": index_id,
                        "vector": batch_embedding,
                        "payload": batch_question_dict.get(question_id, {})
                    }
                    f.write(json.dumps(qdrant_item, ensure_ascii=False) + "\n")

    def generate_index_id(self, question_id, question):
        index_id_origin = "_".join([question_id, question]).replace(" ", "_").lower()
        index_id = hashlib.md5(index_id_origin.encode("utf-8")).hexdigest()
        return index_id


if __name__ == "__main__":
    obj = RedbookDataBuild()
    obj.process()

# python -m recommend.struct_display.redbook.case_analyse.step2_redbook_data_build
# nohup python -m recommend.struct_display.redbook.case_analyse.step2_redbook_data_build > log/recommend/struct_display/redbook/case_analyse/step2_redbook_data_build.log 2>&1 &
