import csv
import os
import pandas as pd

root_path = "/mnt/pfs-guan-ssai/nlu/zhaojiufeng/log_data/recommend/log_join/struct"
file_list = [f for f in os.listdir(root_path) if f.endswith(".csv")]
print(file_list)


# keys
_ = ['', 'record_id', 'busi_time', 'data_json', 'has_click', 'has_recommend', 'has_show', 'recommend_type', 'vin', 'service_type', 'answer_ner_list', 'content_style',
     'content_text', 'display_template_id', 'display_template_type', 'error_code', 'image_search_query', 'image_search_request', 'image_search_response', 'keyword', 'ks_result',
     'media_result', 'msg_id', 'query_ner_list', 'raw_query', 'request', 'response', 'short_message', 'struct_display_info', 'subtitle', 'summary', 'template_signal',
     'timestamp', 'title', 'travel_position', 'query', 'slot_li', 'request_time', 'knowledge_search_result', 'media_search_result', 'time_space_modify_response']


print(os.path.join(root_path, file_list[0]))

for file in file_list:
    df = pd.read_csv(os.path.join(root_path, file), sep=",")
    df_len = len(df)
    exposure = df[df["has_recommend"] == True].shape[0]
    hit = df[df["has_click"] == True].shape[0]
    print(f"{file} - df_len: {df_len}, exposure_rate: {exposure / df_len:.2%}")
    print(f"{file} - df_len: {df_len}, hit_rate: {hit / exposure:.2%}")

# python -m recommend.struct_display.dig_hit_rate.step1_process_data
