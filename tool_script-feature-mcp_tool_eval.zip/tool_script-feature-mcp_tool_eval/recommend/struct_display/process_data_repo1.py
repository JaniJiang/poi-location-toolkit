import os
import csv
import json
import pandas as pd
from pyspark.sql import SparkSession
from pyspark.sql.types import MapType, StringType
from pyspark.sql.functions import col, rand, lit, when, size, udf, from_json
from pyspark.sql import functions as F

statistical_heads = ['文件名', '数据量', 'image_search_query 空占比', 'query_ner_empty 空占比', 'answer_ner_empty 空占比',
                     'title 空占比', 'keyword_empty 空占比', 'query_or_answer_ner 未命中占比', 'query_and_answer_ner 全为空占比']
statistical_save_path = 'recommend/struct_display/process_data_rep/statistical_data_rpeo.csv'


def write_to_excel(pandas_df, output_path):
    """将Pandas DataFrame保存为Excel文件"""
    # 创建输出目录
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    # 清理换行符和特殊字符
    cleaned_df = pandas_df.map(lambda x: x.replace("\n", " ").replace("\r", " ")
                               if isinstance(x, str) else x)

    # 保存Excel文件
    with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
        cleaned_df.to_excel(
            writer,
            index=False,
            sheet_name='SampledData',
            encoding='utf-8'
        )
    print(f"成功保存Excel文件至: {output_path}")


def save_statistical(statistical):
    # 检查文件是否存在以确定是否需要写入头
    file_exists = os.path.isfile(statistical_save_path)

    with open(statistical_save_path, 'a', encoding="utf-8") as f:
        writer = csv.writer(f)

        # 在文件不存在时写入头
        if not file_exists:
            writer.writerow(statistical_heads)

        # 写入统计数据
        writer.writerow(statistical)


def get_and_save_statistical(df, file_name):
    # 统计各类情况
    total_lines = df.count()  # 总行数
    image_search_query_empty = df.filter(col("image_search_query").isNull()).count()
    query_ner_list_empty = df.filter(col("query_ner_list") == "[]").count()
    answer_ner_list_empty = df.filter(col("answer_ner_list") == "[]").count()
    title_empty = df.filter(col("title").isNull()).count()
    keyword_empty = df.filter(col("keyword").isNull()).count()

    query_or_answer_ner_not_empty_and_title_empty = df.filter(
        (col("query_ner_list") != "[]") | (col("answer_ner_list") != "[]") & col("image_search_query").isNull()
    ).count()

    query_and_answer_ner_not_empty_and_title_empty = df.filter(
        (col("query_ner_list") == "[]") & (col("answer_ner_list") == "[]") & col("image_search_query").isNull()
    ).count()

    # 计算占比
    statistical = [
        file_name,  # 文件名
        total_lines,  # 数据量
        round((image_search_query_empty / total_lines) * 100, 2),
        round((query_ner_list_empty / (total_lines - image_search_query_empty)) * 100, 2),
        round((answer_ner_list_empty / (total_lines - image_search_query_empty)) * 100, 2),
        round((title_empty / total_lines) * 100, 2),
        round((keyword_empty / total_lines) * 100, 2),
        round((query_or_answer_ner_not_empty_and_title_empty / total_lines) * 100, 2),
        round((query_and_answer_ner_not_empty_and_title_empty / total_lines) * 100, 2)
    ]

    save_statistical(statistical)


def image_list_empty(json_str):
    try:
        dict = eval(json_str)
        if "image_list" in dict and dict["image_list"] is not None:
            return 1
        else:
            return 0
    except:
        return 0


def pro_image_search_query_empty(recommend_type):
    if recommend_type == "TS_NEWS":
        return "新闻不需要image_search_query"

    return "title&query_ner未能击中title"


def have_picture_data(image_search_response):
    try:
        image_search_response = eval(image_search_response)
        if "data" in dict and image_search_response["data"] is not None:
            return 1
        else:
            return 0
    except:
        return 0


def have_picture(image_search_response):
    try:
        image_search_response = eval(image_search_response)
        if "data" in image_search_response and image_search_response["data"] is not None and image_search_response["data"][0]["image_info"] is not None:
            return 1
        else:
            return 0
    except:
        return 0


def which_erro_step(recommend_type, image_search_query, image_search_response):
    if recommend_type == "TS_TRAVEL_SEARCH_":
        if image_search_query is None or image_search_query == "":
            return "没有image_search_query"
        else:
            return "召回失败"
    else:
        try:
            image_search_response = eval(image_search_response)
            if "message" in image_search_response and image_search_response["message"].startswith("image match,"):
                return "内外路召回失败"
            else:
                return "兜底回复"
        except:
            return "无Response"


def add_key_and_count_statistical(df, file_name):
    # 添加字段：image_list是否为空，image_search_query是否为空，image_search_query为空的原因，是否有搜图结果，搜图结果是否有图片，搜图错误出现在那个步骤
    # 统计指标：'文件名','数据量','image_search_query 空占比','query_ner_empty 空占比','answer_ner_empty 空占比','title 空占比','keyword_empty 空占比','query_or_answer_ner 未命中占比','query_and_answer_ner 全为空占比'
    # 定义 UDF，将字符串转换为字典

    image_list_empty_udf = udf(image_list_empty)
    pro_image_search_query_empty_udf = udf(pro_image_search_query_empty)
    have_picture_data_udf = udf(have_picture_data)
    have_picture_udf = udf(have_picture)
    which_erro_step_udf = udf(which_erro_step)

    # 判断 image_list 是否为空
    df = df.withColumn("image_list是否为空", image_list_empty_udf(col("image_search_request")))
    df = df.withColumn("image_search_query是否为空", col("image_search_query").isNull().cast("int"))
    # DONE: 处理 image_search_query 为空的原因
    # 条件：
    # 1. 新闻不需要image_search_query  DONE
    # 2. title&query_ner未能击中title  DONE
    image_search_empty_reason = ["title&query_ner未能击中title", "新闻不需要image_search_query"]
    df = df.withColumn("image_search_query为空的原因", pro_image_search_query_empty_udf(col("recommend_type")))
    df = df.withColumn("是否有搜图结果", have_picture_data_udf(col("image_search_response")))
    df = df.withColumn("搜图结果是否有图片", have_picture_udf(col("image_search_response")))
    # DONE: 搜图错误出现在那个步骤
    # 1. 小红书这个逻辑将要重新写错误原因  DONE
    # 2. 剩下的ERROR需要根据实际情况来写  DONE
    # 以下error支持：ency_qa，news, music, movie, default
    # 当出现NULL情况时 NULL导致的原因是请求失败的问题
    errors = ["image match, inner: inner match refused, query image list empty, outer-api: img-tag: outerAPIMatch,bingSearchByImageSearchQuery, image search query empty",
              "hit default answer for keyword [我很想帮你，但我没有], "]  # -> hashtable
    search_result_errors_redbook = ["没有image_search_query", "召回失败"]

    df = df.withColumn("搜图错误出现在那个步骤", which_erro_step_udf(col("recommend_type"),
                       col("image_search_query"), col("image_search_response")))
    # 统计指标
    # statistical = ['文件名','数据量','image_search_query 空占比','query_ner_empty 空占比','answer_ner_empty 空占比','title 空占比','keyword_empty 空占比','query_or_answer_ner 未命中占比','query_and_answer_ner 全为空占比']
    get_and_save_statistical(df, file_name)

    return df


def merge_csv(sampled_data_path):
    spark = SparkSession.builder.appName("Merge CSV").getOrCreate()
    merged_df = spark.read.csv(os.path.join(sampled_data_path, "*.csv"), header=True, inferSchema=True)
    merged_df.write.option("header", "true").csv(os.path.join(sampled_data_path, "merged_output.csv"))


def main():
    # 基本配置
    num = 1000
    sampled_data_path = 'recommend/struct_display/process_data_rep/sampling_data_by_image_search_query_empty.csv'

    # Spark 加载数据
    # 创建 Spark 会话
    spark = SparkSession.builder \
        .appName("CSV Processing") \
        .getOrCreate()

    ROOT_DIR = "data/cloud/recommend/struct_display/struct_display_logs_from_data_repo"
    data_files = [f for f in os.listdir(ROOT_DIR) if f.endswith('.csv')]
    sampling_output_file = 'recommend/struct_display/process_data_rep/sampling_data_by_image_search_query_empty.csv'
    statistical_file = 'recommend/struct_display/process_data_rep/statistical_data_rpeo.csv'

    data_files = [f for f in os.listdir(ROOT_DIR) if f.endswith('.csv')]

    # 处理字段任务：
    for i in range(len(data_files)):
        print(f"processing {data_files[i]} ...")
        file_path = os.path.join(ROOT_DIR, data_files[i])
        # 读取 CSV 文件到 DataFrame
        df = spark.read.csv(file_path, header=True, inferSchema=True, encoding='utf-8')

        # 处理字段任务
        processed_df = add_key_and_count_statistical(df, data_files[i])

        # 随机采样
        sampled_df = processed_df.sample(withReplacement=False, fraction=num / processed_df.count())
        # 使用制表符作为分隔符来保存为 TSV 格式
        sampled_df.coalesce(1).write.option("header", "true").option(
            "delimiter", "\t").mode("overwrite").csv(sampled_data_path)

        break

        # group采样
        # TODO

    merge_csv(sampled_data_path)


if __name__ == "__main__":
    main()

    # python -m recommend.struct_display.process_data_repo1
