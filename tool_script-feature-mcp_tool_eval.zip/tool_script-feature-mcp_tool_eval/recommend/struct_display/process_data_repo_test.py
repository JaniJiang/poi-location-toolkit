import os
import csv
import shutil
from pyspark.sql import SparkSession
from pyspark.sql.functions import col


def write_statistical_to_csv(statistical, file_name, original_file_name, total_lines):
    # 检查文件是否存在以确定是否需要写入头
    file_exists = os.path.isfile(file_name)

    with open(file_name, 'a', encoding="utf-8") as f:
        writer = csv.writer(f)

        # 在文件不存在时写入头
        if not file_exists:
            writer.writerow([
                '文件名',
                '数据量',
                'image_search_query 空占比',
                'query_ner_empty 空占比',
                'answer_ner_empty 空占比',
                'title 空占比',
                'keyword_empty 空占比',
                'query_or_answer_ner 未命中占比',
                'query_and_answer_ner 全为空占比'
            ])

        # 写入文件名称、总行数和统计数据
        writer.writerow([original_file_name, total_lines] + statistical)


def write_sampled_data_to_csv(sampled_df, file_name):
    # 确保输出目录存在
    os.makedirs(os.path.dirname(file_name), exist_ok=True)

    # 获取所有列名
    columns = sampled_df.columns

    with open(file_name, 'w', newline='', encoding="utf-8") as f:
        writer = csv.writer(f)

        # 写入表头
        writer.writerow(columns)

        # 逐行处理数据，确保不出现跨行混乱
        for row in sampled_df.collect():
            # 处理每一列数据，替换其中的换行符
            cleaned_row = []
            for value in row:
                if value is None:
                    cleaned_value = ""
                elif isinstance(value, str):
                    # 替换换行符为空格，并去除首尾空格
                    cleaned_value = value.replace("\n", " ").replace("\r", " ").strip()
                else:
                    cleaned_value = str(value)
                cleaned_row.append(cleaned_value)

            writer.writerow(cleaned_row)


# 创建 Spark 会话
spark = SparkSession.builder \
    .appName("CSV Processing") \
    .getOrCreate()

ROOT_DIR = "data/cloud/recommend/struct_display/data_repo_data"
data_files = [f for f in os.listdir(ROOT_DIR) if f.endswith('.csv')]
sampling_output_file = 'recommend/struct_display/process_data_rep/sampling_data_by_image_search_query_empty.csv'
statistical_file = 'recommend/struct_display/process_data_rep/statistical_data_rpeo.csv'

# 初始化采样结果DataFrame
sampled_data = None
header_written = False


for i in range(len(data_files)):
    print(f"processing {data_files[i]} ...")

    file_path = os.path.join(ROOT_DIR, data_files[i])

    # 读取 CSV 文件到 DataFrame
    df = spark.read.csv(file_path, header=True, inferSchema=True)

    # 统计各类情况
    total_lines = df.count()  # 总行数
    num = df.filter(col("recommend_type") == "TS_DEFAULT").count()
    print(f"{file_path}文件中，TS_DEFAULT rate: {num / total_lines * 100:.2f}%")
#     image_search_query_empty = df.filter(col("image_search_query").isNull()).count()
#     query_ner_list_empty = df.filter(col("query_ner_list") == "[]").count()
#     answer_ner_list_empty = df.filter(col("answer_ner_list") == "[]").count()
#     title_empty = df.filter(col("title").isNull()).count()
#     keyword_empty = df.filter(col("keyword").isNull()).count()

#     query_or_answer_ner_not_empty_and_title_empty = df.filter(
#         (col("query_ner_list") != "[]") | (col("answer_ner_list") != "[]") & col("image_search_query").isNull()
#     ).count()

#     query_and_answer_ner_not_empty_and_title_empty = df.filter(
#         (col("query_ner_list") == "[]") & (col("answer_ner_list") == "[]") & col("image_search_query").isNull()
#     ).count()

#     # 计算占比
#     statistical = [
#         round((image_search_query_empty / total_lines) * 100, 2),
#         round((query_ner_list_empty / (total_lines - image_search_query_empty)) * 100, 2),
#         round((answer_ner_list_empty / (total_lines - image_search_query_empty)) * 100, 2),
#         round((title_empty / total_lines) * 100, 2),
#         round((keyword_empty / total_lines) * 100, 2),
#         round((query_or_answer_ner_not_empty_and_title_empty / total_lines) * 100, 2),
#         round((query_and_answer_ner_not_empty_and_title_empty / total_lines) * 100, 2)
#     ]

#     print(statistical, total_lines)
#     write_statistical_to_csv(statistical, statistical_file, data_files[i], total_lines)

#     # 采样image_search_query为空的数据
#     empty_query_df = df.filter(col("image_search_query").isNull())
#     empty_count = empty_query_df.count()

#     # 计算采样数量（不超过100条）
#     sample_size = min(100, empty_count)

#     if sample_size > 0:
#         # 采样数据
#         sampled_df = empty_query_df.sample(withReplacement=False, fraction=1.0).limit(sample_size)

#         # 如果是第一次采样，直接赋值；否则合并
#         if sampled_data is None:
#             sampled_data = sampled_df
#         else:
#             sampled_data = sampled_data.union(sampled_df)

#         print(f"Sampled {sample_size} rows from {data_files[i]} where image_search_query is empty")

# # 如果采样到了数据，则写入文件
# if sampled_data is not None:
#     write_sampled_data_to_csv(sampled_data, sampling_output_file)
#     print(f"Sampled data saved to {sampling_output_file} as a single CSV file")
# else:
#     print("No data sampled (no empty image_search_query found in any file)")

spark.stop()

# python -m recommend.struct_display.process_data_repo
