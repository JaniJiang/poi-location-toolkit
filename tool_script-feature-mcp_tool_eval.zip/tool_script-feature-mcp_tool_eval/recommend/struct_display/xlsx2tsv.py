import pandas as pd

# 读取xlsx文件
xlsx_file = 'recommend/struct_display/V0225-deepseek_结构化测试报告.xlsx'  # 替换为您的xlsx文件路径
df = pd.read_excel(xlsx_file,sheet_name="结果集")

# 将DataFrame导出为tsv文件
tsv_file = 'recommend/struct_display/V0225-deepseek_结构化测试报告.tsv'  # 替换为希望输出的tsv文件路径
df.to_csv(tsv_file, sep='\t', index=False)  # 使用制表符作为分隔符


# python -m recommend.struct_display.xlsx2tsv