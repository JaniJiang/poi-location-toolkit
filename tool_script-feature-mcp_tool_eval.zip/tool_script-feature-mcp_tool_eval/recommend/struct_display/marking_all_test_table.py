import csv
import json
from tqdm import tqdm
import pandas as pd
from typing import List, Dict, Any
from recommend.struct_display.meta import *


# using [payload, response_data = request_llm(history, model=self.model_name, n=1, temperature=0)]
from utils.llm_utils.serverless_function import request_llm


class Marking_Table:
    def __init__(self):
        self.model_name = "gpt-4o"
        self.table_path = f"recommend/struct_display/V0225-deepseek_结构化测试报告.xlsx"
        self.prompt_path = f"recommend/struct_display/prompt/marking_table.json"
        self.output_file_path = f"recommend/struct_display/v0225_ds_marking_by_gpt.tsv"

        self.prompt_data = json.load(open(self.prompt_path, "r"))
        self.prompt_data_system_before = self.prompt_data.get("system_prompt_before", "")
        self.prompt_data_system_after = self.prompt_data.get("system_prompt_after", "")
        self.prompt_data_user = self.prompt_data.get("user_prompt", "")

        if self.prompt_data_system_before == "" or self.prompt_data_user == "":
            print(f"{self.prompt_path} 有问题！")
            exit()

        # 初始化空row
        self.row_new_data = {}
        self.new_data_list = []

        print("init finished!")

    def build_new_data(self, row, stage ,response_json = None):
        if stage == 0:
            # 原始数据写入
            self.row_new_data["业务"] = row.get("业务","")
            self.row_new_data["分类"] = row.get("分类","")
            self.row_new_data["预期预测模板"] = row.get("预期预测模板","")
            self.row_new_data["query"] = row.get("query","")
            self.row_new_data["answer"] = row.get("ds_answer","")
            self.row_new_data["api_reult"] = row.get("api_reult","")

            if row["描述response"]:
                try:
                    debug_info_dict = eval(row.get("描述response", "")).get("debugInfo", "")
                    self.row_new_data["title"] = debug_info_dict.get("title", "")
                    self.row_new_data["query_ner"] = debug_info_dict.get("query-ner", "")
                    self.row_new_data["answer_ner"] = debug_info_dict.get("answer-ner", "")
                    self.row_new_data["keyword"] = debug_info_dict.get("keyword", "")
                    # self.row_new_data["image_search_query"] = debug_info_dict.get("image-search-query", "")
                    # image_search_result 

                except Exception as e:
                    self.row_new_data["title"] = ""
                    self.row_new_data["query_ner"] = ""
                    self.row_new_data["answer_ner"] = ""
                    self.row_new_data["keyword"] = ""
                    # print("build_new_data:", e)
                    # print(eval(row.get("描述response", "")))
                    # print("1111"*20)
        else:
            try:
                #大模型回复数据写入
                self.row_new_data["title是否准确"] = response_json.get("title", "")
                self.row_new_data["keyword是否准确"] = response_json.get("keyword","")
                self.row_new_data["query_ner是否准确"] = response_json.get("query_ner","")
                self.row_new_data["answer_ner是否准确"] = response_json.get("answer_ner","")
                # self.row_new_data["image_search_result是否准确"] = response_json["image_search_result"]
            except Exception as e:
                self.row_new_data["title是否准确"] = ""
                self.row_new_data["keyword是否准确"] = ""
                self.row_new_data["query_ner是否准确"] = ""
                self.row_new_data["answer_ner是否准确"] = ""
                print("build_new_data:", e)
            

    
    def built_new_table(self):
        fieldnames = self.new_data_list[0].keys() if self.new_data_list else []

        # 打开输出文件
        with open(self.output_file_path, mode='w', newline='', encoding='utf-8') as file:
            # 创建一个 CSV 写入器，指定分隔符为制表符
            writer = csv.DictWriter(file, fieldnames=fieldnames, delimiter='\t')
            
            # 写入表头
            writer.writeheader()
            
            # 写入行数据
            writer.writerows(self.new_data_list)

        print(f"数据已写入 {self.output_file_path}")

    def send_message(self):
        # 构建对话list 
        message = self.build_message()
        # 得到回复json
        _, response_data = request_llm(message, model=self.model_name, n=1, temperature=0)

        try:
            response_json = json.loads(response_data['choices'][0]['message']['content'])
        except Exception as e:
            print("send_message:", e)
            return {}
        
        return  response_json

    def build_message(self) -> List:

        system_prompt = self.prompt_data_system_before.format(user_query = self.row_new_data["query"],
                                                       nlp_ans = self.row_new_data["answer"],
                                                       title = self.row_new_data["title"],
                                                       keyword = self.row_new_data["keyword"],
                                                       query_ner = self.row_new_data["query_ner"],
                                                       answer_ner = self.row_new_data["answer_ner"],) + self.prompt_data_system_after
        
        return [
            system_prompt,
            self.prompt_data_user
        ]
        


    def run(self):

        df = pd.read_excel(self.table_path, sheet_name="结果集")
        # 打乱
        df = df.sample(frac=1, random_state=42).reset_index(drop=True)
        total_entries = len(df)

        # 出行助手， 娱乐助手， 百科老师， 通用问答
        limit_dict = {
            "出行助手": [0, 150],
            "娱乐助手": [0, 150],
            "百科老师": [0, 135],
            "通用问答": [0, 150],
        }

        for _, row in tqdm(df.iterrows(), total=total_entries, desc="Processing rows"):
            if limit_dict[row["业务"]][0] > limit_dict[row["业务"]][1]:
                continue
            else:
                limit_dict[row["业务"]][0] += 1

            self.build_new_data(row, stage=0)
            response_json = self.send_message()
            self.build_new_data(row=row, stage=1, response_json=response_json)
            self.new_data_list.append(self.row_new_data)
            # 重置数据
            self.row_new_data = {}

        print(f"已经处理完成！")
        #创建新的表格
        self.built_new_table()


if __name__ == "__main__":

    MT = Marking_Table()
    MT.run()


# python -m recommend.struct_display.marking_all_test_table
# nohup python -m recommend.struct_display.marking_all_test_table > recommend/struct_display/marking_all_test_table.log 2>&1 &