import argparse
from pyspark.sql.functions import col, udf
from utils.spark_utils import init_spark_with_config
from utils.ark_utils import load_df_from_json_dir

parser = argparse.ArgumentParser()
parser.add_argument("--log_date", type=str, required=True)
parser.add_argument("--log_dir", type=str, default="/mnt/pfs-guan-ssai/ssrde/team/xuzhou1/tmp")
args = parser.parse_args()
print("log_date: ", args.log_date)
print("log_dir: ", args.log_dir)

# 读取数据
input_dir = f"{args.log_dir}/result/car_log_for_tool/2025-02-*"
spark = init_spark_with_config("car_log_for_tool", args.log_dir + "/local")
df_all = load_df_from_json_dir(spark, input_dir)
print("df_all.count(): ", df_all.count())


def process_fields(api_name, domain):
    """处理字段"""
    api_name = api_name if type(api_name) is str else ""
    domain = domain if type(domain) is str else ""
    tool_name = api_name if api_name != "" else domain
    return [tool_name]


# 处理字段
process_fields_udf = udf(process_fields, returnType="array<string>")
df_all_query = df_all \
    .withColumn("processed_result", process_fields_udf(df_all.api_name, df_all.domain)) \
    .select("query", "api_query", "api_name", "category", "media_type", "domain",
            col("processed_result")[0].alias("tool_name"))
print("df_all_query.count(): ", df_all_query.count())
df_all_query.repartition(10).write.format("json").mode("overwrite") \
    .option("compression", "none").option("lineSep", "\n") \
    .save(f"{args.log_dir}/result/car_tool_distribution/{args.log_date}")

# 统计字段
# df_all_query_stats = df_all_query.groupBy("api_name", "domain").count().orderBy(col("count").desc())
# print("df_all_query_stats.count(): ", df_all_query_stats.count())
# df_all_query_stats.coalesce(1).write.mode("overwrite") \
#     .csv(f"{args.log_dir}/result/car_tool_distribution/{args.log_date}",
#          sep="\t", header=True, escapeQuotes=False, quoteAll=False)

# cd ark_script && /opt/spark/bin/spark-submit car_tool_distribution.py --log_date=2025-02-11
# cat 2025-02-11.jsonl | jq -r '.tool_name' | sort | uniq -c | sort -nr
