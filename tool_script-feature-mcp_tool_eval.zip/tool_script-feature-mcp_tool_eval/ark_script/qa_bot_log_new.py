import argparse
from pyspark.sql.functions import col, regexp_extract, when, from_json
from pyspark.sql.types import StructType, StructField, StringType, ArrayType
from utils.spark_utils import init_spark_with_config_2
from utils.ark_utils import load_df_from_hudi
from utils.udf_utils import save_as_jsonl


parser = argparse.ArgumentParser()
parser.add_argument("--log_date", type=str, required=True)
parser.add_argument("--log_dir", type=str, default="/mnt/pfs-guan-ssai/nlu/xuzhou1/data/ark_log")
args = parser.parse_args()
print("log_date: ", args.log_date)
print("log_dir: ", args.log_dir)

# 读取数据
table_path = f"bos://spaceai-internal/ark/prod_env/ark_data/ods_service_expert_log_v1_prod/{args.log_date}"
spark = init_spark_with_config_2("qa_bot_log_new", args.log_dir + "/local")
df_all = load_df_from_hudi(spark, table_path)
print("df_all.count(): ", df_all.count())

### 方法一 ###

# 加载数据，但只选择需要的列
raw_df = df_all.select("message")

# 定义JSON schema以便更高效的解析
request_schema = StructType([
    StructField("input", StructType([
        StructField("text", StringType(), True)
    ]), True)
])
response_schema_assistant = StructType([
    StructField("data", StructType([
        StructField("qaPayload", StructType([
            StructField("question", StringType(), True),
            StructField("speak", StringType(), True)
        ]), True)
    ]), True)
])
response_schema_expert = StructType([
    StructField("data", ArrayType(StructType([
        StructField("expandQuestion", StringType(), True),
        StructField("answer", StringType(), True)
    ])), True)
])
# 1. 分析消息类型并提取URI
df_with_uri = raw_df.withColumn(
    "uri_type",
    when(col("message").contains("uri=/assistant/query/release_prod"), "in_car_assistant")
    .when(col("message").contains("uri=/expert/query"), "autoqa")
    .otherwise("unknown")
)
# 2. 只保留已知类型的消息
df_filtered = df_with_uri.filter(col("uri_type") != "unknown")
# 3. 提取request和response部分（使用正则表达式提取request和response JSON字符串）
df_extracted = df_filtered \
    .withColumn("request_str", regexp_extract(col("message"), r",request=(\{.*?\}),response=", 1)) \
    .withColumn("response_str", regexp_extract(col("message"), r",response=(\{.*?\})$", 1))
# 4. 解析JSON - 分阶段处理不同类型的消息
# 处理in_car_assistant类型
df_assistant = df_extracted.filter(col("uri_type") == "in_car_assistant") \
    .withColumn("request_json", from_json(col("request_str"), request_schema)) \
    .withColumn("response_json", from_json(col("response_str"), response_schema_assistant)) \
    .select(
        col("uri_type").alias("module"),
        col("request_json.input.text").alias("query"),
        col("response_json.data.qaPayload.question").alias("question"),
        col("response_json.data.qaPayload.speak").alias("answer")
)
# 处理autoqa类型
df_expert = df_extracted.filter(col("uri_type") == "autoqa") \
    .withColumn("request_json", from_json(col("request_str"), request_schema)) \
    .withColumn("response_json", from_json(col("response_str"), response_schema_expert)) \
    .select(
        col("uri_type").alias("module"),
        col("request_json.input.text").alias("query"),
        col("response_json.data").getItem(0).getField("expandQuestion").alias("question"),
        col("response_json.data").getItem(0).getField("answer").alias("answer")
)
# 5. 合并两种类型的结果
df_combined = df_assistant.union(df_expert)
# 6. 过滤掉不完整的记录
df_qabot = df_combined.filter(
    (col("module").isNotNull()) &
    (col("query").isNotNull() & (col("query") != "")) &
    (col("question").isNotNull() & (col("question") != "")) &
    (col("answer").isNotNull() & (col("answer") != ""))
)
# 7. 处理异常 - 尝试处理可能出现的null值
df_qabot = df_qabot.na.fill("")

# 保存处理结果
save_as_jsonl(df_qabot, f"{args.log_dir}/result/qa_bot_log_new/{args.log_date}", 10)


### 方法二（会有OOM报错，无法使用） ###

# def process_message(message):
#     try:
#         request = json.loads(message.split(",request=")[1].split(",response=")[0])
#         response = json.loads(message.split(",request=")[1].split(",response=")[1])
#         # 自由对话日志
#         if "uri=/assistant/query/release_prod" in message:
#             return [
#                 "in_car_assistant",
#                 str(request["input"]["text"]),
#                 str(response["data"]["qaPayload"]["question"]),
#                 str(response["data"]["qaPayload"]["speak"]),
#             ]
#         # 大模型链路qabot召回日志
#         elif "uri=/expert/query" in message:
#             return [
#                 "autoqa",
#                 str(request["input"]["text"]),
#                 str(response["data"][0]["expandQuestion"]),
#                 str(response["data"][0]["answer"]),
#             ]
#     except:
#         pass
#     return ["", "", "", ""]


# # 处理字段
# process_message_udf = udf(process_message, returnType="array<string>")
# df_qabot = df_all \
#     .select("message") \
#     .withColumn("message_result", process_message_udf(col("message"))) \
#     .select(
#         col("message_result")[0].alias("module"),
#         col("message_result")[1].alias("query"),
#         col("message_result")[2].alias("question"),
#         col("message_result")[3].alias("answer")
#     ) \
#     .filter(
#         (col("module") != "") &
#         (col("query") != "") &
#         (col("question") != "") &
#         (col("answer") != "")
#     )

# # 保存处理结果
# save_as_jsonl(df_qabot, f"{args.log_dir}/result/qa_bot_log_new/{args.log_date}", 10)

# cd ark_script && /opt/spark/bin/spark-submit qa_bot_log_new.py --log_date=2025-04-09
