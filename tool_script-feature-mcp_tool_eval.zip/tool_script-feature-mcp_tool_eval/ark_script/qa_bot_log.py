import argparse
from pyspark.sql.functions import col, udf
from utils.spark_utils import init_spark_with_config
from utils.ark_utils import load_df_from_hudi
from utils.udf_utils import process_slot_li, process_qa_bot_content

parser = argparse.ArgumentParser()
parser.add_argument("--log_date", type=str, required=True)
parser.add_argument("--log_dir", type=str, default="/mnt/pfs-guan-ssai/nlu/xuzhou1/data/ark_log")
args = parser.parse_args()
print("log_date: ", args.log_date)
print("log_dir: ", args.log_dir)

# 读取数据
table_path = f"bos://spaceai-internal/ark/prod_env/ark_data/dwd_vechile_merge_prod_di/{args.log_date}"
spark = init_spark_with_config("qa_bot_log", args.log_dir + "/local")
df_all = load_df_from_hudi(spark, table_path)
print("df_all.count(): ", df_all.count())

# 处理字段
process_slot_li_udf = udf(process_slot_li, returnType="array<string>")
process_qa_bot_content_udf = udf(process_qa_bot_content, returnType="array<string>")
df_qabot = df_all.filter(col("domain").isin(["in_car_assistant"])) \
    .select("query", "slot_li", "content") \
    .withColumn("slot_processed_result", process_slot_li_udf(col("slot_li"))) \
    .withColumn("content_processed_result", process_qa_bot_content_udf(col("content"))) \
    .select(
        "query",
        col("slot_processed_result")[0].alias("api_query"),
        col("slot_processed_result")[1].alias("api_name"),
        col("slot_processed_result")[2].alias("category"),
        col("slot_processed_result")[3].alias("media_type"),
        col("content_processed_result")[0].alias("hit_question"),
        col("content_processed_result")[1].alias("hit_question_id"),
        col("content_processed_result")[2].alias("standard_id"),
        col("content_processed_result")[3].alias("speak"),
        col("content_processed_result")[4].alias("answer_title"),
        col("content_processed_result")[5].alias("answer_content")) \
    .filter(col("hit_question") != "")
print("df_qabot.count(): ", df_qabot.count())

# 保存处理结果
df_qabot.repartition(1).write.format("json").mode("overwrite") \
    .option("compression", "none").option("lineSep", "\n") \
    .save(f"{args.log_dir}/result/qa_bot_log/{args.log_date}")

# cd ark_script && /opt/spark/bin/spark-submit qa_bot_log.py --log_date=2025-04-09
