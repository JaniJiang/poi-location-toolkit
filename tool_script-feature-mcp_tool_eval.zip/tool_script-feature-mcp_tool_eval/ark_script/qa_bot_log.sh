#!/bin/bash
# cd ark_script && bash qa_bot_log.sh

source utils/init.sh
date_num=14
recent_dates=($(get_recent_dates $date_num))

for recent_date in "${recent_dates[@]}"; do
    output_dir="../data/cloud/ark_log/result/qa_bot_log/$recent_date"
    output_flag="$output_dir/_SUCCESS"
    if [ -f $output_flag ]; then
        echo "output already exist: $recent_date"
    else
        echo "run script: /opt/spark/bin/spark-submit qa_bot_log.py --log_date=$recent_date"
        /opt/spark/bin/spark-submit qa_bot_log.py --log_date=$recent_date
    fi
done
