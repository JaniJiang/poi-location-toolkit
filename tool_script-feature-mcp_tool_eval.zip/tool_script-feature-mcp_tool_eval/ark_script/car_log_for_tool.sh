#!/bin/bash
# cd ark_script && bash car_log_for_tool.sh

source utils/init.sh
date_num=7
recent_dates=($(get_recent_dates $date_num))

for recent_date in "${recent_dates[@]}"; do
    output_dir="../data/cloud/result/car_log_for_tool/$recent_date"
    output_flag="$output_dir/_SUCCESS"
    if [ -f $output_flag ]; then
        echo "output already exist: $recent_date"
    else
        echo "run script: /opt/spark/bin/spark-submit car_log_for_tool.py --log_date=$recent_date"
        /opt/spark/bin/spark-submit car_log_for_tool.py --log_date=$recent_date
        # cat $output_dir/part-* > $output_dir/../$recent_date.jsonl
    fi
done
