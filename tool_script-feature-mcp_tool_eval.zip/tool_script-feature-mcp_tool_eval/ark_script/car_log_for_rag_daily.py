import argparse
from pyspark.sql.functions import rand
from utils.spark_utils import init_spark_with_config
from utils.udf_utils import process_rag_log_for_date, save_as_jsonl

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--log_date", type=str, required=True)
    parser.add_argument("--log_dir", type=str, default="/mnt/pfs-guan-ssai/nlu/xuzhou1/data/ark_log")
    args = parser.parse_args()
    print("args: ", args)
    # 初始化Spark
    spark = init_spark_with_config("car_log_for_rag_daily", args.log_dir + "/local")
    # 读取数据
    df_daily = process_rag_log_for_date(spark, args.log_date)
    save_as_jsonl(df_daily, f"{args.log_dir}/result/car_log_for_rag_daily/{args.log_date}", 10)
    # 随机数据
    df_sampled = df_daily.sample(fraction=0.1, seed=42).orderBy(rand()).limit(1000)
    save_as_jsonl(df_sampled, f"{args.log_dir}/result/car_log_for_rag_daily_sampled/{args.log_date}")

# cd ark_script && /opt/spark/bin/spark-submit car_log_for_rag_daily.py --log_date=2025-03-18
# cat part-*.json|jq -r '[.api_name,.category,.media_type]|join("\t")'|sort|uniq -c|sort -nr|awk -F" " '{print $2,$3,$4,$1}' OFS="\t" > count.tsv
