import argparse
from pyspark.sql.functions import rand
from utils.spark_utils import init_spark_with_config
from utils.udf_utils import process_rag_log_for_date, save_as_jsonl
from utils.common_utils import get_dates_of_last_week


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--end_date", type=str, help="End date in YYYY-MM-DD format. Defaults to yesterday")
    parser.add_argument("--log_dir", type=str, default="/mnt/pfs-guan-ssai/nlu/xuzhou1/data/ark_log")
    args = parser.parse_args()
    print("args: ", args)
    # 获取上一周的日期列表
    date_list = get_dates_of_last_week(args.end_date)
    start_date = date_list[0]
    end_date = date_list[-1]
    print(f"Processing log data from {start_date} to {end_date}")
    # 初始化Spark
    spark = init_spark_with_config("car_log_for_rag_weekly", args.log_dir + "/local")
    # 处理每天的日志并合并
    df_weekly = []
    for date in date_list:
        df_daily = process_rag_log_for_date(spark, date)
        if df_daily is not None:
            df_weekly.append(df_daily)
    if not df_weekly:
        print("No data found for the specified date range")
        exit(1)
    # 合并所有日期的数据
    df_combined = df_weekly[0]
    for df_daily in df_weekly[1:]:
        df_combined = df_combined.unionByName(df_daily)
    print(f"Combined df count: {df_combined.count()}")
    save_as_jsonl(df_combined, f"{args.log_dir}/result/car_log_for_rag_weekly/{start_date}_to_{end_date}", 50)
    # 随机抽样
    df_combined = df_combined.repartition(100)
    df_sampled = df_combined.sample(fraction=0.1, seed=42).orderBy(rand()).limit(10000)
    save_as_jsonl(df_sampled, f"{args.log_dir}/result/car_log_for_rag_weekly_sampled/{start_date}_to_{end_date}")

# 使用示例:
# cd ark_script && /opt/spark/bin/spark-submit car_log_for_rag_weekly.py
# cd ark_script && /opt/spark/bin/spark-submit car_log_for_rag_weekly.py --end_date=2025-03-30
# cd ark_script && nohup /opt/spark/bin/spark-submit car_log_for_rag_weekly.py --end_date=2025-03-30 > ../log/car_log_for_rag_weekly/2025-03-30.log 2>&1 &
