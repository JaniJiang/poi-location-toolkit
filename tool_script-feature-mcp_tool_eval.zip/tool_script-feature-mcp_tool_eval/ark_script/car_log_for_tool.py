import argparse
from pyspark.sql.functions import col, udf
from utils.spark_utils import init_spark_with_config
from utils.ark_utils import load_df_from_hudi
from utils.udf_utils import process_slot_li, process_domain_li

parser = argparse.ArgumentParser()
parser.add_argument("--log_date", type=str, required=True)
parser.add_argument("--log_dir", type=str, default="/mnt/pfs-guan-ssai/ssrde/team/xuzhou1/tmp")
args = parser.parse_args()
print("log_date: ", args.log_date)
print("log_dir: ", args.log_dir)

# 读取数据
table_path = f"bos://spaceai-internal/ark/prod_env/ark_data/dwd_vechile_merge_prod_di/{args.log_date}"
spark = init_spark_with_config("car_log_for_tool", args.log_dir + "/local")
df_all = load_df_from_hudi(spark, table_path)
print("df_all.count(): ", df_all.count())

# 处理字段
process_slot_li_udf = udf(process_slot_li, returnType="array<string>")
process_domain_li_udf = udf(process_domain_li, returnType="array<string>")
df_all_query = df_all.filter(col("domain").isin(["gpt_chat", "gpt_autoqa"])) \
    .select("query", "slot_li", "domain_li", "model_1b_output") \
    .withColumn("slot_processed_result", process_slot_li_udf(col("slot_li"))) \
    .withColumn("domain_processed_result", process_domain_li_udf(col("domain_li"))) \
    .select(
        "query",
        col("slot_processed_result")[0].alias("api_query"),
        col("slot_processed_result")[1].alias("api_name"),
        col("slot_processed_result")[2].alias("category"),
        col("slot_processed_result")[3].alias("media_type"),
        col("slot_processed_result")[4].alias("api_query_num"),
        col("domain_processed_result")[0].alias("domain"),
        "slot_li", "domain_li", "model_1b_output")
print("df_all_query.count(): ", df_all_query.count())

# 保存处理结果
df_all_query.repartition(100).write.format("json").mode("overwrite") \
    .option("compression", "none").option("lineSep", "\n") \
    .save(f"{args.log_dir}/result/car_log_for_tool/{args.log_date}")

# cd ark_script && /opt/spark/bin/spark-submit car_log_for_tool.py --log_date=2025-02-10
