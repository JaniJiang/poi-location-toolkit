import argparse
from pyspark.sql.functions import col, rand, udf
from utils.spark_utils import init_spark_with_config
from utils.udf_utils import process_domain_log_for_date, save_as_jsonl
from utils.sample_utils import sample_by_column


def process_fields(domain, api_name, category, media_type):
    """处理字段"""
    domain = domain if type(domain) is str else ""
    api_name = api_name if type(api_name) is str else ""
    category = category if type(category) is str else ""
    media_type = media_type if type(media_type) is str else ""
    domain_key = domain
    if domain in ["gpt_chat", "gpt_autoqa"]:
        if api_name in ["MEDIASearch"]:
            domain_key = "_".join([domain, api_name, media_type])
        else:
            domain_key = "_".join([domain, api_name, category])
    return [domain_key]


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--log_date", type=str, required=True)
    parser.add_argument("--log_dir", type=str, default="/mnt/pfs-guan-ssai/nlu/xuzhou1/data/ark_log")
    args = parser.parse_args()
    print("args: ", args)
    # 初始化Spark
    spark = init_spark_with_config("car_log_for_plan_daily", args.log_dir + "/local")
    # 读取数据
    df_daily = process_domain_log_for_date(spark, args.log_date)
    # 数据格式化
    process_fields_udf = udf(process_fields, returnType="array<string>")
    df_format = df_daily \
        .withColumn("processed_result", process_fields_udf(df_daily.domain, df_daily.api_name, df_daily.category, df_daily.media_type)) \
        .select("query", "api_query", col("processed_result")[0].alias("domain_key"))
    save_as_jsonl(df_format, f"{args.log_dir}/result/car_log_for_plan_daily/{args.log_date}", 10)
    # 分组随机数据
    df_group_sampled = sample_by_column(df_format, sample_field="domain_key", sample_num=1000)
    print("df_group_sampled.count(): ", df_group_sampled.count())
    save_as_jsonl(df_group_sampled, f"{args.log_dir}/result/car_log_for_plan_daily_group_sampled/{args.log_date}")
    # 完全随机数据
    df_all_sampled = df_format.sample(fraction=0.1, seed=42).orderBy(rand()).limit(1000)
    print("df_all_sampled.count(): ", df_all_sampled.count())
    save_as_jsonl(df_all_sampled, f"{args.log_dir}/result/car_log_for_plan_daily_all_sampled/{args.log_date}")

# cd ark_script && /opt/spark/bin/spark-submit car_log_for_plan_daily.py --log_date=2025-04-06
# cd ark_script && /opt/spark/bin/spark-submit car_log_for_plan_daily.py --log_date=2025-04-0*
# cat part-*.json | jq -r '.domain_key' | sort | uniq -c | sort -nr | awk -F" " '{print $2,$1}' OFS="\t" > count.tsv
