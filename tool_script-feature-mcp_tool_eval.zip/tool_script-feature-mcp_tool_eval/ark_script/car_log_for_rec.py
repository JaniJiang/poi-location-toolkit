import argparse
from pyspark.sql.functions import col
from utils.spark_utils import init_spark_with_config
from utils.ark_utils import load_df_from_hudi

parser = argparse.ArgumentParser()
parser.add_argument("--log_date", type=str, required=True)
parser.add_argument("--log_dir", type=str, default="/mnt/pfs-guan-ssai/ssrde/team/xuzhou1/tmp")
args = parser.parse_args()
print("log_date: ", args.log_date)
print("log_dir: ", args.log_dir)

# 读取数据
table_path = f"bos://spaceai-internal/ark/prod_env/ark_data/dwd_vechile_merge_prod_di/{args.log_date}"
spark = init_spark_with_config("car_log_for_rec", args.log_dir + "/local")
df_all = load_df_from_hudi(spark, table_path)
print("df_all.count(): ", df_all.count())

# 处理字段
df_all_query = df_all.filter(col("domain").isin(["gpt_chat", "gpt_autoqa"])) \
    .select("query", "slot_li", "struct_display_msg", "content_style", "show_text_list", "show_text_click")
print("df_all_query.count(): ", df_all_query.count())

# 保存处理结果
df_all_query.repartition(100).write.format("json").mode("overwrite") \
    .option("compression", "none").option("lineSep", "\n") \
    .save(f"{args.log_dir}/result/car_log_for_rec/{args.log_date}")

# cd ark_script && /opt/spark/bin/spark-submit car_log_for_rec.py --log_date=2025-02-10
