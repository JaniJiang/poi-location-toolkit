from utils.spark_utils import init_spark

spark_local_dir = "/mnt/pfs-guan-ssai/ssrde/team/xuzhou1/tmp/local"
spark = init_spark("car_log_date", spark_local_dir)

bos_path_checked = "bos://spaceai-internal/ark/prod_env/ark_data/dwd_vechile_merge_prod_di"
# bos_path_checked = "bos://spaceai-internal/ark/prod_env/ark_data/ods_service_expert_log_v1_prod"
global_path = spark._jvm.org.apache.hadoop.fs.Path(bos_path_checked)
fs = global_path.getFileSystem(spark._jsc.hadoopConfiguration())

list_status = fs.listStatus(spark._jvm.org.apache.hadoop.fs.Path(bos_path_checked))
file_names = [file.getPath().getName() for file in list_status]
print(file_names)

# cd ark_script && /opt/spark/bin/spark-submit car_log_date.py
