import json
from collections import Counter, defaultdict
from pyspark.sql.functions import col, udf
from pyspark.sql.dataframe import DataFrame as SparkDataFrame
from utils.ark_utils import load_df_from_hudi

BOS_LOG_BASE_DIR = "bos://spaceai-internal/ark/prod_env/ark_data/dwd_vechile_merge_prod_di"


def process_slot_li(slot_li):
    return process_slot_li_list([slot_li])


def process_slot_li_list(slot_li_list):
    flat_list = []
    for slot_li in slot_li_list:
        if type(slot_li) is list:
            for item in slot_li:
                if type(item) is str:
                    flat_list.append(item)
        elif type(slot_li) is str:
            flat_list.append(slot_li)
        else:
            continue
    counter = Counter(flat_list)
    counter_sorted = sorted(counter.items(), key=lambda x: x[1], reverse=True)
    # 完整slot结果
    slot_result = [[json.loads(item[0]), item[1]] for item in counter_sorted]
    # 统计slot结果
    api_result_sorted = []
    category_result_sorted = []
    media_type_result_sorted = []
    if len(slot_result) > 0:
        api_query = slot_result[0][0].get("QUERY", "")
        api_result = defaultdict(int)
        category_result = defaultdict(int)
        media_type_result = defaultdict(int)
        for item in slot_result:
            api_result[item[0].get("APINAME", "NONE")] += item[1]
            category_result[item[0].get("CATEGORY", "NONE")] += item[1]
            media_type_result[item[0].get("MEDIATYPE", "NONE")] += item[1]
        api_result_sorted = sorted(api_result.items(), key=lambda x: x[1], reverse=True)
        category_result_sorted = sorted(category_result.items(), key=lambda x: x[1], reverse=True)
        media_type_result_sorted = sorted(media_type_result.items(), key=lambda x: x[1], reverse=True)
    # 获取关键字段
    api_query = slot_result[0][0].get("QUERY", "") if len(slot_result) > 0 else ""
    api_name = api_result_sorted[0][0] if len(api_result_sorted) > 0 else ""
    category = category_result_sorted[0][0] if len(category_result_sorted) > 0 else ""
    media_type = media_type_result_sorted[0][0] if len(media_type_result_sorted) > 0 else ""
    # 输出结果
    return [
        api_query,
        api_name,
        category,
        media_type,
        len(slot_result),
        json.dumps(api_result_sorted, ensure_ascii=False),
        json.dumps(category_result_sorted, ensure_ascii=False),
        json.dumps(media_type_result_sorted, ensure_ascii=False),
        json.dumps(slot_result, ensure_ascii=False),
    ]


def process_domain_li(domain_li):
    domain = ""
    if type(domain_li) is list:
        domain = domain_li[0]
    elif type(domain_li) is str:
        domain = domain_li
    return [domain]


def filter_by_term(query, term_list):
    """通过term过滤query"""
    return any(term.lower() in query.lower() for term in term_list)


def get_timeslots(slot_li):
    """获取timeslots"""
    try:
        api_result = json.loads(slot_li[0])
        time_slots = api_result.get("timeslots", "{}")
    except:
        time_slots = "{}"
    return time_slots


def process_qa_bot_content(content_str):
    try:
        content_dict = json.loads(content_str)
    except:
        return ["", "", "", "", ""]
    # get question
    hit_question = content_dict.get("hitQuestion", "")
    hit_question_id = content_dict.get("hitQuestionId", "")
    standard_id = hit_question_id.split("_")[0]
    speak = content_dict.get("speak", "")
    # get answer
    resources = content_dict.get("display", {}).get("resources", [])
    answer_title, answer_content = "", ""
    for resource in resources:
        if resource.get("type", "") == "title":
            answer_title = resource.get("text", "")
        elif resource.get("type", "") == "content":
            answer_content = resource.get("text", "")
    return [hit_question, hit_question_id, standard_id, speak, answer_title, answer_content]


def process_rag_log_for_date(spark, date):
    """处理指定日期的日志"""
    table_path = f"{BOS_LOG_BASE_DIR}/{date}"
    try:
        df = load_df_from_hudi(spark, table_path)
        print(f"{date} - df.count(): {df.count()}")
        # 初步过滤domain
        df_filtered = df.filter(col("domain").isin(["gpt_chat", "gpt_autoqa"])) \
            .select("query", "slot_li", "request_time", "record_id", "msg_id", "knowledge_search_result", "media_search_result", "time_space_modify_response")
        print(f"{date} - df_filtered.count(): {df_filtered.count()}")
        # 解析slot_li
        process_slot_li_udf = udf(process_slot_li, returnType="array<string>")
        df_parsed = df_filtered \
            .withColumn("slot_processed_result", process_slot_li_udf(col("slot_li"))) \
            .select(
                "query",
                col("slot_processed_result")[0].alias("api_query"),
                col("slot_processed_result")[1].alias("api_name"),
                col("slot_processed_result")[2].alias("category"),
                col("slot_processed_result")[3].alias("media_type"),
                col("slot_processed_result")[4].alias("api_query_num"),
                "request_time",
                "record_id",
                "msg_id",
                "knowledge_search_result",
                "media_search_result",
                "time_space_modify_response"
            ) \
            .filter(
                (col("api_name").isin(["QASearch", "AUTOSearch", "MEDIASearch"])) &
                (col("api_query_num") == 1)
            ) \
            .drop("api_query_num")
        print(f"{date} - df_parsed.count(): {df_parsed.count()}")
        return df_parsed
    except Exception as e:
        print(f"Error processing data for {date}: {str(e)}")
        return None


def process_domain_log_for_date(spark, date):
    """处理指定日期的日志"""
    table_path = f"{BOS_LOG_BASE_DIR}/{date}"
    try:
        df = load_df_from_hudi(spark, table_path)
        print(f"{date} - df.count(): {df.count()}")
        # 初步过滤domain
        df_filtered = df.select("query", "domain", "domain_li", "slot_li")
        print(f"{date} - df_filtered.count(): {df_filtered.count()}")
        # 解析domain_li和slot_li
        process_domain_li_udf = udf(process_domain_li, returnType="array<string>")
        process_slot_li_udf = udf(process_slot_li, returnType="array<string>")
        df_parsed = df_filtered \
            .withColumn("domain_processed_result", process_domain_li_udf(col("domain_li"))) \
            .withColumn("slot_processed_result", process_slot_li_udf(col("slot_li"))) \
            .select(
                "query",
                "domain",
                col("domain_processed_result")[0].alias("domain_li"),
                col("slot_processed_result")[0].alias("api_query"),
                col("slot_processed_result")[1].alias("api_name"),
                col("slot_processed_result")[2].alias("category"),
                col("slot_processed_result")[3].alias("media_type")
            )
        print(f"{date} - df_parsed.count(): {df_parsed.count()}")
        return df_parsed
    except Exception as e:
        print(f"Error processing data for {date}: {str(e)}")
        return None


def save_as_jsonl(df: SparkDataFrame, local_path: str, file_nums: int = 1):
    """保存df到jsonl文件"""
    df.repartition(file_nums).write.format("json").mode("overwrite") \
        .option("compression", "none").option("lineSep", "\n") \
        .save(local_path)
