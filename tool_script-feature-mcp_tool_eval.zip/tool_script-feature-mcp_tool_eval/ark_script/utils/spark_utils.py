from pyspark.sql import SparkSession


def init_spark(app_name, spark_local_dir):
    spark = SparkSession \
        .builder \
        .appName(app_name) \
        .config('spark.local.dir', spark_local_dir) \
        .config("spark.sql.execution.arrow.pyspark.enabled", "true") \
        .getOrCreate()
    return spark


def init_spark_with_config(app_name, spark_local_dir):
    spark = SparkSession \
        .builder \
        .appName(app_name) \
        .config("spark.driver.memory", "300g") \
        .config("spark.driver.maxResultSize", "300g") \
        .config("spark.driver.memoryOverhead", "30g") \
        .config("spark.executor.instances", "30") \
        .config("spark.executor.memory", "16g") \
        .config("spark.executor.memoryOverhead", "8g") \
        .config("spark.sql.shuffle.partitions", "100") \
        .config("spark.default.parallelism", "100") \
        .config("spark.local.dir", spark_local_dir) \
        .config("spark.sql.execution.arrow.pyspark.enabled", "true") \
        .getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    return spark


def init_spark_with_config_2(app_name, spark_local_dir):
    spark = SparkSession \
        .builder \
        .appName(app_name) \
        .config("spark.driver.memory", "300g") \
        .config("spark.driver.maxResultSize", "300g") \
        .config("spark.driver.memoryOverhead", "30g") \
        .config("spark.executor.instances", "30") \
        .config("spark.executor.memory", "16g") \
        .config("spark.executor.memoryOverhead", "8g") \
        .config("spark.sql.shuffle.partitions", "300") \
        .config("spark.default.parallelism", "300") \
        .config("spark.local.dir", spark_local_dir) \
        .config("spark.sql.execution.arrow.pyspark.enabled", "true") \
        .config("spark.sql.parquet.enableVectorizedReader", "false") \
        .config("spark.sql.orc.enableVectorizedReader", "false") \
        .config("spark.sql.sources.bucketing.enabled", "false") \
        .config("spark.sql.adaptive.enabled", "true") \
        .config("spark.memory.fraction", "0.8") \
        .config("spark.memory.storageFraction", "0.2") \
        .getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    return spark
