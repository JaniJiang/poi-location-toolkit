get_recent_dates() {
    local n=$1  # 天数
    local format=${2:-"%Y-%m-%d"}  # 日期格式，默认为 YYYY-MM-DD
    local dates=()
    for i in $(seq 1 $n); do
        dates+=("$(date -d "-$i days" +"$format")")
    done
    echo "${dates[@]}"
}
