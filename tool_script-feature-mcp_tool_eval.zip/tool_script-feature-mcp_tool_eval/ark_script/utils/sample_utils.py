from pyspark.sql.window import Window
from pyspark.sql.types import ArrayType, StructType
from pyspark.sql.dataframe import DataFrame as SparkDataFrame
from pyspark.sql.functions import rand, row_number, count, col, to_json


def sample_by_column(
    df: SparkDataFrame,
    sample_field: str,
    sample_num: int,
    min_num: int = 20
) -> SparkDataFrame:
    """
    在 DataFrame 每个 sample_field 分组内随机抽取最多 sample_num 条样本。
    参数：
    - df: 输入的 Spark DataFrame。
    - sample_field: 根据该字段进行分组抽样。
    - sample_num: 每个分组内抽样的最大样本数。
    - min_num: 每个分组内最小样本数，如果小于该数量则丢弃。
    返回：
    - DataFrame: 抽样后的 DataFrame。
    """
    # 1. 计算每个分组的样本数量
    df_with_count = df.groupBy(sample_field).agg(count("*").alias("group_count"))
    # 2. 筛选出样本数量大于或等于 min_num 的分组
    df_filtered = df.join(df_with_count, on=sample_field, how="inner")
    df_filtered = df_filtered.filter(df_filtered.group_count >= min_num)
    # 3. 为 DataFrame 添加一列随机数
    df_with_rand = df_filtered.withColumn("rand", rand())
    # 4. 定义窗口函数，在每个 sample_field 分组内，根据随机数排序
    window_spec = Window.partitionBy(sample_field).orderBy("rand")
    # 5. 为排序后的数据添加行号
    df_with_row_num = df_with_rand.withColumn("row_num", row_number().over(window_spec))
    # 6. 筛选每个分组内的前 sample_num 条数据
    df_sampled = df_with_row_num.filter(df_with_row_num.row_num <= sample_num)
    # 7. 删除辅助的列
    df_result = df_sampled.drop("rand", "row_num", "group_count")
    return df_result


def convert_complex_types(df: SparkDataFrame):
    for field in df.schema.fields:
        if isinstance(field.dataType, (ArrayType, StructType)):
            df = df.withColumn(field.name, to_json(col(field.name)))
    return df
