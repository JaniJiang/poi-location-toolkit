from pyspark.sql.dataframe import DataFrame as SparkDataFrame


hudi_columns = ["_hoodie_commit_time", "_hoodie_commit_seqno",
                "_hoodie_record_key", "_hoodie_partition_path", "_hoodie_file_name"]


def drop_columns(df: SparkDataFrame, *columns) -> SparkDataFrame:
    for c in columns:
        df = df.drop(c)
    return df


def load_df_from_hudi(spark: SparkDataFrame, table_path) -> SparkDataFrame:
    df = spark.read.format("hudi").load(table_path)
    df = drop_columns(df, *hudi_columns)
    return df


def load_df_from_json_dir(spark: SparkDataFrame, json_dir) -> SparkDataFrame:
    df = spark.read.json(json_dir)
    return df


def load_df_from_tsv_dir(spark: SparkDataFrame, tsv_dir) -> SparkDataFrame:
    df = spark.read.csv(tsv_dir, sep="\t", header=True, inferSchema=True)
    return df
