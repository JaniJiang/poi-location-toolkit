import datetime


def get_dates_of_last_week(end_date_str=None):
    """获取上一周的日期列表"""
    if end_date_str:
        end_date = datetime.datetime.strptime(end_date_str, "%Y-%m-%d")
    else:
        end_date = datetime.datetime.now()
    start_date = end_date - datetime.timedelta(days=6)
    # 生成日期列表
    date_list = []
    current_date = start_date
    while current_date <= end_date:
        date_list.append(current_date.strftime("%Y-%m-%d"))
        current_date += datetime.timedelta(days=1)
    return date_list
