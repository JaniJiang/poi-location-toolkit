import os
import time
import logging
import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from service.engine.embedding_engine import BGEOnnxModel
from service.utils.consts import *

# get environment variables
num_gpus = int(os.environ.get("NUM_GPUS", 1))
bge_model_name = os.environ.get("LPAI_INPUT_MODEL_0", BGE_EMBEDDING_MODEL_PATH)
host = os.environ.get("HOST", "0.0.0.0")
port = int(os.environ.get("PORT", 8000))
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(filename)s %(levelname)s %(message)s")


class EmbeddingService:
    def __init__(self):
        logging.info("[EmbeddingService] num_gpus:%d", num_gpus)
        self.bge_onnx_model = BGEOnnxModel(bge_model_name)


app = FastAPI()
embedding_service = EmbeddingService()


@app.post("/v1/embeddings")
async def get_embeddings(request: Request):
    start_time = time.time()
    try:
        request_json = await request.json()
        logging.info(f"embedding request_json:{request_json}")
        sentences = request_json.get("sentences", [])
        need_normalize = request_json.get("need_normalize", True)
        need_score = request_json.get("need_score", False)
        need_sort = request_json.get("need_sort", False)
        # 根据model_type调用不同的模型
        model_type = request_json.get("model_type", "")
        results = []
        if model_type == EMBEDDING_MODEL_TYPE_BGE:
            results = embedding_service.bge_onnx_model.process(sentences, need_normalize, need_score, need_sort)
        else:
            return JSONResponse({"code": 1, "msg": f"model_type[{model_type}] not exist", "data": []})
        cost_time = round(time.time() - start_time, 2)
        response_data = {"code": 0, "msg": "", "cost_time": cost_time, "data": results}
    except Exception as e:
        logging.warning("embedding model process error:" + str(e))
        cost_time = round(time.time() - start_time, 2)
        response_data = {"code": 1, "msg": str(e), "cost_time": cost_time, "data": []}
    return JSONResponse(response_data)


if __name__ == "__main__":
    uvicorn.run(app, host=host, port=port)
