import os
import time
import logging
import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from service.engine.reranker_engine import Qwen3RerankerModel
from service.utils.consts import *

# get environment variables
num_gpus = int(os.environ.get("NUM_GPUS", 1))
reranker_model_name = os.environ.get("LPAI_INPUT_MODEL_0", "")
host = os.environ.get("HOST", "0.0.0.0")
port = int(os.environ.get("PORT", 8000))
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(filename)s %(levelname)s %(message)s")


class Qwen3RerankerService:
    def __init__(self):
        logging.info("[EmbeddingService] num_gpus:%d", num_gpus)
        self.qwen_reranker_model = Qwen3RerankerModel(reranker_model_name)


app = FastAPI()
embedding_service = Qwen3RerankerService()


@app.post("/v1/qwen3_reranker")
async def qwen3_reranker(request: Request):
    start_time = time.time()
    try:
        request_json = await request.json()
        logging.info(f"model request_json:{request_json}")
        sample_list = request_json.get("sample_list", [])
        results = embedding_service.qwen_reranker_model.process(sample_list)
        cost_time = round(time.time() - start_time, 2)
        response_data = {"code": 0, "msg": "", "cost_time": cost_time, "data": results}
    except Exception as e:
        logging.warning("embedding model process error:" + str(e))
        cost_time = round(time.time() - start_time, 2)
        response_data = {"code": 1, "msg": str(e), "cost_time": cost_time, "data": []}
    return JSONResponse(response_data)


if __name__ == "__main__":
    uvicorn.run(app, host=host, port=port)
    # python -m service.main.rerank
