import torch
import numpy as np
import onnxruntime as ort
import torch.nn.functional as F
from transformers import AutoTokenizer
from service.utils.consts import *
from service.utils.vector_utils import normalize_vectors


class EmbeddingBaseModel(object):

    def __init__(self, model_name=BGE_EMBEDDING_MODEL_PATH, device="cuda:0", max_length=512):
        self.model_name = model_name
        self.device = device
        self.max_length = max_length

    def get_embedding(self, sentences):
        embeddings = self.model.encode(sentences)
        return embeddings

    def process(self, sentences, need_normalize=True, need_score=False, need_sort=False):
        # get embedding
        embeddings = self.get_embedding(sentences)
        # normalize vector
        if need_normalize is True:
            embeddings = normalize_vectors(embeddings)
        # calculate similarity
        if need_score is True:
            results = self.calculate_cosine_similarity(sentences, embeddings)
            if need_sort is True:
                results.sort(key=lambda k: (k.get("cosine_score", 0)), reverse=True)
            return results
        return embeddings.tolist()

    def calculate_cosine_similarity(self, sentences, embeddings):
        # get query
        query = sentences[0]
        query_embedding = embeddings[0]
        query_tensor = torch.FloatTensor(query_embedding)
        # calculate score
        results = []
        for sentence, sentence_embedding in zip(sentences[1:], embeddings[1:]):
            sentence_tensor = torch.FloatTensor(sentence_embedding)
            cosine_score = F.cosine_similarity(query_tensor, sentence_tensor, dim=0)
            result_one = {"cosine_score": cosine_score.item(), "query": query, "sentence": sentence}
            results.append(result_one)
        return results


class EmbeddingOnnxModel(EmbeddingBaseModel):

    def __init__(self, model_name=BGE_EMBEDDING_MODEL_PATH, device="cuda:0", max_length=512):
        super().__init__(model_name, device, max_length)
        self.model_path = model_name + "/onnx/model.onnx"
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
        self.session = ort.InferenceSession(self.model_path, providers=["CUDAExecutionProvider"])

    def get_embedding(self, sentences):
        # Tokenize the input sentences
        tokens = self.tokenizer(sentences, return_tensors='np',
                                max_length=self.max_length, truncation=True, padding=True)
        # Retrieve input names from the model session and create the input feed
        input_feed = {inp.name: tokens[inp.name] for inp in self.session.get_inputs()}
        # Execute the model to get outputs
        outputs = self.session.run(None, input_feed)[0]
        # Calculate and collect the mean of outputs for each sentence to create embeddings
        result_list = [np.mean(outputs[i], axis=0).tolist() for i in range(len(sentences))]
        return result_list


class BGEOnnxModel(EmbeddingOnnxModel):

    def __init__(self, model_name=BGE_EMBEDDING_MODEL_PATH, device="cuda:0", max_length=8192):
        super().__init__(model_name, device, max_length)
