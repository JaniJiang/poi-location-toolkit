import torch
from search.qa_bot.qwen3_reranker.eval.eval_lpai_llm import *
from modelscope import AutoTokenizer, AutoModelForCausalLM


class Qwen3RerankerModel():
    def __init__(self, model_path, device="cuda:0"):
        self.device = device
        self.model_path = model_path
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_path, padding_side="left")
        self.model = AutoModelForCausalLM.from_pretrained(self.model_path).to(self.device).eval()
        self.max_length = 4096
        self.token_true_id = self.tokenizer.convert_tokens_to_ids(POS_LABEL)
        self.token_false_id = self.tokenizer.convert_tokens_to_ids(NEG_LABEL)

    def process(self, sample_list: List[Dict[str, str]]):
        output_list = []
        instructions = []
        for sample_dict in sample_list:
            instruction, output = build_prompt(sample_dict)
            if instruction == "" or output == "":
                continue
            instructions.append(instruction)
        try:
            inputs = self.process_inputs(instructions)
            scores = self.compute_logits(inputs)
            for idx, sample_dict in enumerate(sample_list):
                sample_dict["pred_score"] = round(scores[idx], 6)
                output_list.append(sample_dict)
        except Exception as e:
            logger.warning("[EvalLocalLLM] process failed: " + str(e))

        return output_list

    def process_inputs(self, instructions):
        inputs = self.tokenizer(
            instructions, padding=False, truncation="longest_first",
            return_attention_mask=False, max_length=self.max_length
        )
        inputs = self.tokenizer.pad(inputs, padding=True, return_tensors="pt", max_length=self.max_length)
        for key in inputs:
            inputs[key] = inputs[key].to(self.model.device)
        return inputs

    @torch.no_grad()
    def compute_logits(self, inputs, **kwargs):
        batch_scores = self.model(**inputs).logits[:, -1, :]
        true_vector = batch_scores[:, self.token_true_id]
        false_vector = batch_scores[:, self.token_false_id]
        batch_scores = torch.stack([false_vector, true_vector], dim=1)
        batch_scores = torch.nn.functional.log_softmax(batch_scores, dim=1)
        scores = batch_scores[:, 1].exp().cpu().tolist()
        return scores


if __name__ == "__main__":
    model_path = "data/cloud_share/qabot_relevance_data/qwen3_reranker/model/qa_bot_v3_20250807"
    re = Qwen3RerankerModel(model_path)
    test_dict = {
        "query": "怎么打开WIFI",
        "title": "打开WIFI的方式",
        "label": "yes"
    }
    test_list = [test_dict] * 2
    print(re.process(test_list))
    # python -m service.engine.reranker_engine
