# 服务

## Embedding
### 开发环境配置
```bash
conda create --name service_embedding python=3.10
conda activate service_embedding
pip install -r service/requirements/embedding.txt
```
### 启动命令
```bash
# 本地启动命令
CUDA_VISIBLE_DEVICES=0 HOST=0.0.0.0 PORT=8000 python -m service.main.embedding
# 本地推理接口
curl --location 'http://0.0.0.0:8000/v1/embeddings' \
--header 'Content-Type: application/json' \
--data '{
    "sentences": [
        "酒仙桥路二号店",
        "酒仙桥路2号店",
        "酒仙桥路三号店",
        "酒仙桥路3号店",
        "酒仙桥路几号店"
    ],
    "need_normalize": true,
    "need_score": true,
    "need_sort": true,
    "model_type": "bge-m3"
}'
# LPAI推理接口
curl --location 'https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/embedding-service/v1/embeddings' \
--header 'Content-Type: application/json' \
--data '{
    "sentences": [
        "酒仙桥路二号店",
        "酒仙桥路2号店",
        "酒仙桥路三号店",
        "酒仙桥路3号店",
        "酒仙桥路几号店"
    ],
    "need_normalize": true,
    "need_score": true,
    "need_sort": true,
    "model_type": "bge-m3"
}'
```