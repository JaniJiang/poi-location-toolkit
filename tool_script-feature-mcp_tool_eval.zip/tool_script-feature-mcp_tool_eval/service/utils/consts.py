EMBEDDING_MODEL_TYPE_M3E = "m3e-base"
EMBEDDING_MODEL_TYPE_BGE = "bge-m3"

M3E_EMBEDDING_MODEL_PATH = "data/cloud_share/backbone/AI-ModelScope/m3e-base"
BGE_EMBEDDING_MODEL_PATH = "data/cloud_share/backbone/BAAI/bge-m3"
