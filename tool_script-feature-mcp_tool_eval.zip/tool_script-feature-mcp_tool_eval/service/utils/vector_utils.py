import numpy as np


def normalize_vectors(vectors):
    vectors_normalized = []
    for vector in vectors:
        vectors_normalized.append(normalize_vector(vector))
    return np.array(vectors_normalized)


def normalize_vector(vector):
    if type(vector) is list:
        vector = np.array(vector)
    norm = np.linalg.norm(vector)
    if norm == 0:
        return vector
    return vector / norm


def is_normalized(vector):
    norm = np.linalg.norm(vector)
    return np.isclose(norm, 1.0)


if __name__ == "__main__":
    vector1 = np.array([1, 2, 3, 4])
    vector2 = np.array([[1, 2, 3, 4], [5, 6, 7, 8]])
    normalized_vector = normalize_vector(vector1)
    normalized_vectors = normalize_vectors(vector2)
    print("vector1", vector1, is_normalized(vector1))
    print("normalized_vector", normalized_vector, is_normalized(normalized_vector))
    print("normalized_vectors", normalized_vectors)

# python -m service.utils.vector_utils
