from utils.file_utils import read_json_file


def main():
    # 读取数据
    input_path = "data/cloud_share/mcp_tools/traffic/analyse/train_ticket_result.json"
    input_dict = read_json_file(input_path)
    data_list = input_dict.get("result", {}).get("list", [])
    # 分组合并
    group_dict = {}
    for item in data_list:
        typeid = item["type"]  # 类型
        typename = item["typename"]  # 类型
        # print(typeid, typename)
        if typename not in group_dict:
            group_dict[typename] = []

        trainno = item["trainno"]  # 车次
        station = item["station"]  # 出发站
        endstation = item["endstation"]  # 到达站
        departuretime = item["departuretime"]  # 出发时间
        arrivaltime = item["arrivaltime"]  # 到达时间
        costtime = item["costtime"]  # 耗时

        if station != "沈阳" or endstation != "秦皇岛":
            continue

        merge_price = "具体票价需以购票系统为准"
        if typename in ["直达特快", "特快", "快速"]:
            priceyz = item["priceyz"]  # 硬座
            priceyw = item["priceyw"]  # 硬卧
            pricerw = item["pricerw"]  # 软卧
            merge_price = "/".join([f"硬座{priceyz}", f"硬卧{priceyw}", f"软卧{pricerw}"])
        elif typename in ["高铁"]:
            priceed = item["priceed"]  # 二等座
            priceyd = item["priceyd"]  # 一等座
            pricetd = item["pricetd"]  # 商务座
            if pricetd != "-":
                merge_price = "/".join([f"二等座{priceed}", f"一等座{priceyd}", f"商务座{pricetd}"])
            else:
                merge_price = "/".join([f"二等座{priceed}", f"一等座{priceyd}"])
        elif typename in ["动车"]:
            priceed = item["priceed"]  # 二等座
            priceyd = item["priceyd"]  # 一等座
            merge_price = "/".join([f"二等座{priceed}", f"一等座{priceyd}"])

        group_dict[typename].append("- " + "，".join([
            f"{trainno}",  # f"{trainno}（{station}->{endstation}）",
            f"用时{costtime}（{departuretime}->{arrivaltime}）",
            f"{merge_price}",
        ]))
    # 打印
    for typename in ["高铁", "动车", "直达特快", "特快", "快速"]:
        if typename not in group_dict:
            continue
        train_list = group_dict[typename]
        train_num = len(train_list)
        print(f"\n### {typename}有{train_num}班")
        print("\n".join(train_list))


if __name__ == "__main__":
    main()

# python -m mcp_tools.traffic.analyse.format_train_ticket_result
