import re
from bs4 import BeautifulSoup


class OfflineHTMLRestorer:

    def __init__(self):
        # 基础响应式CSS框架（精简版）
        self.base_css = """
        /* Reset and Base Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            background: #fff;
            padding: 20px;
        }
        
        /* Container */
        .container, main, article, .content, .wrapper {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        /* Typography */
        h1, h2, h3, h4, h5, h6 {
            margin: 1em 0 0.5em;
            line-height: 1.2;
            font-weight: 600;
        }
        
        h1 { font-size: 2.5em; color: #2c3e50; border-bottom: 2px solid #ecf0f1; padding-bottom: 10px; }
        h2 { font-size: 2em; color: #34495e; margin-top: 1.5em; }
        h3 { font-size: 1.5em; color: #34495e; }
        h4 { font-size: 1.2em; }
        
        p {
            margin: 1em 0;
            text-align: justify;
        }
        
        /* Links */
        a {
            color: #3498db;
            text-decoration: none;
            transition: color 0.3s;
        }
        
        a:hover {
            color: #2980b9;
            text-decoration: underline;
        }
        
        /* Lists */
        ul, ol {
            margin: 1em 0;
            padding-left: 2em;
        }
        
        li {
            margin: 0.5em 0;
        }
        
        /* Images */
        img {
            max-width: 100%;
            height: auto;
            display: block;
            margin: 1em auto;
            border-radius: 4px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        
        /* Tables */
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 1em 0;
            overflow-x: auto;
            display: block;
        }
        
        th, td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }
        
        th {
            background: #f5f5f5;
            font-weight: 600;
        }
        
        tr:nth-child(even) {
            background: #f9f9f9;
        }
        
        /* Code blocks */
        code {
            background: #f4f4f4;
            padding: 2px 6px;
            border-radius: 3px;
            font-family: 'Courier New', monospace;
            font-size: 0.9em;
        }
        
        pre {
            background: #282c34;
            color: #abb2bf;
            padding: 1em;
            border-radius: 5px;
            overflow-x: auto;
            margin: 1em 0;
        }
        
        pre code {
            background: none;
            color: inherit;
            padding: 0;
        }
        
        /* Navigation */
        nav, .nav, .navbar, header {
            background: #2c3e50;
            padding: 1em;
            margin: -20px -20px 20px -20px;
        }
        
        nav ul {
            list-style: none;
            padding: 0;
            display: flex;
            flex-wrap: wrap;
        }
        
        nav li {
            margin-right: 20px;
        }
        
        nav a {
            color: white;
            font-weight: 500;
        }
        
        /* Forms */
        input, textarea, select, button {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        
        button, input[type="submit"], .btn, .button {
            background: #3498db;
            color: white;
            cursor: pointer;
            border: none;
            padding: 12px 24px;
            width: auto;
            display: inline-block;
            transition: background 0.3s;
        }
        
        button:hover, input[type="submit"]:hover {
            background: #2980b9;
        }
        
        /* Cards/Boxes */
        .card, .box, .panel, .widget {
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
            background: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        /* Blockquotes */
        blockquote {
            border-left: 4px solid #3498db;
            padding-left: 20px;
            margin: 1em 0;
            font-style: italic;
            color: #555;
        }
        
        /* Footer */
        footer, .footer {
            margin-top: 50px;
            padding-top: 20px;
            border-top: 1px solid #e0e0e0;
            color: #666;
            text-align: center;
        }
        
        /* Utility Classes */
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .text-left { text-align: left; }
        
        /* Grid System */
        .row, .grid {
            display: flex;
            flex-wrap: wrap;
            margin: 0 -10px;
        }
        
        .col, .column {
            flex: 1;
            padding: 10px;
            min-width: 250px;
        }
        
        /* Sidebar Layout */
        .sidebar {
            float: left;
            width: 25%;
            padding-right: 20px;
        }
        
        .main-content {
            float: left;
            width: 75%;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar, .main-content {
                width: 100%;
                float: none;
            }
            
            nav ul {
                flex-direction: column;
            }
            
            .col, .column {
                width: 100%;
            }
        }
        """

    def detect_layout_pattern(self, soup):
        """检测HTML的布局模式"""
        patterns = {
            'blog': 0,
            'news': 0,
            'docs': 0,
            'forum': 0,
            'ecommerce': 0
        }

        # 检测特征元素
        if soup.find_all(['article', 'blog', 'post']):
            patterns['blog'] += 3

        if soup.find_all(class_=re.compile(r'(news|headline|breaking)', re.I)):
            patterns['news'] += 3

        if soup.find_all(['aside', 'sidebar']):
            patterns['blog'] += 1
            patterns['docs'] += 1

        if soup.find_all(class_=re.compile(r'(price|product|cart|shop)', re.I)):
            patterns['ecommerce'] += 3

        if soup.find_all(class_=re.compile(r'(thread|reply|forum|topic)', re.I)):
            patterns['forum'] += 3

        # 返回最可能的模式
        return max(patterns, key=patterns.get)

    def add_semantic_styles(self, soup, pattern):
        """根据检测到的模式添加语义化样式"""
        pattern_styles = {
            'blog': """
                article {
                    margin-bottom: 40px;
                    padding-bottom: 20px;
                    border-bottom: 1px solid #eee;
                }
                
                .post-meta, .meta, time, .date, .author {
                    color: #666;
                    font-size: 0.9em;
                    margin: 10px 0;
                }
                
                .tags, .categories {
                    margin: 20px 0;
                }
                
                .tag, .category {
                    display: inline-block;
                    background: #ecf0f1;
                    padding: 5px 10px;
                    margin: 2px;
                    border-radius: 3px;
                    font-size: 0.85em;
                }
            """,

            'news': """
                .headline, h1 {
                    font-size: 2.5em;
                    font-weight: bold;
                    line-height: 1.2;
                }
                
                .lead, .summary {
                    font-size: 1.2em;
                    color: #555;
                    font-weight: 300;
                    margin: 20px 0;
                }
                
                .byline {
                    color: #666;
                    font-style: italic;
                }
            """,

            'docs': """
                .toc, .table-of-contents {
                    background: #f8f9fa;
                    border: 1px solid #dee2e6;
                    padding: 20px;
                    margin: 20px 0;
                    border-radius: 5px;
                }
                
                .warning, .alert {
                    background: #fff3cd;
                    border-left: 4px solid #ffc107;
                    padding: 15px;
                    margin: 20px 0;
                }
                
                .info, .note {
                    background: #d1ecf1;
                    border-left: 4px solid #17a2b8;
                    padding: 15px;
                    margin: 20px 0;
                }
            """,

            'ecommerce': """
                .product, .item {
                    border: 1px solid #ddd;
                    padding: 15px;
                    margin: 10px;
                    display: inline-block;
                    width: calc(33.33% - 20px);
                    vertical-align: top;
                }
                
                .price {
                    font-size: 1.5em;
                    color: #e74c3c;
                    font-weight: bold;
                }
                
                .old-price {
                    text-decoration: line-through;
                    color: #999;
                }
            """,

            'forum': """
                .post, .comment, .reply {
                    border: 1px solid #ddd;
                    margin: 10px 0;
                    padding: 15px;
                    background: #fafafa;
                }
                
                .avatar {
                    width: 50px;
                    height: 50px;
                    border-radius: 50%;
                    float: left;
                    margin-right: 15px;
                }
                
                .username {
                    font-weight: bold;
                    color: #2c3e50;
                }
            """
        }
        return pattern_styles.get(pattern, '')

    def enhance_structure(self, soup):
        """增强HTML结构"""
        # 为没有class的div添加通用class
        for div in soup.find_all('div'):
            if not div.get('class'):
                # 根据内容推测用途
                if div.find_all(['h1', 'h2', 'h3']):
                    div['class'] = 'content-section'
                elif div.find_all('img'):
                    div['class'] = 'image-container'
                elif div.find_all(['ul', 'ol']):
                    div['class'] = 'list-container'

        # 识别并标记代码块
        for pre in soup.find_all('pre'):
            if not pre.get('class'):
                pre['class'] = 'code-block'

        # 识别表格并添加响应式wrapper
        for table in soup.find_all('table'):
            if not table.parent.get('class') == 'table-wrapper':
                wrapper = soup.new_tag('div', **{'class': 'table-wrapper', 'style': 'overflow-x: auto;'})
                table.wrap(wrapper)

        return soup

    def restore(self, html_content, verbose=False):
        """
        主函数：恢复HTML内容
        Args:
            html_content: HTML字符串内容
            verbose: 是否输出详细信息
        Returns:
            修复后的HTML字符串
        """
        # 解析HTML
        soup = BeautifulSoup(html_content, 'html.parser')

        # 检测布局模式
        pattern = self.detect_layout_pattern(soup)
        if verbose:
            print(f"检测到的页面类型: {pattern}")

        # 增强HTML结构
        soup = self.enhance_structure(soup)

        # 移除原有的失效样式链接
        for link in soup.find_all('link', rel='stylesheet'):
            link.decompose()

        # 移除已存在的内联样式（可选）
        for style in soup.find_all('style'):
            # 检查是否是我们之前添加的样式
            if 'OfflineHTMLRestorer' not in str(style.string):
                style.decompose()

        # 创建新的style标签
        style_tag = soup.new_tag('style')
        style_content = f"/* OfflineHTMLRestorer Styles */\n{self.base_css}\n{self.add_semantic_styles(soup, pattern)}"
        style_tag.string = style_content

        # 确保有head标签
        if not soup.head:
            head = soup.new_tag('head')
            if soup.html:
                soup.html.insert(0, head)
            else:
                # 如果连html标签都没有，创建完整结构
                html = soup.new_tag('html')
                html.append(head)
                if soup.body:
                    html.append(soup.body.extract())
                else:
                    body = soup.new_tag('body')
                    # 将所有内容移到body中
                    for element in list(soup.children):
                        body.append(element.extract())
                    html.append(body)
                soup.append(html)

        # 将样式添加到head
        soup.head.append(style_tag)

        # 添加viewport meta标签（响应式）
        if not soup.find('meta', attrs={'name': 'viewport'}):
            viewport = soup.new_tag('meta')
            viewport.attrs['name'] = 'viewport'
            viewport.attrs['content'] = 'width=device-width, initial-scale=1.0'
            soup.head.insert(0, viewport)

        # 添加字符编码
        if not soup.find('meta', attrs={'charset': True}):
            charset = soup.new_tag('meta')
            charset.attrs['charset'] = 'utf-8'
            soup.head.insert(0, charset)

        # 返回优化后的HTML字符串
        return str(soup)

    def restore_from_file(self, file_path, encoding='utf-8'):
        """
        从文件读取并恢复HTML
        Args:
            file_path: HTML文件路径
            encoding: 文件编码
        Returns:
            修复后的HTML字符串
        """
        with open(file_path, 'r', encoding=encoding, errors='ignore') as f:
            html_content = f.read()
        return self.restore(html_content)

    def quick_restore(self, html_content):
        """
        快速恢复（最小化处理）
        Args:
            html_content: HTML字符串内容
        Returns:
            修复后的HTML字符串
        """
        # 最简单的CSS注入
        minimal_css = """
        <style>
            body { max-width: 900px; margin: 40px auto; padding: 0 20px; 
                   font: 16px/1.6 -apple-system, sans-serif; color: #333; }
            h1,h2,h3 { line-height: 1.2; margin-top: 1.5em; }
            img { max-width: 100%; height: auto; }
            pre { overflow-x: auto; background: #f4f4f4; padding: 1em; }
            table { border-collapse: collapse; width: 100%; }
            th,td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            a { color: #0066cc; }
            code { background: #f0f0f0; padding: 2px 5px; border-radius: 3px; }
            blockquote { border-left: 3px solid #999; padding-left: 1em; color: #666; }
        </style>
        """
        # 在</head>前插入样式
        if '</head>' in html_content:
            return html_content.replace('</head>', minimal_css + '</head>')
        elif '<body' in html_content:
            return html_content.replace('<body', minimal_css + '<body')
        else:
            return minimal_css + html_content


def restore_html_string(html_content, mode="full"):
    """
    便捷函数：直接恢复HTML字符串
    Args:
        html_content: HTML内容
        mode: 'full' 完整恢复, 'quick' 快速恢复
    Returns:
        恢复后的HTML字符串
    """
    restorer = OfflineHTMLRestorer()
    if mode == "quick":
        return restorer.quick_restore(html_content)
    else:
        return restorer.restore(html_content)


if __name__ == "__main__":
    path = "data/cloud_share/mcp_tools/doc_process/analyse/llm_demo/news_demo_1"
    html_content = open(f"{path}.html", "r", encoding="utf-8").read()
    html_content_restored = restore_html_string(html_content, mode="quick")
    with open(f"{path}.restored.html", "w", encoding="utf-8") as f:
        f.write(html_content_restored)
