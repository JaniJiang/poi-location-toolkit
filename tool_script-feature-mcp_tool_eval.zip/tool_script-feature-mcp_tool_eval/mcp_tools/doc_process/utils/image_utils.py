import base64
from playwright.sync_api import sync_playwright
from mcp_tools.doc_process.utils.const import CHROMIUM_PATH


def html_to_base64_image(html_content: str) -> str:
    with sync_playwright() as p:
        browser = p.chromium.launch(
            executable_path=CHROMIUM_PATH,
            args=[
                "--no-sandbox",
                "--disable-setuid-sandbox",
                "--disable-dev-shm-usage",
                "--disable-gpu",
                "--disable-software-rasterizer",
                "--disable-extensions"
            ]
        )
        page = browser.new_page()
        page.set_content(html_content, wait_until="domcontentloaded")
        screenshot_bytes = page.screenshot(full_page=True)
        browser.close()
        base64_str = base64.b64encode(screenshot_bytes).decode("utf-8")
        return base64_str
