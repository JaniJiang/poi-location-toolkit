CHROMIUM_PATH = "data/cloud_share/lastest_pip/chromium-headless-shell-linux/headless_shell"

SYSTEM_PROMPT_V1 = """# 任务
基于网页截图总结出网页内容

# 输出字段
- title：标题
- time：发布时间
- source：来源
- summary：全文摘要（不超过200字）

# 输出示例(JSON格式)
```json
{
    "title": "",
    "time": "",
    "source": "",
    "summary": ""
}
```"""

SYSTEM_PROMPT = SYSTEM_PROMPT_V1
