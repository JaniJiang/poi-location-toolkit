import re
import json
from modelscope import Qwen2_5_VLForConditionalGeneration, AutoProcessor
from mcp_tools.doc_process.utils.const import SYSTEM_PROMPT
from mcp_tools.doc_process.utils.llm_utils import qwen_vl_predict
from mcp_tools.doc_process.utils.image_utils import html_to_base64_image


def main(image_path_or_text):
    model_name_or_path = "/lpai/models/qwen__qwen2_5-vl-7b-instruct/25-04-06-1623"  # "Qwen/Qwen2.5-VL-7B-Instruct"
    model = Qwen2_5_VLForConditionalGeneration.from_pretrained(model_name_or_path, dtype="auto", device_map="auto")
    processor = AutoProcessor.from_pretrained(model_name_or_path)
    messages = [
        {
            "role": "system",
            "content": [{"type": "text", "text": SYSTEM_PROMPT}]
        },
        {
            "role": "user",
            "content": [
                {
                    "type": "image",
                    "image": image_path_or_text,
                },
            ],
        }
    ]
    output_text = qwen_vl_predict(model, processor, messages)
    print("output_text:", output_text)
    try:
        parsed_result = json.loads(re.sub(r"```json|```", "", output_text[0]).strip())
        return parsed_result
    except Exception as e:
        print(f"parse predict result failed: {e}")
    return {}


if __name__ == "__main__":
    # 文件路径
    image_path_or_text = "file://data/cloud_share/mcp_tools/doc_process/analyse/llm_demo/news_demo_1.png"

    # 文件内容
    # html_content = open("data/cloud_share/mcp_tools/doc_process/analyse/llm_demo/news_demo_1_1.html",
    #                     "r", encoding="utf-8").read()
    # html_content_base64 = html_to_base64_image(html_content)
    # image_path_or_text = f"data:image;base64,{html_content_base64}"

    # 模型预测
    result = main(image_path_or_text)
    print(json.dumps(result, ensure_ascii=False, indent=4))

# https://modelscope.cn/models/Qwen/Qwen2.5-VL-7B-Instruct/summary
# pip install torch torchvision transformers accelerate modelscope qwen-vl-utils[decord]==0.0.8 playwright bs4
# CUDA_VISIBLE_DEVICES=0 python -m mcp_tools.doc_process.analyse.llm_demo
