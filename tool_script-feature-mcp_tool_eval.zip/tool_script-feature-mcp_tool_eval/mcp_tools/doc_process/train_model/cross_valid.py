# import pandas as pd
# import os

# # === 参数部分 ===
# input_file = "data/cloud_share/mcp_tools/doc_process/train_data/train_data_all.tsv"   # 原始文件名
# output_dir = "data/cloud_share/mcp_tools/doc_process/train_data/cross_valid"   # 输出文件夹
# train_size = 450            # 每次划分的训练集样本数
# num_splits = 3              # 你要求的三份划分

# # === 创建输出目录 ===
# os.makedirs(output_dir, exist_ok=True)

# # === 读取数据 ===
# data = pd.read_csv(input_file, sep="\t")

# # 检查数据长度
# n = len(data)
# print(f"共 {n} 条样本")

# # === 三次划分 ===
# for i in range(num_splits):
#     # 计算训练集起始索引（循环选择不同区间）
#     start = i * train_size
#     end = start + train_size
#     if end > n:
#         end = n

#     # 选取训练集与测试集
#     train_data = data.iloc[start:end]
#     test_data = data.drop(train_data.index)

#     # 保存结果
#     train_path = os.path.join(output_dir, f"split{i+1}_train.tsv")
#     test_path = os.path.join(output_dir, f"split{i+1}_test.tsv")

#     train_data.to_csv(train_path, sep="\t", index=False)
#     test_data.to_csv(test_path, sep="\t", index=False)

#     print(f"第{i+1}份切分完成：训练集 {len(train_data)} 条，测试集 {len(test_data)} 条")

# print("✅ 共生成 6 个文件（3 组 train/test）已保存在", output_dir)


import os
import pandas as pd

# === 参数部分 ===
input_file = "data/cloud_share/mcp_tools/doc_process/train_data/train_data_all.tsv"   # 原始文件名
output_dir = "data/cloud_share/mcp_tools/doc_process/train_data/cross_valid/raw_tsv"   # 输出文件夹
num_splits = 3              # 划分次数（总共三份）

# === 创建输出目录 ===
os.makedirs(output_dir, exist_ok=True)

# === 读取数据 ===
data = pd.read_csv(input_file, sep="\t")

# 检查数据长度
n = len(data)
print(f"共 {n} 条样本")

# === 三次划分 ===
split_size = n // num_splits  # 每份数据的样本数

for i in range(num_splits):
    # 确定训练集与测试集的索引
    test_start = i * split_size
    test_end = test_start + split_size if i < num_splits - 1 else n  # 保证最后一份数据包含所有剩余数据

    # 划分出测试集
    test_data = data.iloc[test_start:test_end]

    # 合并其他部分作为训练集
    train_data = data.drop(test_data.index)

    # 保存结果
    train_path = os.path.join(output_dir, f"split{i+1}_train.tsv")
    test_path = os.path.join(output_dir, f"split{i+1}_test.tsv")

    train_data.to_csv(train_path, sep="\t", index=False)
    test_data.to_csv(test_path, sep="\t", index=False)

    print(f"第{i+1}次划分完成：训练集 {len(train_data)} 条，测试集 {len(test_data)} 条")

print("✅ 共生成 6 个文件（3 组 train/test）已保存在", output_dir)
