llm_config = {
    "cm-v1-full-qwen2-5-7b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/cm-v1-full-qwen2-5-7b-6304-gqvewq/v1/chat/completions",
    "cm-v1-full-qwen2-1-5b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/cm-v1-full-qwen2-1-5b-45a9-ihrljj/v1/chat/completions",
    "doc-process-model-qwen3-1-7b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/doc-process-model-qwen3-1-7b-434c-xglcyp/v1/chat/completions",
    "dp-cross-p1-full-qwen2-5-32b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/dp-cross-p1-full-qwen2-5-32b-e0ae-ndprov/v1/chat/completions",
    "dp-cross-p2-full-qwen2-5-32b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/dp-cross-p2-full-qwen2-5-32b-e03e-hdxlmv/v1/chat/completions",
    "dp-cross-p3-full-qwen2-5-32b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/dp-cross-p3-full-qwen2-5-32b-5198-thqucs/v1/chat/completions",
    "dp-cross-p1-full-qwen2-5-7b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/dp-cross-p1-full-qwen2-5-7b-40cf-yxkcil/v1/chat/completions",
    "dp-cross-p2-full-qwen2-5-7b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/dp-cross-p2-full-qwen2-5-7b-9bb4-xsofnd/v1/chat/completions",
    "dp-cross-p3-full-qwen2-5-7b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/dp-cross-p3-full-qwen2-5-7b-f3c0-lzbaeh/v1/chat/completions",
    "dp-cross-p1-full-qwen2-5-7b-1": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/dp-cross-p1-full-qwen2-5-7b-1-5e41-ylletw/v1/chat/completions",
    "dp-cross-p2-full-qwen2-5-7b-1": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/dp-cross-p2-full-qwen2-5-7b-1-627e-cpamgv/v1/chat/completions",
    "dp-cross-p3-full-qwen2-5-7b-1": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/dp-cross-p3-full-qwen2-5-7b-1-6637-nijwqj/v1/chat/completions",
    "dp-2-full-qwen2-5-7b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/dp-2-full-qwen2-5-7b-7d87-xkcrvi/v1/chat/completions",
    "dp-2-full-qwen2-5-7b-1": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/dp-2-full-qwen2-5-7b-1-9139-trjkcv/v1/chat/completions",
    "dp-2-full-qwen2-1-5b-1": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/dp-2-full-qwen2-1-5b-1card/v1/chat/completions",
    "dp-2-full-qwen3-1-7b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/dp-2-full-qwen3-1-7b-afa0-hzzugj/v1/chat/completions",
    "dp-2-full-qwen3-1-7b-2": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/dp-2-full-qwen3-1-7b-2-6656-qcfpyx/v1/chat/completions",
    "dp-3-full-qwen3-1-7b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/dp-3-full-qwen3-1-7b-9b4f-yyxpmx/v1/chat/completions",
    "dp-4-full-qwen2-5-7b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/dp-4-full-qwen2-5-7b-9f5b-mirdgp/v1/chat/completions",
    "dp-4-full-qwen3-8b": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/dp-4-full-qwen3-8b-6cd4-wtdcev/v1/chat/completions"
}

test_prompt = """# 任务定义
以下为优化后的提示词，可直接用于基于“title”和“content”的文档质量识别、摘要与特征抽取任务。

# 任务目标
- 基于网页的 title 与 content：
  - 判定文档质量（quanlity：0/1）
  - 生成摘要（优先从正文摘取，必要时轻度归纳）
  - 抽取特征（features 为 JSON，含 tag 与 topic）

# 输入
- title：页面标题（字符串）
- content：页面正文文本（字符串，可能含无关信息）

# 输出字段与格式
- quanlity：字符串 "0" 或 "1"
- summary：字符串（与原文语言一致）
- features：JSON 对象，仅含两个键：
  - tag：字符串，1-3 个上位类别词，用 & 连接
  - topic：字符串，2-6 个更具体主题词/实体，用 & 连接
- 严格只输出 JSON，不要任何额外文本、解释或代码块标记；键顺序为 quanlity, summary, features

# 质量判定规则（quanlity）
- 设为 "1"（高质量）当满足多数条件：
  - 有实质内容（非目录/导航/聚合），信息清晰可读
  - 主题明确，非纯链接/占位/噪声
  - 内容长度足以概括要点（中文正文 ≥ 50 字或其他语言 ≥ 200 字），或虽短但与标题形成完整信息
  - 无明显违法、色情、仇恨、欺诈或强广告诱导
- 设为 "0"（低质量）若任一成立：
  - 仅有标题无正文；正文极短（中文 < 50 字或其他语言 < 200 字）且无法形成完整信息
  - 404/报错/跳转页/登录或付费拦截导致正文缺失
  - 目录页、聚合页、评论区汇总、仅图片/视频无文字、仅代码/表格无解释
  - 大段乱码、机翻异常、重复灌水、明显广告导购/价格列表/招聘列表
  - 色情、暴力、仇恨、诈骗、博彩等不当内容
- 边界：若正文较短但与标题结合可清晰传达关键信息，可判 "1"；仅标题无正文必为 "0"

# 摘要生成规则（summary）
- 语言：与原文语言一致
- 方法：以摘取为主，去除噪声，必要时轻度压缩与改写；严禁引入外部信息或主观推断
- 内容：保留核心事实要素（人物/机构、时间、地点、数据、结论/影响）
- 去除无用信息：站点导航、版权声明、免责声明、广告推广、推荐阅读、评论、来源/责任编辑尾注、分享按钮文案、登录提示、“点击阅读全文/阅读原文”等
- 篇幅建议：中文约 50-200 字；英文约 2-4 句；可随内容适当增减
- 若 quanlity = "0"，summary 置为空字符串 ""

# 特征抽取规则（features）
- 仅包含 {"tag": "...", "topic": "..."} 两个键
- tag（上位类目，1-3 个，用 & 连接）：
  - 从通用类目中择优：科技、互联网、数码、财经、商业、金融、区块链、汽车、房产、教育、职业、法律、健康、医疗、体育、游戏、娱乐、文化、历史、社会、军事、国际、旅游、时尚、科普、艺术、政策、能源、环保、农业、工业制造、物联网、云计算等
  - 选择覆盖面最恰当的上位词，避免过细或与 topic 重复
- topic（具体主题，2-6 个，用 & 连接）：
  - 选取更具体的关键词/实体/技术名/产品名/事件名（如：AI&大模型&OpenAI&ChatGPT 或 经济数据&通胀&美联储&加息）
  - 避免与 tag 重复；尽量使用权威表述与专有名词原文
- 若 quanlity = "0"，tag 与 topic 均置为 ""

# 处理步骤建议
1) 清洗：剔除导航、版权、广告、推荐、评论、登录/付费提示、无关尾注等噪声
2) 识别质量：依据上文规则判定 quanlity
3) 生成摘要：按摘要规则提取与压缩关键信息
4) 抽取特征：确定 1-3 个 tag 与 2-6 个 topic，用半角 & 连接，避免重复
5) 严格输出 JSON，键名与拼写必须与下方模板一致

仅可输出的 JSON 模板示例
{
  "quanlity": "1",
  "summary": "在此填写与原文语言一致的精炼摘要，保留关键信息并去除噪声。",
  "features": {"tag": "科技&互联网", "topic": "AI&大模型&开源社区"}
}"""


# system_prompt = """# 任务定义
# 文档处理的任务，基于网页的title和content进行质量识别、内容摘要和特征抽取。

# # 输入
# - title：页面标题（字符串）
# - content：页面正文文本（字符串，可能含无关信息）

# # 输出字段
# - quanlity: 质量（0或1）
# - summary: 摘要（从content中摘抄段落，去除无用信息，视情况总结）
# - features: 特征（jSON格式，包括tag和topic）

# # 输出示例
# ```json
# {
#     "quanlity": "xxx",
#     "summary": "xxx",
#     "features": {"tag": "xx&xx", "topic": "xx&xx"}
# }
# ```
# """

system_prompt = """# 任务定义
完成文档处理任务，基于网页的title和content进行质量识别、内容摘要和特征抽取。

# 输入
- title：页面标题（字符串）
- content：页面正文文本（字符串，可能含无关信息）

# 输出字段
- quality: 质量（0或1），质量为0表示该新闻内容可能存在以下几种情况：（1）该新闻内容为述评、人物访谈等评论性内容；（2）该新闻内容主观倾向性，不具备客观立场；（3）该新闻内容不具备新闻事实构成要素（时间、地点、人物、事件等）。
- summary: 摘要（从content中摘抄段落，去除无用信息，视情况总结），字数最好不要超过 250 字。
- features: 特征（JSON格式，包括tag、topic和 time）

# 输出示例
```json
{{
    "quality": "xxx",
    "summary": "xxx",
    "features": {{"tag": "xx&xx", "topic": "xx&xx"}},
    "time": "xxx"
}}
```
# title
```
{title}
```

# content
```
{content}
```"""

user_input = """# title
```
{title}
```

# content
```
{content}
```"""


assistant_output = """```json
{{
    "quality": "{quality}",
    "summary": "{summary}",
    "features": {features},
    "time": "{time}" 
}}
```"""
