from utils.data_utils.data_trans import *
from mcp_tools.doc_process.train_model.meta import *
from utils.llm_utils.chat_with_lapi_LLM import *
from tqdm import tqdm
import json
import re


def parse_think_and_json(text):
    """
    解析包含 <think> 标签和 JSON 的文本

    Args:
        text: 输入的文本字符串

    Returns:
        dict: 包含 'think' 和 'json' 两个键的字典
    """
    result = {
        'think': None,
        'json': None
    }
    text = text.replace("'", '"')
    # 解析 <think> 标签内容
    think_pattern = r'<think>(.*?)</think>'
    think_match = re.search(think_pattern, text, re.DOTALL)
    if think_match:
        result['think'] = think_match.group(1).strip()

    # 解析 JSON 内容
    # 查找 ```json 和 ``` 之间的内容
    json_pattern = r'```json\s*(.*?)\s*```'
    json_match = re.search(json_pattern, text, re.DOTALL)
    if json_match:
        json_str = json_match.group(1)
        try:
            result['json'] = json.loads(json_str)
        except json.JSONDecodeError as e:
            print(f"JSON 解析错误: {e}")
            result['json'] = json_str  # 返回原始字符串

    return result


class Eval():
    def __init__(self):
        self.model = "dp-4-full-qwen3-8b"
        self.input_path = "data/cloud_share/mcp_tools/doc_process/train_data/eval_data/test_1014.tsv"
        # self.input_path = "data/cloud_share/mcp_tools/doc_process/train_data/enhance_data/raw_enhace_data.tsv"
        self.df = load_any_to_dataframe(self.input_path)
        self.df_len = len(self.df)
        self.output_path = f"data/cloud_share/mcp_tools/doc_process/train_data/eval_data/test_1014_6_label.tsv"
        # self.output_path = f"data/cloud_share/mcp_tools/doc_process/train_data/enhance_data/raw_enhace_data_label_test.tsv"

    def safe_load_json(self, text: str):
        import re
        text = re.sub(r"```json|```", "", text).strip()
        try:
            return json.loads(text)
        except json.JSONDecodeError as e:
            try:
                text_fixed = text.replace('\n', '\\n').replace('\r', '\\r')
                return json.loads(text_fixed)
            except json.JSONDecodeError:
                try:
                    import re

                    def replace_newlines_in_strings(match):
                        return match.group(0).replace('\n', '\\n').replace('\r', '\\r')

                    text_fixed = re.sub(r'("(?:[^"\\]|\\.)*")', replace_newlines_in_strings, text)
                    return json.loads(text_fixed)
                except json.JSONDecodeError:
                    print("解析失败:", text)
                    return "NONE"

    def process(self):
        self.df["quality_pred"] = None
        self.df["features_pred"] = None
        self.df["summary_pred"] = None
        self.df["time_pred"] = None
        for idx, row in tqdm(self.df.iterrows(), total=self.df_len, desc="Processing"):
            res = 0
            try:
                title = row["title"]
                content = row["content"].replace('"', "'")
                # user_input_content = user_input.format(title=title, content=content)
                # history = [{"role": "system", "content": system_prompt.format(title=title, content=content)}]
                #    {"role": "user", "content": user_input_content}]
                res0 = chat_with_lpai_LLM_signal(system_prompt.format(
                    title=title, content=content), self.model, llm_config[self.model], temperature=0.9)
                # res = chat_with_lpai_LLM_history(history, self.model, llm_config[self.model], temperature=0.1)
                # print(res)
                # if "qwen3" in self.model:
                #     res = parse_think_and_json(res)
                #     res = res["json"]
                # else:
                res = self.safe_load_json(res0)
                # self.df.at[idx, "质量"] = res["quality"]
                # self.df.at[idx, "摘要（段落抽取）"] = res["summary"]
                # self.df.at[idx, "features"] = res["features"]
                if res == "NONE":
                    print(title)
                    print(content)
                    print(res0)
                    continue
                self.df.at[idx, "quality_pred"] = res["quality"]
                self.df.at[idx, "features_pred"] = res["features"]
                self.df.at[idx, "summary_pred"] = res["summary"]
                self.df.at[idx, "time_pred"] = res["time"]
            except Exception as e:
                print(res)
                print(e)
                continue
        self.df.to_csv(self.output_path, sep="\t", index=False)
        print(f"文件已成功保存至： {self.output_path}")

    # 多线程调用
    # def _clean(self, s: str) -> str:
    #     return ("" if s is None else str(s)).replace('"', "'")

    # def _handle_row(self, args):
    #     idx, row, model = args
    #     res = 0
    #     try:
    #         title = self._clean(row["title"])
    #         content = self._clean(row["content"])
    #         out1 = chat_with_lpai_LLM_signal(
    #             system_prompt.format(title=title, content=content),
    #             model, llm_config[model], temperature=0.6,
    #             max_tokens=8192
    #         )
    #         if "qwen3" in model:
    #             out = parse_think_and_json(out1)["json"]
    #         else:
    #             out = self.safe_load_json(out1)
    #         if out == "NONE" or out is None:
    #             return idx, None
    #         return idx, (out.get("quality"), out.get("features"), out.get("summary"))
    #     except Exception as e:
    #         print(res)
    #         print(e)
    #         return idx, None

    # def process(self, max_workers=8):
    #     from concurrent.futures import ThreadPoolExecutor
    #     # 初始化列
    #     for c in ("quality_pred", "features_pred", "summary_pred"):
    #         if c not in self.df.columns:
    #             self.df[c] = None
    #         else:
    #             self.df[c] = None

    #     pairs = [(idx, row, self.model) for idx, row in self.df.iterrows()]
    #     with ThreadPoolExecutor(max_workers=max_workers) as ex:
    #         for idx, triple in tqdm(ex.map(self._handle_row, pairs), total=self.df_len, desc="Processing"):
    #             if triple is None:
    #                 continue
    #             q, f, s = triple
    #             self.df.at[idx, "quality_pred"] = q
    #             self.df.at[idx, "features_pred"] = f
    #             self.df.at[idx, "summary_pred"] = s

    #     self.df.to_csv(self.output_path, sep="\t", index=False)
    #     print(f"文件已成功保存至： {self.output_path}")


if __name__ == "__main__":
    obj = Eval()
    obj.process()
    # python -m mcp_tools.doc_process.train_model.step2_eval_data
