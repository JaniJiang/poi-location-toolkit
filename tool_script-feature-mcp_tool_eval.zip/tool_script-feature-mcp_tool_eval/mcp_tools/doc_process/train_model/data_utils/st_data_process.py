import json
import pandas as pd
from tqdm import tqdm
from typing import List
from utils.data_utils.data_trans import load_any_to_dataframe


def process_ks(ks: List):
    res = []
    for meta in ks:
        datas = meta["data"]
        for data in datas:
            if "bot_data" not in data:
                continue
            bot_datas = data["bot_data"]
            for bot_data in bot_datas:
                if "doc_source" not in bot_data:
                    continue
                if bot_data["doc_source"] == "内部站点":
                    continue
                base_data = {
                    "url": bot_data.get("source_link", None),
                    "title": bot_data.get("title", None),
                    "content": bot_data.get("content", None),
                }
                res.append(base_data)
    return res


def procrss_st_data(input_path, output_path):
    df = load_any_to_dataframe(input_path)
    df_len = len(df)
    total_res = []
    for _, row in tqdm(df.iterrows(), desc="Processing", total=df_len):
        ks = row['knowledge_search_result']
        ks = json.loads(ks)
        if len(ks) == 0:
            continue
        res = process_ks(ks)
        total_res.extend(res)

    df = pd.DataFrame(total_res)
    df.to_csv(output_path, sep="\t", index=False)
    print(f"文件已成功保存至： {output_path}")


if __name__ == "__main__":
    input_path = "data/cloud_share/mcp_tools/doc_process/train_data/st_data/st_raw_data.tsv"
    output_path = "data/cloud_share/mcp_tools/doc_process/train_data/st_data/st_raw_data_label.tsv"
    procrss_st_data(input_path, output_path)
    # python -m mcp_tools.doc_process.train_model.data_utils.st_data_process
