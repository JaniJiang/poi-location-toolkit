import pandas as pd
import numpy as np
from utils.data_utils.data_trans import load_any_to_dataframe


# def post_process(input_path, output_path):
#     df = load_any_to_dataframe(input_path)
#     print(f"原始输入df长度是： {len(df)}")

#     # 规则1：quality_pred == 1 且 summary_pred 为 NaN
#     mask_bad_combo = (df["quality_pred"] == 1) & (pd.isna(df["summary_pred"]))

#     # 规则2：len(summary) > 250（对非字符串或NaN按长度0）
#     summary_len = df["summary_pred"].map(lambda x: len(x) if isinstance(x, str) else 0)
#     mask_summary_too_long = summary_len > 250

#     # 组合过滤（删除满足任一规则的行）
#     mask_to_drop = mask_bad_combo | mask_summary_too_long
#     df_out = df.loc[~mask_to_drop].copy()
#     print(f"输入df长度是： {len(df_out)}")

#     # 保存为TSV
#     df_out.to_csv(output_path, sep="\t", index=False, encoding="utf-8")

def post_process(input_path, output_path, max_len=250):
    df = load_any_to_dataframe(input_path)
    print(f"[原始] 行数: {len(df)}")

    # --- 列检查 ---
    required_cols = ["quality_pred", "summary_pred"]
    missing = [c for c in required_cols if c not in df.columns]
    if missing:
        raise ValueError(f"缺少必要列: {missing}")

    # --- 规范化 quality_pred（避免字符串/浮点导致判断异常）---
    # 尝试转成0/1，无法解析的当作0处理；你也可改成丢弃
    q = pd.to_numeric(df["quality_pred"], errors="coerce").fillna(0).astype(int)
    df["quality_pred"] = q

    # --- 清洗 summary_pred ---
    s = df["summary_pred"].copy()

    # 把非字符串保留为 NaN；字符串去首尾空白
    s = s.map(lambda x: x.strip() if isinstance(x, str) else np.nan)

    # 统一把空白串标记为 NaN
    s = s.replace(r"^\s*$", np.nan, regex=True)

    # 伪空值 -> NaN（大小写不敏感）
    pseudo_empty = {"none", "null", "nan", "n/a", "na", "[]", "{}", "<none>", "<null>"}
    s = s.map(lambda x: np.nan if (isinstance(x, str) and x.lower() in pseudo_empty) else x)

    df["_summary_norm"] = s

    # 长度（非字符串记为0；NaN记为0）
    summary_len = df["_summary_norm"].map(lambda x: len(x) if isinstance(x, str) else 0)

    # --- 规则 ---
    # 1) 严禁空摘要（无论 quality_pred 是多少）
    mask_empty_summary = df["_summary_norm"].isna() | (summary_len == 0)

    # 2) 严禁过长
    mask_summary_too_long = summary_len > max_len

    # 3) 你原始的组合规则（可选）：quality_pred==1 且摘要空（已被规则1覆盖）
    # 保留是为了可读性与日志
    mask_bad_combo = (df["quality_pred"] == 1) & mask_empty_summary

    # --- 统计 ---
    print(f"[统计] 空摘要行数: {mask_empty_summary.sum()}")
    print(f"[统计] 超长摘要行数(>{max_len}): {mask_summary_too_long.sum()}")
    print(f"[统计] 质量=1且空摘要: {mask_bad_combo.sum()}")

    # --- 过滤 ---
    mask_to_drop = mask_empty_summary | mask_summary_too_long
    df_out = df.loc[~mask_to_drop].copy()

    # 如果需要，删除辅助列
    df_out = df_out.drop(columns=["_summary_norm"], errors="ignore")

    print(f"[输出] 行数: {len(df_out)}")

    # --- 边界处理：如果全被过滤，仍然输出（或根据需要改为报错/不写盘）---
    df_out.to_csv(output_path, sep="\t", index=False, encoding="utf-8")
    print(f"文件已保存至： {output_path}")


def eval_data(input_path, output_path, EVAL_NUM=200):
    df = load_any_to_dataframe(input_path)
    # 随机抽样（最多抽到数据总量这么多）
    df_eval = df.sample(n=min(EVAL_NUM, len(df)))
    # 保存为 TSV
    df_eval.to_csv(output_path, sep="\t", index=False, encoding="utf-8")
    print(f"文件已成功保存至： {output_path}")


if __name__ == "__main__":
    input_path = "data/cloud_share/mcp_tools/doc_process/train_data/enhance_data/raw_enhace_data_label_test.tsv"
    output_path = "data/cloud_share/mcp_tools/doc_process/train_data/enhance_data/raw_enhace_data_label_final.tsv"
    output_eval_path = "data/cloud_share/mcp_tools/doc_process/train_data/enhance_data/raw_enhace_data_label_final_eval.tsv"
    # post_process(input_path, output_path)
    eval_data(output_path, output_eval_path)
    # python -m mcp_tools.doc_process.train_model.step3_post_process_online_data
