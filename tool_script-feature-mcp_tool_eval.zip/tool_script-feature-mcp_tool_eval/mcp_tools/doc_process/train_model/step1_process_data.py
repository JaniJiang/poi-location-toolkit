from utils.data_utils.data_trans import *
from mcp_tools.doc_process.train_model.meta import *
from tqdm import tqdm


class Process():
    def __init__(self):
        self.input_path = "data/cloud_share/mcp_tools/doc_process/train_data/train_data_v3.tsv"
        self.output_path = "data/cloud_share/mcp_tools/doc_process/train_data/train_data_v3.jsonl"
        # self.input_path = "data/cloud_share/mcp_tools/doc_process/train_data/fix_summary_ability/fix_summary_v1.tsv"
        # self.output_path = "data/cloud_share/mcp_tools/doc_process/train_data/fix_summary_ability/fix_summary_v1.jsonl"
        self.df = load_any_to_dataframe(self.input_path)
        self.df_len = len(self.df)
        self.dataset = []

    def process(self):
        for _, row in tqdm(self.df.iterrows(), total=self.df_len, desc="Processing"):
            # title = row["title"]
            # content = row["content"]
            # quality = row["quality_pred"]
            # summary = row["summary_pred"]
            # features = row["features_pred"]
            title = row["title"]
            content = str(row["content"]).replace('"', "'")
            quality = row["质量"]
            summary = str(row["摘要（段落抽取）"]).replace('"', "'")
            features = row["features"]
            time = row["事件发生时间"]
            user_input_content = user_input.format(title=title, content=content)
            assistant_output_content = assistant_output.format(
                quality=quality, summary=summary, features=features, time=time)
            base_format = {
                "instruction": system_prompt.format(title=title, content=content),
                "input": "",
                "output": assistant_output_content
            }
            self.dataset.append(base_format)

        with open(self.output_path, "w", encoding="utf-8") as f:
            for item in self.dataset:
                f.write(json.dumps(item, ensure_ascii=False) + "\n")
        print(f"文件已成功保存至: {self.output_path}")


if __name__ == "__main__":
    obj = Process()
    obj.process()
    # python -m mcp_tools.doc_process.train_model.step1_process_data
