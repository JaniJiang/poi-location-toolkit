import pandas as pd
import json
from recommend.struct_display_new.analyse.analyse_entitylink_news.step0_extract_tag_engine import ExtraxtTagFromQueryAndTitle


class GetStructResultTag():
    def __init__(self):
        self.base_path = "data/cloud_share/mcp_tools/news_search/result_analyse/v2/query.tsv"
        self.save_path = "data/cloud_share/mcp_tools/news_search/result_analyse/v2/struct_res_tag.tsv"
        self.extractor = ExtraxtTagFromQueryAndTitle()

    def process(self):
        df = pd.read_csv(self.base_path, sep="\t")
        tag_result = []

        with open(self.save_path, "w", encoding="utf-8") as fout:
            for idx, row in df.iterrows():

                media_search_result = row["media_search_result"]
                try:
                    media_json = json.loads(media_search_result)
                    data_list = []  # 返回新闻列表
                    if isinstance(media_json, dict):
                        data_list = media_json.get("data", [])
                    elif isinstance(media_json, list) and len(media_json) > 0:
                        first = media_json[0]
                        if isinstance(first, dict):
                            data_list = first.get("data", [])
                    else:
                        data_list = []

                    for item in data_list:
                        title = item.get("title", "")

                        # 获取 title TAG
                        title_response = self.extractor.process({"text": title, "type": "title"})
                        title_res = title_response.get("res", {})
                        if isinstance(title_res, str):
                            try:
                                title_res = json.loads(title_res)
                            except Exception:
                                title_res = {}

                        title_tag = title_res.get("tag", "") if isinstance(title_res, dict) else ""
                        print(f"{title}: {title_tag}")

                        tag_result.append({
                            "title": title,
                            "title_tag": title_tag
                        })
                except Exception as e:
                    print(f"解析失败 row={idx}, err={e}")

                fout.write(json.dumps(tag_result, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    obj = GetStructResultTag()
    obj.process()
