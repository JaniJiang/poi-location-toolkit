import json
import pandas as pd
import requests
from datetime import datetime, timedelta


class GetEsSearchResult:
    def __init__(self):
        self.input_path = "data/cloud_share/mcp_tools/news_search/result_analyse/v2/query_with_time.tsv"
        self.output_path = "data/cloud_share/mcp_tools/news_search/result_analyse/v2/query_with_es_result.tsv"

        self.es_search_path = "https://es-search-test.inner.chj.cloud/es_search"
        self.headers = {"Content-Type": "application/json"}
        self.index_name = "test_news_data_202510_v3"
        self.size = 10
        self.minimum_should_match = 1

        # 政治、军事、财经、科技、娱乐、金融、经济、教育、体育、健康、法律、文旅、民生、汽车、房产
        self.default_news_tags = ["军事", "财经", "科技", "金融", "娱乐", "国际", "国内", "经济", "体育", "汽车"]
        self.boost_map = {
            "军事": 1,
            "财经": 1,
            "国内": 2,
            "科技": 1,
            "国际": 1,
            "金融": 2,
            "娱乐": 1,
        }

    def build_es_dsl(self, query: str, query_tag: str, area: str, topic: str, start_time: str, end_time: str):
        if query_tag.strip() == 'nan':
            tags = self.default_news_tags
        elif query_tag.strip() in ["早间", "晚间", "午间", "热点", "头条"]:
            tags = self.default_news_tags
        else:
            tags = [tag.strip() for tag in query_tag.split("&") if tag.strip()
                    and tag not in ["早间", "晚间", "午间", "热点", "头条"]]
            if not tags:
                tags = self.default_news_tags

        must_conditions = []
        if len(tags) == 1:  # 单个 tag
            must_conditions.append({
                "term": {"features.tag": tags[0]}
            })
        else:  # 多个 tag
            should_conditions = [
                {"term": {"features.tag": tag}} for tag in tags
            ]
            must_conditions.append({
                "bool": {
                    "should": should_conditions,
                    "minimum_should_match": 1
                }
            })

        # topic（来自日志表 content 字段中的 TAG）
        if topic and topic != 'nan':
            must_conditions.append({"term": {"features.topic": topic}})

        # 地域
        if area and area != 'nan':
            must_conditions.append({"term": {"features.area": area}})

        # 时间范围
        if start_time == 'nan' or end_time == 'nan' or pd.isna(start_time) or pd.isna(end_time):
            # now = datetime.now()
            now = datetime(2025, 10, 16, 23, 59, 59)
            start_time = (now - timedelta(days=3)).strftime("%Y-%m-%d %H:%M:%S")
            end_time = now.strftime("%Y-%m-%d %H:%M:%S")
        must_conditions.append({
            "range": {
                "publish_time": {
                    "gte": start_time,
                    "lte": end_time,
                    "format": "yyyy-MM-dd HH:mm:ss",
                }
            }
        })

        dsl = {
            "query": {
                "bool": {
                    "must": must_conditions
                }
            },
            "size": self.size,
        }
        if area == "美股":
            print(dsl)
        return dsl

    def get_es_result(self, query: str, query_tag: str, area: str, topic: str, start_time: str, end_time: str):
        payload = {
            "index_name": self.index_name,
            "dsl": self.build_es_dsl(query, query_tag, area, topic, start_time, end_time),
        }
        try:
            resp = requests.post(
                self.es_search_path,
                headers=self.headers,
                data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                timeout=20,
            )
            if resp.status_code == 200:
                return resp.json()
            else:
                print(f"请求失败: {resp.status_code} {resp.text}")
                return []
        except Exception as e:
            print(f"请求异常: {e}")
            return []

    def process(self):
        df = pd.read_csv(self.input_path, sep="\t")
        # df = df.sample(n=min(100, len(df)), random_state=42)
        with open(self.output_path, "w", encoding="utf-8") as fout:
            fout.write("query\tquery_tag\tarea\tstart_time\tend_time\tes_search_result\n")
            for idx, row in df.iterrows():
                query = str(row["query"])
                query_tag = str(row["tag"])
                area = str(row["area"])
                topic = str(row["topic"])
                start_time = str(row["start_time"])
                end_time = str(row["end_time"])
                if not query_tag.strip():
                    fout.write(f"{query}\t{query_tag}\t\n")
                    continue
                print(f"{idx}: 查询 {query_tag}+{area}（query={query},start_time={start_time},end_time={end_time}）...")
                es_result = self.get_es_result(query, query_tag, area, topic, start_time, end_time)
                fout.write(
                    f"{query}\t{query_tag}\t{area}\t{start_time}\t{end_time}\t{json.dumps(es_result, ensure_ascii=False)}\n")


if __name__ == "__main__":
    obj = GetEsSearchResult()
    obj.process()
