import json
import pandas as pd
from datetime import datetime


class GetQueryTime:
    def __init__(self):
        self.input_path = "data/cloud_share/mcp_tools/news_search/result_analyse/v2/query_all.tsv"
        self.output_path = "data/cloud_share/mcp_tools/news_search/result_analyse/v2/query_all_with_time_check.tsv"
        self.time_format = "%Y-%m-%d %H:%M:%S"

    def process(self):
        df = pd.read_csv(self.input_path, sep="\t", dtype=str).fillna("")

        results = []

        for _, row in df.iterrows():
            try:
                start_time = datetime.strptime(row["start_time"], self.time_format)
                if start_time.strftime("%H:%M:%S") == "06:00:00":
                    start_time = start_time.replace(hour=0, minute=0, second=0)
                end_time = datetime.strptime(row["end_time"], self.time_format)
            except Exception:
                results.append("invalid_time")
                continue

            media_search_result = row["media_search_result"]
            if not media_search_result.strip():
                results.append("0/0")
                continue

            try:
                result_json = json.loads(media_search_result)
                if isinstance(result_json, dict):
                    data_list = result_json.get("data", [])
                elif isinstance(result_json, list) and len(result_json) > 0:
                    first = result_json[0]
                    if isinstance(first, dict):
                        data_list = first.get("data", [])
                else:
                    data_list = []
            except Exception:
                results.append("parse_error")
                continue

            out_of_range_count = 0
            total_count = len(data_list)

            for item in data_list:
                doc_time_str = (
                    item.get("extend_data", {}).get("doc_timestamp")
                    if isinstance(item, dict)
                    else None
                )
                if not doc_time_str:
                    continue

                try:
                    doc_time = datetime.strptime(doc_time_str, self.time_format)
                    if not (start_time <= doc_time <= end_time):
                        out_of_range_count += 1
                except Exception:
                    continue

            in_range_count = total_count - out_of_range_count
            results.append(f"{in_range_count}/{total_count}")

        df["media_time_in_range_ratio"] = results
        df["media_time_in_range_ratio"].to_csv(self.output_path, sep="\t", index=False)
        print(f"处理完成，结果已保存到：{self.output_path}")


if __name__ == "__main__":
    obj = GetQueryTime()
    obj.process()
