import pandas as pd


class CountAcc:
    def __init__(self):
        self.input_path = "data/cloud_share/mcp_tools/news_search/result_analyse/v2/query_with_acc_label.tsv"

    def parse_fraction_or_number(self, val):
        if pd.isna(val):
            return 0
        val = str(val).strip()
        if "/" in val:
            try:
                a, b = val.split("/")
                a = int(a.strip())
                b = int(b.strip())
                return a / b if b != 0 else 0
            except Exception:
                return 0
        else:
            try:
                return float(val)
            except Exception:
                return 0

    def parse_numer_denom(self, val, fallback_count):
        if pd.isna(val):
            return 0, 0
        val = str(val).strip()
        if "/" in val:
            try:
                a, b = val.split("/")
                a = float(a.strip())
                b = float(b.strip())
                return a, b
            except Exception:
                return 0, 0
        else:
            try:
                f = float(val)
                if f == 1:
                    return fallback_count, fallback_count
                else:
                    return f * fallback_count, fallback_count
            except Exception:
                return 0, 0

    def process(self):
        df = pd.read_csv(self.input_path, sep="\t")

        es_len = df["es_news_count"].sum()/len(df)
        media_len = df["media_news_count"].sum()/len(df)
        print(f"自建工具 平均结果数量: {es_len}")
        print(f"MediaSearch 平均结果数量: {media_len}")

        # 计算每行比例
        df["es_ratio"] = df["es_news_acc"].apply(self.parse_fraction_or_number)
        df["media_ratio"] = df["media_news_acc"].apply(self.parse_fraction_or_number)
        # print(df["es_ratio"].sum(), df["media_ratio"].sum())

        # 平均值
        es_acc = df["es_ratio"].mean()
        media_acc = df["media_ratio"].mean()

        print(f"自建工具 ACC: {es_acc}")
        print(f"MediaSearch ACC: {media_acc}")

        # 融合 ACC
        combined_ratios = []
        for _, row in df.iterrows():
            es_num, es_den = self.parse_numer_denom(row["es_news_acc"], row["es_news_count"])
            media_num, media_den = self.parse_numer_denom(row["media_news_acc"], row["media_news_count"])
            total_num = es_num + media_num
            total_den = es_den + media_den
            ratio = total_num / total_den if total_den != 0 else 0
            combined_ratios.append(ratio)

        df["combined_ratio"] = combined_ratios
        avg_combined_ratio = df["combined_ratio"].mean()

        print(f"融合工具 ACC: {avg_combined_ratio:.4f}")


if __name__ == "__main__":
    obj = CountAcc()
    obj.process()
