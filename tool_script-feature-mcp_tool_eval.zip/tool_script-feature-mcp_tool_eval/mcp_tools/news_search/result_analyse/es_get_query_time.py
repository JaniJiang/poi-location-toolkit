import json
import pandas as pd
from datetime import datetime


class GetQueryTime:
    def __init__(self):
        self.input_path = "data/cloud_share/mcp_tools/news_search/result_analyse/v2/query.tsv"
        self.output_path = "data/cloud_share/mcp_tools/news_search/result_analyse/v2/query_with_time.tsv"

    def parse_time_str(self, t):
        if not t or pd.isna(t) or t == "":
            return None
        t = t.strip()
        try:
            dt = datetime.strptime(t, "%Y-%m-%d %H:%M:%S")
        except:
            try:
                dt = datetime.strptime(t, "%Y-%m-%d")
            except:
                return None
        return dt.strftime("%Y-%m-%d %H:%M:%S")

    def extract_times(self, content_str):
        if pd.isna(content_str):
            return None, None
        try:
            content = json.loads(content_str)
        except Exception:
            try:
                content = json.loads(json.loads(content_str))
            except Exception:
                return None, None

        start_time = None
        end_time = None

        times = content.get("timeslots")
        if isinstance(times, str):
            try:
                times = json.loads(times)
            except:
                try:
                    times = json.loads(times.replace("\\", ""))
                except:
                    times = None
        if isinstance(times, dict):
            st = times.get("start")
            start_time = st.get("time") if isinstance(st, dict) else None
            if not start_time and "startTime" in times:
                start_time = times["startTime"]

            et = times.get("end")
            sup = times.get("supplemental")
            dur = times.get("duration")
            if isinstance(et, dict):
                end_time = et.get("time")
            if not end_time and isinstance(sup, dict):
                end_time = sup.get("time")
            if not end_time and isinstance(dur, dict):
                end_time = dur.get("time")
            if not end_time and "endTime" in times:
                end_time = times["endTime"]

        if (not start_time or not end_time):
            TIMESLOTS = content.get("TIMESLOTS")
            if isinstance(TIMESLOTS, str):
                try:
                    TIMESLOTS = json.loads(TIMESLOTS)
                except:
                    try:
                        TIMESLOTS = json.loads(TIMESLOTS.replace("\\", ""))
                    except:
                        TIMESLOTS = None
            if isinstance(TIMESLOTS, dict):
                if not start_time:
                    start_time = TIMESLOTS.get("startTime")
                if not end_time:
                    end_time = TIMESLOTS.get("endTime")

        start_time = self.parse_time_str(start_time)
        end_time = self.parse_time_str(end_time)

        if start_time and end_time and start_time == end_time:
            date_part = start_time[:10]
            start_time = f"{date_part} 00:00:00"
            end_time = f"{date_part} 23:59:59"
        return start_time, end_time

    def process(self):
        df = pd.read_csv(self.input_path, sep="\t")
        df[["start_time", "end_time"]] = df["content"].apply(lambda x: pd.Series(self.extract_times(x)))
        df.to_csv(self.output_path, sep="\t", index=False)


if __name__ == "__main__":
    obj = GetQueryTime()
    obj.process()
