import json
import pandas as pd


class CountResult:
    def __init__(self):
        self.input_path_es = "data/cloud_share/mcp_tools/news_search/result_analyse/v2/query_with_es_result.tsv"
        self.input_path_struct = "data/cloud_share/mcp_tools/news_search/result_analyse/v2/query.tsv"
        self.output_path = "data/cloud_share/mcp_tools/news_search/result_analyse/v2/query_with_count_result.tsv"

    def process(self):
        df_es = pd.read_csv(self.input_path_es, sep="\t")
        df_struct = pd.read_csv(self.input_path_struct, sep="\t")

        # 统计 es_search_result 的新闻数量
        df_es["es_news_count"] = df_es["es_search_result"].apply(lambda x: len(json.loads(x)) if pd.notna(x) else 0)

        # 统计 media_search_result 的新闻数量
        def count_media_news(media_str):
            try:
                media_json = json.loads(media_str)
                data_list = []
                if isinstance(media_json, dict):
                    data_list = media_json.get("data", [])
                elif isinstance(media_json, list) and len(media_json) > 0 and isinstance(media_json[0], dict):
                    data_list = media_json[0].get("data", [])
                return len(data_list)
            except Exception:
                return 0

        df_struct["media_news_count"] = df_struct["media_search_result"].apply(count_media_news)

        df_result = pd.DataFrame({
            "query": df_es["query"],
            "es_news_count": df_es["es_news_count"],
            "media_news_count": df_struct["media_news_count"]
        })

        df_result.to_csv(self.output_path, sep="\t", index=False)
        print(f"保存完成: {self.output_path}")


if __name__ == "__main__":
    obj = CountResult()
    obj.process()
