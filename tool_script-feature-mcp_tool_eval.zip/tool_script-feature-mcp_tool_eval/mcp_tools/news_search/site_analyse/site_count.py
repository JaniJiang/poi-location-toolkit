import json
import pandas as pd
from collections import Counter
from recommend.struct_display_new.analyse.analyse_entitylink_news.step0_extract_tag_engine import ExtraxtTagFromQueryAndTitle


class GetEsSearchResult:
    def __init__(self):
        self.input_path = "data/cloud_share/mcp_tools/news_search/site_analyse/query.tsv"
        self.output_query_path = "data/cloud_share/mcp_tools/news_search/site_analyse/query_with_tag.tsv"
        self.output_tag_path = "data/cloud_share/mcp_tools/news_search/site_analyse/tag_count.tsv"

        self.extractor = ExtraxtTagFromQueryAndTitle()

    def process(self):
        df = pd.read_csv(self.input_path, sep="\t")
        tag_counter = Counter()
        results = []
        total_queries = len(df)

        for idx, row in df.iterrows():
            query = row["query"]
            tag_field = ""

            try:
                query_response = self.extractor.process({"text": query, "type": "query"})
                query_res = query_response.get("res", {})
                if isinstance(query_res, str):
                    query_res = json.loads(query_res)
                tag_field = query_res.get("tag", "") if isinstance(query_res, dict) else ""
            except Exception as e:
                print(f"[ERROR] idx={idx}, query={query}, error={e}")

            tags = [t.strip() for t in tag_field.split("&") if t.strip()]
            for t in tags:
                tag_counter[t] += 1

            results.append({"query": query, "tag": tag_field})
            print(f"{idx}: query = {query}, tags = {tags}")

        query_tag_df = pd.DataFrame(results)
        query_tag_df.to_csv(self.output_query_path, sep="\t", index=False)
        print(f"已输出 query+tag 数据，共 {len(query_tag_df)} 条，保存至：{self.output_query_path}")

        tag_df = pd.DataFrame(tag_counter.items(), columns=["tag", "count"])
        tag_df["ratio(%)"] = (tag_df["count"] / total_queries * 100).round(2)
        tag_df = tag_df.sort_values(by="count", ascending=False)

        tag_df.to_csv(self.output_tag_path, sep="\t", index=False)
        print(f"已输出 tag 统计结果，共 {len(tag_df)} 个标签，保存至：{self.output_tag_path}")


if __name__ == "__main__":
    obj = GetEsSearchResult()
    obj.process()
