import pandas as pd
import json
from collections import Counter


class CountTagDistribution:
    def __init__(self):
        self.input_path = "data/cloud_share/mcp_tools/news_search/data_analyse/data_1101_to_1105.tsv"
        self.output_path = "data/cloud_share/mcp_tools/news_search/data_analyse/data_1101_to_1105_tag_distribution.tsv"

    def process(self):
        df = pd.read_csv(self.input_path, sep="\t", dtype=str)
        print(f"Loaded {len(df)} rows from {self.input_path}")

        all_tags = []
        for features_str in df["features"].dropna():
            try:
                features = json.loads(features_str)
                tags = features.get("tag", [])
                if isinstance(tags, list):
                    all_tags.extend(tags)
            except Exception as e:
                continue

        tag_counts = Counter(all_tags)

        df_tags = pd.DataFrame(tag_counts.items(), columns=["tag", "count"])
        total = df_tags["count"].sum()
        df_tags["percentage"] = (df_tags["count"] / total * 100).round(2)

        df_tags = df_tags.sort_values("count", ascending=False)
        df_tags.to_csv(self.output_path, sep="\t", index=False)

        print(f"Tag distribution saved to: {self.output_path}")
        print(df_tags.head(20))


if __name__ == "__main__":
    obj = CountTagDistribution()
    obj.process()
