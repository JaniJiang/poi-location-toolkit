import json
import pandas as pd


class GenerateAgentSchema:

    def __init__(self):
        self.input_path = "data/cloud_share/mcp_tools/schema/input.tsv"
        self.output_path = "data/cloud_share/mcp_tools/schema/output_agent_schema.tsv"

    def process(self):
        current_agent_name = ""
        current_agent_desc = ""
        current_agent_skills = []
        input_df = pd.read_csv(self.input_path, sep="\t").fillna("")
        output_list = []
        for _, row in input_df.iterrows():
            if row["二级分类"] != "":
                if current_agent_name != "":
                    agent_schema_dict = {
                        "name": current_agent_name,
                        "description": current_agent_desc,
                        "skills": current_agent_skills,
                    }
                    output_list.append(json.dumps(agent_schema_dict, ensure_ascii=False, indent=4))
                current_agent_name = row["二级分类"]
                current_agent_desc = row["二级分类描述"]
                current_agent_skills = []
            current_agent_skills.append({
                "name": row["工具名称"],
                "description": row["工具简介"],
            })
        if current_agent_name != "":
            agent_schema_dict = {
                "name": current_agent_name,
                "description": current_agent_desc,
                "skills": current_agent_skills,
            }
            output_list.append(json.dumps(agent_schema_dict, ensure_ascii=False, indent=4))
        # 保存结果
        output_df = pd.DataFrame(output_list)
        output_df.to_csv(self.output_path, sep="\t", index=False, header=False)


if __name__ == "__main__":
    obj = GenerateAgentSchema()
    obj.process()

# python -m mcp_tools.schema.generate_agent_schema
