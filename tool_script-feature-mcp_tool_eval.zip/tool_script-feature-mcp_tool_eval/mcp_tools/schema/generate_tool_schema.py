import json
import pandas as pd


class GenerateToolSchema:

    def __init__(self):
        self.input_path = "data/cloud_share/mcp_tools/schema/input.tsv"
        self.output_path = "data/cloud_share/mcp_tools/schema/output_tool_schema.tsv"

    def process(self):
        input_df = pd.read_csv(self.input_path, sep="\t").fillna("")
        output_list = []
        for _, row in input_df.iterrows():
            if row["优先级"] != "P0":
                continue
            params_dict, required_params_list = self.parse_input_params(row["工具输入参数"])
            tool_schema_dict = {
                "type": "function",
                "function": {
                    "name": row["工具名称"],
                    "description": row["工具详细描述"],
                    "parameters": {
                        "type": "object",
                        "properties": params_dict,
                        "required": required_params_list,
                    }
                }
            }
            output_list.append(json.dumps(tool_schema_dict, ensure_ascii=False, indent=4))
        # 保存结果
        output_df = pd.DataFrame(output_list)
        output_df.to_csv(self.output_path, sep="\t", index=False, header=False)

    def parse_input_params(self, params_str: str):
        params_dict = {}
        required_params_list = []
        if params_str == "":
            return params_dict, required_params_list
        for param_str in params_str.split("\n"):
            param_name, param_conf = param_str.split(":")
            param_type, param_desc, param_required, param_demo = param_conf.split("|")
            if param_demo != "无" and param_demo.startswith("[") is False and param_demo.endswith("]") is False:
                description = f"{param_desc}，比如{param_demo}等"
            else:
                description = param_desc
            params_dict[param_name] = {
                "type": param_type,
                "description": description,
            }
            if param_demo.startswith("[") is True and param_demo.endswith("]") is True:
                params_dict[param_name]["enum"] = param_demo.lstrip("[]").rstrip("]").split("、")
            if param_required == "必选":
                required_params_list.append(param_name)
        return params_dict, required_params_list


if __name__ == "__main__":
    obj = GenerateToolSchema()
    obj.process()

# python -m mcp_tools.schema.generate_tool_schema
