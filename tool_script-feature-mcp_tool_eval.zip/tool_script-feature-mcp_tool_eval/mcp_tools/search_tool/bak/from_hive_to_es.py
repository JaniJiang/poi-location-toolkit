import os
import pdb
import json
import pandas as pd
from loguru import logger
from search.qa_bot.qwen3_reranker.meta import *
from utils.search_utils.es_client import ElasticSearchClient
from datagrid import get_client
from typing import Iterator


class PushData:

    def __init__(self, index_name, if_refresh_index):
        self.index_name = index_name
        self.refresh_index = if_refresh_index
        # init es client
        self.es_client = ElasticSearchClient(CLUSTER_NAME)
        self.mapping = {
            "properties": {
                "id": {"type": "keyword"},
                "title": {"type": "text"},
                "content": {"type": "text"},
                "url": {"type": "text"},
                "site": {"type": "text"},
                "publish_time": {"type": "text"},
                "site": {"type": "text"}
            }
        }

    def process(self, df):
        # create index
        code = self.es_client.check_and_create_index(self.index_name, self.refresh_index, self.mapping)
        if code is False:
            logger.error(f"[PushData] check_and_create_index {self.index_name} failed")
            return False
        logger.info(f"[PushData] check_and_create_index {self.index_name} success")
        # filter data
        df = df[[col for col in self.mapping["properties"].keys()]]
        # read data
        data_list = json.loads(df.to_json(orient='records'))
        # load data
        success, failed = self.es_client.load_data(self.index_name, data_list)
        logger.info(f"[PushData] {success} documents loaded successfully, {failed} documents failed to load.")
        return True

    def append(self, df):
        # read data
        data_list = df.to_json(orient='records')
        # load data
        success, failed = self.es_client.load_data(self.index_name, data_list)
        logger.info(f"[PushData] {success} documents loaded successfully, {failed} documents failed to load.")
        return True


def write_iterator_to_csv(iterator: Iterator[pd.DataFrame], file_path: str):
    # 检查文件是否存在，以确定是否需要写入表头
    file_exists = False
    try:
        with open(file_path, 'r', newline='', encoding='utf-8') as file:
            if file.read(1):  # 如果能读取到至少一个字符，说明文件存在且非空
                file_exists = True
    except FileNotFoundError:
        pass

    # 写入数据
    for df in iterator:
        # 如果文件不存在或者这是第一个 DataFrame，则包含表头
        mode = 'a' if file_exists else 'w'
        header = not file_exists

        # 将 DataFrame 写入 CSV 文件
        df.to_csv(file_path, mode=mode, index=False, header=header)

        # 写入完成后，将文件存在标志设置为 True
        file_exists = True


def load_dip_dataset(client, datasetcode: str, version: str):
    datagrid_cache_dir = "/lpai/volumes/ss-sai-bd-ga/songyanmei/sym/output2"
    ite = client.load_dataset_cached_local_iterator(
        dataset_id=f"{datasetcode}",
        version_id=f"{version}",
        cache_dir=datagrid_cache_dir,
        filter_expression=None, batch_size=10000, verbose=True, progress=True)
    count = 0
    import pandas as pd
    dataframes = []
    for it in ite:
        if False:
            print(it)
            break
        dataframes.append(it)
        # (row,_)  = it.shape
        # count += row
    # print(f"total rows has been loaded is : {count}")
    # 合并所有 DataFrame
    merged_df = pd.concat(dataframes, ignore_index=True)
    # 删除dip数据集内置的列
    # '__rowid', '__objects','__rowschema','__rowimporttime' 是dip数据集的内置列，业务方使用的时候可以手动过滤下
    merged_df = merged_df.drop(columns=['__rowid', '__objects', '__rowschema', '__rowimporttime'])
    print(merged_df.shape)
    print(merged_df)


if __name__ == "__main__":
    os.environ['dip.env'] = 'prod'
    os.environ['dip.x-dip-spacecode'] = 'sai-dp'
    os.environ['dip_refresh_token'] = 'BJ:7yqCc1aWCIZnrRuOqGD'
    os.environ['dip.x-chj-gwtoken'] = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJud01DajhpZm9FMEFTZVFrVkF5V2dBUThQVHpldmJMaSJ9.BS9D24qhhIW-96wecYvgLCWicOvIeym-IeWk6xDf3pQ'
    # logging.basicConfig(level=logging.INFO)
    # logger=logging.getLogger(__name__)
    # credentials=load_credentials()
    print(os.environ['dip.env'], os.environ['dip.x-dip-spacecode'], os.environ['dip_refresh_token'])
    client = get_client(env=os.environ['dip.env'], space_code=os.environ['dip.x-dip-spacecode'],
                        refresh_token=os.environ['dip_refresh_token'], x_chj_gwtoken=os.environ['dip.x-chj-gwtoken'])
    filter = "select url from ssai_ods.search_data_features where dt = '2025-09-28' limit 10"
    database = "ssai_ods"
    table = "search_data_features"
    partition_spec = "dt=2025-09-28"
    cache_dir = '/lpai/volumes/ss-sai-bd-ga/songyanmei/sym/output2'
    # ite=client.load_dataset_cached_local_iterator(database=database,table=table,cache_dir=cache_dir,filter_expression=None,batch_size=10000,progress=True,verbose=True)
    # write_iterator_to_csv(ite)
    # for it in ite:
    #     print(it)

    datagrid_cache_dir = "/lpai/volumes/ss-sai-bd-ga/songyanmei/sym/output2"

    # df4=client.load_table_in_iterator_by_sql(sql=filter,batch_size=100,verbose=False,progress=True)
    # load data from data warehouse and cache data in local disk.
    # file://root/.cache/datagrid/hub/e605fe53711e472225043da7ddc427ee0bf98f816e3cc93023e80b03aa4b90b6
    if False:
        df_iterator = client.load_table_cache_local_iterator(database=database, table=table, partition_spec=partition_spec,
                                                             cache_dir=datagrid_cache_dir,
                                                             filter_expression=None, batch_size=10000, verbose=True,
                                                             progress=True)
        for df in df_iterator:
            print(df)
            break

    if True:
        df_iterator = client.load_table_in_iterator(database=database, table=table, partition_spec=partition_spec,

                                                    filter_expression=filter, batch_size=10000, verbose=True,
                                                    progress=True)
        dataframes = []
        # write_iterator_to_csv(df_iterator,"/lpai/volumes/ss-sai-bd-ga/songyanmei/sym/output2")
        for df in df_iterator:
            dataframes.append(df)
        merged_df = pd.concat(dataframes, ignore_index=True)
        pdb.set_trace()
        merged_df.to_csv('/mnt/volumes/ss-sai-bd-ga/wuzhenyan/dip/aa.csv', index=False)

        obj = PushData("news_data_0928", True)
        obj.process(df=merged_df)

    # load data from local disk cache
    if False:
        local_cache_dir = "file://lpai/volumes/ss-sai-bd-ga/songyanmei/sym/output/e605fe53711e472225043da7ddc427ee0bf98f816e3cc93023e80b03aa4b90b6"
        df_ite = client.load_data_in_iterator(
            path=local_cache_dir,
            filter_expression=None, batch_size=10000)
        count = 0
        for df in df_ite:
            # count = count + df.shape()[0]
            (row, col) = df.shape
            count += row
        print(count)

    # 下面的例子是读取dip数据生产平台的数据集
    # 目标数据集地址：https://dip-data-labeling.inner.chj.cloud/datasets/ds_bcc9b4eb2ae949d6ad7b3ff630755399?version=1
    if False:
        # 此datasetcode来自于第五节中的数据集编码复制过来的
        datasetcode = "ds_bcc9b4eb2ae949d6ad7b3ff630755399"
        dataset_version = "V1"
        if not datasetcode or not datasetcode.strip():
            raise ValueError("datasetcode can not be none or empty")
        if not dataset_version or not dataset_version.strip():
            raise ValueError("dataset_version can not be none or empty")
        load_dip_dataset(client=client, datasetcode=datasetcode, version=dataset_version)

    # write_iterator_to_csv(df4,'/lpai/volumes/ss-sai-bd-ga/songyanmei/sym/outputdir/output6.csv')

    # print(df2)

    # data = [i for i in range(10)]
    # df3=pd.DataFrame(data)

    # pd.DataFrame(df4).to_csv('/lpai/volumes/ss-sai-bd-ga/songyanmei/sym/outputdir/output2.csv', index=False, sep='\t')
    # print(client)
    # print("aa")

      # df2=client.load_table_in_iterator(database=db, table=table, partition_spec='dt=2025-05-28',
    #                                             filter_expression=filter_expression, batch_size=10000, verbose=True,
    #                                             progress=True)
       # for item in df4:
    # pd.DataFrame(df4[0]).to_csv('/lpai/volumes/ss-sai-bd-ga/songyanmei/sym/outputdir/output4.csv', index=False, sep='\t')
        # print(item.head(4))

# python -m mcp_tools.search_tool.from_hive_to_es
