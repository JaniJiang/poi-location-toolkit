import json
from utils.search_utils.es_client import ElasticSearchClient
from search.qa_bot.qwen3_reranker.meta import *


class SearchData:

    def __init__(self):
        self.es_client = ElasticSearchClient(CLUSTER_NAME)

    def search(self, text: str, log_size: int = 100, qa_size: int = 10):
        # 查询新闻数据
        log_query_dsl_dict = self.title_recall_strategy(text, log_size)
        log_item_list = self.es_client.search(log_query_dsl_dict, "news_data_0928", need_parse=True)
        return log_item_list

    def title_recall_strategy(self, text, size):
        """日志query召回策略"""
        query_dsl_dict = {
            "query": {
                "bool": {
                    "should": [
                        {"match": {"title": {"query": text, "boost": 1.0}}},
                    ],
                    "minimum_should_match": 1
                }
            },
            "size": size
        }
        return query_dsl_dict


if __name__ == "__main__":
    obj = SearchData()
    result_dict = obj.search("柬泰边境发生交火事件", log_size=10, qa_size=200)
    print(json.dumps(result_dict, ensure_ascii=False, indent=4))

# python -m mcp_tools.search_tool.search_es
