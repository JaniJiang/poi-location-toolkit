# McpClient的业务工具
MCP_CLIENT_TOOL_NEWS_SEARCH = "news_search"
MCP_CLIENT_TOOL_VIDEO_SEARCH = "video_search"
MCP_CLIENT_TOOL_MUSIC_SEARCH = "music_search"
MCP_CLIENT_TOOL_GENERAL_SEARCH = "general_search"

# 评估数据版本
DATA_DIR = "data/cloud_share/mcp_tools/search_tool/eval"
EVAL_CATEGORY = MCP_CLIENT_TOOL_GENERAL_SEARCH
EVAL_VERSION = f"v4_20251119"  # v1_20251031 | v2_20251112 | v3_20251113 | v4_20251119

# 评估模式
EVAL_MODE_MCP_TOOL = "mcp_tool"
EVAL_MODE_MCP_CLIENT = "mcp_client"
EVAL_MODE = EVAL_MODE_MCP_CLIENT  # EVAL_MODE_MCP_TOOL | EVAL_MODE_MCP_CLIENT

# 工具服务的URL
MCP_TOOL_SEARCH_URL = "https://es-search-test.inner.chj.cloud/es_search"
MCP_CLIENT_SEARCH_URL = "https://mind-mcp-client-testtwo.inner.chj.cloud/callBizTool"

# 检索工具的原子工具
SEARCH_TOOL_CATEGORY_NEWS = "热点新闻"
SEARCH_TOOL_CATEGORY_VIDEOS = "热门视频"


# 规划服务的URL
DEEP_PLAN_URL = "http://deep-plan-service-testtwo.inner.chj.cloud/v1/chat/completions"
