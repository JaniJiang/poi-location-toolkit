-- 新闻搜索
SELECT
  record_id,
  get_json_object(content, '$.QUERY') AS api_query,
  content,
  media_search_result
FROM
  ssai_ods.dwd_ssai_merge_voice_prod
WHERE
  dt BETWEEN '2025-10-31' AND '2025-10-31'
  and get_json_object(content, '$.APINAME') = 'MEDIASearch'
  and get_json_object(content, '$.MEDIATYPE') = '新闻'
  and record_id not like 'trid-com.%'
ORDER BY rand()
LIMIT 100;

-- 视频搜索
SELECT
  record_id,
  get_json_object(content, '$.QUERY') AS api_query,
  content,
  media_search_result
FROM
  ssai_ods.dwd_ssai_merge_voice_prod
WHERE
  dt BETWEEN '2025-10-31' AND '2025-10-31'
  and get_json_object(content, '$.APINAME') = 'MEDIASearch'
  and get_json_object(content, '$.MEDIATYPE') = '视频'
  and record_id not like 'trid-com.%'
ORDER BY rand()
LIMIT 100;

-- 音乐搜索
SELECT
  record_id,
  get_json_object(content, '$.QUERY') AS api_query,
  content,
  media_search_result
FROM
  ssai_ods.dwd_ssai_merge_voice_prod
WHERE
  dt BETWEEN '2025-10-31' AND '2025-10-31'
  and get_json_object(content, '$.APINAME') = 'MEDIASearch'
  and get_json_object(content, '$.MEDIATYPE') = '音乐'
  and record_id not like 'trid-com.%'
ORDER BY rand()
LIMIT 100;
