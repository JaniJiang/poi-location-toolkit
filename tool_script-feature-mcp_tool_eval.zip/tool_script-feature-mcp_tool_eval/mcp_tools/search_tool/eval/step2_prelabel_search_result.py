import json
import pandas as pd
from tqdm import tqdm
from datetime import datetime
from mcp_tools.search_tool.eval.meta import *


class PreLabelSearchResult:

    def __init__(self):
        self.input_path = f"{DATA_DIR}/{EVAL_VERSION}_{EVAL_MODE}/{EVAL_CATEGORY}/step1_get_search_result.tsv"
        self.output_path = f"{DATA_DIR}/{EVAL_VERSION}_{EVAL_MODE}/{EVAL_CATEGORY}/step2_prelabel_search_result.tsv"

    def process(self):
        input_df = pd.read_csv(self.input_path, sep="\t").fillna("")
        for idx, row in tqdm(input_df.iterrows(), total=len(input_df)):
            # 预标注
            prelabel_result_dict = self.prelabel_data(row)
            # 保存预标注结果
            input_df.loc[idx, "media_count"] = int(prelabel_result_dict.get("media_count", 0))
            input_df.loc[idx, "media_acc"] = prelabel_result_dict.get("media_acc", "")
            input_df.loc[idx, "tool_count"] = int(prelabel_result_dict.get("tool_count", 0))
            input_df.loc[idx, "tool_acc"] = prelabel_result_dict.get("tool_acc", "")

            if EVAL_CATEGORY == MCP_CLIENT_TOOL_NEWS_SEARCH:
                input_df.loc[idx, "media_acc_label"] = json.dumps(
                    prelabel_result_dict.get("media_acc_label", []), ensure_ascii=False)
                input_df.loc[idx, "tool_acc_label"] = json.dumps(
                    prelabel_result_dict.get("tool_acc_label", []), ensure_ascii=False)
        input_df.to_csv(self.output_path, sep="\t", header=True, index=False)

    def prelabel_data(self, row):
        # 通用的预标注
        prelabel_result_dict = self.prelabel_common_data(row)
        # 各个业务定制化的预标注
        if EVAL_CATEGORY == MCP_CLIENT_TOOL_NEWS_SEARCH:
            prelabel_result_dict.update(self.prelabel_news_data(row))
        elif EVAL_CATEGORY == MCP_CLIENT_TOOL_VIDEO_SEARCH:
            prelabel_result_dict.update(self.prelabel_videos_data(row))
        return prelabel_result_dict

    def prelabel_common_data(self, row):
        # 媒体搜索结果条数
        try:
            media_search_result_str = row["media_search_result"]
            media_search_result_list = json.loads(media_search_result_str)
            media_count = len(media_search_result_list[0]["data"])
        except:
            media_count = 0
        # 自建工具结果条数
        try:
            tool_response_str = row["tool_response"]
            tool_response_dict = json.loads(tool_response_str)
            tool_count = len(tool_response_dict["data"])
        except:
            tool_count = 0
        return {"media_count": media_count, "tool_count": tool_count}

    def prelabel_news_data(self, row):
        prelabel_result_dict = {}
        try:
            tool_response = json.loads(row["tool_response"])
            start_time = tool_response["feature"]["preprocess"]["start_time"]
            end_time = tool_response["feature"]["preprocess"]["end_time"]
        except:
            print("start_time end_time 解析失败")
            return {"media_acc": "0/0", "tool_acc": "0/0", "media_is_compliant": [], "tool_is_compliant": []}
        # 统计媒体搜索结果
        media_acc_label = []
        try:
            media_result = json.loads(row["media_search_result"])[0]["data"]
            for item in media_result:
                doc_time = item.get("extend_data", {}).get("doc_timestamp", "")
                if start_time <= doc_time <= end_time:
                    media_acc_label.append(1)
                else:
                    media_acc_label.append(0)
            media_total = len(media_result)
            media_valid = sum(media_acc_label)
        except:
            media_total, media_valid = 0, 0
            media_acc_label = []
        # 统计自建工具结果
        tool_acc_label = []
        try:
            tool_data = tool_response.get("data", [])
            start_date, end_date = start_time[:10], end_time[:10]
            for item in tool_data:
                event_time = item.get("features", {}).get("event_time", "")
                if start_date <= event_time <= end_date:
                    tool_acc_label.append(1)
                else:
                    tool_acc_label.append(0)
            tool_total = len(tool_data)
            tool_valid = sum(tool_acc_label)
        except:
            tool_total, tool_valid = 0, 0
            tool_acc_label = []

        prelabel_result_dict["media_acc"] = f"{media_valid}/{media_total}"
        prelabel_result_dict["tool_acc"] = f"{tool_valid}/{tool_total}"
        prelabel_result_dict["media_acc_label"] = media_acc_label
        prelabel_result_dict["tool_acc_label"] = tool_acc_label
        return prelabel_result_dict

    def prelabel_videos_data(self, row):
        prelabel_result_dict = {}
        query = row["api_query"]
        time_list = ["最近", "现在"]
        if any(time in query for time in time_list):
            return prelabel_result_dict
        else:
            raw_data_1 = row["media_search_result"]
            raw_data_2 = row["tool_response"]
            json_data_1 = json.loads(raw_data_1)
            json_data_2 = json.loads(raw_data_2)
            media_acc = 0
            tool_acc = 0
            standard_time = json.loads(json.loads(row["content"])["TIMESLOTS"])["startTime"]
            for obj in json_data_1:
                for data in obj["data"]:
                    try:
                        if "doc_timestamp" in data["extend_data"]:
                            doc_timestamp = data["extend_data"]["doc_timestamp"]
                            if self.calculate_date_difference(standard_time, doc_timestamp) <= 90:
                                media_acc += 1
                    except Exception as e:
                        print(e)
            for data in json_data_2["data"]:
                if "publish_time" in data:
                    publish_time = data["publish_time"]
                    if self.calculate_date_difference(standard_time, publish_time, data_2_format="%Y-%m-%d") <= 90:
                        tool_acc += 1
            return {"media_acc": media_acc, "tool_acc": tool_acc}

    def calculate_date_difference(self, date_str1, date_str2, data_1_format="%Y-%m-%d", data_2_format="%Y-%m-%d %H:%M:%S"):
        date1 = datetime.strptime(date_str1, data_1_format)
        date2 = datetime.strptime(date_str2, data_2_format)
        # 计算并返回日期差（只返回天数差）
        return (date1 - date2).days


if __name__ == "__main__":
    obj = PreLabelSearchResult()
    obj.process()

# python -m mcp_tools.search_tool.eval.step2_prelabel_search_result
