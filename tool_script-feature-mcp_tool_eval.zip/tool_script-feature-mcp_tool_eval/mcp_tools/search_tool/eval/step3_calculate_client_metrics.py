import pandas as pd
from mcp_tools.search_tool.eval.meta import *
from collections import defaultdict


class CalculateClientMetrics:

    def __init__(self):
        self.input_path = f"{DATA_DIR}/{EVAL_VERSION}_{EVAL_MODE}/{EVAL_CATEGORY}/step2_prelabel_search_result.labeled.tsv"
        print(f"[{EVAL_CATEGORY}]")

    def process(self):
        df = pd.read_csv(self.input_path, sep="\t").fillna("")
        df = df[['query_id', 'rank', 'tool_response', '是否正确']]

        # 提取异常query数
        exception_df = df[df['tool_response'] == "EXCEPTION"]
        exception_count = len(exception_df)
        df = df[df['tool_response'] != "EXCEPTION"]
        df = df[df['是否正确'].notna() & (df['是否正确'] != "")]

        # 获取tool_type
        df['tool_type'] = df['tool_response'].apply(self.determine_tool_type)

        # 计算指标
        metrics = self.calculate_metrics(df, exception_count)

        for tool_type, metric in metrics.items():
            print(f"ACC@N-{tool_type}: {metric['average_acc']:.6f}")
            print(f"P@N-{tool_type}: {metric['average_patn']:.6f}")
            print(f"平均结果条数-{tool_type}: {metric['average_count']:.6f}")

    @staticmethod
    def determine_tool_type(tool_response):
        if '"source": "CUSTOM"' in tool_response:
            return "CUSTOM"
        return "EXTERNAL"

    def calculate_metrics(self, df, exception_count):
        results_by_type = defaultdict(list)

        # 计算自建/外部工具指标
        grouped = df.groupby(['query_id', 'tool_type'])
        for (_, tool_type), group in grouped:
            correct_count = group['是否正确'].sum()
            total_count = len(group)
            accuracy = correct_count / total_count if total_count > 0 else 0
            patn = 1 if accuracy > 0 else 0
            results_by_type[tool_type].append({"accuracy": accuracy, "count": total_count, "p@n": patn})

        # 计算融合工具指标
        grouped = df.groupby(['query_id'])
        for _, group in grouped:
            correct_count = group['是否正确'].sum()
            total_count = len(group)
            accuracy = correct_count / total_count if total_count > 0 else 0
            patn = 1 if accuracy > 0 else 0
            results_by_type["COMBINED"].append({"accuracy": accuracy, "count": total_count, "p@n": patn})

        # 整理指标
        final_metrics = {}
        for tool_type, results in results_by_type.items():
            average_acc = sum(r['accuracy'] for r in results) / len(results) if results else 0
            average_count = sum(r['count'] for r in results) / \
                (len(df.groupby(['query_id']))+exception_count) if results else 0   # 平均结果条数的分母均为query数
            average_patn = sum(r['p@n'] for r in results) / len(results) if results else 0
            final_metrics[tool_type] = {
                "average_acc": average_acc,
                "average_count": average_count,
                "average_patn": average_patn
            }

        return final_metrics


if __name__ == "__main__":
    obj = CalculateClientMetrics()
    obj.process()

# python -m mcp_tools.search_tool.eval.step3_calculate_client_metrics
