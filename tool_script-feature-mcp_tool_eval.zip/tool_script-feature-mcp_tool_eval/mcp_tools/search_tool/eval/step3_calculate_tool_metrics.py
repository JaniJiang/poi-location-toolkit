import pandas as pd
from mcp_tools.search_tool.eval.meta import *


class CalculateToolMetrics:

    def __init__(self):
        self.input_path = f"{DATA_DIR}/{EVAL_VERSION}_{EVAL_MODE}/{EVAL_CATEGORY}/step2_prelabel_search_result.labeled.tsv"
        print(f"[{EVAL_CATEGORY}]")

    def process(self):
        df = pd.read_csv(self.input_path, sep="\t").fillna("")

        # 计算平均结果条数-media
        media_len = df["media_count"].sum() / len(df)
        print(f"平均结果条数-媒体搜索: {media_len:.1f}")

        if EVAL_CATEGORY not in [MCP_CLIENT_TOOL_MUSIC_SEARCH]:
            # 计算平均结果条数-tool
            tool_len = df["tool_count"].sum() / len(df)
            print(f"平均结果条数-自建工具: {tool_len:.1f}")
            # 计算平均结果条数-merge
            combined_len = (df["media_count"] + df["tool_count"]).sum() / len(df)
            print(f"平均结果条数-融合工具: {combined_len:.1f}")

        # 计算准确率-media
        media_acc_list = df["media_acc"].tolist()
        media_acc_rate = self.process_acc_rate(media_acc_list)
        print(f"ACC@N-媒体搜索: {media_acc_rate}")

        if EVAL_CATEGORY not in [MCP_CLIENT_TOOL_MUSIC_SEARCH]:
            # 计算准确率-tool
            tool_acc_list = df["tool_acc"].tolist()
            tool_acc_rate = self.process_acc_rate(tool_acc_list)
            print(f"ACC@N-自建工具: {tool_acc_rate}")
            # 计算准确率-merge
            merge_acc_list = []
            for idx, media_acc in enumerate(media_acc_list):
                tool_acc = tool_acc_list[idx]
                merge_acc = self.merge_two_acc(media_acc, tool_acc)
                merge_acc_list.append(merge_acc)
            merge_acc_rate = self.process_acc_rate(merge_acc_list)
            print(f"ACC@N-融合工具: {merge_acc_rate}")

    def process_acc_rate(self, acc_list):
        """计算ACC@N"""
        acc_sum = 0.0
        acc_count = 0
        for acc in acc_list:
            if acc in ["", "0/0"]:
                continue
            acc_sum += eval(acc)
            acc_count += 1
        acc_rate = round(acc_sum/acc_count, 4) * 100
        return acc_rate

    def merge_two_acc(self, acc_1, acc_2):
        """工具ACC融合"""
        if acc_1 == "":
            return acc_2
        if acc_2 == "":
            return acc_1
        k1, v1 = acc_1.split("/")
        k2, v2 = acc_2.split("/")
        return f"{int(k1)+int(k2)}/{int(v1)+int(v2)}"


if __name__ == "__main__":
    obj = CalculateToolMetrics()
    obj.process()

# python -m mcp_tools.search_tool.eval.step3_calculate_tool_metrics
