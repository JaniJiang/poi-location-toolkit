import json
import pandas as pd
from tqdm import tqdm
from loguru import logger
from mcp_tools.search_tool.eval.meta import *


class AnalyseDupSearchResult:

    def process(self):
        for eval_category in [
            # MCP_CLIENT_TOOL_NEWS_SEARCH,
            MCP_CLIENT_TOOL_VIDEO_SEARCH,
            # MCP_CLIENT_TOOL_MUSIC_SEARCH,
            # MCP_CLIENT_TOOL_GENERAL_SEARCH
        ]:
            input_path = f"{DATA_DIR}/{EVAL_VERSION}_{EVAL_MODE}/{eval_category}/step1_get_search_result.tsv"
            input_df = pd.read_csv(input_path, sep="\t").fillna("")
            total_count = 0
            dup_count = 0
            for _, row in tqdm(input_df.iterrows(), total=len(input_df)):
                try:
                    tool_response_dict = json.loads(row["tool_response"])
                except Exception as e:
                    logger.warning(f"[AnalyseDupSearchResult] json.loads failed: {e}", )
                    continue
                item_list = tool_response_dict["data"]
                item_id_dict = {}
                for item in item_list:
                    total_count += 1
                    item_id = str(item["id"])
                    if item_id in item_id_dict:
                        dup_count += 1
                    item_id_dict[item_id] = True
            print(eval_category, total_count, dup_count)


if __name__ == "__main__":
    obj = AnalyseDupSearchResult()
    obj.process()

# python -m mcp_tools.search_tool.eval.analyse.analyse_dup_search_result
