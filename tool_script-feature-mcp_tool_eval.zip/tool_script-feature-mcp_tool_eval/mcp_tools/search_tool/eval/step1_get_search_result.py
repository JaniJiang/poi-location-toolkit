import os
import json
import pandas as pd
from tqdm import tqdm
from loguru import logger
from utils.http_client import HTTPClient
from mcp_tools.search_tool.eval.meta import *


class GetSearchResult:

    def __init__(self):
        if EVAL_MODE == EVAL_MODE_MCP_TOOL:
            self.input_path = f"{DATA_DIR}/{EVAL_VERSION}_{EVAL_MODE}/{EVAL_CATEGORY}/input.tsv"
        else:
            self.input_path = f"{DATA_DIR}/{EVAL_VERSION}_{EVAL_MODE}/eval_output.tsv"
        self.output_path = f"{DATA_DIR}/{EVAL_VERSION}_{EVAL_MODE}/{EVAL_CATEGORY}/step1_get_search_result"
        os.makedirs(os.path.dirname(self.output_path), exist_ok=True)

    def process(self):
        input_df = pd.read_csv(self.input_path, sep="\t").fillna("")
        indices_to_drop = []
        for idx, row in tqdm(input_df.iterrows(), total=len(input_df)):
            if hasattr(row, "工具"):
                if row["工具"] != EVAL_CATEGORY:
                    indices_to_drop.append(idx)
                    continue
            # 构造请求参数
            if EVAL_MODE == EVAL_MODE_MCP_TOOL:
                content_dict = {}
                try:
                    content_dict = json.loads(row["content"])
                except Exception as e:
                    logger.warning(f"[GetSearchResult] content_dict parse failed: {e}")
                request_params = self.build_mcp_tool_request_params(content_dict)
                url = MCP_TOOL_SEARCH_URL
            else:
                arguments_dict = {}
                try:
                    tool_calls_list = json.loads(row["tool_calls"])
                    if len(tool_calls_list) == 0:
                        indices_to_drop.append(idx)
                        continue
                    tool_call_dict = tool_calls_list[0]  # TODO: 先只取一个
                    if len(tool_call_dict) == 0:
                        indices_to_drop.append(idx)
                        continue
                    if tool_call_dict["name"] != EVAL_CATEGORY:
                        indices_to_drop.append(idx)
                        continue
                    arguments_dict = tool_call_dict["arguments"]
                except Exception as e:
                    logger.warning(f"[GetSearchResult] tool_calls parse failed: {e}")
                request_params = self.build_mcp_client_request_params(arguments_dict)
                url = MCP_CLIENT_SEARCH_URL
            # 发起请求
            if len(request_params) == 0:
                indices_to_drop.append(idx)
                continue
            http_client_obj = HTTPClient(url)
            try:
                response_dict = http_client_obj.request(request_params)
            except Exception as e:
                response_dict = {}
                logger.warning(f"[GetSearchResult] HTTPClient process failed: {e}")
            # 保存结果
            input_df.loc[idx, "tool_request"] = json.dumps(request_params, ensure_ascii=False, indent=4)
            input_df.loc[idx, "tool_response"] = json.dumps(response_dict, ensure_ascii=False)
        # 保存搜索结果
        input_df = input_df.drop(indices_to_drop)
        input_df.to_csv(f"{self.output_path}.tsv", sep="\t", header=True, index=False)
        # 保存展开后的搜索结果
        if EVAL_MODE == EVAL_MODE_MCP_CLIENT:
            split_search_result_list = []
            exception_search_result_list = []
            for idx, row in input_df.iterrows():
                try:
                    tool_response = json.loads(row["tool_response"])
                except:
                    exception_search_result_list.append(self.build_exception_result(row, idx))
                    continue
                if tool_response is None or len(tool_response) == 0:
                    exception_search_result_list.append(self.build_exception_result(row, idx))
                    continue
                try:
                    if EVAL_CATEGORY in [MCP_CLIENT_TOOL_GENERAL_SEARCH]:
                        item_list = tool_response["data"][0]["bot_data"]
                    else:
                        item_list = tool_response["data"]
                except:
                    exception_search_result_list.append(self.build_exception_result(row, idx))
                    continue
                for item_idx, item in enumerate(item_list):
                    for field_name in ["tool_data", "media_resources"]:  # 减少冗余字段，方便查看和标注
                        if field_name in item:
                            del item[field_name]
                    split_search_result_list.append({
                        "query_id": idx + 1,
                        "query": row["query"],
                        # "old_function_name": row["old_function_name"],
                        # "old_arguments": row["old_arguments"],
                        # "old_tag": row["old_tag"],
                        "tool_calls": row["tool_calls"],
                        "tool_request": row["tool_request"],
                        "feature": json.dumps(tool_response.get("feature", {}), ensure_ascii=False, indent=4),
                        "rank": item_idx + 1,
                        "source": item.get("source", ""),
                        "tool_response": json.dumps(item, ensure_ascii=False, indent=4),
                    })
            split_search_result_list.extend(exception_search_result_list)
            split_search_result_df = pd.DataFrame(split_search_result_list)
            split_search_result_df.to_csv(f"{self.output_path}.split.tsv", sep="\t", header=True, index=False)

    def build_mcp_tool_request_params(self, content_dict):
        request_params = {}
        # 解析槽位
        query = content_dict.get("QUERY", "")
        category = content_dict.get("CATEGORY", "")
        channel = content_dict.get("CHANNEL", "")
        tag = content_dict.get("TAG", "")
        time = ""
        area = content_dict.get("AREA", "")
        actors = content_dict.get("ACTORS", "")
        director = content_dict.get("DIRECTOR", "")
        try:
            timeslots = json.loads(content_dict.get("timeslots", ""))
        except:
            timeslots = {}
        # 构造自建新闻搜索参数
        if EVAL_CATEGORY == MCP_CLIENT_TOOL_NEWS_SEARCH:
            time = content_dict.get("PUBLISHTIME", "")
            request_params = {
                "query": query,
                "category": SEARCH_TOOL_CATEGORY_NEWS,
                "extend_info": {
                    "category": category, "tag": tag, "time": time, "area": area,
                    "timeslots": timeslots,
                }
            }
        # 构造自建视频搜索参数
        elif EVAL_CATEGORY == MCP_CLIENT_TOOL_VIDEO_SEARCH:
            try:
                time = json.loads(content_dict.get("DURATION", "")).get("raw", "")
            except:
                pass
            request_params = {
                "query": query,
                "category": SEARCH_TOOL_CATEGORY_VIDEOS,
                "extend_info": {
                    "channel": channel, "category": category, "tag": tag, "time": time, "area": area, "actors": actors, "director": director,
                    "timeslots": timeslots,
                }
            }
        return request_params

    def build_mcp_client_request_params(self, arguments_dict):
        arguments_dict["metadata"] = "{}"
        request_params = {
            "name": EVAL_CATEGORY,
            "arguments": arguments_dict,
        }
        return request_params

    def build_exception_result(self, row, idx):
        exception_result = {
            "query_id": idx + 1,
            "query": row["query"],
            "tool_calls": row["tool_calls"],
            "tool_request": row["tool_request"],
            "feature": "{}",
            "rank": "EXCEPTION",
            "source": "EXCEPTION",
            "tool_response": "EXCEPTION",
        }
        return exception_result


if __name__ == "__main__":
    obj = GetSearchResult()
    obj.process()

# python -m mcp_tools.search_tool.eval.step1_get_search_result
# nohup python -m mcp_tools.search_tool.eval.step1_get_search_result > log/mcp_tools/search_tool/eval/step1_get_search_result.log 2>&1 &
