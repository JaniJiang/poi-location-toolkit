import os
import json
import pandas as pd
from collections import Counter
import matplotlib.pyplot as plt


class AnalyseMediaFeatures:

    def __init__(self):
        type = "news"
        self.input_path = f"data/cloud_share/mcp_tools/search_tool/rank/analyse/media_search_result_{type}.tsv"
        base_dir = os.path.dirname(self.input_path)
        self.score_fig_path = os.path.join(base_dir, f"media_search_result_{type}_score_hist.png")
        self.sigmoid_fig_path = os.path.join(base_dir, f"media_search_result_{type}_q_d_score_sigmoid_hist.png")

    def process(self):
        df = pd.read_csv(self.input_path, sep="\t")

        sources, froms, recalls, sigmoids, scores, authorities = [], [], [], [], [], []
        score_missing = 0

        for x in df["media_search_result"]:
            try:
                data = json.loads(x)[0]["data"]
                for item in data:
                    sources.append(item.get("source"))
                    authorities.append(item.get("authority"))

                    score = item.get("score")
                    if isinstance(score, (int, float)):
                        scores.append(score)
                    else:
                        score_missing += 1

                    extend = item.get("extend_data", {})
                    froms.append(extend.get("from"))
                    recalls.append(extend.get("recall_strategy"))

                    sigmoid_val = extend.get("q_d_score_sigmoid")
                    try:
                        sigmoids.append(float(sigmoid_val))
                    except:
                        pass
            except:
                continue

        def print_counter(title, items):
            print(f"\n=== {title} 统计 ===")
            for k, v in Counter([i for i in items if i not in [None, ""]]).most_common():
                print(k, v)

        print_counter("source", sources)
        print_counter("from", froms)
        print_counter("recall_strategy", recalls)
        print_counter("authority", authorities)

        # ==== score 统计 ====
        print("\n=== score 统计 ===")
        print(f"缺失数量: {score_missing}")
        print(f"平均值: {sum(scores)/len(scores):.4f}")
        print(f"最大值: {max(scores):.4f}")
        print(f"最小值: {min(scores):.4f}")

        plt.figure()
        plt.hist(scores, bins=30)
        plt.title("Score Distribution")
        plt.xlabel("score")
        plt.ylabel("num")
        plt.tight_layout()
        plt.savefig(self.score_fig_path)

        # ==== q_d_score_sigmoid 统计 ====
        print("\n=== q_d_score_sigmoid 统计 ===")
        print(f"平均值: {sum(sigmoids)/len(sigmoids):.6f}")
        print(f"最大值: {max(sigmoids):.6f}")
        print(f"最小值: {min(sigmoids):.6f}")

        plt.figure()
        plt.hist(sigmoids, bins=30)
        plt.title("q_d_score_sigmoid Distribution")
        plt.xlabel("q_d_score_sigmoid")
        plt.ylabel("num")
        plt.tight_layout()
        plt.savefig(self.sigmoid_fig_path)


if __name__ == "__main__":
    obj = AnalyseMediaFeatures()
    obj.process()

# python -m mcp_tools.search_tool.rank.analyse.analyse_media_features
