import pandas as pd
import json
import math
from datetime import datetime
from dateutil import parser
from difflib import SequenceMatcher
import config


class GenerateFeatures:

    def __init__(self):
        self.input_path = "data/cloud_share/mcp_tools/search_tool/rank/generate_features/news_search_result.labeled.tsv"
        self.now = datetime.now()

    def str_similarity(self, a, b):
        if not a or not b:
            return 0.0
        return SequenceMatcher(None, a, b).ratio()

    def parse_time(self, time_str):
        if not time_str or pd.isna(time_str):
            return None
        try:
            return parser.parse(time_str)
        except Exception:
            return None

    def time_gap_seconds(self, time_str, k=0.01):
        news_time = self.parse_time(time_str)
        if not news_time:
            return None
        time_gap = (self.now - news_time).total_seconds() / 3600
        return math.exp(-k * time_gap)

    def process_media_search_result(self, record_id, api_query, media_search_result, media_acc_label):
        try:
            labels = json.loads(media_acc_label if isinstance(media_acc_label, str) else "[]")
        except Exception:
            labels = []
        items = []
        try:
            msr_data = json.loads(media_search_result)
            if isinstance(msr_data, list) and len(msr_data) > 0 and "data" in msr_data[0]:
                msr_data = msr_data[0]["data"]
        except Exception:
            return items

        for idx, news in enumerate(msr_data):
            base_id = f"{record_id}_msr_{idx}"

            title = news.get("title", "")
            content = ""
            tag_from_content = ""

            if news.get("media_resources"):
                try:
                    raw_content = news["media_resources"][0].get("content", "")
                    if isinstance(raw_content, str) and raw_content.strip().startswith("{"):
                        content_json = json.loads(raw_content)
                        content = content_json.get("新闻内容", "")
                        tag_from_content = content_json.get("新闻类型", "")
                    else:
                        content = raw_content
                except Exception:
                    content = ""
            if not content:
                content = news.get("content", "")

            extend = news.get("extend_data", {}) or {}

            tool_type = 0
            source = news.get("source", "")
            from_type = config.from_type_map.get(extend.get("from", ""), None)
            authority = config.authority_map.get(news.get("authority", ""), None)

            # score
            score = news.get("score", None)
            q_d_score_sigmoid = extend.get("q_d_score_sigmoid", None)

            # recall
            recall_strategy = extend.get("recall_strategy") or extend.get("content-from") or extend.get("recall-source")
            recall_strategy = config.recall_strategy_map.get(recall_strategy, None)

            # time
            time_gap = self.time_gap_seconds(extend.get("doc_timestamp", ""))

            # tag
            if tag_from_content:
                tag_candidate = tag_from_content
            elif "|" in title:
                tag_candidate = title.split("|")[0]
            else:
                tag_candidate = ""
            tag_match = self.str_similarity(api_query, tag_candidate) if tag_candidate else None

            # length
            title_length = len(title)
            content_length = len(content)

            label = labels[idx] if idx < len(labels) else None

            items.append({
                "record_id": base_id,
                "api_query": api_query,
                "title": title,
                "content": content,
                "tool_type": tool_type,
                "authority": authority,
                "source": source,
                "from": from_type,
                "score": score,
                "q_d_score_sigmoid": q_d_score_sigmoid,
                "recall_strategy": recall_strategy,
                "time_gap": time_gap,
                "tag_match": tag_match,
                "topic_match": "",
                "title_length": title_length,
                "content_length": content_length,
                "event_time_match": "",
                "label": label
            })

        return items

    def process_tool_response(self, record_id, api_query, tool_response, tool_acc_label):
        try:
            labels = json.loads(tool_acc_label if isinstance(tool_acc_label, str) else "[]")
        except Exception:
            labels = []
        items = []
        try:
            tr_data = json.loads(tool_response)
            if "data" in tr_data:
                tr_data = tr_data["data"]
        except Exception:
            return items

        for idx, news in enumerate(tr_data):
            base_id = f"{record_id}_tr_{idx}"

            title = news.get("title", "")
            content = news.get("content", "")
            publish_time = news.get("publish_time", "")
            features = news.get("features", {}) or {}

            tool_type = 1
            authority = 1
            source = None
            from_type = None

            # score
            score = None
            q_d_score_sigmoid = None
            recall_strategy = len(config.recall_strategy_map)

            # tag
            tag_list = features.get("tag", [])
            tags = " ".join(tag for tag in tag_list)
            tag_match = self.str_similarity(api_query, tags)

            # topic
            topics = features.get("topic", [])
            topic_str = " ".join(topics) if isinstance(topics, list) else str(topics)
            topic_match = self.str_similarity(api_query, topic_str)

            # time
            time_gap = self.time_gap_seconds(publish_time)
            event_time = features.get("event_time", "")
            event_dt = self.parse_time(event_time)
            pub_dt = self.parse_time(publish_time)
            event_time_match = 1 if event_dt and pub_dt and event_dt.date() == pub_dt.date() else 0

            # length
            title_length = len(title)
            content_length = len(content)

            label = labels[idx] if idx < len(labels) else None

            items.append({
                "record_id": base_id,
                "api_query": api_query,
                "title": title,
                "content": content,
                "tool_type": tool_type,
                "authority": authority,
                "source": source,
                "from": from_type,
                "score": score,
                "q_d_score_sigmoid": q_d_score_sigmoid,
                "recall_strategy": recall_strategy,
                "time_gap": time_gap,
                "tag_match": tag_match,
                "topic_match": topic_match,
                "title_length": title_length,
                "content_length": content_length,
                "event_time_match": event_time_match,
                "label": label
            })

        return items

    def process(self):
        df = pd.read_csv(self.input_path, sep="\t")
        all_items = []

        for _, row in df.iterrows():
            record_id = row.get("record_id", "")
            api_query = row.get("api_query", "")

            media_result = row.get("media_search_result", "")
            media_acc_label = row.get("media_acc_label", "[]")
            tool_result = row.get("tool_response", "")
            tool_acc_label = row.get("tool_acc_label", "[]")

            all_items.extend(self.process_media_search_result(record_id, api_query, media_result, media_acc_label))
            all_items.extend(self.process_tool_response(record_id, api_query, tool_result, tool_acc_label))

        out_df = pd.DataFrame(all_items)

        # 去重
        cols = [
            "api_query", "title", "content", "tool_type", "authority", "source", "from",
            "score", "q_d_score_sigmoid", "recall_strategy", "time_gap",
            "tag_match", "topic_match", "title_length", "content_length",
            "event_time_match", "label"
        ]
        before = len(out_df)
        out_df.drop_duplicates(subset=cols, keep="first", inplace=True)
        print(f"删除重复数据 {before - len(out_df)} 条，保留 {len(out_df)} 条。")

        out_path = self.input_path.replace(".tsv", ".features.tsv")
        out_df.to_csv(out_path, sep="\t", index=False)
        print(f"特征文件已生成: {out_path}")


if __name__ == "__main__":
    obj = GenerateFeatures()
    obj.process()
    # python -m mcp_tools.search_tool.rank.model.generate_features
