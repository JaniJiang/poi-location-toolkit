from_type_map = {
    "freshness-hot-news": 0,
    "freshness-news": 1,
}

authority_map = {
    "非权威": 0,
    "权威": 1,
}

recall_strategy_map = {
    "das": 0,
    "full": 1,
    "chunk": 2,
    "sogou": 3,
    "cache": 4,
    "vec_freshness": 5
}
