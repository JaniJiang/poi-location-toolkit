import pandas as pd
import requests
import time

# === 1. 文件路径 ===
in_path = "/mnt/volumes/ss-sai-bd-ga/public_qiaojiaqi/save_files/datasets/tsvset/stock_request.tsv"
out_path = "/mnt/volumes/ss-sai-bd-ga/public_qiaojiaqi/save_files/datasets/tsvset/stock_response.tsv"

# === 2. 读取 TSV ===
df = pd.read_csv(in_path, sep="\t")

# === 3. 定义请求参数 ===
url = "http://tool-platform-server-feishu.ssai-apis-staging.chj.cloud:80/tools/v1/dynamic_function/stock"
headers = {
    "Content-Type": "application/json",
    "x-msg-id": "msg_id_ssai_xuzhou",
    "x-record-id": "record_id_ssai_xuzhou",
    "x-track-id": "track_id_ssai_xuzhou",
    "x-account-id": "account_id_ssai_xuzhou",
    "x-vin": "vin_ssai_xuzhou"
}

# === 4. 新增列容器 ===
contents = []
latencies = []

# === 5. 遍历每一行 ===
for i, row in df.iterrows():
    query = row["query"]
    payload = {"query": query}
    
    print(f"🔹 [{i+1}/{len(df)}] 正在请求：{query}")

    start_time = time.time()
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=10)
        elapsed = round(time.time() - start_time, 3)
        latencies.append(elapsed)

        if response.status_code == 200:
            try:
                data = response.json()
                contents.append(data.get("content", ""))
            except Exception as e:
                contents.append(f"JSON解析失败: {e}")
        else:
            contents.append(f"HTTP {response.status_code}")
    except Exception as e:
        elapsed = round(time.time() - start_time, 3)
        latencies.append(elapsed)
        contents.append(f"Error: {e}")

    # === 每次请求后休眠 1 秒 ===
    time.sleep(1)

# === 6. 保存结果 ===
df["latency(s)"] = latencies
df["response_content"] = contents
df.to_csv(out_path, sep="\t", index=False)

print(f"\n✅ 已完成 {len(df)} 条请求，结果已保存到：{out_path}")
