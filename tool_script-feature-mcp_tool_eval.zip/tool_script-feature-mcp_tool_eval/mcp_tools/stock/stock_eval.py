import pandas as pd
from tqdm import tqdm
from datetime import datetime
from utils.tool_utils.api_hub import ApiHub


class StockEval:

    def __init__(self):
        # 路径参数
        self.input_path_dict = {
            "us": "data/cloud_share/mcp_tools/stock/stock_eval/stock_code_us.tsv",
            "hk": "data/cloud_share/mcp_tools/stock/stock_eval/stock_code_hk.tsv",
            "sz": "data/cloud_share/mcp_tools/stock/stock_eval/stock_code_sz.tsv",
            "sh": "data/cloud_share/mcp_tools/stock/stock_eval/stock_code_sh.tsv",
        }
        self.output_dir = "data/cloud_share/mcp_tools/stock/stock_eval"
        # 工具参数
        self.tool_url_dict = {
            "us": "http://csd-api-ontest.inner.chj.cloud/bcs-apihub-tools-proxy-service/tool/v1/ali/ali-finance-us-shares-price",
            "hk": "http://csd-api-ontest.inner.chj.cloud/bcs-apihub-tools-proxy-service/tool/v1/ali/ali-finance-hk-stocks-price",
            "sz": "http://csd-api-ontest.inner.chj.cloud/bcs-apihub-tools-proxy-service/tool/v1/ali/ali-finance-a-shares-price",
            "sh": "http://csd-api-ontest.inner.chj.cloud/bcs-apihub-tools-proxy-service/tool/v1/ali/ali-finance-a-shares-price",
        }
        self.call_name = "tool-offline-algorithm"

    def process(self):
        for stock_type, input_path in self.input_path_dict.items():
            tool_url = self.tool_url_dict[stock_type]
            api_hub_obj = ApiHub(tool_url, self.call_name)
            input_df = pd.read_csv(input_path, sep="\t", dtype=str)
            result_list = []
            for _, row in tqdm(input_df.iterrows(), total=len(input_df), desc=f"process {stock_type}"):
                stock_name = row["名称"]
                stock_code = row["股票代码"]
                # 发起请求
                request_data = {"symbol": stock_code}
                response_json = api_hub_obj.call(request_data)
                # 解析结果
                try:
                    stock_data = response_json.get("data", {}).get(stock_code, {})
                    update_time = stock_data.get("update_time", "")
                    if stock_type not in ["us"]:
                        update_time_dt = datetime.fromtimestamp(int(update_time))
                        update_time_new = update_time_dt.strftime("%Y-%m-%d %H:%M:%S")
                    else:
                        update_time_new = update_time
                    run_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    result_item = {
                        "名称": stock_name,
                        "股票代码": stock_code,
                        "运行时间": run_time,
                        "品种名称": stock_data.get("name", ""),
                        "实时价格": stock_data.get("price", ""),
                        "今日最高价": stock_data.get("high", ""),
                        "今日最低价": stock_data.get("low", ""),
                        "今日开盘价": stock_data.get("open", ""),
                        "昨日收盘价": stock_data.get("preclose", ""),
                        "数据时间": update_time_new,
                        "涨跌额": stock_data.get("change", ""),
                        "涨跌率": stock_data.get("changeRate", ""),
                        "成交量": stock_data.get("volume", ""),
                    }
                except:
                    result_item = {
                        "名称": stock_name, "股票代码": stock_code, "运行时间": run_time,
                        "品种名称": "FAILED", "实时价格": "FAILED",
                        "今日最高价": "FAILED", "今日最低价": "FAILED", "今日开盘价": "FAILED", "昨日收盘价": "FAILED",
                        "数据时间": "FAILED", "涨跌额": "FAILED", "涨跌率": "FAILED", "成交量": "FAILED",
                    }
                result_list.append(result_item)
            # 保存结果
            result_df = pd.DataFrame(result_list)
            result_df.to_csv(f"{self.output_dir}/output_{stock_type}.tsv", sep="\t", index=False, header=True)


if __name__ == "__main__":
    obj = StockEval()
    obj.process()

# python -m mcp_tools.stock.stock_eval
