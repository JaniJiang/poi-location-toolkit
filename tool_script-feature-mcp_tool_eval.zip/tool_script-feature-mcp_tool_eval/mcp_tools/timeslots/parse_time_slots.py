import json
import requests
import pandas as pd
from tqdm import tqdm

# url = "https://mind-mcp-client-dev.inner.chj.cloud/parseTimeSlots"
url = "http://mind-mcp-client-dev.inner.chj.cloud/parseStdTimeSlots"
headers = {"Content-Type": "application/json"}
input_path = "data/cloud_share/mcp_tools/timeslots/timeslots_raw_data.tsv"
output_path = "data/cloud_share/mcp_tools/timeslots/timeslots_new_data.tsv"


def get_req_time(time):
    req_params = {"time": f"{time}"}
    resp = requests.post(url, headers=headers, json=req_params, timeout=10)
    if resp.status_code == 200:
        try:
            resp_json = resp.json()
            return resp_json
        except:
            pass
    return None


def parse_dict(origin_dict):
    if origin_dict is None:
        return None
    new_dict = {}
    for k, v in origin_dict.items():
        if type(v) is str:
            try:
                v_dict = json.loads(v)
                new_dict[k] = v_dict
            except:
                new_dict[k] = v
        else:
            new_dict[k] = v
    return new_dict


df = pd.read_csv(input_path, sep="\t").fillna("")

for idx, row in tqdm(df.iterrows(), desc="Processing rows", total=len(df)):
    content_new = parse_dict(json.loads(row["content"]))
    tool_request_new = parse_dict(json.loads(row["tool_request"]))
    df.at[idx, "content_new"] = json.dumps(content_new, ensure_ascii=False, indent=4)
    df.at[idx, "tool_request_new"] = json.dumps(tool_request_new, ensure_ascii=False, indent=4)
    # 请求parseTimeSlots工具
    time = tool_request_new.get("extend_info", {}).get("time", "")
    if time == "":
        continue
    df.at[idx, "time"] = time
    req_time = get_req_time(time)
    req_time_new = parse_dict(req_time)
    if req_time_new is not None:
        df.at[idx, "parseTimeSlots_result"] = json.dumps(req_time_new, ensure_ascii=False, indent=4)
    else:
        df.at[idx, "parseTimeSlots_result"] = None

df.to_csv(output_path, sep="\t", index=False)

# python mcp_tools/timeslots/parse_time_slots.py
