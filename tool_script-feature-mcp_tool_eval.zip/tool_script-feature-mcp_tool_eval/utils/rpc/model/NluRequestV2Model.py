class NluRequestV2:

    def __init__(self, topic):
        self.request_config_json = {
            "input": {
                "text": topic,
            },
            "semantictagger_only": True
        }

    def set_input(self, topic):
        self.request_config_json["input"]["text"] = topic

    def get_request_recommend_config(self):
        return self.request_config_json
