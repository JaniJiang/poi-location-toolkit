class SafeDetectRequest:

    def __init__(self, msg_id, record_id, detect_topic,
                 preNluResults, contentType=1, bizChannel=3, timeoutMs=2000):
        self.request_config_json = {
            "common_metadata": {
                "request_info": {
                    "msg_id": msg_id,
                    "record_id": record_id
                },
            },
            "query": detect_topic,
            "generated_result": "",
            "contentType": contentType,
            "safePolicies": [],
            "timeoutMs": timeoutMs,
            "domain": "",
            "bizChannel": bizChannel,
            "preNluResults": preNluResults,
            "needPassTranslated": False
        }

    def set_query(self, detect_topic):
        self.request_config_json["query"] = detect_topic

    def set_msg_id(self, msg_id):
        self.request_config_json["common_metadata"]["request_info"]["msg_id"] = msg_id

    def set_record_id(self, record_id):
        self.request_config_json["common_metadata"]["request_info"]["record_id"] = record_id

    def get_request_recommend_config(self):
        return self.request_config_json
