NONE_LIST = ["", " ", "None", None, {}, [],  "-"]
