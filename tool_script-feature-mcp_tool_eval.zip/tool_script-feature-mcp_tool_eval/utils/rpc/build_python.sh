#!/bin/bash
# bash utils/rpc/build_python.sh

# 逐个proto生成python文件
for file in utils/rpc/proto/*; do
    proto_name=$(basename "$file" | cut -d. -f1)
    echo "build ${proto_name}"
    # 清理旧python文件
    if [ -f utils/rpc/py/${proto_name}_pb2.py ]; then
        rm utils/rpc/py/${proto_name}_pb2.py
        rm utils/rpc/py/${proto_name}_pb2_grpc.py
    fi
    # 生成新python文件
    python -m grpc_tools.protoc --proto_path=utils/rpc/proto --python_out=utils/rpc/py --grpc_python_out=utils/rpc/py ${proto_name}.proto
done
