"""https://li.feishu.cn/wiki/BKCRwSXsQiUDqaknEEMcY5wWn3c"""
import requests
import json
from tqdm.notebook import tqdm
import time
import logging
import collections
import concurrent
from concurrent.futures import ThreadPoolExecutor
from pprint import pprint
import sched
import re
import threading
import os
import pickle
from datetime import datetime
import asyncio

DEFAULT_SYSTEM_PROMPT = "You are a helpful assistant."
MODEL_URLS = {
    'gpt-4o': "https://xuzhou1-tool-llm.ontest.fc.chj.cloud/gpt-4o",
    'claude-3_5-sonnet': "https://xuzhou1-tool-llm.ontest.fc.chj.cloud/claude-3_5-sonnet",
    'deepseek-v3': "https://xuzhou1-tool-llm.ontest.fc.chj.cloud/deepseek-v3",
    'deepseek-r1': "https://xuzhou1-tool-llm.ontest.fc.chj.cloud/deepseek-r1",
    'deepseek-r1-distill-qwen-32b': "https://xuzhou1-tool-llm.ontest.fc.chj.cloud/deepseek-r1-distill-qwen-32b",
    'qwen__qwen3-8b': "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/qwen--qwen3-8b-tool/v1/chat/completions"
}


class RateLimiter:
    def __init__(self, rate):
        self.rate = rate
        self.current = 0
        self.last_check = datetime.now()

    async def wait(self):
        while True:
            now = datetime.now()
            passed_seconds = (now - self.last_check).seconds
            if passed_seconds > 1:
                self.last_check = now
                self.current = 0
            if self.current < self.rate:
                self.current += 1
                return
            await asyncio.sleep(1)


def request_llm(history, model='gpt-4o', n=1, temperature=1, max_tokens=4096, show_payload=False):
    if not history:
        return {'error': '传入的history为空！'}
    if not history[0]:
        history[0] = DEFAULT_SYSTEM_PROMPT

    messages = [{"role": ["assistant", "user"][i % 2], "content": message} for i, message in enumerate(history)]
    messages[0]['role'] = 'system'

    url = MODEL_URLS.get(model)
    if url is None:
        print("当前仅支持以下模型：", ", ".join(MODEL_URLS.keys()))
        raise ValueError(f"此模型尚未支持：{model}")

    if model in ['deepseek-r1', 'deepseek-r1-distill-qwen-32b'] and n != 1:
        print(f"【警告】deepseek-r1模型的n只能设置为1，当前为{n}，已自动改为1")
        n = 1

    headers = {'Content-Type': 'application/json'}
    if model == 'qwen__qwen3-8b':
        payload = {
            "messages": messages,
            "chat_template_kwargs": {"enable_thinking": False},
            "max_tokens": 50,
            "n": n,
            "temperature": temperature,
            "max_tokens": max_tokens
        }
    else:
        payload = {
            "messages": messages,
            "n": n,
            "temperature": temperature,
            "max_tokens": max_tokens
        }
    if show_payload:
        pprint(payload)

    try:
        response = requests.request("POST", url, headers=headers, json=payload, timeout=120)
        response_data = response.json()
        if response.status_code != 200:
            print(f"请求失败，状态码为{response.status_code}，response为\n{response.text}")
    except Exception as e:
        logging.debug("【request_llm】response结构化出现错误。")
        logging.debug(response.text)
        logging.debug('API调用异常：{}'.format(e))
        logging.debug(f"payload is {payload}")
        response_data = {"error": "API调用异常。"}
        logging.debug("-" * 327)
    return payload, response_data


async def request_llm_async(rate_limiter, semaphore, session, max_retries, history, model='gpt-4o', n=1, temperature=1, max_tokens=4096, show_payload=False):
    """
    # 功能

    调用大模型API，获取回复。

    # 参数

    - history (list): 对话历史，格式为 [system prompt, query, response, query, ...]
        - 如果system prompt置空，则使用默认system prompt（见代码）
        - 示例: [["你是一个智能助理。", "今天天气如何？", "天气晴朗。"]]
    - model (str): 使用的模型名称，可选 ['gpt-4-turbo', 'gpt-4o']，默认为 'gpt-4o'。
    - n (int): 模型生成回复的数量，默认为 1。
    - temperature (float): 控制生成的文本多样性的值，范围在 [0, 2] 之间。值越低，结果越确定；值越高，结果越随机。
        - 过高可能导致错误，实测1.3左右就有较大概率出错了。
        - 示例: temperature=0.7
    - max_tokens (int): 模型回复的最大长度，默认为 4096。
    - show_payload (bool): 是否显示请求的payload数据，默认为False。

    # 返回值

    - response (dict): 包含模型生成的回复或错误信息的字典。

    # 示例

    >>> history = ["你是一个智能助理。", "中国的首都是哪里？"]
    >>> response = request_llm(history, model='gpt-4o', n=1, temperature=0.7)
    >>> print(response)
    {'data': {'choices': [{'content': '中国的首都是北京。'}]}, 'success': True}
    """
    if not history:
        return {'error': '传入的history为空！'}
    if not history[0]:
        history[0] = DEFAULT_SYSTEM_PROMPT

    messages = [{"role": ["assistant", "user"][i % 2], "content": message} for i, message in enumerate(history)]
    messages[0]['role'] = 'system'

    url = MODEL_URLS.get(model)
    if url is None:
        print("当前仅支持以下模型：", ", ".join(MODEL_URLS.keys()))
        raise ValueError(f"此模型尚未支持：{model}")

    if model in ['deepseek-r1', 'deepseek-r1-distill-qwen-32b'] and n != 1:
        print(f"【警告】deepseek-r1模型的n只能设置为1，当前为{n}，已自动改为1")
        n = 1

    headers = {'Content-Type': 'application/json'}
    payload = {
        "messages": messages,
        "n": n,
        "temperature": temperature,
        "max_tokens": max_tokens
    }
    if show_payload:
        pprint(payload)

    retries = 0
    while retries < max_retries:
        await rate_limiter.wait()  # 控制请求的发出速率
        try:
            async with session.post(url, json=payload, headers=headers) as response:
                return payload, await response.json()
        except Exception as e:
            print(f'chatgpt api exception: {e}')
            retries += 1
            await asyncio.sleep(1)


def llm(historys, model='gpt-4o', n=1, temperature=1, max_tokens=4096, show_payload=False, show=False, qps=0.6, log_file="llm_log.txt", use_cache=False):
    """
    # 功能

    调用大模型批量生成回复。

    # 参数

    - historys (list of list): 由对话历史组成的列表，每个对话历史的格式为 [system prompt, query, response, query, ...]
        - 不要重复使用对话历史。如果需要获得模型的多次回复，建议调整参数 n。
        - system prompt可置空，此时会自动补充默认的system prompt。
        - 可以传入单条对话历史（list）。
        - 也可以传入一个字符串，表示要问的问题。
        - 示例: [["你是一个智能助理。", "周杰伦的老婆是谁？"],["", "1+1=?"]]、["你是一个智能助理。", "中国的首都在哪里？"]或"写字楼的称呼是怎么来的？"
    - model (str): 使用的模型名称，可选 ['gpt-4-turbo', 'gpt-4o']，默认为 'gpt-4o'。
    - n (int): 模型生成回复的数量，默认为 1。
    - temperature (float): 控制生成的文本多样性的值，范围在 [0, 2] 之间。值越低，结果越确定；值越高，结果越随机。
        - 过高可能导致错误，实测1.3左右就有较大概率出错了。
        - 示例: temperature=0.7
    - max_tokens (int): 模型回复的最大长度，默认为 4096。
    - show_payload (bool): 是否显示请求的payload数据，默认为False。
    - show (bool): 是否显示query与response，默认为False。
    - qps (float): 每秒并发量，默认为1.9。
    - log_file (str): 日志文件的路径，默认为 "llm_log.txt"。
    - use_cache (bool): 是否使用cache，默认为False，使用时会在调用位置保存一个llm_cache.pkl

    # 返回值

    - n==1: responses (list), 模型生成的回复列表。
    - n>1: responses(list of list), 模型生成的回复列表，每个列表元素中包含模型的多次回答。

    # 示例

    ## n == 1

    >>> historys = [["你是一个智能助理。", "今天天气如何？"]]
    >>> responses = llm(historys, model='gpt-4o', n=1, temperature=0.5)
    >>> print(responses)
    ["天气晴朗。"]

    ## n > 1

    >>> historys = [["你是一个智能助理。", "今天天气如何？"]]
    >>> responses = llm(historys, model='gpt-4o', n=3, temperature=0.5)
    >>> print(responses)
    [["天气晴朗。", "天气还不错。", "天气挺好的。"]]

    ## 使用默认prompt

    >>> historys = [["", "今天天气如何？"], ["", "1+1="]]
    >>> responses = llm(historys)
    >>> print(responses)
    ["天气晴朗。", "2"]

    # 只有一条对话历史，只需传入一维列表即可

    >>> history = ["", "今天天气如何？"]
    >>> responses = llm(history)
    >>> print(responses)
    ["天气晴朗。"]

    # 也可以直接传入问题

    >>> response = llm("中国的首都是哪里？")
    >>> print(response)
    ["中国的首都是北京。"]
    """
    if isinstance(historys, str):
        historys = [["", historys]]
    if not isinstance(historys[0], list):
        historys = [historys]
    if n <= 0:
        raise ValueError("n必须大于0！")

    start_time = time.time()

    CACHE_FILE = 'llm_cache.pkl'
    cache = {}  # 初始化缓存
    if use_cache:  # 判断是否使用缓存
        # 加载缓存
        if os.path.exists(CACHE_FILE) and os.path.getsize(CACHE_FILE) > 0:
            with open(CACHE_FILE, 'rb') as f:
                cache = pickle.load(f)

    query_to_response = {}
    cache_lock = threading.Lock()  # 用于保障缓存的线程安全 // ChatGPT修改

    # 初始化定时调度器
    s = sched.scheduler(time.time, time.sleep)
    semaphore = threading.Semaphore(0)
    progress_bar = tqdm(total=len(historys), desc="请求进度：")
    lock = threading.Lock()

    def request_llm_with_cache(history):
        # 先检查缓存，降低锁持有时间
        history_tuple = tuple(history)
        if use_cache:
            with cache_lock:
                result = cache.get(history_tuple)
            if result:
                payload, response = result
                progress_bar.update()
                return history, (payload, response)

        # 如果缓存未命中，则执行请求
        semaphore.acquire()
        payload, response = request_llm(history, model, n, temperature, max_tokens, show_payload)

        # 结果获取成功后立即更新缓存，以最小化锁区域
        if use_cache and response.get('choices', [''])[0] != '':
            with cache_lock:
                cache[history_tuple] = (payload, response)

        progress_bar.update()
        return history, (payload, response)

    def release_semaphore(sc):
        semaphore.release()
        s.enter(1/qps, 1, release_semaphore, argument=(sc,))

    s.enter(1, 1, release_semaphore, argument=(s,))
    scheduler_thread = threading.Thread(target=s.run)
    scheduler_thread.daemon = True
    scheduler_thread.start()

    with open(log_file, 'a', encoding='utf-8') as f, ThreadPoolExecutor(max_workers=50) as executor:
        futures = {executor.submit(request_llm_with_cache, history): history for history in historys}  # ChatGPT修改
        for future in concurrent.futures.as_completed(futures):
            history = futures[future]
            try:
                history, (payload, response) = future.result()
                with lock:
                    if n == 1 or model == 'deepseek-r1':
                        query_to_response[history[-1]] = response['choices'][0]['message']['content']
                    else:
                        query_to_response[history[-1]] = [item['message']['content'] for item in response['choices']]
                    f.write(json.dumps([datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            payload, response], ensure_ascii=False) + "\n")
            except Exception as exc:
                with lock:
                    query_to_response[history[-1]] = ''
                err_msg = f'Query {history[-1]} generated an exception: {exc}\n'
                # 【TODO】临时关闭了err_msg，这里需要优化
                # print(err_msg)
                with lock:
                    f.write(json.dumps([datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            'N/A', 'N/A'], ensure_ascii=False) + "\n")

    responses = [query_to_response[history[-1]] for history in historys]

    if use_cache:  # 只有在use_cache为True时才将缓存保存至文件 // ChatGPT修改
        with open(CACHE_FILE, 'wb') as f:  # ChatGPT修改
            pickle.dump(cache, f)  # ChatGPT修改

    if show:
        for i, (history, response) in enumerate(zip(historys, responses)):
            print(f"{'*'*30} {i+1} {'*'*30}")
            print(f"【QUERY】{history[-1]}")
            if n == 1:
                print(f"【RESPONSE】{response}")
            else:
                print("【RESPONSE】")
                for j, res in enumerate(response):
                    print(f"【{j+1}】{res}")

    return responses


if __name__ == "__main__":
    history = ["你是一个智能助理。", "中国的首都是哪里？"]
    # payload, response_data = request_llm(history, model="gpt-4o", n=1, temperature=0)
    # payload, response_data = request_llm(history, model="claude-3_5-sonnet", n=1, temperature=0)
    # payload, response_data = request_llm(history, model="deepseek-v3", n=1, temperature=0)
    # payload, response_data = request_llm(history, model="deepseek-r1", n=1, temperature=0)
    payload, response_data = request_llm(history, model="deepseek-r1-distill-qwen-32b", n=1, temperature=0)
    print(json.dumps({"payload": payload, "response": response_data}, ensure_ascii=False))

# python utils/llm_utils/serverless_function.py
