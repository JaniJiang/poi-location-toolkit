import re
from utils.llm_utils.openai_style_api import OpenAIStyleAPI
# 参考Qwen-Agent框架中的提示词, https://github.com/QwenLM/Qwen-Agent

# 需要在LPAI LLM上部署qwen3模型 https://lpai-llm.lixiang.com/
API_DICT = {
    "模型名称": {
        "model": "<关联模型名>",
        "url": "<Restful api>v1/chat/completions"
    },
    "qwen-1.7b": {
        "model": "qwen__qwen3-1_7b",
        "url": "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/qwen--qwen3-1-7b-4bdf-ffcunk/v1/chat/completions"
    },
}

Agent_System_Template = """<|System|>:你是一个可以调用外部工具的助手，可以使用的工具包括：
{tools_text}
```
背景介绍:
{background}
```
如果使用工具请遵循以下格式回复：
```
Thought:思考你当前步骤需要解决什么问题，是否需要使用工具
Action:工具名称，你的工具必须从 [{tools_name_text}] 选择
ActionInput:工具输入参数
```
如果你已经知道了答案，或者你不需要工具，请遵循以下格式回复
```
Thought:给出最终答案的思考过程
FinalAnswer:最终答案
```
"""

Agent_User_Template = """
开始!<TOKENS_UNUSED_2>
<|User|>:{query}<eoh>
<|Bot|>:
"""


class Qwen_Agent:
    def __init__(self, model_name, desc_dict, background):
        self.tools_text = self.build_tool_desc(desc_dict)
        self.system_prompt = self.build_agent_system_prompt(background)
        self.model, self.url = API_DICT[model_name]["model"], API_DICT[model_name]["url"]
        self.api_obj = OpenAIStyleAPI(self.url)

    def build_tool_desc(self, desc_dict):
        '''
        构建提示词中的工具说明
        : param desc_dict: 每个工具的信息列表
        : return  提示词中的工具说明列表
        desc_dict示例:
        [
            {"tool_name": "工具名", "tool_des": "工具含义", "tool_params": {所需参数以及含义}},
        ]
        '''
        tool_desc_list = []
        for tool_data in desc_dict:
            filled_desc = {
                "type": "function",
                "function": {
                    "name": tool_data["tool_name"],
                    "description": tool_data["tool_des"],
                    "parameters": tool_data["tool_params"],
                },
            }
            tool_desc_list.append(filled_desc)
        return tool_desc_list

    def build_agent_system_prompt(self, background):
        '''
        构建完整系统提示词
        : param background
        : return  提示词中的工具说明列表
        desc_dict示例:
        [
            {"tool_name": "工具名", "tool_des": "工具含义", "tool_params": {所需参数以及含义}},
        ]
        '''
        tools_name_text = [tool_desc["function"]["name"] for tool_desc in self.tools_text]
        return Agent_System_Template.format(tools_text=self.tools_text, tools_name_text=tools_name_text, background=background)

    def process(self, query):
        """
        调用模型进行测试
        """
        prompt = [
            {
                "role": "system", "content": self.system_prompt
            },
            {
                "role": "user", "content": Agent_User_Template.format(query=query)}
        ]
        answer = self.api_obj.v1_chat_completions(self.model, prompt)
        if answer is None:
            return None
        answer_parsed = self.parse_answer(answer)
        return answer_parsed

    def parse_answer(self, model_answer):
        # 提取 Thought
        thought_match = re.search(r"Thought:\s*(.*)", model_answer)
        thought = thought_match.group(1).strip() if thought_match else None

        # 提取 Action
        action_match = re.search(r"Action:\s*(\w+)", model_answer)
        action = action_match.group(1).strip() if action_match else None

        # 提取 ActionInput
        # ActionInput 后可能为空，所以我们匹配到行尾
        action_input_match = re.search(r"ActionInput:\s*(.*)", model_answer)
        action_input = action_input_match.group(1).strip() if action_input_match else None

        # 如果 Action 和 ActionInput 未找到，尝试提取 FinalAnswer
        final_answer = None
        if action is None and action_input is None:
            final_answer_match = re.search(r"FinalAnswer:\s*(.*)", model_answer, re.DOTALL)  # re.DOTALL 允许 . 匹配换行符
            final_answer = final_answer_match.group(1).strip() if final_answer_match else None

        return {
            "thought": thought,
            "action": action,
            "action_input": action_input,
            "final_answer": final_answer
        }


# --- 使用示例 ---
if __name__ == "__main__":
    model_name = 'qwen-1.7b'
    desc_dict = [
        {"tool_name": "time_search", "tool_des": "用于查询当地的时间", "tool_params": {"location": "用户指定的地方名"}},
        {"tool_name": "wearth_search", "tool_des": "用于查询当地的天气", "tool_params": {"location": "用户指定的地方名"}}
    ]
    background = "你是一个智能助手需要根据用户给出的问题选择对应的工具帮助用户解决问题"
    obj = Qwen_Agent(model_name, desc_dict, background)
    answer = obj.process("杭州市今天的天气怎么样")
    print(answer)
    # 测试结果:{'thought': '用户询问杭州市今天的天气，需要使用天气查询工具。', 'action': 'wearth_search', 'action_input': '{"location": "杭州市"}', 'final_answer': None}
# python -m utils.llm_utils.qwen3_agent_prompt
