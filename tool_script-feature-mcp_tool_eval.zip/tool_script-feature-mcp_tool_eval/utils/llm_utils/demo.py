import json
import requests


def cua_plan():
    url = "http://172.24.169.156:8000/v1/completions"
    headers = {"Content-Type": "application/json"}
    request_dict = {
        "model": "cua-plan-v2",
        "prompt": """[unused0]system
你要进行一个语言理解任务。

# Tools

## Functions

{"name":"cu_agent_continue"}
{"name":"other"}[unused1]
[unused0]user
我要和昨天一样的[unused1]
[unused0]assistant
已为你选择好理想汽车总部门店，你要大杯中杯还是超大杯？什么温度？[unused1]
[unused0]user
大杯，冰的[unused1]
""",
        "temperature": 0.0,
        "n": 1,
    }
    response_obj = requests.post(url, headers=headers, json=request_dict, timeout=10)
    if response_obj.status_code != 200:
        return None
    response_dict = json.loads(response_obj.text)
    tool_name = response_dict.get("choices", [])[0].get("text", "")
    return tool_name


if __name__ == "__main__":
    print(cua_plan())

# python utils/llm_utils/demo.py
