import json
import requests
from retry import retry
from loguru import logger


class OpenAIStyleAPI(object):

    def __init__(self, url):
        self.url = url
        self.headers = {"Content-Type": "application/json"}
        self.timeout = 30

    @retry(tries=3, delay=1)
    def v1_chat_completions(self, model, messages, temperature=0.0, n=1, parse_answer=True):
        data = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "n": n,
        }
        response = requests.post(self.url, headers=self.headers, json=data, timeout=self.timeout)
        if response.status_code != 200:
            logger.error("[OpenAIStyleAPI] response.status_code:%s, response.reason:%s",
                         response.status_code, response.reason)
            return None
        try:
            response_json = json.loads(response.text)
            if parse_answer is True:
                answer = response_json.get("choices", [])[0].get("message", {}).get("content", "")
                return answer
            else:
                return response_json
        except Exception as e:
            logger.error("[OpenAIStyleAPI] json.loads error:%s", e)
        return None

    @retry(tries=3, delay=1)
    def v1_completions(self, model, prompt, temperature=0.0, n=1, max_tokens=500, stop="[unused1]", parse_answer=True):
        data = {
            "model": model,
            "prompt": prompt,
            "temperature": temperature,
            "n": n,
            "max_tokens": max_tokens,
            # "stop": stop,
            # "stop_token_ids": [151645, 151666],
            # "stop_token_ids": [151645],
            # "include_stop_str_in_output": True,
        }
        response = requests.post(self.url, headers=self.headers, json=data, timeout=self.timeout)
        if response.status_code != 200:
            logger.error("[OpenAIStyleAPI] response.status_code:%s, response.reason:%s",
                         response.status_code, response.reason)
            return None
        try:
            response_json = json.loads(response.text)
            if parse_answer is True:
                answer = response_json.get("choices", [])[0].get("text", "")
                return answer
            else:
                return response_json
        except Exception as e:
            logger.error("[OpenAIStyleAPI] json.loads error:%s", e)
        return None

# python -m utils.llm_utils.openai_style_api
