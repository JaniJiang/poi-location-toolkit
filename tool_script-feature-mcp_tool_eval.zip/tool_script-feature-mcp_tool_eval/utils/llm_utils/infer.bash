python -m vllm.entrypoints.openai.api_server \
    --model model_path \
    --host 0.0.0.0 \
    --port 8000 \
    --max-model-len 4096 \
    --gpu-memory-utilization 0.9 \
    --tensor-parallel-size 2 \ 
    --dtype float16 \
