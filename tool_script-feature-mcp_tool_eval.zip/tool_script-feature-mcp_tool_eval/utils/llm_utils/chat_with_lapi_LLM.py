# 本地使用LPAI平台大模型
import re
import json
import requests
from typing import Optional, Tuple, Dict, Any, Union, List


def is_valid_llm_history(input_data):
    """
    检查LLM的history是否合法
    """
    if not isinstance(input_data, list):
        return False

    if len(input_data) != 2:
        return False

    expected_roles = ["system", "user"]

    for i, item in enumerate(input_data):
        if not isinstance(item, dict):
            return False
        if item.get("role") != expected_roles[i]:
            return False
        if not isinstance(item.get("content"), str):
            return False

    return True


def chat_with_lpai_LLM_signal(instruction, model, url, temperature=1, n=1, max_tokens=1024) -> dict:
    payload = {
        "model": model,
        "temperature": temperature,
        "n": n,
        "max_tokens": max_tokens,
        "messages": [{"role": "user", "content": instruction}],
        "stream": False,
    }
    res = requests.post(url, json=payload, headers={"Content-Type": "application/json"})
    return json.loads(res.text)["choices"][0]["message"]["content"]


def chat_with_lpai_LLM_history(history, model, url, temperature=1, n=1, max_tokens=1024) -> dict:
    if not is_valid_llm_history(history):
        raise TypeError("该History不是一个合法的多轮对话信息")
    payload = {
        "model": model,
        "temperature": temperature,
        "n": n,
        "max_tokens": max_tokens,
        "messages": history,
        "stream": False
    }
    res = requests.post(url, json=payload, headers={"Content-Type": "application/json"})
    return json.loads(res.text)["choices"][0]["message"]["content"]


# def parse_json_from_think_res(text: str, key: str, index: int = 0, value=None):
#     m = re.search(r"<think>(.*?)</think>", text, re.DOTALL | re.IGNORECASE)
#     think_text = m.group(1).strip() if m else None
#     chunks = re.findall(r"\{[\s\S]*?\}", text)  # 非贪婪匹配
#     matched = []
#     for s in chunks:
#         s_clean = s.strip().rstrip('"').strip()  # 去除末尾引号
#         try:
#             obj = json.loads(s_clean)
#         except json.JSONDecodeError:
#             continue
#         if isinstance(obj, dict) and key in obj and (value is None or obj[key] == value):
#             matched.append(obj)
#     if not matched:
#         return None, think_text
#     if index == -1:
#         return matched[-1], think_text
#     return (matched[index] if 0 <= index < len(matched) else None), think_text

def parse_json_from_think_res(
    text: str,
    key: str,
    index: Optional[int] = 0,   # index=None 时返回所有匹配
    value: Any = None
) -> Tuple[Union[Dict[str, Any], List[Dict[str, Any]], None], Optional[str]]:
    """
    解析 <think> 内容和 JSON 片段。

    参数:
        text: 输入字符串
        key: 要匹配的 key
        index: 指定返回哪个匹配项
            - index = 0: 第一个
            - index = -1: 最后一个
            - index = None: 返回所有匹配项
        value: 过滤条件，只有 obj[key] == value 才算匹配

    返回:
        (匹配到的 dict 或 list[dict], think_text)
    """
    # 提取 think
    m = re.search(r"<think>(.*?)</think>", text, re.DOTALL | re.IGNORECASE)
    think_text = m.group(1).strip() if m else None

    # 找 {...} 或 [...] 块
    chunks = re.findall(r"(\{[\s\S]*?\}|\[[\s\S]*?\])", text)

    matched: List[Dict[str, Any]] = []
    for s in chunks:
        s_clean = s.strip().rstrip('"').strip()
        try:
            obj = json.loads(s_clean)
        except json.JSONDecodeError:
            continue

        if isinstance(obj, dict):
            if key in obj and (value is None or obj[key] == value):
                matched.append(obj)
        elif isinstance(obj, list):
            for d in obj:
                if isinstance(d, dict) and key in d and (value is None or d[key] == value):
                    matched.append(d)

    if not matched:
        return None, think_text

    # 返回模式
    if index is None:
        return matched, think_text  # 全部
    elif index == -1:
        return matched[-1], think_text
    elif 0 <= index < len(matched):
        return matched[index], think_text
    else:
        return None, think_text
