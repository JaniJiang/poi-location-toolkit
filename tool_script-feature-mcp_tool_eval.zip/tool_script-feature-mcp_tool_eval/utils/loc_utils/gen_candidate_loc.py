from utils.file_utils import read_json_file, write_jsonl_file


class GenCandidateLoc:

    def __init__(self):
        self.area_json_path = "data/dict/area_code_2024.json"
        self.candidate_space_path = "data/dict/candidate_loc.jsonl"
        self.province_suffix_list = ["维吾尔自治区", "回族自治区", "壮族自治区", "自治区", "省", "市",]
        self.city_suffix_list = ["朝鲜族自治州", "土家族苗族自治州", "藏族羌族自治州", "藏族自治州",
                                 "布依族苗族自治州", "南苗族侗族自治州", "壮族苗族自治州", "傣族自治州",
                                 "白族自治州", "傣族景颇族自治州", "傈僳族自治州", "回族自治州", "蒙古自治州",
                                 "柯尔克孜自治州", "哈萨克自治州", "彝族自治州",
                                 "市", "新区", "地区"]
        self.county_suffix_list = [
            "拉祜族佤族布朗族傣族自治县", "傣族拉祜族佤族自治县", "彝族哈尼族拉祜族自治县", "哈尼族彝族傣族自治县", "彝族回族苗族自治县",
            "苗族瑶族傣族自治县", "独龙族怒族自治县", "白族普米族自治县", "保安族东乡族撒拉族自治县", "苗族土家族自治县", "苗族布依族自治县",
            "苗族侗族自治县", "回族彝族自治县", "彝族傣族自治县", "傣族佤族自治县", "哈尼族彝族自治县", "傣族彝族自治县", "回族土族自治县",
            "黎族苗族自治县", "壮族瑶族自治县",
            "土家族自治县", "羌族自治县", "藏族自治县", "水族自治县", "彝族自治县", "纳西族自治县", "拉祜族自治县", "黎族自治县",
            "哈尼族自治县", "侗族自治县", "苗族自治县", "瑶族自治县", "满族自治县",  "回族自治县", "朝鲜族自治县",  "佤族自治县",
            "仫佬族自治县", "毛南族自治县", "傈僳族自治县", "裕固族自治县", "哈萨克族自治县", "哈萨克自治县", "土族自治县", "撒拉族自治县",
            "锡伯自治县", "塔吉克自治县",  "各族自治县", "畲族自治县", "达斡尔族自治旗", "达斡尔族区", "左翼蒙古族自治县", "蒙古族自治县", "蒙古自治县",
            "右翼前旗", "右翼中旗", "右翼后旗", "左翼前旗", "左翼中旗", "左翼后旗", "前旗", "中旗", "后旗", "左旗", "右旗",
            "的岛礁及其海域", "行政委员会", "高新技术产业开发区", "高新技术产业园区", "经济技术开发区", "经济开发区", "风景名胜区",
            "文化旅游创意园区", "循环化工园区", "工业园区", "管理区",
            "自治县", "市", "县", "区", "镇", "旗"
        ]

    def process(self):
        area_json_data = read_json_file(self.area_json_path)
        result_list = self.gen_candidate_space(area_json_data)
        write_jsonl_file(result_list, self.candidate_space_path)

    def gen_candidate_space(self, area_json_data):
        result_list = [
            {"country": "中国", "province": "香港", "city": "香港", "county": ""},
            {"country": "中国", "province": "澳门", "city": "澳门", "county": ""},
        ]
        # 处理province
        for province_data in area_json_data:
            if province_data["level"] == 1:
                province_name = province_data["name"]
                # 清洗province
                if len(province_name) > 2:
                    for province_suffix in self.province_suffix_list:
                        if province_name.endswith(province_suffix) is True:
                            province_name = province_name.removesuffix(province_suffix)
                            break
                # 处理city
                for city_data in province_data["children"]:
                    if city_data["level"] == 2:
                        city_name = city_data["name"]
                        # 清洗city
                        if city_name in ["市辖区", "县"]:  # 直辖市
                            city_name = province_name
                        elif city_name in ["省直辖县级行政区划", "自治区直辖县级行政区划"]:  # 直辖县
                            city_name = ""
                        if len(city_name) > 2:
                            for city_suffix in self.city_suffix_list:
                                if city_name.endswith(city_suffix) is True:
                                    city_name = city_name.removesuffix(city_suffix)
                                    break
                        # 处理county
                        tmp_county_dict = {}
                        for county_data in city_data["children"]:
                            if county_data["level"] in [3, 4]:
                                county_name = county_data["name"]
                                # 清洗county
                                if county_name in ["市辖区"]:  # 无用county
                                    continue
                                if len(county_name) > 2:
                                    for county_suffix in self.county_suffix_list:
                                        if county_name.endswith(county_suffix) is True:
                                            county_name = county_name.removesuffix(county_suffix)
                                            break
                                if len(county_name) <= 1:
                                    continue
                                if county_name in tmp_county_dict:
                                    continue
                                tmp_county_dict[county_name] = True
                                # 保存单条loc数据
                                result_list.append({"country": "中国", "province": province_name,
                                                    "city": city_name, "county": county_name})
        return result_list


if __name__ == "__main__":
    obj = GenCandidateLoc()
    obj.process()

# python -m utils.loc_utils.gen_candidate_loc
