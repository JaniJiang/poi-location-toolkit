import json
import pandas as pd
from utils.metrics_utils.http_utils import upsert_data


def main(metrics_data_path: str, week_name: str, week_num: int):
    # 读取指标文件
    metrics_df = pd.read_csv(metrics_data_path, sep="\t")
    # 格式化指标数据到接口参数
    request_data = []
    for _, row in metrics_df.iterrows():
        if row["看板使用"] != 1 or pd.isna(row[week_name]):
            continue
        request_data.append({
            "type": 1,  # 1:周 2:月
            "periodNum": week_num,  # 第几周
            "dataId": int(row["指标ID"]),  # 指标ID
            "dataValue": str(row[week_name]).rstrip("%").strip(" "),  # 指标值
        })
    print(json.dumps(request_data, ensure_ascii=False, indent=4))
    # 通过接口批量导入指标
    result = upsert_data(request_data)
    return result


if __name__ == "__main__":
    metrics_data_path = "data/cloud/metrics/metrics_data.tsv"
    num_list = [26, 27, 28, 29, 30, 31]
    for num in num_list:
        week_name = f"W{num}"
        week_num = int(f"25{num}")
        result = main(metrics_data_path, week_name, week_num)
        print(result)

# python -m utils.metrics_utils.run_metrics_upsert
