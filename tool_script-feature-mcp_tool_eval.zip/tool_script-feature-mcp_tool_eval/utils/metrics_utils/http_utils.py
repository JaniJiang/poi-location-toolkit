import json
import requests

URL = "https://platform-server.inner.chj.cloud/board/addValues"


def upsert_data(metrics_list):
    """参考：https://li.feishu.cn/docx/MPUedTVcDo5HFhxm9mHctnA2nBh"""
    payload = json.dumps(metrics_list)
    headers = {"Content-Type": "application/json"}
    response = requests.request("POST", URL, headers=headers, data=payload)
    return response


if __name__ == "__main__":
    metrics_data = [
        {
            "type": 1,  # 1:周 2:月
            "periodNum": 2516,  # 第几周
            "dataId": 1,  # 指标ID
            "dataValue": "2.07",  # 指标值
        }
    ]
    result = upsert_data(metrics_data)
    print(result)

# python -m utils.metrics_utils.http_utils
