import numpy as np
import pandas as pd


def cal_metrics(df, output_path, score_field_name, label_field_name, score_step, score_min=None, score_max=None):
    thresholds = []
    precisions = []
    recalls = []
    accs = []
    if score_min is None:
        score_min = round(df[score_field_name].min(), 6)
    if score_max is None:
        score_max = round(df[score_field_name].max(), 6)
    print(score_min, score_max)
    for threshold in np.arange(score_min, score_max, score_step):
        pred = (df[score_field_name] >= threshold).astype(int)
        tp = ((pred == 1) & (df[label_field_name] == 1)).sum()
        fp = ((pred == 1) & (df[label_field_name] == 0)).sum()
        tn = ((pred == 0) & (df[label_field_name] == 0)).sum()
        fn = ((pred == 0) & (df[label_field_name] == 1)).sum()
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0
        acc = (tp + tn) / (tp + tn + fp + fn) if (tp + tn + fp + fn) > 0 else 0.0
        thresholds.append(round(threshold, 5))
        precisions.append(round(precision, 5))
        recalls.append(round(recall, 5))
        accs.append(round(acc, 5))
    result = pd.DataFrame({"threshold": thresholds, "precision": precisions, "recall": recalls, "acc": accs})
    print("Best Thres accroding to acc:")
    print(result.loc[result['acc'].idxmax()])
    result.to_csv(f"{output_path}.{score_field_name}.tsv", sep="\t", index=False, header=True)
