import os
import csv
import json
import pandas as pd


def csv2jsonl(csv_path, jsonl_path):
    """
    Convert a CSV file to JSONL (JSON Lines) format.
    Parameters:
    csv_path (str): Path to the input CSV file.
    jsonl_path (str): Path to the output JSONL file.
    """
    try:
        # Open the CSV file
        with open(csv_path, "r", encoding="utf-8") as csv_file:
            # Create a CSV reader
            csv_reader = csv.DictReader(csv_file)
            # Open the output JSONL file
            with open(jsonl_path, "w", encoding="utf-8") as jsonl_file:
                # Convert each row to JSON and write to the output file
                for row in csv_reader:
                    # Convert row to JSON string and write to file with newline
                    jsonl_file.write(json.dumps(row, ensure_ascii=False) + "\n")
        print(f"Successfully converted {csv_path} to {jsonl_path}")
    except Exception as e:
        print(f"Error converting CSV to JSONL: {e}")


def jsonl2tsv(jsonl_path, tsv_path, del_field_list=[]):
    """
    Convert a JSONL (JSON Lines) file to TSV (Tab-Separated Values) format,
    preserving the original field order from the first JSON record.
    Parameters:
    jsonl_path (str): Path to the input JSONL file.
    tsv_path (str): Path to the output TSV file.
    """
    try:
        with open(jsonl_path, "r", encoding="utf-8") as jsonl_file, \
                open(tsv_path, "w", encoding="utf-8", newline="") as tsv_file:
            # Initialize variables
            writer = None
            fieldnames = None
            for line in jsonl_file:
                record = json.loads(line.strip())
                # For the first record, determine field order and initialize writer
                if fieldnames is None:
                    fieldnames = list(record.keys())
                    if del_field_list:
                        fieldnames = [fieldname for fieldname in fieldnames if fieldname not in del_field_list]
                    writer = csv.DictWriter(tsv_file, fieldnames=fieldnames, delimiter="\t", extrasaction="ignore")
                    writer.writeheader()
                # Write the record
                if del_field_list:
                    record = {k: v for k, v in record.items() if k not in del_field_list}
                writer.writerow(record)
        print(f"Successfully converted {jsonl_path} to {tsv_path}")
    except Exception as e:
        print(f"Error converting JSONL to TSV: {e}")


def tsv2jsonl(tsv_path):
    jsonl_path = os.path.splitext(tsv_path)[0] + '.jsonl'

    with open(tsv_path, 'r', encoding='utf-8') as tsv_file, \
            open(jsonl_path, 'w', encoding='utf-8') as jsonl_file:

        reader = csv.DictReader(tsv_file, delimiter='\t')

        for row in reader:
            json_line = json.dumps(row, ensure_ascii=False)
            jsonl_file.write(json_line + '\n')

    print(f'Converted {tsv_path} to {jsonl_path}')


def format_tsv_json(input_path, output_path):
    df = pd.read_csv(input_path, sep="\t")
    df["参数"] = df["参数"].apply(lambda x:
                              json.dumps(json.loads(x), indent=4, ensure_ascii=False)
                              if isinstance(x, str) else x)
    df.to_csv(output_path, sep="\t")


def load_any_to_dataframe(file_path: str) -> pd.DataFrame:
    """
    Load various file types (csv, tsv, jsonl, json) into a pandas DataFrame.

    Parameters:
        file_path (str): Path to the input file.

    Returns:
        pd.DataFrame: DataFrame containing the loaded data.
    """
    file_path_lower = file_path.lower()

    try:
        if file_path_lower.endswith(".csv"):
            df = pd.read_csv(file_path)

        elif file_path_lower.endswith(".tsv"):
            df = pd.read_csv(file_path, sep="\t", dtype=str)

        elif file_path_lower.endswith(".jsonl"):
            df = pd.read_json(file_path, lines=True)

        elif file_path_lower.endswith(".json"):
            # Try to load as JSON array or dict
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            # If the JSON is a dict, try to normalize it
            if isinstance(data, dict):
                df = pd.json_normalize(data)
            else:
                df = pd.DataFrame(data)
        else:
            raise ValueError(f"Unsupported file format: {file_path}")
    except Exception as e:
        raise RuntimeError(f"Error loading file {file_path}: {e}")

    return df


def txt2list(file_path, is_set=False):
    data_set = []
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            data_set.append(line.strip())
    if is_set:
        return set(data_set)
    else:
        return data_set


if __name__ == "__main__":
    # csv2jsonl
    # data_dir = "/mnt/pfs-guan-ssai/nlu/zhaojiufeng/media_bot_log/data"
    # csv2jsonl(f"{data_dir}/result.csv", f"{data_dir}/result.jsonl")

    # jsonl2tsv
    # data_dir = "data/cloud/search/rag/log_analyse/v2/2025-03-17_to_2025-03-23"
    # del_field_list = ["knowledge_search_result", "media_search_result", "time_space_modify_response"]
    # jsonl2tsv(f"{data_dir}/step2_label_search_result.jsonl",
    #           f"{data_dir}/step2_label_search_result.tsv", del_field_list)

    # format_tsv_json
    data_dir = "data/cloud/cua/plan/sample/eval"
    format_tsv_json(f"{data_dir}/dev_hard.tsv", f"{data_dir}/dev_hard.format.tsv")

    # python utils/data_utils/data_trans.py
