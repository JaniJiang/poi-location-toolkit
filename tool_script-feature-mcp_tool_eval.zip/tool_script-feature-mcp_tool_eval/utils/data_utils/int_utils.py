def num_to_chinese(num):
    """将数字转换为汉字表示"""
    chinese_digits = ["零", "一", "二", "三", "四", "五", "六", "七", "八", "九"]
    units = ["", "十", "百", "千", "万", "十", "百", "千", "亿"]
    if num == 0:
        return chinese_digits[0]
    result = ""
    i = 0
    while num > 0:
        digit = num % 10
        # 处理零的情况
        if digit == 0:
            if result and result[0] != chinese_digits[0]:
                result = chinese_digits[0] + result
        else:
            result = chinese_digits[digit] + units[i] + result
        i += 1
        num //= 10
    # 处理一些特殊情况，如"一十"应简化为"十"
    if result.startswith("一十"):
        result = result[1:]
    # 处理连续的零
    while "零零" in result:
        result = result.replace("零零", "零")
    # 清除尾部的零
    if result.endswith("零"):
        result = result[:-1]
    return result


if __name__ == "__main__":
    test_numbers = [6, 15, 20, 103]
    for num in test_numbers:
        print(f"{num} -> {num_to_chinese(num)}")
