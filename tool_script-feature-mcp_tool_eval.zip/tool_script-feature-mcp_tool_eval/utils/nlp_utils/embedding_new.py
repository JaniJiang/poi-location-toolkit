import json
import requests
import numpy as np
from tqdm import tqdm

URL = "http://bge-m3-ssai-http.ssai-apis-staging.chj.cloud:80/v2/models/bge-m3/infer"


def get_embedding(text_list):
    payload = json.dumps({
        "id": "123",
        "inputs": [
            {
                "name": "query",
                "data": text_list,
                "shape": [len(text_list), 1],
                "datatype": "BYTES"
            }
        ],
        "outputs": [{"name": "low_vecs"}]  # dense_vecs | low_vecs
    })
    headers = {"Content-Type": "application/json"}
    response = requests.request("POST", URL, headers=headers, data=payload)
    try:
        embedding_result = json.loads(response.text)["outputs"][0]
    except Exception as e:
        embedding_result = None
        print(f"get_embedding failed: {e}")
    return embedding_result


def get_one_batch_embedding(text_list):
    embedding_result = get_embedding(text_list)
    data = embedding_result["data"]
    num_rows, num_columns = embedding_result["shape"]
    if len(data) != num_rows * num_columns:
        raise ValueError("数据长度与目标形状不一致。")
    embedding_list = []
    for i in range(num_rows):
        row = data[i * num_columns: (i + 1) * num_columns]
        embedding_list.append(row)
    return embedding_list


def get_batch_embedding(text_list, batch_size=2):
    embedding_list = []
    for i in tqdm(range(0, len(text_list), batch_size), desc="get_batch_embedding"):
        batch_text_list = text_list[i: (i + batch_size)]
        batch_embedding_list = get_one_batch_embedding(batch_text_list)
        embedding_list.extend(batch_embedding_list)
    return embedding_list


def semantic_score(text_list):
    # 获取向量
    embedding_list = get_batch_embedding(text_list)
    # 计算余弦相似度
    first_embedding = embedding_list[0]
    cosine_score_list = []
    for other_embedding in embedding_list[1:]:
        cosine_score = cosine_similarity(first_embedding, other_embedding)
        cosine_score_list.append(float(cosine_score))
    return cosine_score_list


def cosine_similarity(vec1, vec2):
    dot_product = np.dot(vec1, vec2)
    norm_vec1 = np.linalg.norm(vec1)
    norm_vec2 = np.linalg.norm(vec2)
    return dot_product / (norm_vec1 * norm_vec2)


if __name__ == "__main__":
    # text_list = ["上海安亭净月汇店", "上海安亭隽悦荟店"]
    # text_list = ["佛山市职业技术学院", "佛山职业技术学院店"]
    # text_list = ["老老钢厂店", "老钢厂店"]
    # text_list = ["菁蓉汇西门店", "箐蓉汇西门店"]
    # text_list = ["中国人寿大厦B1层", "中国人寿大厦写字楼店"]
    # text_list = ["徐康商业广场店", "徐矿商业广场店"]
    # text_list = ["厦门日报新闻大厦", "厦门日报社新闻大厦店", "厦门日报社新闻大厦"]
    # text_list = ["菁蓉汇西门店", "箐蓉汇西门店"]

    # print(json.dumps(get_batch_embedding(text_list,  batch_size=1), ensure_ascii=False))
    # print(json.dumps(get_one_batch_embedding(text_list), ensure_ascii=False))

    # cosine_score_list = semantic_score(text_list)
    # print(text_list, "\n", cosine_score_list)

    # 计算文件内容的语义相似度
    from tqdm import tqdm
    from utils.file_utils import read_text_split_file
    query_item_list = read_text_split_file("output/query_demo.tsv")
    with open("output/query_demo_result.tsv", "w") as f:
        for query_item in tqdm(query_item_list, total=len(query_item_list)):
            cosine_score_list = semantic_score([query_item[0], query_item[1]])
            f.write("\t".join(query_item + [str(cosine_score_list[0])]) + "\n")

# python -m utils.nlp_utils.embedding_new
