from modelscope import snapshot_download
from sentence_transformers import SentenceTransformer
from optimum.onnxruntime import ORTModelForFeatureExtraction
from transformers import AutoTokenizer
import os
import torch
import random
import numpy as np

def load_model_to_local(gpu, use_onnx=True):
    MODEL_NAME = "BAAI/bge-m3"
    LOCAL_MODEL_DIR = 'data/rep/beg-m3'

    # 下载bge-m3模型
    if not os.path.exists(LOCAL_MODEL_DIR):
        os.makedirs(LOCAL_MODEL_DIR, exist_ok=True)
        snapshot_download(
            repo_id=MODEL_NAME,
            local_dir=LOCAL_MODEL_DIR,
            local_dir_use_symlinks=False
        )
    
    # 加载模型（根据是否使用ONNX选择加载方式）
    if use_onnx:
        # 使用ONNX Runtime加速
        model = ORTModelForFeatureExtraction.from_pretrained(f"{LOCAL_MODEL_DIR}/onnx")
        tokenizer = AutoTokenizer.from_pretrained(f"{LOCAL_MODEL_DIR}/onnx")

        return tokenizer, model
    else:

        # device = get_device()
        # 原始PyTorch版本
        model = SentenceTransformer(LOCAL_MODEL_DIR, device=f"cuda:{gpu}")
        # 原始版本编码
        return model
    
def get_device():
    num_gpus = torch.cuda.device_count()
    
    if num_gpus > 0:
        # 可用的 GPU 列表
        available_gpus = []
        
        for i in range(num_gpus):
            memory_allocated = torch.cuda.memory_allocated(i)
            memory_total = torch.cuda.get_device_properties(i).total_memory

            # 检查 GPU 的负载情况（例如：未满载）
            if memory_allocated < memory_total * 0.9:  # 使用 <90% 作为条件
                available_gpus.append(i)

        if available_gpus:
            selected_gpu = random.choice(available_gpus)  # 随机选择一个可用的 GPU
            return torch.device(f"cuda:{selected_gpu}")
    
    # 如果没有可用的 GPU，则返回 cpu
    return torch.device("cpu")

def get_embedding_local(text_list, term_list=[]):
    MODEL_NAME = "BAAI/bge-m3"
    LOCAL_MODEL_DIR = 'data/rep/beg-m3'
    USE_ONNX = True

    # 下载bge-m3模型
    if not os.path.exists(LOCAL_MODEL_DIR):
        os.makedirs(LOCAL_MODEL_DIR, exist_ok=True)
        snapshot_download(
            repo_id=MODEL_NAME,
            local_dir=LOCAL_MODEL_DIR,
            local_dir_use_symlinks=False
        )
    
    # 加载模型（根据是否使用ONNX选择加载方式）
    if USE_ONNX:
        # 使用ONNX Runtime加速
        model = ORTModelForFeatureExtraction.from_pretrained(f"{LOCAL_MODEL_DIR}/onnx")
        tokenizer = AutoTokenizer.from_pretrained(f"{LOCAL_MODEL_DIR}/onnx")

        # ONNX版本编码
        inputs = tokenizer(text_list, padding=True, truncation=True, return_tensors="pt")
        outputs = model(**inputs)
        embeddings = outputs.last_hidden_state[:, 0].numpy()
        # 归一化处理（BGE模型建议的后续处理）
        embeddings = embeddings / np.linalg.norm(embeddings, axis=1, keepdims=True)
    else:
        # 原始PyTorch版本
        model = SentenceTransformer(LOCAL_MODEL_DIR)
        # 原始版本编码
        embeddings = model.encode(text_list, normalize_embeddings=True)
    
    return embeddings