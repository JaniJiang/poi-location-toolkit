from tqdm import tqdm
from utils.file_utils import read_text_split_file
from utils.nlp_utils.embedding_client import EmbeddingClient


def main():
    input_path = "output/text_pair.txt"
    output_path = "output/text_pair.txt.out"
    input_list = read_text_split_file(input_path)
    with open(output_path, "w") as f_out:
        for item in tqdm(input_list, total=len(input_list)):
            if len(item) != 2:
                continue
            text1 = item[0]
            text2 = item[1]
            request_info = {
                "sentences": [text1, text2],
                "need_normalize": True,
                "need_score": True,
                "need_sort": True,
                "model_type": "bge-m3"
            }
            obj = EmbeddingClient()
            result = obj.process(request_info)
            cosine_score = result[0]["cosine_score"]
            f_out.write("\t".join([text1, text2, str(round(cosine_score, 3))]) + "\n")


if __name__ == "__main__":
    main()

# python -m utils.nlp_utils.text_similarity
