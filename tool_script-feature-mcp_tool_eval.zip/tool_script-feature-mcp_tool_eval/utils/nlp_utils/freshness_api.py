import json
import requests

url = "http://ks-engine-server-feishu.ssai-apis-staging.chj.cloud:80/cloud/inner/nlp/kg/knowledge-search-engine/freshness"
headers = {"Content-Type": "application/json"}
metadata = {
    "request_info": {
        "msg_id": "ssss"
    },
    "vehicle_info": {
        "vin": "1c4dd333c1f111111"
    },
    "app_info": {
        "category": "test",
        "id": "local-test",
        "version": "local-version"
    }
}


def request_freshness(query):
    input_dict = {
        "metadata": metadata,
        "originQuery": "",
        "modelQuery": query
    }
    response = requests.post(url, data=json.dumps(input_dict), headers=headers)
    result = json.loads(response.text)
    return result


def time_intent_granularity(pred_score):
    label_id = -1
    if pred_score >= 0 and pred_score <= 0.2:
        label_id = 0
    elif pred_score > 0.2 and pred_score <= 0.4:
        label_id = 1
    elif pred_score > 0.4 and pred_score <= 0.6:
        label_id = 2
    elif pred_score > 0.6 and pred_score <= 0.8:
        label_id = 3
    elif pred_score > 0.8 and pred_score <= 1:
        label_id = 4
    label_id2granularity = {-1: "无", 0: "无", 1: "多年", 2: "年份", 3: "月份", 4: "日期"}
    intent = 1 if label_id >= 1 else 0
    granularity = label_id2granularity[label_id]
    return intent, granularity


if __name__ == "__main__":
    query = "比亚迪汉售价"
    result = request_freshness(query)
    pred_score = result.get("general_timeliness_probability_score", -1)
    intent, granularity = time_intent_granularity(pred_score)
    print([query, intent, granularity, pred_score])

# python -m utils.nlp_utils.freshness_api
