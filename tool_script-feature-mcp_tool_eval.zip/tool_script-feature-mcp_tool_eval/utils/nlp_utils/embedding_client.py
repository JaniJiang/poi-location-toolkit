import requests
from loguru import logger


class EmbeddingClient(object):

    def __init__(self):
        self.url = "https://lpai-inference-guan.inner.chj.cloud/inference/ss-sai/embedding-service/v1/embeddings"
        self.timeout = 5

    def process(self, request_info: dict) -> list:
        try:
            headers = {"Content-Type": "application/json"}
            response = requests.post(self.url, headers=headers, json=request_info, timeout=self.timeout)
            response.raise_for_status()
            response_json = response.json()
            if response_json.get("code", -1) == 0:
                return response_json.get("data", [])
            else:
                logger.warning("[EmbeddingClient] Process failed, code: {}, msg: {}",
                               response_json.get("code"), response_json.get("msg"))
                return []
        except requests.RequestException as e:
            logger.warning("[EmbeddingClient] Request exception: {}", e)
            return []


if __name__ == "__main__":
    request_info = {
        "sentences": ["酒仙桥路二号店", "酒仙桥路2号店", "酒仙桥路三号店", "酒仙桥路3号店", "酒仙桥路几号店"],
        "need_normalize": True,
        "need_score": True,
        "need_sort": True,
        "model_type": "bge-m3"
    }
    obj = EmbeddingClient()
    result = obj.process(request_info)
    import json
    print(json.dumps(result, ensure_ascii=False, indent=4))

# python -m utils.nlp_utils.embedding_client
