import json
import requests
import numpy as np
from tqdm import tqdm
from utils.nlp_utils.embedding_local import get_embedding_local

URL = "http://api-server-mindgpt-open.ssai-apis-staging.chj.cloud/open/v1/embeddings"


def get_embedding(text_list, term_list=[]):
    payload = json.dumps({
        "input": text_list,
        "term": term_list,
        "model": "bge-m3"  # bge-base-zh-v1.5-m3-b | bge-m3
    })
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE3MjE3MTcyNTMsImlzcyI6Im1pbmRncHQuY2hlaGVqaWEuY29tIiwianRpIjoic2VjcmV0X2tleSIsIm5iZiI6MTcyMTcxNzI1Mywic3ViIjoibGl1eWluZzEzIn0.S8Y88-vDJGBwI9lEQLK1CSsTI6dQn-A1zG8kqbeatxI",
    }
    response = requests.request("POST", URL, headers=headers, data=payload)
    try:
        embedding_result = json.loads(response.text)["data"]
    except Exception as e:
        embedding_result = None
        print(f"error: {text_list}")
    return embedding_result


def get_one_batch_embedding(text_list, dim=768, local_model=False):
    if local_model:
        embedding_result = get_embedding_local(text_list)
    else:
        embedding_result = get_embedding(text_list)
    embedding_field = "embedding" if dim == 768 else "low_embedding"
    embedding_list = [x[embedding_field] for x in embedding_result]
    return embedding_list


def get_batch_embedding(text_list, dim=768, batch_size=2, local_model=False):
    embedding_list = []
    for i in tqdm(range(0, len(text_list), batch_size), desc="get_batch_embedding"):
        batch_text_list = text_list[i: (i + batch_size)]
        batch_embedding_list = get_one_batch_embedding(batch_text_list, dim, local_model)
        embedding_list.extend(batch_embedding_list)
    return embedding_list


def semantic_score(text_list, dim=768):
    # 获取向量
    embedding_list = get_batch_embedding(text_list, dim)
    # 计算余弦相似度
    first_embedding = embedding_list[0]
    cosine_score_list = []
    for other_embedding in embedding_list[1:]:
        cosine_score = cosine_similarity(first_embedding, other_embedding)
        cosine_score_list.append(float(cosine_score))
    return cosine_score_list


def cosine_similarity(vec1, vec2):
    dot_product = np.dot(vec1, vec2)
    norm_vec1 = np.linalg.norm(vec1)
    norm_vec2 = np.linalg.norm(vec2)
    return dot_product / (norm_vec1 * norm_vec2)


if __name__ == "__main__":
    # text_list = ["日照香炉生紫烟"]
    # term_list = ["香炉|紫烟"]
    # embedding_list = get_embedding(text_list, term_list)
    # print(json.dumps(embedding_list, ensure_ascii=False))

    text_list = ["冬季库尔德宁（早知道）"]
    # print(json.dumps(get_embedding(text_list), ensure_ascii=False))
    print(json.dumps(get_batch_embedding(text_list, dim=128, batch_size=1), ensure_ascii=False))
    print(json.dumps(get_one_batch_embedding(text_list, dim=128), ensure_ascii=False))

    # text_list = ["特朗普能赢吗"]
    # print(json.dumps(get_batch_embedding(text_list, dim=128), ensure_ascii=False))

    # text_list = ["美国总统大选", "美国总统大选", "美国大选", "美国总统选举", "美国的总统的大选"]
    # text_list = ["上一届奥运会在哪个城市举办的", "奥运会举办城市", "奥运会举办国家"]
    # text_list = ["上一届奥运会在哪个国家举办的", "奥运会举办国家", "奥运会举办城市"]
    # text_list = ["上一届世界杯的冠军是谁", "世界杯冠军", "欧洲杯冠军"]
    # text_list = ["美国大选 特朗普能赢吗", "美国大选特朗普能赢吗", "美国大选特朗普能不能赢"]
    # text_list = ["今天的黄金价格", "世界杯结果预测"]
    # text_list = ["目前中国有多少家证券公司", "奥运运动员数量"]
    # text_list = ["上一次世界杯是在哪儿办的", "国际足联世界杯举办地点", "世界杯举办地点"]
    # cosine_score_list = semantic_score(text_list, dim=128)
    # print(text_list, "\n", cosine_score_list)

    # # 计算文件内容的语义相似度
    # from tqdm import tqdm
    # from utils.file_utils import read_text_split_file
    # query_item_list = read_text_split_file("output/query_item.txt")
    # with open("output/result_semantic_score.txt", "w") as f:
    #     for query_item in tqdm(query_item_list, total=len(query_item_list)):
    #         cosine_score_list = semantic_score(query_item, dim=128)
    #         f.write("\t".join(query_item + [str(cosine_score_list[0])]) + "\n")

# python -m utils.nlp_utils.embedding
