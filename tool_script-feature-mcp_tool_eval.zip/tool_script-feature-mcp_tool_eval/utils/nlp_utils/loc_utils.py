import re


def normalize_location(name):
    if len(name) <= 2:
        # 如果地名只有两个字，则直接返回，不进行处理
        return name
    # 定义需要去除的后缀列表
    suffixes = ["省", "市", "区", "县", "乡", "镇",
                "自治区", "壮族自治区", "回族自治区", "维吾尔自治区", "维吾尔族自治区",
                "特别行政区", "行政区", "特区", "自治州", "旗", "自治旗"]
    # 创建一个正则表达式，匹配上述后缀
    suffix_pattern = "|".join(suffixes)
    pattern = re.compile(f"({suffix_pattern})$")
    # 使用正则表达式替换掉后缀
    normalized_name = re.sub(pattern, "", name)
    return normalized_name


def location_match_v1(dict1, dict2):
    # 定义地域层次结构
    loc_hierarchy = ["LOC_Specific", "LOC_Town", "LOC_County", "LOC_City", "LOC_Province", "LOC_Country"]
    # 如果任一字典为空，认为匹配
    if len(dict1) == 0 or len(dict2) == 0:
        return 1
    # 从最低层级开始匹配
    for loc_type in loc_hierarchy:
        if loc_type in dict1 or loc_type in dict2:
            # 如果当前层级在两个字典中都存在
            if loc_type in dict1 and loc_type in dict2:
                # 检查当前层级地域是否为子集关系
                if not set(dict1[loc_type]).issubset(set(dict2[loc_type])):
                    return 0
            # 如果当前层级只存在于一个字典中，那么不匹配
            else:
                return 0
            # 如果当前层级匹配，不需要再向上检查
            break
    # 所有实体类型都检查通过
    return 1


def location_match_v2(dict1, dict2):
    # 定义地域层次结构，包括特定地域
    loc_hierarchy = ["LOC_Specific", "LOC_Town", "LOC_County", "LOC_City", "LOC_Province", "LOC_Country"]
    # 如果任一字典为空，认为匹配
    if len(dict1) == 0 or len(dict2) == 0:
        return 1
    # 遍历所有地域实体类型
    for loc_type in loc_hierarchy:
        # 检查是否存在于两个字典中
        entities_set1 = set(dict1.get(loc_type, []))
        entities_set2 = set(dict2.get(loc_type, []))
        # 如果两个集合的交集非空，则表示至少有一个地点匹配
        if entities_set1.intersection(entities_set2):
            return 1
    # 如果没有找到任何匹配的实体类型
    return 0


if __name__ == "__main__":
    locations = ["四川省", "成都市", "武侯区", "新疆维吾尔族自治区", "澳门特别行政区", "西藏自治区", "香港特区"]
    normalized_locations = [normalize_location(loc) for loc in locations]
    print(normalized_locations)
