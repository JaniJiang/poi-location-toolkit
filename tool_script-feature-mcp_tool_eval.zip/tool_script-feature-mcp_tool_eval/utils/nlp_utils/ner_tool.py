import json
import requests
from utils.nlp_utils.loc_utils import normalize_location

URL = "http://nlu-lids-server-50-inference.ssai-apis-staging.chj.cloud/cloud/inner/nlp/lids/nlu_engine/parse_v2"


def request_ner(query, url=URL, need_parse=True, need_group=True):
    payload = {
        "sessionContexts": [],
        "sessionContextsV2": [],
        "staticsCarData": {},
        "semantictaggerOnly": True,
        "input": {"text": query},
    }
    headers = {"Content-Type": "application/json"}
    try:
        response = requests.post(url, json=payload, headers=headers)
        ner_result = response.json()
        # print(json.dumps(ner_result, ensure_ascii=False, indent=4))
        if need_parse is False:
            return ner_result
        ner_model_result, ner_rule_result = parse_ner_result(ner_result)
        if need_group is False:
            return ner_model_result, ner_rule_result
        model_ori_result, model_norm_result, rule_result = group_ner_result(ner_model_result, ner_rule_result)
        return model_ori_result, model_norm_result, rule_result
    except Exception as e:
        print("request_ner failed:", e)
        return None


def parse_ner_result(ner_result):
    ner_model_parsed_result = []
    ner_rule_parsed_result = []
    for item in ner_result["semantic_tags"]:
        for item2 in item["tags"]:
            if item2["source"] == "NER_MODEL":
                del item2["source"]
                ner_model_parsed_result.append(item2)
            elif item2["source"] == "RULE":
                if item2.get("prob", 0) != 1 or len(item2["norm"]) <= 1:
                    continue
                del item2["source"]
                ner_rule_parsed_result.append(item2)
    return ner_model_parsed_result, ner_rule_parsed_result


def group_ner_result(ner_model_result, ner_rule_result):
    if len(ner_model_result) == 0 and len(ner_rule_result) == 0:
        return {}, {}, {}
    # 按照槽位分组模型结果
    model_ori_result = {}
    model_norm_result = {}
    for ner_item in ner_model_result:
        tag = ner_item["tag"]
        # if tag.startswith("LOC_") is False and tag not in ["PER"]:
        if tag.startswith("LOC_") is False:
            continue
        # 原始结果
        ori_value = ner_item["norm"]
        if tag not in model_ori_result:
            model_ori_result[tag] = []
        if ori_value not in model_ori_result[tag]:
            model_ori_result[tag].append(ori_value)
        # 归一化结果(NER接口已支持归一化)
        # norm_value = normalize_location(ori_value)
        norm_value = ori_value
        if len(norm_value) <= 1:
            continue
        if tag not in model_norm_result:
            model_norm_result[tag] = []
        if norm_value not in model_norm_result[tag]:
            model_norm_result[tag].append(norm_value)
    # 按照槽位分组规则结果
    rule_result = {}
    for ner_item in ner_rule_result:
        tag = ner_item["tag"]
        if tag not in ["sys.nation", "sys.province", "sys.city", "sys.district"]:
            continue
        ori_value = ner_item["norm"]
        if tag not in rule_result:
            rule_result[tag] = []
        if ori_value not in rule_result[tag]:
            rule_result[tag].append(ori_value)
    for tag, value_list in rule_result.items():
        rule_result[tag] = retain_shorter_names(value_list)
    return model_ori_result, model_norm_result, rule_result


def retain_shorter_names(locations):
    # 首先对地名列表按照字符串长度进行排序，这样较短的地名会在前面
    locations = sorted(locations, key=len)
    # 结果列表，存放保留下来的地名
    result = []
    # 遍历排序后的地名列表
    for location in locations:
        # 如果结果列表中的任何地名都不是当前地名的前缀，则保留当前地名
        if not any(location.startswith(res_loc) for res_loc in result):
            result.append(location)
    return result


if __name__ == "__main__":
    # query = "朝阳的美食小吃"
    # print(json.dumps(request_ner(query, need_parse=False, need_group=False), ensure_ascii=False), "\n")
    # print(json.dumps(request_ner(query, need_parse=True, need_group=False), ensure_ascii=False), "\n")
    # print(json.dumps(request_ner(query, need_parse=True, need_group=True), ensure_ascii=False), "\n")

    from tqdm import tqdm
    from utils.file_utils import read_text_file
    query_list = read_text_file("output/query.txt")
    with open("output/result_ner.txt", "w") as f:
        for query in tqdm(query_list, total=len(query_list)):
            model_result, rule_result = request_ner(query, need_parse=True, need_group=False)
            f.write("\t".join([str(x) for x in [
                query,
                json.dumps(model_result, ensure_ascii=False),
                # json.dumps(rule_result, ensure_ascii=False),
            ]]) + "\n")

# python -m utils.nlp_utils.ner_tool
